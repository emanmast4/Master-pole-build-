# Master Metals — Unnecessary-Code Audit

Date: 2026-10-23

## Scope and confidence

This is a static source/dependency review of the provided React/Vite project. It checks the local import graph and searches for package references. It is **not** a successful build, a runtime test, or a guarantee that all code is unnecessary. Dependencies can be used by build scripts or future features, and apparently unused UI may be intentionally retained.

## Findings

### Strong cleanup candidates

1. `src/components/DimensionsEditModal.tsx` — no import or reference found from the app's `src/main.tsx` reachable import graph. It appears unused in the current app bundle.
2. `src/components/WireframeCubeIcon.tsx` — no import or reference found from the reachable app import graph. It appears unused in the current app bundle.
3. `@google/genai` — no direct source import or reference found in `src/` or build configuration. If no planned AI feature needs it, remove the dependency.
4. `dotenv` — no direct use found in the app source or Vite config. Vite already loads `.env` files for its normal configuration behavior, so this dependency appears unnecessary unless another script uses it.
5. `express` and `@types/express` — no direct use found in the app source or Vite config. They appear unnecessary for this client-side Vite app unless there is a separate server script not included in the project.
6. `motion` — no direct source import found. It appears unnecessary unless imported by code outside `src/` or used by a future feature.
7. `autoprefixer` — no direct import found. The project uses Tailwind's Vite plugin; verify the CSS build before removing this dependency.

### Keep for now

- `@capacitor/core`, `@capacitor/android`, and `@capacitor/cli`: needed for the intended Android packaging workflow, even though app source files do not import them directly yet.
- `three`: directly imported by 3D building components.
- `lucide-react`: directly used by many UI components.
- React, Vite, the React plugin, Tailwind, and TypeScript-related packages: part of the app/build setup.

## What I did not change

I did not delete files or dependencies based only on static search. Before removing candidates, run the project build and tests, inspect all scripts and any planned features, then remove one candidate at a time and rebuild. The current environment has no local `node_modules`, so I could not complete a dependency-backed TypeScript/build check in this audit.

## Recommended next cleanup pass

1. Confirm the two unreferenced components are not intended for a future feature.
2. Inspect all npm scripts and the full repository for server scripts before removing `express`/`dotenv`/`@google/genai`/`motion`.
3. Remove confirmed-unused dependencies and regenerate the lockfile using the project's chosen package manager.
4. Run TypeScript checks, production build, and smoke tests for quote/BOM, saved projects, export/restore, and 3D view.
