# Stability fixes applied

- Consolidated theme persistence on `master_metals_app_settings`; theme context no longer independently toggles the document class.
- Guarded theme context storage access and unsupported `matchMedia` environments.
- Removed prefilled personal name, address, and phone data from exported quotes to prevent accidental misaddressed quotes.
- Reduced the Three.js pixel-ratio cap for lower GPU/memory pressure on high-DPI devices.
- Paused the 3D animation loop when the document is backgrounded or the canvas is outside the viewport.
- Disposed scene-owned geometries, materials, material textures, environment texture, renderer lists, and WebGL context on unmount.
- Versioned the service-worker cache and made optional shell assets non-fatal during installation.
- Changed navigation requests to network-first with a cached offline fallback, reducing stale-app deployments while retaining offline reload support.

## Validation still required

Run `npm install` (or `bun install`), `npm run lint`, and `npm run build` in a network-enabled environment. Then test online first launch, offline reload after a successful online visit, quote printing, theme persistence, and repeated open/close of the 3D view on mobile. This archive was not validated on a physical device.
