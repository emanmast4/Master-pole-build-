const CACHE_NAME = 'master-metals-offline-v2';
const APP_SHELL = ['/', '/index.html', '/manifest.webmanifest'];

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    // The deployed root is essential; optional aliases should not fail the install.
    try { await cache.add('/'); } catch { /* offline shell will be retried on a later install */ }
    await Promise.all(APP_SHELL.filter((url) => url !== '/').map(async (url) => {
      try { await cache.add(url); } catch { /* optional alias/manifest */ }
    }));
    const response = await cache.match('/');
    if (response) {
      const html = await response.text();
      const assets = [...html.matchAll(/(?:src|href)="([^\"]+)"/g)]
        .map((match) => match[1])
        .filter((url) => url.startsWith('/') && !url.startsWith('//'));
      await Promise.all(assets.map(async (url) => {
        try { await cache.add(url); } catch { /* optional asset; runtime fetch can retry */ }
      }));
    }
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((key) => key.startsWith('master-metals-offline-') && key !== CACHE_NAME).map((key) => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;

  // Keep navigation fresh when online, but serve the cached app shell offline.
  if (request.mode === 'navigate') {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE_NAME);
      try {
        const response = await fetch(request);
        if (response.ok) event.waitUntil(cache.put('/index.html', response.clone()).catch(() => {}));
        return response;
      } catch {
        return (await cache.match('/index.html')) || (await cache.match('/')) || Response.error();
      }
    })());
    return;
  }

  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    const cached = await cache.match(request);
    if (cached) return cached;
    const response = await fetch(request);
    if (response.ok && response.type === 'basic') {
      event.waitUntil(cache.put(request, response.clone()).catch(() => {}));
    }
    return response;
  })());
});
