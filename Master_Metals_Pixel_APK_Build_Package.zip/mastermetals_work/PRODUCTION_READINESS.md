# Production-readiness status

This package includes the current Master Metals feature updates and a set of direct runtime regression checks for the pricing engine. It is **not certified production-ready for supplier orders or construction**.

## Checks completed in this environment

- ZIP integrity check (`unzip -t`).
- TypeScript/TSX syntax transpilation checks for all application source files.
- Pricing-engine runtime checks against the default building, 12:12 pitch with zero overhang, independent overhangs, invalid opening bounds, and an enabled lean-to with mixed open/enclosed faces. These checks verified nonnegative finite totals, BOM presence, and the expected opening-bound warning.

## Checks not completed

- Full Vite production build and TypeScript type-check: dependencies could not be installed because the package install timed out in this environment.
- Browser/device end-to-end tests, deployment smoke test, and accessibility checks.
- Supplier price/profile verification or structural engineering review.

## Required before commercial use

1. Run `npm ci`, `npm run lint`, and `npm run build` in a network-enabled CI environment; fix any reported failures.
2. Verify every supplier profile, effective panel coverage, trim stock length/lap, current unit price, tax, delivery, and waste policy against current written supplier data.
3. Have a qualified building designer/engineer verify trusses, posts, headers, connections, foundations, wind/snow load assumptions, and opening framing.
4. Compare BOM quantities to at least one approved set of plans and a supplier-checked takeoff, then perform browser tests for the supported building configurations.

Displayed totals are preliminary estimates until these checks are complete. Do not use the app as an engineered plan or treat an unverified BOM as a guaranteed supplier order.
