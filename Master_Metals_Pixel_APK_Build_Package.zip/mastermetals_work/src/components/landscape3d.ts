import * as THREE from 'three';

/**
 * Procedural Simplex / Value noise helper for organic natural patterns (clouds, terrain, bark, turf)
 */
function createNoise2D(seed = 42) {
  const perm = new Uint8Array(512);
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  const p = new Uint8Array(256);
  for (let i = 0; i < 256; i++) p[i] = i;
  for (let i = 255; i > 0; i--) {
    s = (s * 16807) % 2147483647;
    const j = s % (i + 1);
    const tmp = p[i];
    p[i] = p[j];
    p[j] = tmp;
  }
  for (let i = 0; i < 512; i++) perm[i] = p[i & 255];

  const fade = (t: number) => t * t * t * (t * (t * 6 - 15) + 10);
  const lerp = (a: number, b: number, t: number) => a + t * (b - a);
  const grad = (hash: number, x: number, y: number) => {
    const h = hash & 7;
    const u = h < 4 ? x : y;
    const v = h < 4 ? y : x;
    return ((h & 1) === 0 ? u : -u) + ((h & 2) === 0 ? v : -v);
  };

  return (x: number, y: number) => {
    const X = Math.floor(x) & 255;
    const Y = Math.floor(y) & 255;
    const xf = x - Math.floor(x);
    const yf = y - Math.floor(y);
    const u = fade(xf);
    const v = fade(yf);

    const a = perm[X] + Y;
    const aa = perm[a];
    const ab = perm[a + 1];
    const b = perm[X + 1] + Y;
    const ba = perm[b];
    const bb = perm[b + 1];

    return lerp(
      lerp(grad(perm[aa], xf, yf), grad(perm[ba], xf - 1, yf), u),
      lerp(grad(perm[ab], xf, yf - 1), grad(perm[bb], xf - 1, yf - 1), u),
      v
    );
  };
}

/**
 * 1. PHOTOREALISTIC SKY DOME
 * Renders physically grounded Rayleigh & Mie scattering atmosphere, multi-layered
 * fractal cumulus clouds with silver linings, high cirrus ice wisps, and warm solar haze.
 */
export function createSkyDome(): THREE.Mesh {
  const skyGeo = new THREE.SphereGeometry(6500, 64, 40);
  
  const canvas = document.createElement('canvas');
  canvas.width = 2048;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d')!;

  // 1. Physically accurate Rayleigh atmospheric gradient
  const grad = ctx.createLinearGradient(0, 0, 0, 1024);
  grad.addColorStop(0.00, '#11355b'); // Zenith deep navy-indigo
  grad.addColorStop(0.18, '#1f4f82'); // Upper atmosphere royal azure
  grad.addColorStop(0.38, '#3d72a6'); // Mid-sky true cerulean
  grad.addColorStop(0.58, '#6997c4'); // Lower atmosphere sky blue
  grad.addColorStop(0.74, '#99bcdc'); // Warm ambient horizon haze
  grad.addColorStop(0.84, '#c6d9ea'); // Rayleigh scattering threshold
  grad.addColorStop(0.90, '#e5ecf3'); // Solar horizon glow
  grad.addColorStop(0.95, '#ebedea'); // Distant aerosol haze line
  grad.addColorStop(0.98, '#9faea4'); // Ground bounce blend
  grad.addColorStop(1.00, '#535e4d'); // Earth below horizon
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 2048, 1024);

  // 2. High-Altitude Cirrus Ice Whispers (feathered fibratus streaks)
  const noise = createNoise2D(1337);
  ctx.save();
  for (let y = 100; y < 450; y += 12) {
    ctx.beginPath();
    let started = false;
    for (let x = 0; x <= 2048; x += 16) {
      const n = noise(x * 0.003, y * 0.015) + 0.5 * noise(x * 0.009, y * 0.03);
      if (n > 0.15) {
        const offset = noise(x * 0.005, y * 0.02) * 28;
        const cy = y + offset;
        if (!started) {
          ctx.moveTo(x, cy);
          started = true;
        } else {
          ctx.lineTo(x, cy);
        }
      } else {
        started = false;
      }
    }
    const alpha = Math.min(0.22, Math.max(0.03, (0.5 - (y / 1000)) * 0.45));
    ctx.strokeStyle = `rgba(255, 255, 255, ${alpha})`;
    ctx.lineWidth = 4 + (y % 5);
    ctx.lineCap = 'round';
    ctx.stroke();
  }
  ctx.restore();

  // 3. Realistic Sun Disc & Mie Forward-Scattering Corona
  const sunX = 1480;
  const sunY = 320;
  
  // Outer warm aureole (broad solar bloom)
  const outerBloom = ctx.createRadialGradient(sunX, sunY, 15, sunX, sunY, 680);
  outerBloom.addColorStop(0.00, 'rgba(255, 250, 235, 0.75)');
  outerBloom.addColorStop(0.12, 'rgba(255, 242, 210, 0.40)');
  outerBloom.addColorStop(0.35, 'rgba(255, 230, 185, 0.16)');
  outerBloom.addColorStop(0.70, 'rgba(240, 220, 180, 0.04)');
  outerBloom.addColorStop(1.00, 'rgba(230, 210, 170, 0.0)');
  ctx.fillStyle = outerBloom;
  ctx.fillRect(0, 0, 2048, 1024);

  // Intense sun core
  const innerSun = ctx.createRadialGradient(sunX, sunY, 0, sunX, sunY, 90);
  innerSun.addColorStop(0.0, 'rgba(255, 255, 255, 1.0)');
  innerSun.addColorStop(0.25, 'rgba(255, 255, 250, 0.95)');
  innerSun.addColorStop(0.55, 'rgba(255, 248, 225, 0.65)');
  innerSun.addColorStop(1.0, 'rgba(255, 240, 200, 0.0)');
  ctx.fillStyle = innerSun;
  ctx.beginPath();
  ctx.arc(sunX, sunY, 90, 0, Math.PI * 2);
  ctx.fill();

  // 4. Volumetric Procedural Cumulus Clouds with Silver Lining
  // Cloud clusters with thermodynamic puff distribution
  const cloudBases = [
    { x: 260, y: 440, w: 520, h: 180, scale: 1.25, opacity: 0.88 },
    { x: 920, y: 480, w: 420, h: 140, scale: 0.95, opacity: 0.82 },
    { x: 1720, y: 420, w: 600, h: 200, scale: 1.35, opacity: 0.92 },
    { x: 620, y: 560, w: 340, h: 110, scale: 0.75, opacity: 0.70 },
    { x: 1340, y: 530, w: 380, h: 120, scale: 0.85, opacity: 0.78 },
    { x: 40, y: 510, w: 280, h: 90, scale: 0.70, opacity: 0.65 },
    { x: 1980, y: 460, w: 320, h: 120, scale: 0.80, opacity: 0.75 },
  ];

  const cloudNoise = createNoise2D(90210);

  cloudBases.forEach((cb) => {
    const puffs = 28;
    for (let p = 0; p < puffs; p++) {
      const frac = p / puffs;
      const ox = (frac - 0.5) * cb.w + (Math.sin(p * 2.7) * 25);
      const oy = -Math.sin(frac * Math.PI) * (cb.h * 0.7) + (Math.cos(p * 1.9) * 18);
      const rad = (45 + Math.sin(p * 3.1) * 22) * cb.scale;

      const px = cb.x + ox;
      const py = cb.y + oy;

      // Distance to sun for directional silver-lining illumination
      const dxToSun = sunX - px;
      const dyToSun = sunY - py;
      const distToSun = Math.sqrt(dxToSun * dxToSun + dyToSun * dyToSun);
      const sunFactor = Math.min(1.0, Math.max(0.0, 1.0 - (distToSun / 1400)));

      // 1. Ambient Shadow Base (underside of cloud catching ground/ambient light)
      const baseGrad = ctx.createRadialGradient(px, py + rad * 0.35, rad * 0.1, px, py + rad * 0.35, rad * 1.1);
      baseGrad.addColorStop(0.0, `rgba(168, 185, 204, ${cb.opacity * 0.68})`);
      baseGrad.addColorStop(0.65, `rgba(196, 210, 226, ${cb.opacity * 0.38})`);
      baseGrad.addColorStop(1.0, 'rgba(215, 228, 240, 0.0)');
      ctx.fillStyle = baseGrad;
      ctx.beginPath();
      ctx.arc(px, py + rad * 0.35, rad * 1.1, 0, Math.PI * 2);
      ctx.fill();

      // 2. Main Fluffy Body
      const midGrad = ctx.createRadialGradient(px - rad * 0.15, py - rad * 0.2, rad * 0.1, px, py, rad);
      midGrad.addColorStop(0.0, `rgba(255, 255, 255, ${cb.opacity * 0.95})`);
      midGrad.addColorStop(0.55, `rgba(242, 246, 252, ${cb.opacity * 0.75})`);
      midGrad.addColorStop(0.85, `rgba(220, 232, 244, ${cb.opacity * 0.35})`);
      midGrad.addColorStop(1.0, 'rgba(210, 225, 238, 0.0)');
      ctx.fillStyle = midGrad;
      ctx.beginPath();
      ctx.arc(px, py, rad, 0, Math.PI * 2);
      ctx.fill();

      // 3. Sunlit Silver Lining Rim (top & sunward edge highlight)
      if (sunFactor > 0.1) {
        const rimX = px + (dxToSun / distToSun) * (rad * 0.3);
        const rimY = py + (dyToSun / distToSun) * (rad * 0.3);
        const rimGrad = ctx.createRadialGradient(rimX, rimY, 2, rimX, rimY, rad * 0.6);
        rimGrad.addColorStop(0.0, `rgba(255, 253, 245, ${cb.opacity * 0.95 * (0.6 + sunFactor * 0.4)})`);
        rimGrad.addColorStop(0.4, `rgba(255, 250, 235, ${cb.opacity * 0.5})`);
        rimGrad.addColorStop(1.0, 'rgba(255, 248, 225, 0.0)');
        ctx.fillStyle = rimGrad;
        ctx.beginPath();
        ctx.arc(rimX, rimY, rad * 0.6, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  });

  // 5. Seamless Atmospheric Horizon Haze Band
  const horizonBand = ctx.createLinearGradient(0, 780, 0, 1024);
  horizonBand.addColorStop(0.00, 'rgba(215, 230, 242, 0.0)');
  horizonBand.addColorStop(0.45, 'rgba(225, 235, 244, 0.45)');
  horizonBand.addColorStop(0.75, 'rgba(235, 240, 245, 0.85)');
  horizonBand.addColorStop(0.92, 'rgba(240, 242, 238, 0.98)');
  horizonBand.addColorStop(1.00, 'rgba(180, 192, 178, 1.0)');
  ctx.fillStyle = horizonBand;
  ctx.fillRect(0, 780, 2048, 244);

  const skyTexture = new THREE.CanvasTexture(canvas);
  skyTexture.wrapS = THREE.ClampToEdgeWrapping;
  skyTexture.wrapT = THREE.ClampToEdgeWrapping;
  skyTexture.colorSpace = THREE.SRGBColorSpace;

  const skyMat = new THREE.MeshBasicMaterial({
    map: skyTexture,
    side: THREE.BackSide,
    depthWrite: false,
    fog: false,
  });

  const skyMesh = new THREE.Mesh(skyGeo, skyMat);
  skyMesh.position.y = -18;
  return skyMesh;
}

/**
 * 2. ULTRA-REALISTIC MULTI-SPECIES TURF TEXTURE
 * Blends healthy Kentucky bluegrass, fine fescues, perennial ryegrass,
 * delicate clover flecks, organic soil undertones, and alternating mower striping.
 */
export function createGrassTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 2048;
  canvas.height = 2048;
  const ctx = canvas.getContext('2d')!;

  // 1. Base Soil & Turf Deep Layer
  const baseGrad = ctx.createLinearGradient(0, 0, 2048, 2048);
  baseGrad.addColorStop(0.00, '#2d4c22'); // Deep Kentucky bluegrass
  baseGrad.addColorStop(0.35, '#395e29'); // Healthy lush meadow
  baseGrad.addColorStop(0.70, '#315424'); // Dense turf base
  baseGrad.addColorStop(1.00, '#26421c'); // Earthy rich loam undertone
  ctx.fillStyle = baseGrad;
  ctx.fillRect(0, 0, 2048, 2048);

  const noise = createNoise2D(777);

  // 2. Macro Pasture & Soil Organic Moisture Patches
  for (let y = 0; y < 2048; y += 16) {
    for (let x = 0; x < 2048; x += 16) {
      const n1 = noise(x * 0.002, y * 0.002);
      const n2 = noise(x * 0.008, y * 0.008) * 0.5;
      const total = n1 + n2;
      if (total > 0.15) {
        // Lush deep green moisture swale
        ctx.fillStyle = `rgba(58, 102, 42, ${Math.min(0.42, total * 0.35)})`;
        ctx.fillRect(x, y, 16, 16);
      } else if (total < -0.2) {
        // Sun-warmed golden fescue dry zone
        ctx.fillStyle = `rgba(112, 126, 58, ${Math.min(0.35, -total * 0.3)})`;
        ctx.fillRect(x, y, 16, 16);
      }
    }
  }

  // 3. Professional Turf Rolling / Mowing Stripes
  // Generates subtle alternating light reflection identical to reel mowers
  const stripeWidth = 128;
  for (let x = 0; x < 2048; x += stripeWidth * 2) {
    // Forward pass (blades bent away reflecting sky sheen)
    const fwdGrad = ctx.createLinearGradient(x, 0, x + stripeWidth, 0);
    fwdGrad.addColorStop(0.0, 'rgba(255, 255, 255, 0.045)');
    fwdGrad.addColorStop(0.5, 'rgba(255, 255, 255, 0.075)');
    fwdGrad.addColorStop(1.0, 'rgba(255, 255, 255, 0.045)');
    ctx.fillStyle = fwdGrad;
    ctx.fillRect(x, 0, stripeWidth, 2048);

    // Reverse pass (blades bent toward viewer, darker profile)
    const revGrad = ctx.createLinearGradient(x + stripeWidth, 0, x + stripeWidth * 2, 0);
    revGrad.addColorStop(0.0, 'rgba(10, 25, 8, 0.045)');
    revGrad.addColorStop(0.5, 'rgba(10, 25, 8, 0.07)');
    revGrad.addColorStop(1.0, 'rgba(10, 25, 8, 0.045)');
    ctx.fillStyle = revGrad;
    ctx.fillRect(x + stripeWidth, 0, stripeWidth, 2048);
  }

  // 4. Fine Individual Grass Blades (45,000 micro-strokes with realistic blade taper)
  for (let i = 0; i < 45000; i++) {
    const x = Math.random() * 2048;
    const y = Math.random() * 2048;
    const len = 4 + Math.random() * 8;
    const angle = (Math.random() - 0.5) * 0.6;
    const toneRand = Math.random();

    let strokeColor: string;
    if (toneRand > 0.72) {
      strokeColor = '#558b38'; // Fresh sunlit blade tip
    } else if (toneRand > 0.42) {
      strokeColor = '#416e2a'; // Mid-blade lush green
    } else if (toneRand > 0.18) {
      strokeColor = '#2b4d1b'; // Deep shaded under-blade
    } else {
      strokeColor = '#6d883f'; // Golden dry fescue blade
    }

    ctx.strokeStyle = strokeColor;
    ctx.lineWidth = 1.0 + Math.random() * 0.7;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + angle * len, y - len);
    ctx.stroke();
  }

  // 5. White Clover & Dandelion Specks for organic pasture authenticity
  for (let c = 0; c < 240; c++) {
    const cx = Math.random() * 2048;
    const cy = Math.random() * 2048;
    ctx.fillStyle = Math.random() > 0.25 ? 'rgba(245, 250, 245, 0.75)' : 'rgba(250, 225, 90, 0.75)';
    ctx.beginPath();
    ctx.arc(cx, cy, 1.2 + Math.random() * 1.5, 0, Math.PI * 2);
    ctx.fill();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(110, 110);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

/**
 * Grass Normal / Bump Map for photorealistic tactile micro-shadows under directional sun
 */
export function createGrassBumpMap(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#808080';
  ctx.fillRect(0, 0, 1024, 1024);

  // Micro-blade height variances
  for (let i = 0; i < 28000; i++) {
    const x = Math.random() * 1024;
    const y = Math.random() * 1024;
    const val = 128 + Math.floor((Math.random() - 0.48) * 110);
    ctx.fillStyle = `rgb(${val},${val},${val})`;
    ctx.fillRect(x, y, 1.5, 4.0);
  }

  const bump = new THREE.CanvasTexture(canvas);
  bump.wrapS = THREE.RepeatWrapping;
  bump.wrapT = THREE.RepeatWrapping;
  bump.repeat.set(110, 110);
  return bump;
}

/**
 * 3. REALISTIC CRUSHED LIMESTONE GRAVEL TEXTURE
 * High-definition #57 stone aggregate with compaction dust, gray quarry fines,
 * and stone chipping texture.
 */
export function createGravelTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d')!;

  // Base compacted stone dust
  ctx.fillStyle = '#a6b0bb';
  ctx.fillRect(0, 0, 1024, 1024);

  // Random stone chips with realistic angular geometry
  for (let i = 0; i < 18000; i++) {
    const x = Math.random() * 1024;
    const y = Math.random() * 1024;
    const size = 2.0 + Math.random() * 4.5;
    const tone = Math.random();

    let stoneColor: string;
    if (tone > 0.8) {
      stoneColor = '#d9e0e7'; // Bright limestone chip
    } else if (tone > 0.5) {
      stoneColor = '#b5bfc9'; // Neutral limestone
    } else if (tone > 0.2) {
      stoneColor = '#8e9aa5'; // Dark blue-gray quarry chip
    } else {
      stoneColor = '#77828d'; // Weathered basalt/slate chip
    }

    ctx.fillStyle = stoneColor;
    ctx.beginPath();
    ctx.arc(x, y, size, 0, Math.PI * 2);
    ctx.fill();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(16, 16);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

export function createGravelBumpMap(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#808080';
  ctx.fillRect(0, 0, 512, 512);

  for (let i = 0; i < 12000; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    const val = 128 + Math.floor((Math.random() - 0.5) * 120);
    ctx.fillStyle = `rgb(${val},${val},${val})`;
    ctx.beginPath();
    ctx.arc(x, y, 1.5 + Math.random() * 2.5, 0, Math.PI * 2);
    ctx.fill();
  }

  const bump = new THREE.CanvasTexture(canvas);
  bump.wrapS = THREE.RepeatWrapping;
  bump.wrapT = THREE.RepeatWrapping;
  bump.repeat.set(16, 16);
  return bump;
}

export function createConcreteApronTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#d1d8df';
  ctx.fillRect(0, 0, 512, 512);

  // Fine broom finish striations
  for (let y = 0; y < 512; y += 2) {
    ctx.fillStyle = Math.random() > 0.5 ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.06)';
    ctx.fillRect(0, y, 512, 1);
  }

  // Micro aggregate flecks
  for (let i = 0; i < 2400; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    ctx.fillStyle = Math.random() > 0.5 ? 'rgba(90,100,110,0.25)' : 'rgba(255,255,255,0.3)';
    ctx.fillRect(x, y, 1, 1);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(2, 2);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

/**
 * 4. ULTRA-REALISTIC 3D PANORAMIC MOUNTAIN SYSTEM
 * Generates true 3-tier geographical terrain:
 * 1) Majestic snow-dusted alpine mountain peaks on the far horizon with rugged couloirs & crags
 * 2) Mid-distance conifer-covered ridges with atmospheric blue distance scattering
 * 3) Rolling green pasture foothills and wooded knolls with realistic stereoscopic parallax
 */
export function createDistantMountains(): THREE.Group {
  const mountainGroup = new THREE.Group();
  const noise = createNoise2D(2026);

  // -------------------------------------------------------------
  // LAYER 1: Far Majestic Alpine Mountain Range (Radius ~3600ft, Height up to 550ft)
  // -------------------------------------------------------------
  const farSegs = 320;
  const farRadius = 3600;
  const farPositions: number[] = [];
  const farColors: number[] = [];
  const farIndices: number[] = [];

  const snowSummitColor = new THREE.Color('#eaf0f6'); // Crisp alpine snow cap
  const rockCragColor = new THREE.Color('#586c80');    // Weathered granite rock face
  const shadowSlopeColor = new THREE.Color('#384b5e'); // Shadowed couloir deep slate
  const hazeAtmosphere = new THREE.Color('#9bbcd8');   // Horizon Rayleigh haze blend

  for (let i = 0; i < farSegs; i++) {
    const angle = (i / farSegs) * Math.PI * 2;
    
    // Fractal harmonic mountains with jagged peaks and saddles
    const n1 = Math.sin(angle * 4.0 + 0.8) * 36;
    const n2 = Math.cos(angle * 9.0 + 1.5) * 22;
    const n3 = Math.sin(angle * 19.0) * 11;
    const n4 = Math.cos(angle * 37.0) * 5;
    const n5 = noise(Math.cos(angle) * 3, Math.sin(angle) * 3) * 16;
    
    const peakHeight = Math.max(90, 280 + n1 * 3.8 + n2 * 3.2 + n3 * 2.5 + n4 * 2.0 + n5 * 3.0);

    // Natural undulating perimeter radius
    const rOffset = Math.sin(angle * 6.0) * 160 + Math.cos(angle * 14.0) * 70;
    const currentR = farRadius + rOffset;

    const x = Math.cos(angle) * currentR;
    const z = Math.sin(angle) * currentR;

    // Base point (anchored in horizon haze)
    farPositions.push(x, -10, z);
    farColors.push(hazeAtmosphere.r, hazeAtmosphere.g, hazeAtmosphere.b);

    // Peak crest point
    farPositions.push(x, peakHeight, z);
    
    // Color depends on altitude: high summits get pristine snow, mid get craggy rock, lower get haze
    if (peakHeight > 340) {
      farColors.push(snowSummitColor.r, snowSummitColor.g, snowSummitColor.b);
    } else if (peakHeight > 230) {
      // Transition between rock and snow
      const t = (peakHeight - 230) / 110;
      const c = rockCragColor.clone().lerp(snowSummitColor, t);
      farColors.push(c.r, c.g, c.b);
    } else {
      const c = shadowSlopeColor.clone().lerp(hazeAtmosphere, 0.45);
      farColors.push(c.r, c.g, c.b);
    }
  }

  for (let i = 0; i < farSegs; i++) {
    const next = (i + 1) % farSegs;
    const b1 = i * 2;
    const t1 = i * 2 + 1;
    const b2 = next * 2;
    const t2 = next * 2 + 1;

    farIndices.push(b1, t1, b2);
    farIndices.push(b2, t1, t2);
  }

  const farGeo = new THREE.BufferGeometry();
  farGeo.setAttribute('position', new THREE.Float32BufferAttribute(farPositions, 3));
  farGeo.setAttribute('color', new THREE.Float32BufferAttribute(farColors, 3));
  farGeo.setIndex(farIndices);
  farGeo.computeVertexNormals();

  const farMat = new THREE.MeshStandardMaterial({
    vertexColors: true,
    roughness: 0.95,
    metalness: 0.04,
    side: THREE.DoubleSide,
  });
  const farAlpineRidge = new THREE.Mesh(farGeo, farMat);
  mountainGroup.add(farAlpineRidge);

  // -------------------------------------------------------------
  // LAYER 2: Mid-Distance Forested Ridge Ranges (Radius ~2500ft, Height up to 260ft)
  // -------------------------------------------------------------
  const midSegs = 260;
  const midRadius = 2500;
  const midPositions: number[] = [];
  const midColors: number[] = [];
  const midIndices: number[] = [];

  const forestRidgeTop = new THREE.Color('#284232');   // Deep conifer canopy ridge
  const forestRidgeMid = new THREE.Color('#385640');   // Sunward pine forest slope
  const forestHazeBase = new THREE.Color('#7899b5');   // Atmospheric aerial perspective

  for (let i = 0; i < midSegs; i++) {
    const angle = (i / midSegs) * Math.PI * 2;
    const m1 = Math.sin(angle * 5.0 + 2.1) * 20;
    const m2 = Math.cos(angle * 11.0 + 0.6) * 10;
    const m3 = Math.sin(angle * 23.0) * 5;
    const m4 = noise(Math.cos(angle) * 5 + 10, Math.sin(angle) * 5 + 10) * 8;
    const ridgeH = Math.max(45, 140 + m1 * 3.0 + m2 * 2.6 + m3 * 2.0 + m4 * 2.4);

    const rOffset = Math.cos(angle * 7.0) * 120;
    const currentR = midRadius + rOffset;

    const x = Math.cos(angle) * currentR;
    const z = Math.sin(angle) * currentR;

    midPositions.push(x, -6, z);
    midColors.push(forestHazeBase.r, forestHazeBase.g, forestHazeBase.b);

    midPositions.push(x, ridgeH, z);
    const c = ridgeH > 150 ? forestRidgeTop : forestRidgeMid;
    midColors.push(c.r, c.g, c.b);
  }

  for (let i = 0; i < midSegs; i++) {
    const next = (i + 1) % midSegs;
    const b1 = i * 2;
    const t1 = i * 2 + 1;
    const b2 = next * 2;
    const t2 = next * 2 + 1;

    midIndices.push(b1, t1, b2);
    midIndices.push(b2, t1, t2);
  }

  const midGeo = new THREE.BufferGeometry();
  midGeo.setAttribute('position', new THREE.Float32BufferAttribute(midPositions, 3));
  midGeo.setAttribute('color', new THREE.Float32BufferAttribute(midColors, 3));
  midGeo.setIndex(midIndices);
  midGeo.computeVertexNormals();

  const midMat = new THREE.MeshStandardMaterial({
    vertexColors: true,
    roughness: 0.92,
    metalness: 0.03,
    side: THREE.DoubleSide,
  });
  const midForestedHills = new THREE.Mesh(midGeo, midMat);
  mountainGroup.add(midForestedHills);

  // -------------------------------------------------------------
  // LAYER 3: Countryside Knolls & Foothills (Radius ~1600ft, Height up to 110ft)
  // -------------------------------------------------------------
  const nearSegs = 200;
  const nearRadius = 1600;
  const nearPositions: number[] = [];
  const nearColors: number[] = [];
  const nearIndices: number[] = [];

  const pastureKnollTop = new THREE.Color('#466b35');  // Pastoral farm knoll
  const pastureKnollBase = new THREE.Color('#385628'); // Deep pasture green

  for (let i = 0; i < nearSegs; i++) {
    const angle = (i / nearSegs) * Math.PI * 2;
    const k1 = Math.sin(angle * 3.0 + 4.2) * 11;
    const k2 = Math.cos(angle * 7.0 + 1.8) * 5;
    const knollH = Math.max(22, 65 + k1 * 3.0 + k2 * 2.5);

    const rOffset = Math.sin(angle * 4.0) * 85;
    const currentR = nearRadius + rOffset;

    const x = Math.cos(angle) * currentR;
    const z = Math.sin(angle) * currentR;

    nearPositions.push(x, -4, z);
    nearColors.push(pastureKnollBase.r, pastureKnollBase.g, pastureKnollBase.b);

    nearPositions.push(x, knollH, z);
    nearColors.push(pastureKnollTop.r, pastureKnollTop.g, pastureKnollTop.b);
  }

  for (let i = 0; i < nearSegs; i++) {
    const next = (i + 1) % nearSegs;
    const b1 = i * 2;
    const t1 = i * 2 + 1;
    const b2 = next * 2;
    const t2 = next * 2 + 1;

    nearIndices.push(b1, t1, b2);
    nearIndices.push(b2, t1, t2);
  }

  const nearGeo = new THREE.BufferGeometry();
  nearGeo.setAttribute('position', new THREE.Float32BufferAttribute(nearPositions, 3));
  nearGeo.setAttribute('color', new THREE.Float32BufferAttribute(nearColors, 3));
  nearGeo.setIndex(nearIndices);
  nearGeo.computeVertexNormals();

  const nearMat = new THREE.MeshStandardMaterial({
    vertexColors: true,
    roughness: 0.90,
    metalness: 0.02,
    side: THREE.DoubleSide,
  });
  const nearFoothills = new THREE.Mesh(nearGeo, nearMat);
  mountainGroup.add(nearFoothills);

  return mountainGroup;
}

/**
 * 5. ULTRA-REALISTIC BOTANICAL CONIFER TREE (Spruce / Douglas Fir)
 * Features natural flared root flare, fluted cedar/pine bark trunk, 8 tiered
 * branch whorls with drooping and upturned branch boughs, needle fronds, and apical leader.
 */
export function createPineTree(
  height = 24,
  barkMat: THREE.Material,
  pineMats: THREE.Material[]
): THREE.Group {
  const tree = new THREE.Group();

  // 1. Natural Tapered & Fluted Trunk with Root Flare at ground
  const trunkH = height * 0.42;
  const trunkBaseR = Math.max(0.45, height * 0.038);
  const trunkTopR = trunkBaseR * 0.45;
  const trunkGeo = new THREE.CylinderGeometry(trunkTopR, trunkBaseR, trunkH, 10);
  const trunk = new THREE.Mesh(trunkGeo, barkMat);
  trunk.position.y = trunkH / 2;
  trunk.castShadow = true;
  trunk.receiveShadow = true;
  tree.add(trunk);

  // Ground root flare flares anchoring into the turf
  const rootCount = 4;
  for (let r = 0; r < rootCount; r++) {
    const angle = (r / rootCount) * Math.PI * 2 + 0.3;
    const rootGeo = new THREE.ConeGeometry(trunkBaseR * 0.55, trunkBaseR * 2.2, 5);
    const root = new THREE.Mesh(rootGeo, barkMat);
    root.rotation.z = Math.PI / 2.3;
    root.rotation.y = angle;
    root.position.set(Math.cos(angle) * trunkBaseR * 0.9, 0.2, Math.sin(angle) * trunkBaseR * 0.9);
    tree.add(root);
  }

  // 2. Eight Natural Tiered Branch Whorls with drooping boughs & needle clusters
  const tiers = 8;
  const foliageBaseY = height * 0.18;
  const foliageTotalH = height * 0.84;
  const tierStep = foliageTotalH / tiers;

  for (let t = 0; t < tiers; t++) {
    const progress = t / tiers; // 0 at base, 1 at top
    // Natural parabolic canopy taper
    const tierRadius = (height * 0.32) * Math.pow(1.0 - progress * 0.82, 0.88);
    const tierY = foliageBaseY + t * tierStep;
    const boughsInTier = Math.max(4, Math.floor(7 - progress * 3));
    const matIndex = t % pineMats.length;
    const foliageMat = pineMats[matIndex];

    for (let b = 0; b < boughsInTier; b++) {
      const boughAngle = (b / boughsInTier) * Math.PI * 2 + (t * 0.72) + (Math.sin(b * 1.5) * 0.15);
      const boughLen = tierRadius * (0.85 + Math.sin(b * 2.1) * 0.15);
      
      // Conical drooping branch bough cluster
      const boughGeo = new THREE.ConeGeometry(boughLen * 0.42, boughLen * 1.05, 6);
      const bough = new THREE.Mesh(boughGeo, foliageMat);
      
      // Positioned out from trunk with realistic downward sag and slight upward tip curl
      const droop = -0.32 - (1.0 - progress) * 0.22;
      bough.rotation.z = droop;
      bough.rotation.y = boughAngle;
      
      const distFromCenter = boughLen * 0.45;
      bough.position.set(
        Math.cos(boughAngle) * distFromCenter,
        tierY + (Math.sin(b * 1.3) * 0.3),
        Math.sin(boughAngle) * distFromCenter
      );
      bough.castShadow = true;
      bough.receiveShadow = true;
      tree.add(bough);
    }

    // Secondary central core foliage for solid volumetric fullness
    const coreConeGeo = new THREE.ConeGeometry(tierRadius * 0.75, tierStep * 1.4, 7);
    const coreCone = new THREE.Mesh(coreConeGeo, foliageMat);
    coreCone.position.y = tierY + tierStep * 0.5;
    coreCone.rotation.y = t * 1.3;
    coreCone.castShadow = true;
    tree.add(coreCone);
  }

  // 3. Slender Apex Spire (Terminal Leader)
  const apexGeo = new THREE.ConeGeometry(0.35, height * 0.18, 5);
  const apexMat = pineMats[pineMats.length - 1];
  const apex = new THREE.Mesh(apexGeo, apexMat);
  apex.position.y = height * 0.96;
  apex.castShadow = true;
  tree.add(apex);

  return tree;
}

/**
 * 6. ULTRA-REALISTIC MATURE DECIDUOUS HARDWOOD TREE (Oak / Sugar Maple)
 * Features organic bifurcating trunk, natural primary limbs, interlocking organic
 * foliage canopies, and realistic sunlight transmission highlights.
 */
export function createDeciduousTree(
  height = 24,
  barkMat: THREE.Material,
  leafMats: THREE.Material[]
): THREE.Group {
  const tree = new THREE.Group();

  // 1. Organic Tapered Trunk
  const trunkH = height * 0.46;
  const trunkBaseR = Math.max(0.5, height * 0.045);
  const trunkGeo = new THREE.CylinderGeometry(trunkBaseR * 0.65, trunkBaseR, trunkH, 10);
  const trunk = new THREE.Mesh(trunkGeo, barkMat);
  trunk.position.y = trunkH / 2;
  trunk.rotation.z = (Math.random() - 0.5) * 0.08;
  trunk.rotation.x = (Math.random() - 0.5) * 0.08;
  trunk.castShadow = true;
  trunk.receiveShadow = true;
  tree.add(trunk);

  // Ground root flare flares
  for (let r = 0; r < 4; r++) {
    const angle = (r / 4) * Math.PI * 2 + 0.4;
    const rootGeo = new THREE.ConeGeometry(trunkBaseR * 0.6, trunkBaseR * 2.4, 5);
    const root = new THREE.Mesh(rootGeo, barkMat);
    root.rotation.z = Math.PI / 2.3;
    root.rotation.y = angle;
    root.position.set(Math.cos(angle) * trunkBaseR, 0.2, Math.sin(angle) * trunkBaseR);
    tree.add(root);
  }

  // 2. Primary Scaffold Limbs (Bifurcating branches spreading outward into canopy)
  const limbCount = 4;
  for (let l = 0; l < limbCount; l++) {
    const limbAngle = (l / limbCount) * Math.PI * 2 + (l * 0.4);
    const limbLen = height * 0.32;
    const limbRadius = trunkBaseR * 0.42;
    const limbGeo = new THREE.CylinderGeometry(limbRadius * 0.55, limbRadius, limbLen, 7);
    const limb = new THREE.Mesh(limbGeo, barkMat);
    
    // Spread upward & outward at ~35-45 degrees
    limb.rotation.z = 0.55;
    limb.rotation.y = limbAngle;
    
    const lx = Math.cos(limbAngle) * (limbLen * 0.35);
    const lz = Math.sin(limbAngle) * (limbLen * 0.35);
    limb.position.set(lx, trunkH * 0.82 + (limbLen * 0.35), lz);
    limb.castShadow = true;
    tree.add(limb);
  }

  // 3. Volumetric Leaf Cloud Masses (16 interlocking organic dodecahedrons)
  const crownRadius = height * 0.36;
  const crownCenterY = height * 0.68;

  const clusterConfigs = [
    // Center & High Crest
    { x: 0, y: 0.18, z: 0, scale: 1.25 },
    { x: 0.08, y: 0.34, z: 0.08, scale: 0.95 },
    // Outer Primary Mantle
    { x: -crownRadius * 0.65, y: -0.06, z: crownRadius * 0.25, scale: 1.05 },
    { x: crownRadius * 0.68, y: -0.04, z: -crownRadius * 0.32, scale: 1.10 },
    { x: crownRadius * 0.28, y: -0.12, z: crownRadius * 0.62, scale: 0.95 },
    { x: -crownRadius * 0.35, y: 0.14, z: -crownRadius * 0.55, scale: 1.0 },
    // Skirt & Lateral Boughs
    { x: -crownRadius * 0.78, y: -0.22, z: -crownRadius * 0.15, scale: 0.85 },
    { x: crownRadius * 0.80, y: -0.20, z: crownRadius * 0.22, scale: 0.88 },
    { x: 0.12, y: -0.26, z: -crownRadius * 0.72, scale: 0.82 },
    { x: -0.15, y: -0.24, z: crownRadius * 0.75, scale: 0.85 },
    // Fillers
    { x: crownRadius * 0.42, y: 0.22, z: crownRadius * 0.35, scale: 0.80 },
    { x: -crownRadius * 0.45, y: 0.25, z: -crownRadius * 0.25, scale: 0.82 },
    { x: -crownRadius * 0.22, y: -0.08, z: -crownRadius * 0.32, scale: 0.90 },
    { x: crownRadius * 0.30, y: 0.02, z: crownRadius * 0.40, scale: 0.92 },
  ];

  clusterConfigs.forEach((cfg, idx) => {
    const r = crownRadius * cfg.scale * 0.72;
    // Icosahedron with detail 1 provides organic, multifaceted leaf clusters that catch realistic light
    const geo = new THREE.IcosahedronGeometry(r, 1);
    const leafMat = leafMats[idx % leafMats.length];
    const cluster = new THREE.Mesh(geo, leafMat);
    cluster.position.set(
      cfg.x,
      crownCenterY + cfg.y * height,
      cfg.z
    );
    cluster.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI);
    cluster.castShadow = true;
    cluster.receiveShadow = true;
    tree.add(cluster);
  });

  return tree;
}

/**
 * 7. SCENIC TREE GROVES & WINDBREAKS
 * Naturally places mature pine forests, oak groves, and specimen shade trees
 * around property boundaries with realistic scale, age distribution, and orientation.
 */
export function createScenicTrees(buildingW: number, buildingL: number): THREE.Group {
  const treeGroup = new THREE.Group();

  // Natural rough aged tree bark
  const barkMat = new THREE.MeshStandardMaterial({
    color: '#34261b', // Aged dark walnut/cedar bark
    roughness: 0.94,
    metalness: 0.04,
  });

  // Multi-species Evergreen Needles (Deep Blue Spruce, Ponderosa Pine, Forest Fir)
  const pineMats = [
    new THREE.MeshStandardMaterial({ color: '#163622', roughness: 0.88, flatShading: true }),
    new THREE.MeshStandardMaterial({ color: '#1e462c', roughness: 0.86, flatShading: true }),
    new THREE.MeshStandardMaterial({ color: '#132d1c', roughness: 0.90, flatShading: true }),
    new THREE.MeshStandardMaterial({ color: '#255437', roughness: 0.84, flatShading: true }),
  ];

  // Multi-species Deciduous Leaves (Sugar Maple, White Oak, American Elm)
  const leafMats = [
    new THREE.MeshStandardMaterial({ color: '#315c22', roughness: 0.85, flatShading: true }),
    new THREE.MeshStandardMaterial({ color: '#3f702c', roughness: 0.84, flatShading: true }),
    new THREE.MeshStandardMaterial({ color: '#274b1b', roughness: 0.88, flatShading: true }),
    new THREE.MeshStandardMaterial({ color: '#4b8235', roughness: 0.82, flatShading: true }),
    new THREE.MeshStandardMaterial({ color: '#57963d', roughness: 0.80, flatShading: true }),
  ];

  const minClearRadius = Math.max(720, Math.max(buildingW, buildingL) * 6.5);

  // 1. Distant Back Forest Tree Line (Dense mixed forest canopy backdrop on the far horizon)
  for (let i = 0; i < 54; i++) {
    const x = (Math.random() - 0.5) * 2600;
    const z = -minClearRadius - 120 - Math.random() * 450;
    const isPine = Math.random() > 0.38;
    const height = 36 + Math.random() * 26;
    const tree = isPine
      ? createPineTree(height, barkMat, pineMats)
      : createDeciduousTree(height, barkMat, leafMats);
    tree.position.set(x, 0, z);
    tree.rotation.y = Math.random() * Math.PI * 2;
    treeGroup.add(tree);
  }

  // 2. Left Flank Agricultural Windbreak (Shelterbelt evergreen grove far in distance)
  for (let i = 0; i < 34; i++) {
    const x = -minClearRadius - 120 - Math.random() * 400;
    const z = (Math.random() - 0.5) * 2000;
    const isPine = Math.random() > 0.35;
    const height = 34 + Math.random() * 24;
    const tree = isPine
      ? createPineTree(height, barkMat, pineMats)
      : createDeciduousTree(height, barkMat, leafMats);
    tree.position.set(x, 0, z);
    tree.rotation.y = Math.random() * Math.PI * 2;
    treeGroup.add(tree);
  }

  // 3. Right Flank Tree Grove (Mixed deciduous and pine woodland far in distance)
  for (let i = 0; i < 34; i++) {
    const x = minClearRadius + 120 + Math.random() * 400;
    const z = (Math.random() - 0.5) * 2000;
    const isPine = Math.random() > 0.45;
    const height = 34 + Math.random() * 24;
    const tree = isPine
      ? createPineTree(height, barkMat, pineMats)
      : createDeciduousTree(height, barkMat, leafMats);
    tree.position.set(x, 0, z);
    tree.rotation.y = Math.random() * Math.PI * 2;
    treeGroup.add(tree);
  }

  return treeGroup;
}

/**
 * 9. WEATHERED 3-RAIL SPLIT-CEDAR RANCH FENCE
 */
export function createRusticFence(fenceRadius = 210): THREE.Group {
  const fenceGroup = new THREE.Group();
  
  const woodMat = new THREE.MeshStandardMaterial({
    color: '#695f54', // Aged weathered cedar patina
    roughness: 0.95,
    metalness: 0.04,
  });

  const postSpacing = 16;
  const postH = 4.8;
  const postR = 0.35;
  const railH = 0.28;
  const railD = 0.22;

  const postGeo = new THREE.CylinderGeometry(postR * 0.85, postR, postH, 6);
  const railGeo = new THREE.BoxGeometry(postSpacing + 0.5, railH, railD);

  const sides = [
    { startX: -fenceRadius, startZ: -fenceRadius, endX: fenceRadius, endZ: -fenceRadius },
    { startX: -fenceRadius, startZ: -fenceRadius, endX: -fenceRadius, endZ: fenceRadius },
    { startX: fenceRadius, startZ: -fenceRadius, endX: fenceRadius, endZ: fenceRadius },
    { startX: -fenceRadius, startZ: fenceRadius, endX: -24, endZ: fenceRadius },
    { startX: 24, startZ: fenceRadius, endX: fenceRadius, endZ: fenceRadius },
  ];

  sides.forEach((side) => {
    const dx = side.endX - side.startX;
    const dz = side.endZ - side.startZ;
    const len = Math.sqrt(dx * dx + dz * dz);
    const count = Math.floor(len / postSpacing);
    const angle = Math.atan2(dz, dx);

    for (let i = 0; i <= count; i++) {
      const t = i / count;
      const px = side.startX + dx * t;
      const pz = side.startZ + dz * t;

      const post = new THREE.Mesh(postGeo, woodMat);
      post.position.set(px, postH / 2, pz);
      post.rotation.y = Math.random() * Math.PI;
      post.castShadow = true;
      post.receiveShadow = true;
      fenceGroup.add(post);

      if (i < count) {
        const midX = side.startX + dx * (t + 0.5 / count);
        const midZ = side.startZ + dz * (t + 0.5 / count);

        const railHeights = [1.3, 2.5, 3.8];
        railHeights.forEach((rh) => {
          const rail = new THREE.Mesh(railGeo, woodMat);
          rail.position.set(midX, rh, midZ);
          rail.rotation.y = -angle;
          rail.castShadow = true;
          fenceGroup.add(rail);
        });
      }
    }
  });

  return fenceGroup;
}

/**
 * 10. PHOTOREALISTIC IMAGE-BASED LIGHTING (IBL) ENVIRONMENT MAP
 * Generates an equirectangular HDR sky & horizon reflection map so metal siding,
 * glossy paint, and glass windows reflect true clouds and natural sky light.
 */
export function createEnvironmentMap(renderer: THREE.WebGLRenderer): THREE.Texture {
  const pmremGenerator = new THREE.PMREMGenerator(renderer);
  pmremGenerator.compileEquirectangularShader();

  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // 1. Natural Sky Hemisphere
  const skyGrad = ctx.createLinearGradient(0, 0, 0, 256);
  skyGrad.addColorStop(0.00, '#153b65'); // Zenith
  skyGrad.addColorStop(0.35, '#356a9e'); // Mid sky
  skyGrad.addColorStop(0.70, '#749fc7'); // Lower sky
  skyGrad.addColorStop(0.90, '#bed5e8'); // Atmospheric haze
  skyGrad.addColorStop(1.00, '#e5ecf2'); // Horizon line
  ctx.fillStyle = skyGrad;
  ctx.fillRect(0, 0, 1024, 256);

  // 2. High-brightness Sun Spot for authentic specular reflections
  const sunGrad = ctx.createRadialGradient(720, 90, 2, 720, 90, 120);
  sunGrad.addColorStop(0.0, '#ffffff');
  sunGrad.addColorStop(0.2, '#fff6dc');
  sunGrad.addColorStop(0.6, '#ffe1a0');
  sunGrad.addColorStop(1.0, 'rgba(255, 230, 180, 0)');
  ctx.fillStyle = sunGrad;
  ctx.fillRect(0, 0, 1024, 256);

  // 3. Soft cloud bands in the reflection map
  ctx.fillStyle = 'rgba(255, 255, 255, 0.55)';
  for (let i = 0; i < 14; i++) {
    const cx = (i * 85 + 40) % 1024;
    const cy = 110 + (i % 4) * 25;
    ctx.beginPath();
    ctx.ellipse(cx, cy, 75, 22, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  // 4. Ground Pasture & Horizon Foliage Hemisphere
  const groundGrad = ctx.createLinearGradient(0, 256, 0, 512);
  groundGrad.addColorStop(0.00, '#38542c'); // Horizon tree line
  groundGrad.addColorStop(0.25, '#426832'); // Pasture turf
  groundGrad.addColorStop(0.65, '#2e4922'); // Loam grass
  groundGrad.addColorStop(1.00, '#1e3216'); // Nadir ground
  ctx.fillStyle = groundGrad;
  ctx.fillRect(0, 256, 1024, 256);

  const texture = new THREE.CanvasTexture(canvas);
  texture.mapping = THREE.EquirectangularReflectionMapping;

  const envTarget = pmremGenerator.fromEquirectangular(texture);
  pmremGenerator.dispose();
  texture.dispose();

  return envTarget.texture;
}

/**
 * 11. ROLLING PASTURE TERRAIN WITH NATURAL DRAINAGE SWALES
 * Laser-graded smooth inside the building pad and approach apron,
 * and organically undulating in the surrounding open fields.
 */
export function createRollingPastureTerrain(buildingW: number, buildingL: number): THREE.Mesh {
  const geo = new THREE.PlaneGeometry(8000, 8000, 160, 160);
  const pos = geo.attributes.position;

  // Generous gravel pad and driveway footprint dimensions
  const padMargin = 14; // Full gravel apron extent around the building
  const padHalfW = buildingW / 2 + padMargin;
  const padHalfL = buildingL / 2 + padMargin;
  const padTransition = 5.0; // Clean bevel slope transition at perimeter

  const driveHalfW = Math.max(16, buildingW * 0.32);
  const driveMaxZ = padHalfL + 95;

  for (let i = 0; i < pos.count; i++) {
    const px = pos.getX(i);
    const pz = -pos.getY(i); // Local Y is world -Z in rotated PlaneGeometry

    // Distance to rectangular pad boundary (0 inside)
    const dx = Math.max(0, Math.abs(px) - padHalfW);
    const dz = Math.max(0, Math.abs(pz) - padHalfL);
    const distToPad = Math.sqrt(dx * dx + dz * dz);

    // Driveway corridor check
    const inDriveway = Math.abs(px) <= driveHalfW && pz >= padHalfL - 2 && pz <= driveMaxZ;
    const driveDx = Math.max(0, Math.abs(px) - driveHalfW);
    const driveDz = pz < padHalfL ? 0 : Math.max(0, pz - driveMaxZ);
    const distToDrive = Math.sqrt(driveDx * driveDx + driveDz * driveDz);

    let height = 0;

    if (distToPad === 0 || inDriveway) {
      // SUB-GRADE EXCAVATION:
      // Completely depressed underneath the gravel pad and driveway
      // Guarantees zero grass clipping, z-fighting, or grass blades on the gravel surface
      height = -1.2;
    } else if (distToPad < padTransition || (distToDrive < padTransition && pz >= padHalfL)) {
      // Smooth engineered grade transition from depressed pad base to turf grade
      const effectiveDist = Math.min(distToPad, pz >= padHalfL ? distToDrive : distToPad);
      const t = Math.min(1.0, effectiveDist / padTransition);
      height = -1.2 * (1.0 - t);
    } else {
      // Natural rolling pasture landscape beyond the site pad
      const distFromCenter = Math.sqrt(px * px + pz * pz);
      const pastureStartRadius = Math.max(padHalfW, padHalfL) + 30;

      if (distFromCenter > pastureStartRadius) {
        const blend = Math.min(1.0, Math.max(0.0, (distFromCenter - pastureStartRadius) / 90));
        const w1 = Math.sin(px * 0.005 + 0.3) * Math.cos(pz * 0.005 + 0.7) * 8.5;
        const w2 = Math.sin(px * 0.012 + 1.1) * 3.8;
        const w3 = Math.cos(pz * 0.010) * 3.0;
        height = (w1 + w2 + w3) * blend;
      } else {
        height = 0;
      }
    }

    pos.setZ(i, height);
  }

  geo.computeVertexNormals();

  const lawnMat = new THREE.MeshStandardMaterial({
    map: createGrassTexture(),
    bumpMap: createGrassBumpMap(),
    bumpScale: 0.04,
    roughness: 0.90,
    metalness: 0.02,
  });

  const terrain = new THREE.Mesh(geo, lawnMat);
  terrain.rotation.x = -Math.PI / 2;
  terrain.position.y = -0.04;
  terrain.receiveShadow = true;
  return terrain;
}

/**
 * Contact Shadow Plane directly beneath the building to eliminate any floating look
 */
export function createContactShadowPlane(buildingW: number, buildingL: number): THREE.Mesh {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#000000';
  ctx.fillRect(0, 0, 256, 256);

  const grad = ctx.createRadialGradient(128, 128, 85, 128, 128, 128);
  grad.addColorStop(0.0, 'rgba(0,0,0,0.55)');
  grad.addColorStop(0.65, 'rgba(0,0,0,0.3)');
  grad.addColorStop(1.0, 'rgba(0,0,0,0.0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 256, 256);

  const tex = new THREE.CanvasTexture(canvas);
  const geo = new THREE.PlaneGeometry(buildingW + 4, buildingL + 4);
  const mat = new THREE.MeshBasicMaterial({
    map: tex,
    transparent: true,
    opacity: 0.48,
    depthWrite: false,
  });

  const mesh = new THREE.Mesh(geo, mat);
  mesh.rotation.x = -Math.PI / 2;
  mesh.position.y = 0.09;
  return mesh;
}

/**
 * Architectural Scale Pickup Truck on the driveway
 */
export function createArchitecturalTruck(): THREE.Group {
  const truck = new THREE.Group();

  const bodyPaintMat = new THREE.MeshStandardMaterial({
    color: '#1e2631',
    roughness: 0.28,
    metalness: 0.72,
  });

  const glassMat = new THREE.MeshStandardMaterial({
    color: '#0f172a',
    roughness: 0.08,
    metalness: 0.92,
    transparent: true,
    opacity: 0.72,
  });

  const chromeMat = new THREE.MeshStandardMaterial({
    color: '#cbd5e1',
    roughness: 0.15,
    metalness: 0.95,
  });

  const tireRubberMat = new THREE.MeshStandardMaterial({
    color: '#18181b',
    roughness: 0.92,
    metalness: 0.08,
  });

  const wheelRimMat = new THREE.MeshStandardMaterial({
    color: '#94a3b8',
    roughness: 0.22,
    metalness: 0.88,
  });

  // Lower Body & Chassis Frame
  const lowerBodyGeo = new THREE.BoxGeometry(6.6, 1.3, 19.2);
  const lowerBody = new THREE.Mesh(lowerBodyGeo, bodyPaintMat);
  lowerBody.position.set(0, 2.1, 0);
  lowerBody.castShadow = true;
  lowerBody.receiveShadow = true;
  truck.add(lowerBody);

  // Hood & Front Fenders
  const hoodGeo = new THREE.BoxGeometry(6.4, 0.9, 5.8);
  const hood = new THREE.Mesh(hoodGeo, bodyPaintMat);
  hood.position.set(0, 3.1, 6.4);
  hood.castShadow = true;
  truck.add(hood);

  // Cabin Upper with raked windshield
  const cabGeo = new THREE.BoxGeometry(6.1, 2.2, 7.8);
  const cab = new THREE.Mesh(cabGeo, bodyPaintMat);
  cab.position.set(0, 4.3, 0.2);
  cab.castShadow = true;
  truck.add(cab);

  const windshieldGeo = new THREE.BoxGeometry(5.9, 1.8, 0.15);
  const windshield = new THREE.Mesh(windshieldGeo, glassMat);
  windshield.position.set(0, 4.25, 4.1);
  windshield.rotation.x = -0.32;
  truck.add(windshield);

  // Bed walls & tailgate
  const bedWallLeftGeo = new THREE.BoxGeometry(0.35, 1.6, 5.6);
  const bedWallLeft = new THREE.Mesh(bedWallLeftGeo, bodyPaintMat);
  bedWallLeft.position.set(-3.12, 3.4, -6.6);
  bedWallLeft.castShadow = true;
  truck.add(bedWallLeft);

  const bedWallRight = new THREE.Mesh(bedWallLeftGeo, bodyPaintMat);
  bedWallRight.position.set(3.12, 3.4, -6.6);
  bedWallRight.castShadow = true;
  truck.add(bedWallRight);

  const tailgateGeo = new THREE.BoxGeometry(6.4, 1.6, 0.35);
  const tailgate = new THREE.Mesh(tailgateGeo, bodyPaintMat);
  tailgate.position.set(0, 3.4, -9.4);
  tailgate.castShadow = true;
  truck.add(tailgate);

  // Wheels & Tires (4 corners)
  const wheelPositions = [
    { x: -3.2, z: 5.6 },
    { x: 3.2, z: 5.6 },
    { x: -3.2, z: -5.8 },
    { x: 3.2, z: -5.8 },
  ];

  const tireGeo = new THREE.CylinderGeometry(1.5, 1.5, 1.1, 16);
  const rimGeo = new THREE.CylinderGeometry(0.9, 0.9, 1.15, 12);

  wheelPositions.forEach((wp) => {
    const tire = new THREE.Mesh(tireGeo, tireRubberMat);
    tire.rotation.z = Math.PI / 2;
    tire.position.set(wp.x, 1.5, wp.z);
    tire.castShadow = true;
    truck.add(tire);

    const rim = new THREE.Mesh(rimGeo, wheelRimMat);
    rim.rotation.z = Math.PI / 2;
    rim.position.set(wp.x, 1.5, wp.z);
    truck.add(rim);
  });

  // Front Chrome Grille & Bumpers
  const grilleGeo = new THREE.BoxGeometry(5.8, 1.4, 0.4);
  const grille = new THREE.Mesh(grilleGeo, chromeMat);
  grille.position.set(0, 2.7, 9.4);
  grille.castShadow = true;
  truck.add(grille);

  return truck;
}
