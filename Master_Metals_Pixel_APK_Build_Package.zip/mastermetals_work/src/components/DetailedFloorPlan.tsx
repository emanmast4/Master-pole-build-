import React, { useState } from 'react';
import { CustomBuildingState, PricingBreakdown, WallOpening, WallSide } from '../types';
import { 
  Compass, 
  Layers, 
  Ruler, 
  ZoomIn, 
  ZoomOut, 
  RefreshCcw, 
  Table, 
  Printer, 
  CheckCircle2, 
  Maximize2,
  Info
} from 'lucide-react';

interface DetailedFloorPlanProps {
  state: CustomBuildingState;
  pricing: PricingBreakdown;
  className?: string;
}

export const DetailedFloorPlan: React.FC<DetailedFloorPlanProps> = ({
  state,
  pricing,
  className = '',
}) => {
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [showTrusses, setShowTrusses] = useState<boolean>(true);
  const [showDimensions, setShowDimensions] = useState<boolean>(true);
  const [showPosts, setShowPosts] = useState<boolean>(true);
  const [showSchedule, setShowSchedule] = useState<boolean>(true);
  const [showDiagonalCheck, setShowDiagonalCheck] = useState<boolean>(true);

  const { dimensions, materials, openings, leanTo, walls, interior } = state;
  const { width, length, eaveHeight, trussSpacing } = dimensions;

  // Calculate diagonal square check dimension (Pythagorean theorem)
  const diagonalLengthFt = Math.sqrt(Math.pow(width, 2) + Math.pow(length, 2));

  // Canvas size and architectural scale calculation
  const canvasWidth = 920;
  const canvasHeight = 560;

  // Padding to accommodate multi-tier dimension strings and title block
  const marginX = 140;
  const marginY = 110;
  const availWidth = canvasWidth - marginX * 2;
  const availHeight = canvasHeight - marginY * 2;

  // Scale factor (pixels per foot)
  const scale = Math.min(availWidth / length, availHeight / width);
  const planL = length * scale;
  const planW = width * scale;

  // Building top-left origin (building length along X axis, width along Y axis)
  // Front Wall = Bottom edge (Y = originY + planW)
  // Back Wall = Top edge (Y = originY)
  // Left Wall = Left edge (X = originX)
  // Right Wall = Right edge (X = originX + planL)
  const originX = (canvasWidth - planL) / 2;
  const originY = (canvasHeight - planW) / 2;

  // Bay & Post Calculations
  const bayCount = Math.max(1, Math.round(length / trussSpacing));
  const actualBaySpacingFt = length / bayCount;
  const baySpacingPx = actualBaySpacingFt * scale;

  // Wall Thickness (6" post-frame + 1.5" girts = 7.5" ~ 0.625 ft)
  const wallThickPx = Math.max(4, 0.625 * scale);

  // Zoom handlers
  const handleZoom = (delta: number) => {
    setZoomLevel((prev) => Math.min(2.0, Math.max(0.7, Number((prev + delta).toFixed(1)))));
  };
  const handleResetZoom = () => setZoomLevel(1);

  // Print trigger
  const handlePrint = () => {
    window.print();
  };

  // Helper to get formatted feet and inches
  const formatFtIn = (decimalFt: number) => {
    const feet = Math.floor(decimalFt);
    const inches = Math.round((decimalFt - feet) * 12);
    if (inches === 12) return `${feet + 1}'-0"`;
    if (inches === 0) return `${feet}'-0"`;
    return `${feet}'-${inches}"`;
  };

  // Door/Window Schedule Data
  const scheduleItems = openings.map((op, idx) => {
    const mark = op.type === 'overhead_door' ? `OH-${idx + 1}` : op.type === 'walk_door' ? `WD-${idx + 1}` : op.type === 'sliding_barn_door' ? `SD-${idx + 1}` : `WIN-${idx + 1}`;
    const sideName = op.side === 'front' ? 'Front Eave (S)' : op.side === 'back' ? 'Back Eave (N)' : op.side === 'left' ? 'Left Gable (W)' : 'Right Gable (E)';
    return {
      mark,
      type: op.label,
      size: `${op.widthFt}'W × ${op.heightFt}'H`,
      side: sideName,
      offset: `${op.positionOffsetFt}' from corner`,
      details: op.insulated ? 'Insulated' : op.hasWindows ? 'Window Inserts' : 'Standard',
    };
  });

  return (
    <div className={`bg-white border border-slate-200/90 rounded-xl overflow-hidden shadow-[0_4px_6px_-1px_rgba(0,0,0,0.1),0_2px_4px_-2px_rgba(0,0,0,0.06)] flex flex-col transition-colors duration-200 ${className}`}>
      {/* Layer Toggles & Zoom Controls */}
      <div className="bg-white px-3 sm:px-6 py-2 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2 text-[#0F172A]">
        <div className="flex flex-wrap items-center gap-1.5">
          {/* Layer toggles */}
          <div className="flex items-center gap-1 bg-slate-50 p-1 rounded-lg border border-slate-200 text-xs font-semibold">
            <button
              onClick={() => setShowTrusses(!showTrusses)}
              className={`relative px-2.5 py-1 rounded-md transition-all cursor-pointer active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0284C7] ${
                showTrusses
                  ? 'bg-sky-50 text-[#0F172A] font-black shadow-sm border-2 border-[#0284C7] ring-2 ring-[#0284C7]/25'
                  : 'text-slate-600 hover:text-[#0F172A] hover:bg-slate-200/60 font-semibold'
              }`}
              title="Toggle Truss Centerlines"
            >
              Trusses
              {showTrusses && (
                <span className="absolute -bottom-[2px] inset-x-2 h-0.5 bg-[#0284C7] rounded-full shadow-sm shadow-[#0284C7]/50" />
              )}
            </button>
            <button
              onClick={() => setShowPosts(!showPosts)}
              className={`relative px-2.5 py-1 rounded-md transition-all cursor-pointer active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0284C7] ${
                showPosts
                  ? 'bg-sky-50 text-[#0F172A] font-black shadow-sm border-2 border-[#0284C7] ring-2 ring-[#0284C7]/25'
                  : 'text-slate-600 hover:text-[#0F172A] hover:bg-slate-200/60 font-semibold'
              }`}
              title="Toggle 6x6 Timber Columns"
            >
              Posts
              {showPosts && (
                <span className="absolute -bottom-[2px] inset-x-2 h-0.5 bg-[#0284C7] rounded-full shadow-sm shadow-[#0284C7]/50" />
              )}
            </button>
            <button
              onClick={() => setShowDimensions(!showDimensions)}
              className={`relative px-2.5 py-1 rounded-md transition-all cursor-pointer active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0284C7] ${
                showDimensions
                  ? 'bg-sky-50 text-[#0F172A] font-black shadow-sm border-2 border-[#0284C7] ring-2 ring-[#0284C7]/25'
                  : 'text-slate-600 hover:text-[#0F172A] hover:bg-slate-200/60 font-semibold'
              }`}
              title="Toggle CAD Dimension Strings"
            >
              Dimensions
              {showDimensions && (
                <span className="absolute -bottom-[2px] inset-x-2 h-0.5 bg-[#0284C7] rounded-full shadow-sm shadow-[#0284C7]/50" />
              )}
            </button>
            <button
              onClick={() => setShowSchedule(!showSchedule)}
              className={`relative px-2.5 py-1 rounded-md transition-all cursor-pointer active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0284C7] ${
                showSchedule
                  ? 'bg-sky-50 text-[#0F172A] font-black shadow-sm border-2 border-[#0284C7] ring-2 ring-[#0284C7]/25'
                  : 'text-slate-600 hover:text-[#0F172A] hover:bg-slate-200/60 font-semibold'
              }`}
              title="Toggle Door & Window Schedule"
            >
              Schedule
              {showSchedule && (
                <span className="absolute -bottom-[2px] inset-x-2 h-0.5 bg-[#0284C7] rounded-full shadow-sm shadow-[#0284C7]/50" />
              )}
            </button>
          </div>

          {/* Zoom & Print */}
          <div className="flex items-center gap-1 pl-1 border-l border-slate-200">
            <button
              onClick={() => handleZoom(0.15)}
              className="p-1.5 text-slate-500 hover:text-[#0F172A] rounded-md hover:bg-slate-100 cursor-pointer active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0284C7]"
              title="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => handleZoom(-0.15)}
              className="p-1.5 text-slate-500 hover:text-[#0F172A] rounded-md hover:bg-slate-100 cursor-pointer active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0284C7]"
              title="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={handleResetZoom}
              className="p-1.5 text-slate-500 hover:text-[#0F172A] rounded-md hover:bg-slate-100 cursor-pointer active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0284C7]"
              title="Reset Zoom"
            >
              <RefreshCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Blueprint Visualizer Stage */}
      <div className="relative w-full overflow-hidden bg-white min-h-[480px] sm:min-h-[520px] flex items-center justify-center p-4">
        {/* Subtle Architectural Grid Background */}
        <div 
          className="absolute inset-0 opacity-40 pointer-events-none"
          style={{
            backgroundImage: `radial-gradient(#cbd5e1 1px, transparent 1px)`,
            backgroundSize: '24px 24px',
            backgroundPosition: '12px 12px',
          }}
        />

        {/* Blueprint SVG Canvas */}
        <div 
          className="w-full h-full flex items-center justify-center transition-transform duration-150"
          style={{ transform: `scale(${zoomLevel})` }}
        >
          <svg
            viewBox={`0 0 ${canvasWidth} ${canvasHeight}`}
            className="w-full h-full max-h-[580px] drop-shadow-md"
            preserveAspectRatio="xMidYMid meet"
          >
            <defs>
              {/* Concrete Slab Texture Pattern */}
              <pattern id="concreteHatch" width="16" height="16" patternUnits="userSpaceOnUse">
                <circle cx="4" cy="4" r="0.8" fill="#94a3b8" opacity="0.25" />
                <circle cx="12" cy="12" r="0.8" fill="#94a3b8" opacity="0.25" />
                <circle cx="12" cy="4" r="0.5" fill="#94a3b8" opacity="0.2" />
                <circle cx="4" cy="12" r="0.5" fill="#94a3b8" opacity="0.2" />
              </pattern>

              {/* Loft Mezzanine Floor Joist Pattern */}
              <pattern id="joistHatch" width="12" height="12" patternUnits="userSpaceOnUse">
                <line x1="0" y1="0" x2="12" y2="0" stroke="#d97706" strokeWidth="0.8" opacity="0.4" strokeDasharray="3 3" />
              </pattern>

              {/* Dimension Arrowhead Markers */}
              <marker id="dimTick" markerWidth="6" markerHeight="6" refX="3" refY="3">
                <line x1="0" y1="6" x2="6" y2="0" stroke="#0284c7" strokeWidth="1.3" />
              </marker>
              <marker id="dimTickAmber" markerWidth="6" markerHeight="6" refX="3" refY="3">
                <line x1="0" y1="6" x2="6" y2="0" stroke="#d97706" strokeWidth="1.3" />
              </marker>
            </defs>

            {/* 1. LEAN-TO PORCH EXTENSION (If enabled) */}
            {leanTo.enabled && (() => {
              const ltW = leanTo.widthFt * scale;
              let pX = originX;
              let pY = originY;
              let pWidth = planL;
              let pHeight = ltW;

              if (leanTo.side === 'left') {
                pX = originX - ltW;
                pY = originY;
                pWidth = ltW;
                pHeight = planW;
              } else if (leanTo.side === 'right') {
                pX = originX + planL;
                pY = originY;
                pWidth = ltW;
                pHeight = planW;
              } else if (leanTo.side === 'front') {
                pX = originX;
                pY = originY + planW;
                pWidth = planL;
                pHeight = ltW;
              }

              return (
                <g id="lean-to-footprint">
                  {/* Porch Slab/Gravel Area */}
                  <rect
                    x={pX}
                    y={pY}
                    width={pWidth}
                    height={pHeight}
                    fill="#fef3c7"
                    opacity="0.5"
                    stroke="#d97706"
                    strokeWidth="1.5"
                    strokeDasharray="4 4"
                  />
                  {/* Porch Label */}
                  <text
                    x={pX + pWidth / 2}
                    y={pY + pHeight / 2}
                    fill="#b45309"
                    fontSize="10"
                    fontFamily="monospace"
                    fontWeight="bold"
                    textAnchor="middle"
                  >
                    LEAN-TO PORCH ({leanTo.widthFt}' × {leanTo.side === 'front' ? length : width}')
                  </text>
                  <text
                    x={pX + pWidth / 2}
                    y={pY + pHeight / 2 + 14}
                    fill="#92400e"
                    fontSize="8"
                    fontFamily="monospace"
                    textAnchor="middle"
                    fontWeight="bold"
                  >
                    {leanTo.enclosed ? 'ENCLOSED EXTENSION' : 'OPEN PORCH WITH 6x6 TIMBER POSTS'}
                  </text>

                  {/* Porch Exterior Posts */}
                  {(() => {
                    const porchPosts = [];
                    const pBayCount = Math.max(1, Math.round((leanTo.side === 'front' ? length : width) / 10));
                    const pPostSpacing = (leanTo.side === 'front' ? planL : planW) / pBayCount;

                    for (let i = 0; i <= pBayCount; i++) {
                      if (leanTo.side === 'front') {
                        porchPosts.push({ x: pX + i * pPostSpacing, y: pY + pHeight });
                      } else if (leanTo.side === 'left') {
                        porchPosts.push({ x: pX, y: pY + i * pPostSpacing });
                      } else if (leanTo.side === 'right') {
                        porchPosts.push({ x: pX + pWidth, y: pY + i * pPostSpacing });
                      }
                    }

                    return porchPosts.map((pp, idx) => (
                      <g key={`porch-post-${idx}`}>
                        <rect
                          x={pp.x - 3}
                          y={pp.y - 3}
                          width="6"
                          height="6"
                          fill="#d97706"
                          stroke="#1e293b"
                          strokeWidth="0.8"
                        />
                        {/* Pier outline */}
                        <circle cx={pp.x} cy={pp.y} r="5" fill="none" stroke="#d97706" strokeWidth="0.6" strokeDasharray="2 2" />
                      </g>
                    ));
                  })()}
                </g>
              );
            })()}

            {/* 2. CONCRETE SLAB SLAB OUTLINE & MONOLITHIC FOOTING */}
            {/* Outer Footing Line */}
            <rect
              x={originX - wallThickPx / 2}
              y={originY - wallThickPx / 2}
              width={planL + wallThickPx}
              height={planW + wallThickPx}
              fill="none"
              stroke="#0284c7"
              strokeWidth="0.8"
              strokeDasharray="4 3"
            />

            {/* Interior Concrete Slab Floor */}
            <rect
              x={originX}
              y={originY}
              width={planL}
              height={planW}
              fill="#f8fafc"
              stroke="#0284c7"
              strokeWidth="2"
            />
            {/* Concrete Hatch */}
            <rect
              x={originX}
              y={originY}
              width={planL}
              height={planW}
              fill="url(#concreteHatch)"
              pointerEvents="none"
            />

            {/* 3. ROOF OVERHANG PERIMETER (12" Eave & Rake Overhang Dashed) */}
            {(() => {
              const ohPx = 1.0 * scale; // 12" overhang
              return (
                <rect
                  x={originX - ohPx}
                  y={originY - ohPx}
                  width={planL + ohPx * 2}
                  height={planW + ohPx * 2}
                  fill="none"
                  stroke="#94a3b8"
                  strokeWidth="1"
                  strokeDasharray="6 4"
                />
              );
            })()}

            {/* 4. CLEAR-SPAN ROOF TRUSS CENTERLINES */}
            {showTrusses && (
              <g id="truss-centerlines">
                {Array.from({ length: bayCount + 1 }).map((_, idx) => {
                  const tx = originX + idx * baySpacingPx;
                  const isEndTruss = idx === 0 || idx === bayCount;
                  return (
                    <g key={`truss-${idx}`}>
                      <line
                        x1={tx}
                        y1={originY}
                        x2={tx}
                        y2={originY + planW}
                        stroke={isEndTruss ? '#0284c7' : '#94a3b8'}
                        strokeWidth={isEndTruss ? '1.5' : '1'}
                        strokeDasharray={isEndTruss ? 'none' : '5 4'}
                      />
                      {/* Truss Mark Label */}
                      <text
                        x={tx}
                        y={originY - 8}
                        fill={isEndTruss ? '#0284c7' : '#64748b'}
                        fontSize="8"
                        fontFamily="monospace"
                        fontWeight="bold"
                        textAnchor="middle"
                      >
                        T-{idx + 1}
                      </text>
                    </g>
                  );
                })}

                {/* Truss Spacing Callout in center bay */}
                {bayCount > 1 && (
                  <g transform={`translate(${originX + baySpacingPx / 2}, ${originY + 18})`}>
                    <line x1={-baySpacingPx / 2 + 3} y1="0" x2={baySpacingPx / 2 - 3} y2="0" stroke="#d97706" strokeWidth="1" />
                    <text x="0" y="-4" fill="#b45309" fontSize="8" fontFamily="monospace" fontWeight="bold" textAnchor="middle">
                      {formatFtIn(actualBaySpacingFt)} O.C. TRUSS
                    </text>
                  </g>
                )}
              </g>
            )}

            {/* 5. STORAGE LOFT MEZZANINE (If configured in Interior) */}
            {interior.loft !== 'none' && (() => {
              const loftRatio = interior.loft === 'quarter_loft' ? 0.25 : interior.loft === 'half_loft' ? 0.5 : 1.0;
              const loftL = planL * loftRatio;
              const loftX = originX + planL - loftL; // positioned along rear / east bay
              return (
                <g id="storage-loft-mezzanine">
                  <rect
                    x={loftX}
                    y={originY}
                    width={loftL}
                    height={planW}
                    fill="url(#joistHatch)"
                    stroke="#d97706"
                    strokeWidth="1.5"
                    strokeDasharray="6 3"
                  />
                  {/* Loft Girders & Edge Beam */}
                  <line x1={loftX} y1={originY} x2={loftX} y2={originY + planW} stroke="#d97706" strokeWidth="2.5" />
                  
                  {/* Loft Text Badge */}
                  <rect
                    x={loftX + loftL / 2 - 60}
                    y={originY + planW * 0.25 - 10}
                    width="120"
                    height="32"
                    fill="#ffffff"
                    stroke="#d97706"
                    strokeWidth="1.2"
                    rx="4"
                  />
                  <text
                    x={loftX + loftL / 2}
                    y={originY + planW * 0.25 + 2}
                    fill="#b45309"
                    fontSize="9"
                    fontFamily="monospace"
                    fontWeight="bold"
                    textAnchor="middle"
                  >
                    STORAGE LOFT MEZZANINE
                  </text>
                  <text
                    x={loftX + loftL / 2}
                    y={originY + planW * 0.25 + 14}
                    fill="#92400e"
                    fontSize="7.5"
                    fontFamily="monospace"
                    textAnchor="middle"
                    fontWeight="bold"
                  >
                    8'-0" CLEAR HEADROOM UNDER
                  </text>

                  {/* Access Ladder / Stair Footprint */}
                  <rect
                    x={loftX - 14}
                    y={originY + planW - 40}
                    width="14"
                    height="30"
                    fill="#ffffff"
                    stroke="#d97706"
                    strokeWidth="1"
                  />
                  <text
                    x={loftX - 7}
                    y={originY + planW - 22}
                    fill="#b45309"
                    fontSize="7"
                    fontFamily="monospace"
                    textAnchor="middle"
                    fontWeight="bold"
                    transform={`rotate(-90, ${loftX - 7}, ${originY + planW - 22})`}
                  >
                    STAIR
                  </text>
                </g>
              );
            })()}

            {/* 6. EXTERIOR WALL ENVELOPE (Continuous Girts & 36" Ag-Panels) */}
            {/* Exterior Double-Line Architectural Wall Framing */}
            <rect
              x={originX - wallThickPx}
              y={originY - wallThickPx}
              width={planL + wallThickPx * 2}
              height={planW + wallThickPx * 2}
              fill="none"
              stroke="#0284c7"
              strokeWidth="2.5"
            />
            {/* Inner Wall Face */}
            <rect
              x={originX}
              y={originY}
              width={planL}
              height={planW}
              fill="none"
              stroke="#0284c7"
              strokeWidth="1.2"
            />

            {/* 36" Ag-Panel Modular Lap Markers along bottom eave wall */}
            {Array.from({ length: Math.floor(length / 3) }).map((_, pIdx) => {
              const px = originX + pIdx * 3 * scale;
              return (
                <line
                  key={`panel-tick-${pIdx}`}
                  x1={px}
                  y1={originY + planW}
                  x2={px}
                  y2={originY + planW + wallThickPx}
                  stroke="#0284c7"
                  strokeWidth="0.8"
                  opacity="0.6"
                />
              );
            })}

            {/* 6B. WEIGHT-BEARING WALL HEADERS ((2) 2x12s for 8' O.C. Posts along North & South Eave Walls) */}
            <g id="weight-bearing-wall-headers">
              {/* Back Eave Wall (North) Double 2x12 Header Plies */}
              <line
                x1={originX}
                y1={originY - 2.5}
                x2={originX + planL}
                y2={originY - 2.5}
                stroke="#d97706"
                strokeWidth="1.8"
              />
              <line
                x1={originX}
                y1={originY + 2.5}
                x2={originX + planL}
                y2={originY + 2.5}
                stroke="#d97706"
                strokeWidth="1.8"
              />
              {/* Front Eave Wall (South) Double 2x12 Header Plies */}
              <line
                x1={originX}
                y1={originY + planW - 2.5}
                x2={originX + planL}
                y2={originY + planW - 2.5}
                stroke="#d97706"
                strokeWidth="1.8"
              />
              <line
                x1={originX}
                y1={originY + planW + 2.5}
                x2={originX + planL}
                y2={originY + planW + 2.5}
                stroke="#d97706"
                strokeWidth="1.8"
              />
            </g>

            {/* 6C. ATTACHED LEAN-TO PORCH CAD FOOTPRINT & TIMBER POSTS */}
            {leanTo?.enabled && (() => {
              const hostWallLength = leanTo.side === 'front' || leanTo.side === 'back' ? width : length;
              const ltL = Math.min(hostWallLength, leanTo.lengthFt || hostWallLength);
              const ltW = leanTo.widthFt || 10;
              const maxOff = Math.max(0, hostWallLength - ltL);
              const ltOff = Math.max(0, Math.min(maxOff, leanTo.startOffsetFt ?? 0));

              let padX = originX;
              let padY = originY;
              let padW = 0;
              let padH = 0;
              const postList: { x: number; y: number }[] = [];
              const postCnt = Math.max(2, Math.ceil(ltL / 10) + 1);

              if (leanTo.side === 'right') {
                padX = originX + planL;
                padY = originY + ltOff * scale;
                padW = ltW * scale;
                padH = ltL * scale;
                const outerX = padX + padW;
                for (let i = 0; i < postCnt; i++) {
                  postList.push({ x: outerX, y: padY + (i / (postCnt - 1)) * padH });
                }
              } else if (leanTo.side === 'left') {
                padX = originX - ltW * scale;
                padY = originY + ltOff * scale;
                padW = ltW * scale;
                padH = ltL * scale;
                const outerX = padX;
                for (let i = 0; i < postCnt; i++) {
                  postList.push({ x: outerX, y: padY + (i / (postCnt - 1)) * padH });
                }
              } else if (leanTo.side === 'front') {
                padX = originX + ltOff * scale;
                padY = originY + planW;
                padW = ltL * scale;
                padH = ltW * scale;
                const outerY = padY + padH;
                for (let i = 0; i < postCnt; i++) {
                  postList.push({ x: padX + (i / (postCnt - 1)) * padW, y: outerY });
                }
              } else if (leanTo.side === 'back') {
                padX = originX + ltOff * scale;
                padY = originY - ltW * scale;
                padW = ltL * scale;
                padH = ltW * scale;
                const outerY = padY;
                for (let i = 0; i < postCnt; i++) {
                  postList.push({ x: padX + (i / (postCnt - 1)) * padW, y: outerY });
                }
              }

              return (
                <g id="lean-to-floor-plan">
                  {/* Concrete Pad Outline */}
                  <rect
                    x={padX}
                    y={padY}
                    width={padW}
                    height={padH}
                    fill="#fef3c7"
                    fillOpacity="0.4"
                    stroke="#d97706"
                    strokeWidth="1.5"
                    strokeDasharray={leanTo.enclosed ? 'none' : '4 3'}
                  />
                  {/* Timber columns along outer edge */}
                  {postList.map((pt, pIdx) => (
                    <rect
                      key={pIdx}
                      x={pt.x - 3}
                      y={pt.y - 3}
                      width="6"
                      height="6"
                      fill="#d97706"
                      stroke="#1e293b"
                      strokeWidth="0.8"
                    />
                  ))}
                  {/* Porch text annotation */}
                  <text
                    x={padX + padW / 2}
                    y={padY + padH / 2 + 3}
                    fill="#b45309"
                    fontSize="8"
                    fontFamily="monospace"
                    fontWeight="bold"
                    textAnchor="middle"
                  >
                    LEAN-TO: {ltW}' × {ltL}' ({leanTo.enclosed ? 'ENCLOSED' : 'OPEN PORCH'})
                  </text>
                </g>
              );
            })()}

            {/* 7. WALL ORIENTATION LABELS */}
            <g id="wall-labels" fontFamily="monospace" fontSize="8.5" fontWeight="bold">
              {/* Front Wall (South) */}
              <text x={originX + planL / 2} y={originY + planW + 28} fill="#b45309" textAnchor="middle">
                FRONT EAVE WEIGHT-BEARING WALL — (2) 2x12 HEADERS @ {dimensions.postSpacing || 8}' O.C. POSTS
              </text>
              {/* Back Wall (North) */}
              <text x={originX + planL / 2} y={originY - 26} fill="#b45309" textAnchor="middle">
                BACK EAVE WEIGHT-BEARING WALL — (2) 2x12 HEADERS @ {dimensions.postSpacing || 8}' O.C. POSTS
              </text>
              {/* Left Wall (West) */}
              <text
                x={originX - 32}
                y={originY + planW / 2}
                fill="#475569"
                textAnchor="middle"
                transform={`rotate(-90, ${originX - 32}, ${originY + planW / 2})`}
              >
                LEFT GABLE ENDWALL (WEST)
              </text>
              {/* Right Wall (East) */}
              <text
                x={originX + planL + 32}
                y={originY + planW / 2}
                fill="#475569"
                textAnchor="middle"
                transform={`rotate(90, ${originX + planL + 32}, ${originY + planW / 2})`}
              >
                RIGHT GABLE ENDWALL (EAST)
              </text>
            </g>

            {/* 8. 6x6 TIMBER POST COLUMNS */}
            {showPosts && (() => {
              const posts: { x: number; y: number; tag: string }[] = [];
              // Corners
              posts.push({ x: originX, y: originY, tag: 'C1' });
              posts.push({ x: originX + planL, y: originY, tag: 'C2' });
              posts.push({ x: originX + planL, y: originY + planW, tag: 'C3' });
              posts.push({ x: originX, y: originY + planW, tag: 'C4' });

              // Sidewall eave posts
              for (let i = 1; i < bayCount; i++) {
                const px = originX + i * baySpacingPx;
                posts.push({ x: px, y: originY, tag: `P-N${i}` });
                posts.push({ x: px, y: originY + planW, tag: `P-S${i}` });
              }

              // Endwall gable posts (spaced every 10-12ft)
              const endwallBayCount = Math.max(1, Math.round(width / 12));
              const endwallSpacing = planW / endwallBayCount;
              for (let j = 1; j < endwallBayCount; j++) {
                const py = originY + j * endwallSpacing;
                posts.push({ x: originX, y: py, tag: `P-W${j}` });
                posts.push({ x: originX + planL, y: py, tag: `P-E${j}` });
              }

              return posts.map((post, pIdx) => (
                <g key={`col-${pIdx}`}>
                  <rect
                    x={post.x - 3.5}
                    y={post.y - 3.5}
                    width="7"
                    height="7"
                    fill="#d97706"
                    stroke="#1e293b"
                    strokeWidth="1"
                  />
                  {/* Concrete footing pier dashed ring */}
                  <circle
                    cx={post.x}
                    cy={post.y}
                    r="6.5"
                    fill="none"
                    stroke="#d97706"
                    strokeWidth="0.6"
                    strokeDasharray="2 2"
                  />
                </g>
              ));
            })()}

            {/* 9. DOORS & WINDOWS ARCHITECTURAL OPENING SYMBOLS */}
            <g id="openings-blueprint">
              {openings.map((op, idx) => {
                const mark = op.type === 'overhead_door' ? `OH-${idx + 1}` : op.type === 'walk_door' ? `WD-${idx + 1}` : op.type === 'sliding_barn_door' ? `SD-${idx + 1}` : `W-${idx + 1}`;
                const opLen = op.widthFt * scale;

                // Determine position on the appropriate wall
                let wallX = originX;
                let wallY = originY;
                let isHorizontal = true;

                if (op.side === 'front') {
                  wallX = originX + op.positionOffsetFt * scale;
                  wallY = originY + planW;
                  isHorizontal = true;
                } else if (op.side === 'back') {
                  wallX = originX + (length - op.positionOffsetFt - op.widthFt) * scale;
                  wallY = originY;
                  isHorizontal = true;
                } else if (op.side === 'left') {
                  wallX = originX;
                  wallY = originY + op.positionOffsetFt * scale;
                  isHorizontal = false;
                } else if (op.side === 'right') {
                  wallX = originX + planL;
                  wallY = originY + (width - op.positionOffsetFt - op.widthFt) * scale;
                  isHorizontal = false;
                }

                // A. OVERHEAD GARAGE DOOR (Sectional door + ceiling horizontal tracks)
                if (op.type === 'overhead_door') {
                  const trackRunPx = Math.min(planW * 0.7, (op.heightFt + 1) * scale);
                  return (
                    <g key={`op-${op.id}`}>
                      {/* Wall cutout (clear opening) */}
                      {isHorizontal ? (
                        <>
                          <rect x={wallX} y={wallY - wallThickPx} width={opLen} height={wallThickPx * 2} fill="#f8fafc" />
                          {/* Door panel line */}
                          <line x1={wallX} y1={wallY} x2={wallX + opLen} y2={wallY} stroke="#0284c7" strokeWidth="3" />
                          {/* Jamb Posts */}
                          <rect x={wallX - 3} y={wallY - 3} width="6" height="6" fill="#d97706" stroke="#1e293b" strokeWidth="0.8" />
                          <rect x={wallX + opLen - 3} y={wallY - 3} width="6" height="6" fill="#d97706" stroke="#1e293b" strokeWidth="0.8" />
                          {/* Ceiling tracks extending into building */}
                          {op.side === 'front' ? (
                            <>
                              <line x1={wallX} y1={wallY} x2={wallX} y2={wallY - trackRunPx} stroke="#0284c7" strokeWidth="1" strokeDasharray="3 3" />
                              <line x1={wallX + opLen} y1={wallY} x2={wallX + opLen} y2={wallY - trackRunPx} stroke="#0284c7" strokeWidth="1" strokeDasharray="3 3" />
                              <line x1={wallX} y1={wallY - trackRunPx} x2={wallX + opLen} y2={wallY - trackRunPx} stroke="#94a3b8" strokeWidth="1" strokeDasharray="2 2" />
                            </>
                          ) : (
                            <>
                              <line x1={wallX} y1={wallY} x2={wallX} y2={wallY + trackRunPx} stroke="#0284c7" strokeWidth="1" strokeDasharray="3 3" />
                              <line x1={wallX + opLen} y1={wallY} x2={wallX + opLen} y2={wallY + trackRunPx} stroke="#0284c7" strokeWidth="1" strokeDasharray="3 3" />
                              <line x1={wallX} y1={wallY + trackRunPx} x2={wallX + opLen} y2={wallY + trackRunPx} stroke="#94a3b8" strokeWidth="1" strokeDasharray="2 2" />
                            </>
                          )}
                          {/* Mark Tag Badge */}
                          <rect x={wallX + opLen / 2 - 14} y={op.side === 'front' ? wallY + 8 : wallY - 18} width="28" height="12" fill="#ffffff" stroke="#0284c7" strokeWidth="0.8" rx="2" />
                          <text x={wallX + opLen / 2} y={op.side === 'front' ? wallY + 17 : wallY - 9} fill="#0284c7" fontSize="8" fontFamily="monospace" fontWeight="bold" textAnchor="middle">
                            {mark}
                          </text>
                        </>
                      ) : (
                        <>
                          <rect x={wallX - wallThickPx} y={wallY} width={wallThickPx * 2} height={opLen} fill="#f8fafc" />
                          <line x1={wallX} y1={wallY} x2={wallX} y2={wallY + opLen} stroke="#0284c7" strokeWidth="3" />
                          {/* Ceiling tracks extending horizontally into building */}
                          {op.side === 'left' ? (
                            <>
                              <line x1={wallX} y1={wallY} x2={wallX + trackRunPx} y2={wallY} stroke="#0284c7" strokeWidth="1" strokeDasharray="3 3" />
                              <line x1={wallX} y1={wallY + opLen} x2={wallX + trackRunPx} y2={wallY + opLen} stroke="#0284c7" strokeWidth="1" strokeDasharray="3 3" />
                            </>
                          ) : (
                            <>
                              <line x1={wallX} y1={wallY} x2={wallX - trackRunPx} y2={wallY} stroke="#0284c7" strokeWidth="1" strokeDasharray="3 3" />
                              <line x1={wallX} y1={wallY + opLen} x2={wallX - trackRunPx} y2={wallY + opLen} stroke="#0284c7" strokeWidth="1" strokeDasharray="3 3" />
                            </>
                          )}
                          <rect x={op.side === 'left' ? wallX - 22 : wallX + 4} y={wallY + opLen / 2 - 6} width="24" height="12" fill="#ffffff" stroke="#0284c7" strokeWidth="0.8" rx="2" />
                          <text x={op.side === 'left' ? wallX - 10 : wallX + 16} y={wallY + opLen / 2 + 3} fill="#0284c7" fontSize="8" fontFamily="monospace" fontWeight="bold" textAnchor="middle">
                            {mark}
                          </text>
                        </>
                      )}
                    </g>
                  );
                }

                // B. WALK DOOR (Swing leaf + 90 degree door swing arc)
                if (op.type === 'walk_door') {
                  const doorSwingR = opLen;
                  return (
                    <g key={`op-${op.id}`}>
                      {isHorizontal ? (
                        <>
                          <rect x={wallX} y={wallY - wallThickPx} width={opLen} height={wallThickPx * 2} fill="#f8fafc" />
                          {/* Door frame jambs */}
                          <circle cx={wallX} cy={wallY} r="2.5" fill="#d97706" />
                          <circle cx={wallX + opLen} cy={wallY} r="2.5" fill="#d97706" />
                          {/* Door leaf swinging inside */}
                          <line
                            x1={wallX}
                            y1={wallY}
                            x2={wallX}
                            y2={op.side === 'front' ? wallY - doorSwingR : wallY + doorSwingR}
                            stroke="#d97706"
                            strokeWidth="2"
                          />
                          {/* 90-degree swing arc */}
                          <path
                            d={op.side === 'front' 
                              ? `M ${wallX + opLen} ${wallY} A ${doorSwingR} ${doorSwingR} 0 0 1 ${wallX} ${wallY - doorSwingR}`
                              : `M ${wallX + opLen} ${wallY} A ${doorSwingR} ${doorSwingR} 0 0 0 ${wallX} ${wallY + doorSwingR}`
                            }
                            fill="none"
                            stroke="#d97706"
                            strokeWidth="1"
                            strokeDasharray="2 2"
                            opacity="0.9"
                          />
                          {/* Tag */}
                          <text x={wallX + opLen / 2} y={op.side === 'front' ? wallY + 12 : wallY - 8} fill="#b45309" fontSize="7.5" fontFamily="monospace" fontWeight="bold" textAnchor="middle">
                            {mark}
                          </text>
                        </>
                      ) : (
                        <>
                          <rect x={wallX - wallThickPx} y={wallY} width={wallThickPx * 2} height={opLen} fill="#f8fafc" />
                          <line
                            x1={wallX}
                            y1={wallY}
                            x2={op.side === 'left' ? wallX + doorSwingR : wallX - doorSwingR}
                            y2={wallY}
                            stroke="#d97706"
                            strokeWidth="2"
                          />
                          <path
                            d={op.side === 'left'
                              ? `M ${wallX} ${wallY + opLen} A ${doorSwingR} ${doorSwingR} 0 0 1 ${wallX + doorSwingR} ${wallY}`
                              : `M ${wallX} ${wallY + opLen} A ${doorSwingR} ${doorSwingR} 0 0 0 ${wallX - doorSwingR} ${wallY}`
                            }
                            fill="none"
                            stroke="#d97706"
                            strokeWidth="1"
                            strokeDasharray="2 2"
                            opacity="0.9"
                          />
                          <text x={op.side === 'left' ? wallX - 10 : wallX + 12} y={wallY + opLen / 2} fill="#b45309" fontSize="7.5" fontFamily="monospace" fontWeight="bold" textAnchor="middle">
                            {mark}
                          </text>
                        </>
                      )}
                    </g>
                  );
                }

                // C. SLIDING BARN DOOR (Track mounted on exterior face + split sliding leaves)
                if (op.type === 'sliding_barn_door') {
                  return (
                    <g key={`op-${op.id}`}>
                      {isHorizontal ? (
                        <>
                          <rect x={wallX} y={wallY - wallThickPx} width={opLen} height={wallThickPx * 2} fill="#f8fafc" />
                          {/* Exterior Rail Track */}
                          <line
                            x1={wallX - 8}
                            y1={op.side === 'front' ? wallY + wallThickPx + 3 : wallY - wallThickPx - 3}
                            x2={wallX + opLen + 8}
                            y2={op.side === 'front' ? wallY + wallThickPx + 3 : wallY - wallThickPx - 3}
                            stroke="#64748b"
                            strokeWidth="2"
                          />
                          {/* Sliding Leaf Panel */}
                          <rect
                            x={wallX}
                            y={op.side === 'front' ? wallY + 2 : wallY - 6}
                            width={opLen}
                            height="4"
                            fill="#e2e8f0"
                            stroke="#0284c7"
                            strokeWidth="1.2"
                          />
                          <text x={wallX + opLen / 2} y={op.side === 'front' ? wallY + 16 : wallY - 10} fill="#0284c7" fontSize="7.5" fontFamily="monospace" fontWeight="bold" textAnchor="middle">
                            {mark} (SLIDER)
                          </text>
                        </>
                      ) : (
                        <>
                          <rect x={wallX - wallThickPx} y={wallY} width={wallThickPx * 2} height={opLen} fill="#f8fafc" />
                          <rect
                            x={op.side === 'left' ? wallX - 6 : wallX + 2}
                            y={wallY}
                            width="4"
                            height={opLen}
                            fill="#e2e8f0"
                            stroke="#0284c7"
                            strokeWidth="1.2"
                          />
                          <text x={op.side === 'left' ? wallX - 16 : wallX + 18} y={wallY + opLen / 2} fill="#0284c7" fontSize="7.5" fontFamily="monospace" fontWeight="bold" textAnchor="middle">
                            {mark}
                          </text>
                        </>
                      )}
                    </g>
                  );
                }

                // D. WINDOW (Glazing lines & sill indicators)
                if (op.type === 'window') {
                  return (
                    <g key={`op-${op.id}`}>
                      {isHorizontal ? (
                        <>
                          {/* Window Opening */}
                          <rect x={wallX} y={wallY - wallThickPx} width={opLen} height={wallThickPx * 2} fill="#f8fafc" />
                          {/* Glass Line */}
                          <line x1={wallX} y1={wallY} x2={wallX + opLen} y2={wallY} stroke="#0284c7" strokeWidth="2" />
                          {/* Window Sill */}
                          <line
                            x1={wallX - 2}
                            y1={op.side === 'front' ? wallY + wallThickPx : wallY - wallThickPx}
                            x2={wallX + opLen + 2}
                            y2={op.side === 'front' ? wallY + wallThickPx : wallY - wallThickPx}
                            stroke="#64748b"
                            strokeWidth="1.5"
                          />
                          <text x={wallX + opLen / 2} y={op.side === 'front' ? wallY + 12 : wallY - 7} fill="#0284c7" fontSize="7" fontFamily="monospace" textAnchor="middle">
                            {mark}
                          </text>
                        </>
                      ) : (
                        <>
                          <rect x={wallX - wallThickPx} y={wallY} width={wallThickPx * 2} height={opLen} fill="#f8fafc" />
                          <line x1={wallX} y1={wallY} x2={wallX} y2={wallY + opLen} stroke="#0284c7" strokeWidth="2" />
                          <text x={op.side === 'left' ? wallX - 10 : wallX + 12} y={wallY + opLen / 2} fill="#0284c7" fontSize="7" fontFamily="monospace" textAnchor="middle">
                            {mark}
                          </text>
                        </>
                      )}
                    </g>
                  );
                }

                return null;
              })}
            </g>

            {/* 10. DIAGONAL SQUARENESS CHECK (Pythagorean check dimension) */}
            {showDiagonalCheck && (
              <g id="diagonal-square-check" opacity="0.6">
                <line
                  x1={originX}
                  y1={originY}
                  x2={originX + planL}
                  y2={originY + planW}
                  stroke="#0284c7"
                  strokeWidth="1.2"
                  strokeDasharray="4 4"
                />
                <g transform={`translate(${originX + planL / 2}, ${originY + planW / 2 - 20})`}>
                  <rect x="-65" y="-9" width="130" height="18" fill="#ffffff" stroke="#0284c7" strokeWidth="0.8" rx="3" />
                  <text x="0" y="3.5" fill="#0284c7" fontSize="8" fontFamily="monospace" fontWeight="bold" textAnchor="middle">
                    DIAG: {formatFtIn(diagonalLengthFt)} (SQ CHECK)
                  </text>
                </g>
              </g>
            )}

            {/* 11. ARCHITECTURAL CAD DIMENSIONS */}
            {showDimensions && (
              <g id="dimension-strings" fontFamily="monospace" fontSize="9" fontWeight="bold">
                {/* A. Overall Building Length (Top Tier) */}
                <g id="dim-overall-length">
                  {/* Extension lines */}
                  <line x1={originX} y1={originY - wallThickPx} x2={originX} y2={originY - 55} stroke="#0284c7" strokeWidth="0.8" opacity="0.6" />
                  <line x1={originX + planL} y1={originY - wallThickPx} x2={originX + planL} y2={originY - 55} stroke="#0284c7" strokeWidth="0.8" opacity="0.6" />
                  {/* Dimension line with ticks */}
                  <line x1={originX} y1={originY - 45} x2={originX + planL} y2={originY - 45} stroke="#0284c7" strokeWidth="1.5" markerStart="url(#dimTick)" markerEnd="url(#dimTick)" />
                  {/* Dimension Text Badge */}
                  <rect x={originX + planL / 2 - 45} y={originY - 54} width="90" height="18" fill="#ffffff" stroke="#0284c7" strokeWidth="1" rx="4" />
                  <text x={originX + planL / 2} y={originY - 41.5} fill="#0284c7" fontSize="10" textAnchor="middle">
                    {length}'-0" LENGTH
                  </text>
                </g>

                {/* B. Bay Spacing String (Middle Tier along Top Eave) */}
                {bayCount > 1 && (
                  <g id="dim-bay-spacing">
                    {Array.from({ length: bayCount }).map((_, bIdx) => {
                      const bx1 = originX + bIdx * baySpacingPx;
                      const bx2 = bx1 + baySpacingPx;
                      return (
                        <g key={`bay-dim-${bIdx}`}>
                          <line x1={bx1} y1={originY - 24} x2={bx2} y2={originY - 24} stroke="#d97706" strokeWidth="1" markerStart="url(#dimTickAmber)" markerEnd="url(#dimTickAmber)" />
                          <text x={(bx1 + bx2) / 2} y={originY - 28} fill="#b45309" fontSize="7.5" textAnchor="middle">
                            {formatFtIn(actualBaySpacingFt)}
                          </text>
                        </g>
                      );
                    })}
                  </g>
                )}

                {/* C. Overall Building Width (Left Tier) */}
                <g id="dim-overall-width">
                  <line x1={originX - wallThickPx} y1={originY} x2={originX - 65} y2={originY} stroke="#0284c7" strokeWidth="0.8" opacity="0.6" />
                  <line x1={originX - wallThickPx} y1={originY + planW} x2={originX - 65} y2={originY + planW} stroke="#0284c7" strokeWidth="0.8" opacity="0.6" />
                  <line x1={originX - 55} y1={originY} x2={originX - 55} y2={originY + planW} stroke="#0284c7" strokeWidth="1.5" markerStart="url(#dimTick)" markerEnd="url(#dimTick)" />
                  <g transform={`translate(${originX - 55}, ${originY + planW / 2}) rotate(-90)`}>
                    <rect x="-42" y="-9" width="84" height="18" fill="#ffffff" stroke="#0284c7" strokeWidth="1" rx="4" />
                    <text x="0" y="3.5" fill="#0284c7" fontSize="10" textAnchor="middle">
                      {width}'-0" WIDTH
                    </text>
                  </g>
                </g>

                {/* D. Clear Span Footprint Callout (Center Floor) */}
                <g id="slab-callout" pointerEvents="none">
                  <rect
                    x={originX + planL / 2 - 110}
                    y={originY + planW / 2 - 18}
                    width="220"
                    height="36"
                    fill="#ffffff"
                    stroke="#0284c7"
                    strokeWidth="1.2"
                    rx="6"
                  />
                  <text
                    x={originX + planL / 2}
                    y={originY + planW / 2 - 2}
                    fill="#0f172a"
                    fontSize="12"
                    fontWeight="bold"
                    textAnchor="middle"
                  >
                    {pricing.squareFootage.toLocaleString()} SQ. FT. CLEAR SPAN
                  </text>
                  <text
                    x={originX + planL / 2}
                    y={originY + planW / 2 + 11}
                    fill="#0284c7"
                    fontSize="8.5"
                    textAnchor="middle"
                  >
                    4" 3000-PSI CONCRETE SLAB • SMOOTH TROWEL FINISH
                  </text>
                </g>
              </g>
            )}

            {/* 12. NORTH ORIENTATION COMPASS ROSE */}
            <g id="compass-rose" transform="translate(65, 75)">
              <circle cx="0" cy="0" r="22" fill="#ffffff" stroke="#0284c7" strokeWidth="1.2" />
              {/* Star pointers */}
              <polygon points="0,-18 4,-4 0,-7 -4,-4" fill="#0284c7" />
              <polygon points="0,18 4,4 0,7 -4,4" fill="#64748b" />
              <polygon points="18,0 4,4 7,0 4,-4" fill="#64748b" />
              <polygon points="-18,0 -4,4 -7,0 -4,-4" fill="#64748b" />
              <text x="0" y="-22" fill="#0284c7" fontSize="10" fontWeight="bold" fontFamily="monospace" textAnchor="middle">
                N
              </text>
              <text x="0" y="30" fill="#64748b" fontSize="8" fontFamily="monospace" textAnchor="middle">
                PLAN NORTH
              </text>
            </g>

            {/* 13. GRAPHIC SCALE BAR */}
            <g id="scale-bar" transform={`translate(${originX}, ${canvasHeight - 35})`}>
              <rect x="0" y="0" width={20 * scale} height="4" fill="#0284c7" />
              <rect x="0" y="0" width={10 * scale} height="4" fill="#e2e8f0" />
              <text x="0" y="-4" fill="#475569" fontSize="7.5" fontFamily="monospace">0</text>
              <text x={10 * scale} y="-4" fill="#475569" fontSize="7.5" fontFamily="monospace" textAnchor="middle">10'</text>
              <text x={20 * scale} y="-4" fill="#475569" fontSize="7.5" fontFamily="monospace" textAnchor="middle">20'</text>
              <text x={10 * scale} y="14" fill="#64748b" fontSize="7" fontFamily="monospace" textAnchor="middle">GRAPHIC SCALE</text>
            </g>

            {/* 14. ARCHITECTURAL TITLE BLOCK STAMP */}
            <g id="title-block" transform={`translate(${canvasWidth - 230}, ${canvasHeight - 80})`}>
              <rect x="0" y="0" width="215" height="65" fill="#ffffff" stroke="#0284c7" strokeWidth="1" rx="4" />
              <text x="12" y="16" fill="#0284c7" fontSize="9" fontWeight="bold" fontFamily="monospace">
                A-101 • ARCHITECTURAL FLOOR PLAN
              </text>
              <text x="12" y="29" fill="#0f172a" fontSize="8" fontFamily="monospace">
                {width}' × {length}' × {eaveHeight}' {state.style.toUpperCase()} POLE BUILDING
              </text>
              <text x="12" y="41" fill="#475569" fontSize="7.5" fontFamily="monospace">
                36" AG-PANEL (3/4" RIBS @ 9" O.C.)
              </text>
              <text x="12" y="53" fill="#b45309" fontSize="7.5" fontFamily="monospace">
                HEADERS: (2) 2x12s @ {dimensions.postSpacing || 8}' O.C. POSTS
              </text>
            </g>
          </svg>
        </div>
      </div>

      {/* Door & Window Schedule Table (Architectural Schedule Panel) */}
      {showSchedule && (
        <div className="bg-white border-t border-slate-200 p-4 sm:p-5 transition-colors text-[#0F172A]">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
            <div className="flex items-center gap-2">
              <Table className="w-4 h-4 text-[#0284C7]" />
              <h4 className="text-xs font-bold text-[#0F172A] uppercase tracking-wider font-mono">
                Architectural Openings Schedule & Rough Framing
              </h4>
            </div>
            <span className="text-[11px] font-mono text-slate-500">
              Total Openings: {openings.length} units
            </span>
          </div>

          {openings.length === 0 ? (
            <div className="p-4 rounded-xl bg-white border border-dashed border-slate-200 text-center text-xs text-slate-500 font-mono shadow-xs">
              Clean default building shell. No doors, windows, or custom penetrations added yet. (Add via Sides & Openings tab above).
            </div>
          ) : (
            <div className="overflow-x-auto rounded-xl border border-slate-200/90 shadow-xs bg-white">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-50 text-[#0F172A] border-b border-slate-200">
                  <tr>
                    <th className="py-2 px-3 font-bold">Mark</th>
                    <th className="py-2 px-3 font-bold">Opening Type</th>
                    <th className="py-2 px-3 font-bold">Size (W × H)</th>
                    <th className="py-2 px-3 font-bold">Wall Location</th>
                    <th className="py-2 px-3 font-bold">Offset from Corner</th>
                    <th className="py-2 px-3 font-bold">Framing Specification</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white text-slate-700">
                  {scheduleItems.map((item, i) => (
                    <tr key={i} className="hover:bg-slate-50 transition-colors">
                      <td className="py-2 px-3 font-bold text-[#0284C7]">{item.mark}</td>
                      <td className="py-2 px-3 font-medium text-[#0F172A]">{item.type}</td>
                      <td className="py-2 px-3 font-bold text-[#0F172A]">{item.size}</td>
                      <td className="py-2 px-3 text-slate-600">{item.side}</td>
                      <td className="py-2 px-3 text-slate-600">{item.offset}</td>
                      <td className="py-2 px-3">
                        <span className="px-2 py-0.5 rounded-full bg-sky-50 text-[#0284C7] border border-sky-200 text-[10px] font-semibold">
                          {item.details}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Quick Framing Takeoff Summary */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 mt-3 text-xs font-mono">
            <div className="bg-white p-3 rounded-lg border border-slate-200/90 shadow-xs">
              <span className="text-slate-500 block text-[10px]">Slab Footprint</span>
              <strong className="text-[#0F172A] font-bold">{pricing.squareFootage.toLocaleString()} SQ FT</strong>
            </div>
            <div className="bg-white p-3 rounded-lg border border-slate-200/90 shadow-xs">
              <span className="text-slate-500 block text-[10px]">Perimeter Run</span>
              <strong className="text-[#0F172A] font-bold">{(width + length) * 2} LF</strong>
            </div>
            <div className="bg-white p-3 rounded-lg border border-slate-200/90 shadow-xs">
              <span className="text-slate-500 block text-[10px]">Truss Spacing</span>
              <strong className="text-[#0284C7] font-bold">{trussSpacing}' O.C. ({pricing.trusses.totalTrussesNeeded})</strong>
            </div>
            <div className="bg-white p-3 rounded-lg border border-slate-200/90 shadow-xs">
              <span className="text-slate-500 block text-[10px]">Post Columns</span>
              <strong className="text-[#0F172A] font-bold">{dimensions.postSpacing || 8}' O.C. (6x6 Treated)</strong>
            </div>
            <div className="bg-white p-3 rounded-lg border border-sky-300 shadow-xs bg-sky-50/40">
              <span className="text-[#0284C7] block text-[10px] font-bold">Weight-Bearing Headers</span>
              <strong className="text-sky-900 font-bold">(2) 2x12s ({pricing.weightBearingHeaders?.total2x12LinearFeet || 4 * length} LF)</strong>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
