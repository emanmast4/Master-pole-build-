import React from 'react';
import { Box, Compass, Layers, Palette, Ruler, Wrench } from 'lucide-react';

export type CategoryTabId = 'dimensions' | 'style' | 'framing' | 'sides_openings' | 'materials' | 'interior' | 'style_size';

export const NAV_TABS = [
  {
    id: 'dimensions' as const,
    label: 'Dimensions',
    icon: Ruler,
  },
  {
    id: 'style' as const,
    label: 'Style',
    icon: Box,
  },
  {
    id: 'framing' as const,
    label: 'Framing',
    icon: Compass,
  },
  {
    id: 'sides_openings' as const,
    label: 'Sides & Openings',
    icon: Layers,
  },
  {
    id: 'materials' as const,
    label: 'Colors',
    icon: Palette,
  },
  {
    id: 'interior' as const,
    label: 'Interior Options',
    icon: Wrench,
  },
];

export interface CategoryNavigationTabsProps {
  activeTab?: CategoryTabId;
  onOpenCategoryModal?: (tabId: CategoryTabId) => void;
  className?: string;
  dimensions?: { width: number; length: number; eaveHeight: number; roofPitch?: number };
}

export const CategoryNavigationTabs: React.FC<CategoryNavigationTabsProps> = ({
  activeTab = 'style',
  onOpenCategoryModal,
  className = '',
  dimensions,
}) => {
  return (
    <div className={`w-full px-3 py-2.5 sm:py-3 flex items-center justify-center bg-white ${className}`}>
      {/* 2x3 Grid: All 6 tabs have the exact same size, pill-shaped with M3 Expressive bouncy physics */}
      <div className="grid grid-cols-2 gap-2 sm:gap-2.5 w-full max-w-md sm:max-w-lg">
        {NAV_TABS.map((tab) => {
          const Icon = tab.icon;
          const isActive =
            activeTab === tab.id ||
            (activeTab === 'style_size' && (tab.id === 'style' || tab.id === 'framing'));
          return (
            <button
              key={tab.id}
              type="button"
              id={`nav-tab-${tab.id}`}
              onClick={() => {
                if (onOpenCategoryModal) {
                  onOpenCategoryModal(tab.id);
                }
              }}
              className={`relative px-4 sm:px-5 py-2.5 sm:py-3 rounded-full text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-90 hover:scale-[1.03] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
                isActive
                  ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] shadow-sm shadow-cyan-400/20 font-black ring-2 ring-[#06B6D4]/30'
                  : 'group bg-white text-[#0369A1] hover:text-[#075985] hover:bg-sky-50/70 border border-sky-200/80 shadow-2xs font-semibold'
              }`}
              title={
                tab.id === 'dimensions' && dimensions
                  ? `${dimensions.width}'W × ${dimensions.length}'L × ${dimensions.eaveHeight}'H • Click to configure dimensions`
                  : tab.label
              }
            >
              <Icon
                className={`w-4 h-4 shrink-0 transition-colors ${
                  isActive ? 'text-[#06B6D4]' : 'text-[#0369A1] group-hover:text-[#06B6D4]'
                }`}
                strokeWidth={isActive ? 2.4 : 1.8}
              />
              <span className={`truncate ${isActive ? 'text-[#075985] font-black tracking-tight' : 'text-[#0369A1] group-hover:text-[#075985]'}`}>
                {tab.label}
              </span>
              {isActive && (
                <span className="absolute -bottom-[2px] inset-x-4 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};

