import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { CustomBuildingState, PricingBreakdown, WallOpening, WallSide } from '../types';
import { 
  createSkyDome, 
  createGrassTexture, 
  createGrassBumpMap, 
  createGravelTexture, 
  createGravelBumpMap, 
  createConcreteApronTexture, 
  createDistantMountains, 
  createScenicTrees, 
  createRusticFence, 
  createEnvironmentMap, 
  createRollingPastureTerrain, 
  createContactShadowPlane 
} from './landscape3d';
import {
  createAgPanelTexture,
  createSoffitTexture,
  buildWallAgPanelRibs,
  buildRoofAgPanelRibs,
  getRoofProfileY,
  AG_PANEL_CONSTANTS
} from './agPanel3d';
import { 
  ZoomIn, 
  ZoomOut, 
  RefreshCcw, 
  Layers, 
  Play, 
  Pause,
  Box,
  Palette,
  Wrench,
  ShieldCheck,
  Ruler
} from 'lucide-react';
import { CategoryNavigationTabs, CategoryTabId } from './CategoryNavigationTabs';

interface Interactive3DBuildingProps {
  state: CustomBuildingState;
  pricing: PricingBreakdown;
  selectedSide?: WallSide;
  onSelectSide?: (side: WallSide) => void;
  onUpdateDimensions?: (dimensions: { length: number; width: number; eaveHeight: number }) => void;
  onOpenCategoryModal?: (tabId: CategoryTabId) => void;
  activeTab?: string;
  isAutoRotating?: boolean;
  onToggleAutoRotate?: () => void;
  showFraming?: boolean;
  onToggleFraming?: () => void;
  isPanMode?: boolean;
  onRegisterCameraControls?: (controls: { zoom: (factor: number) => void; reset: () => void }) => void;
}

export const Interactive3DBuilding: React.FC<Interactive3DBuildingProps> = ({
  state,
  pricing,
  selectedSide,
  onSelectSide,
  onUpdateDimensions,
  onOpenCategoryModal,
  activeTab = 'style_size',
  isAutoRotating: controlledAutoRotating,
  onToggleAutoRotate,
  showFraming: controlledShowFraming,
  onToggleFraming,
  isPanMode = false,
  onRegisterCameraControls,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const animFrameIdRef = useRef<number | null>(null);
  const buildingGroupRef = useRef<THREE.Group | null>(null);

  const [internalAutoRotating, setInternalAutoRotating] = useState(false);
  const [internalShowFraming, setInternalShowFraming] = useState(false);
  const isAutoRotating = controlledAutoRotating ?? internalAutoRotating;
  const showFraming = controlledShowFraming ?? internalShowFraming;

  const { style = 'gable', dimensions, materials, openings, leanTo, walls } = state;
  const { width, length, eaveHeight, roofPitch, overhangInches } = dimensions;

  // Resolve trim colors
  const mainTrimColor = materials.trimColor;
  const cornerTrimColor = materials.customTrimColorsEnabled && materials.cornerTrimColor ? materials.cornerTrimColor : mainTrimColor;
  const eaveTrimColor = materials.customTrimColorsEnabled && materials.eaveTrimColor ? materials.eaveTrimColor : mainTrimColor;
  const rakeTrimColor = materials.customTrimColorsEnabled && materials.rakeTrimColor ? materials.rakeTrimColor : mainTrimColor;
  const ridgeCapColor = materials.customTrimColorsEnabled && materials.ridgeCapColor ? materials.ridgeCapColor : mainTrimColor;
  const doorTrimColor = materials.customTrimColorsEnabled && materials.doorTrimColor ? materials.doorTrimColor : mainTrimColor;
  const wainscotCapColor = materials.customTrimColorsEnabled && materials.wainscotCapColor ? materials.wainscotCapColor : mainTrimColor;
  const ratGuardColor = materials.customTrimColorsEnabled && materials.ratGuardColor ? materials.ratGuardColor : cornerTrimColor;
  const dripEdgeColor = materials.customTrimColorsEnabled && materials.dripEdgeColor ? materials.dripEdgeColor : eaveTrimColor;
  const fasciaTrimColor = materials.customTrimColorsEnabled && materials.fasciaTrimColor ? materials.fasciaTrimColor : eaveTrimColor;
  const soffitColor = materials.customTrimColorsEnabled && materials.soffitColor ? materials.soffitColor : '#f8fafc';
  const snowGuardColor = materials.customTrimColorsEnabled && materials.snowGuardColor ? materials.snowGuardColor : eaveTrimColor;
  const hasGutters = !!materials.hasGutters;
  const gutterColor = materials.gutterColor || materials.trimColor || '#18181b';

  // Set up Three.js Scene
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const widthPx = container.clientWidth || 800;
    const heightPx = container.clientHeight || 460;

    // 1. Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#38BDF8');
    scene.fog = new THREE.FogExp2('#7DD3FC', 0.00012);
    sceneRef.current = scene;

    // Atmospheric Sky Dome with natural Rayleigh gradient, clouds, and solar horizon haze
    const skyDome = createSkyDome();
    scene.add(skyDome);

    // Distant Panoramic Rolling Countryside Hills & Forested Ridges
    const mountains = createDistantMountains();
    scene.add(mountains);

    // Scenic Tree Groves & Perimeter Windbreaks
    const trees = createScenicTrees(width, length);
    scene.add(trees);

    // Realistic Weathered 3-Rail Split-Cedar Ranch Fence
    const fence = createRusticFence(520);
    scene.add(fence);

    // 2. Camera
    const camera = new THREE.PerspectiveCamera(42, widthPx / heightPx, 0.5, 10000);
    camera.position.set(width * 1.5, eaveHeight * 1.8, length * 1.5);
    cameraRef.current = camera;

    // 3. Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
    renderer.setSize(widthPx, heightPx);
    // Cap render resolution to reduce GPU/memory pressure on high-DPI mobile screens.
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.06;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Image-Based Lighting (IBL) Environment Map for authentic PBR reflections
    // Provides realistic sky sheen on white siding, glossy highlights on black roof, and glass reflection
    const envMap = createEnvironmentMap(renderer);
    scene.environment = envMap;

    // 4. OrbitControls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.maxPolarAngle = Math.PI / 2 - 0.01; // Keep camera slightly above grass level
    controls.minDistance = 10;
    controls.maxDistance = 750;
    controls.target.set(0, eaveHeight * 0.45, 0);
    controls.autoRotate = false;
    controls.autoRotateSpeed = 1.5;
    controlsRef.current = controls;

    // 5. Lighting
    // Ambient hemisphere light (natural sky blue fill from above, warm earthy turf bounce from below)
    const hemiLight = new THREE.HemisphereLight('#e8f2fc', '#34462b', 0.95);
    scene.add(hemiLight);

    // Sun directional light (physically warm daylight sun casting crisp realistic shadows)
    const sunLight = new THREE.DirectionalLight('#fffbf2', 2.3);
    sunLight.position.set(width * 2.2, eaveHeight * 3.8, length * 2.0);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 2048;
    sunLight.shadow.mapSize.height = 2048;
    sunLight.shadow.camera.near = 1;
    sunLight.shadow.camera.far = 450;
    const shadowSize = Math.max(width, length) * 2.2;
    sunLight.shadow.camera.left = -shadowSize;
    sunLight.shadow.camera.right = shadowSize;
    sunLight.shadow.camera.top = shadowSize;
    sunLight.shadow.camera.bottom = -shadowSize;
    sunLight.shadow.bias = -0.0003;
    scene.add(sunLight);

    // Soft sky horizon fill light for balanced ambient illumination
    const fillLight = new THREE.DirectionalLight('#d0e2f2', 0.48);
    fillLight.position.set(-width * 1.8, eaveHeight * 2.2, -length * 1.8);
    scene.add(fillLight);

    // Ground plane: Realistic rolling pasture terrain with bump depth and natural undulations
    const terrain = createRollingPastureTerrain(width, length);
    scene.add(terrain);

    // Render only while the canvas is visible and the page is foregrounded.
    // This avoids a permanent GPU loop while the user is on another tab or screen.
    let inViewport = true;
    let disposed = false;
    const canRender = () => !disposed && inViewport && document.visibilityState !== 'hidden';
    const renderFrame = () => {
      animFrameIdRef.current = null;
      if (!canRender()) return;
      controls.update();
      renderer.render(scene, camera);
      animFrameIdRef.current = requestAnimationFrame(renderFrame);
    };
    const startRendering = () => {
      if (canRender() && animFrameIdRef.current === null) {
        renderer.render(scene, camera);
        animFrameIdRef.current = requestAnimationFrame(renderFrame);
      }
    };
    const stopRendering = () => {
      if (animFrameIdRef.current !== null) {
        cancelAnimationFrame(animFrameIdRef.current);
        animFrameIdRef.current = null;
      }
    };
    const intersectionObserver = typeof IntersectionObserver !== 'undefined'
      ? new IntersectionObserver((entries) => {
          inViewport = entries.some((entry) => entry.isIntersecting);
          if (inViewport) startRendering(); else stopRendering();
        }, { threshold: 0.01 })
      : null;
    intersectionObserver?.observe(container);
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') stopRendering();
      else startRendering();
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);
    startRendering();

    // Resize Observer
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width: w, height: h } = entry.contentRect;
        if (w > 0 && h > 0 && cameraRef.current && rendererRef.current) {
          cameraRef.current.aspect = w / h;
          cameraRef.current.updateProjectionMatrix();
          rendererRef.current.setSize(w, h);
        }
      }
    });
    resizeObserver.observe(container);

    return () => {
      disposed = true;
      resizeObserver.disconnect();
      intersectionObserver?.disconnect();
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      stopRendering();
      controls.dispose();

      // Dispose every scene-owned GPU resource, not just the current building.
      const disposedTextures = new Set<THREE.Texture>();
      const disposeMaterial = (material: THREE.Material) => {
        for (const value of Object.values(material)) {
          if (value instanceof THREE.Texture && !disposedTextures.has(value)) {
            disposedTextures.add(value);
            value.dispose();
          }
        }
        material.dispose();
      };
      scene.traverse((object) => {
        const renderable = object as THREE.Object3D & { geometry?: THREE.BufferGeometry; material?: THREE.Material | THREE.Material[] };
        renderable.geometry?.dispose();
        if (Array.isArray(renderable.material)) renderable.material.forEach(disposeMaterial);
        else if (renderable.material) disposeMaterial(renderable.material);
      });
      if (scene.environment && !disposedTextures.has(scene.environment)) scene.environment.dispose();
      renderer.renderLists.dispose();
      renderer.dispose();
      renderer.forceContextLoss();
      scene.clear();
      sceneRef.current = null;
      cameraRef.current = null;
      controlsRef.current = null;
      rendererRef.current = null;
      buildingGroupRef.current = null;
      if (container) container.innerHTML = '';
    };
  }, []);

  // Update controls auto-rotate state
  useEffect(() => {
    if (controlsRef.current) {
      controlsRef.current.autoRotate = isAutoRotating;
    }
  }, [isAutoRotating]);

  // Build the 3D Building Geometry whenever state changes
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    // Remove previous building group
    if (buildingGroupRef.current) {
      scene.remove(buildingGroupRef.current);
      buildingGroupRef.current.traverse((child) => {
        if (child instanceof THREE.Mesh) {
          child.geometry.dispose();
          if (Array.isArray(child.material)) {
            child.material.forEach((m) => m.dispose());
          } else {
            child.material.dispose();
          }
        }
      });
    }

    const buildingGroup = new THREE.Group();
    buildingGroupRef.current = buildingGroup;

    // Building dimensions in Three.js coordinates
    // Let X = building width (front & back faces run along X, left/right walls along Z)
    // Let Z = building length
    // Let Y = building height (vertical)
    const halfW = width / 2;
    const halfL = length / 2;
    const overhangFt = overhangInches / 12;

    // 1. Standard Gable Parameters
    const standardPeakRise = halfW * (roofPitch / 12);
    const standardRidgeY = eaveHeight + standardPeakRise;
    const standardRoofAngle = Math.atan2(standardPeakRise, halfW);

    // Realistic Post-Frame Eave & Fascia Geometry (per contractor build photo):
    const eaveFasciaHeight = 0.52; // ~6.25 inches plumb vertical fascia cover
    const standardMetalLip = 0.14; // ~1.7 inches metal roofing panel lip past fascia board
    const metalLipPastFascia = standardMetalLip;
    const standardFasciaDrop = overhangFt * Math.tan(standardRoofAngle);
    const standardFasciaTopY = eaveHeight - standardFasciaDrop;
    const standardFasciaCenterY = standardFasciaTopY - eaveFasciaHeight / 2;
    const standardSlopeToFascia = (halfW + overhangFt) / Math.cos(standardRoofAngle);
    const standardRafterLen = standardSlopeToFascia + metalLipPastFascia;

    // 2. Monitor Barn Parameters
    const monitorCenterW = width * 0.40;
    const monitorHalfCenterW = monitorCenterW / 2;
    const monitorWingWidth = halfW - monitorHalfCenterW;
    const monitorWingPitch = Math.max(2, roofPitch * 0.75);
    const monitorWingRise = monitorWingWidth * (monitorWingPitch / 12);
    const monitorWingTopY = eaveHeight + monitorWingRise;
    const monitorClerestoryH = Math.max(3.5, eaveHeight * 0.25);
    const monitorRaisedEaveY = monitorWingTopY + monitorClerestoryH;
    const monitorCenterRise = monitorHalfCenterW * (roofPitch / 12);
    const monitorRaisedRidgeY = monitorRaisedEaveY + monitorCenterRise;
    const monitorWingAngle = Math.atan2(monitorWingRise, monitorWingWidth);
    const monitorWingRafterLen = Math.sqrt(Math.pow(monitorWingWidth, 2) + Math.pow(monitorWingRise, 2)) + overhangFt;
    const monitorCenterAngle = Math.atan2(monitorCenterRise, monitorHalfCenterW);
    const monitorCenterRafterLen = Math.sqrt(Math.pow(monitorHalfCenterW, 2) + Math.pow(monitorCenterRise, 2)) + overhangFt * 0.6;

    // 3. Dutch Gambrel Barn Parameters
    const gambrelKnuckleX = halfW * 0.58;
    const gambrelKnuckleRise = (halfW * 0.42) * (Math.max(16, roofPitch * 3.2) / 12);
    const gambrelKnuckleY = eaveHeight + gambrelKnuckleRise;
    const gambrelUpperRise = (halfW * 0.58) * (Math.max(3.5, roofPitch * 0.75) / 12);
    const gambrelRidgeY = gambrelKnuckleY + gambrelUpperRise;
    const gambrelLowerSpan = halfW - gambrelKnuckleX;
    const gambrelLowerAngle = Math.atan2(gambrelKnuckleRise, gambrelLowerSpan);
    const gambrelLowerRafterLen = Math.sqrt(Math.pow(gambrelLowerSpan, 2) + Math.pow(gambrelKnuckleRise, 2)) + overhangFt;
    const gambrelUpperAngle = Math.atan2(gambrelUpperRise, gambrelKnuckleX);
    const gambrelUpperRafterLen = Math.sqrt(Math.pow(gambrelKnuckleX, 2) + Math.pow(gambrelUpperRise, 2)) + 0.3;

    // 4. Mono-Slope / Shed Parameters
    const singleSlopeHighRise = width * (roofPitch / 12);
    const singleSlopeHighEaveY = eaveHeight + singleSlopeHighRise;
    const singleSlopeAngle = Math.atan2(singleSlopeHighRise, width);
    const singleSlopeLowEaveY = eaveHeight - overhangFt * Math.tan(singleSlopeAngle);
    const singleSlopeRafterLen = Math.sqrt(Math.pow(width, 2) + Math.pow(singleSlopeHighRise, 2)) + overhangFt * 2;

    // 5. Commercial Box Gable Parameters
    const commercialParapetY = eaveHeight + standardPeakRise + 2.5;

    // General Ridge Y alias
    const ridgeY = style === 'monitor' ? monitorRaisedRidgeY : (style === 'gambrel' ? gambrelRidgeY : (style === 'single_slope' ? singleSlopeHighEaveY : standardRidgeY));
    const peakRise = standardPeakRise;

    // Wainscot parameters
    const hasWainscot = Object.values(walls).some((w) => w.hasWainscot);
    const wainscotH = hasWainscot ? materials.wainscotHeightFt : 0;
    const sidingH = eaveHeight - wainscotH;

    // Materials helper
    const createPanelMat = (colorHex: string, roughness = 0.45, metalness = 0.25) => {
      const tex = createAgPanelTexture(colorHex);
      tex.repeat.set(4, 4);
      return new THREE.MeshStandardMaterial({
        color: new THREE.Color(colorHex),
        map: tex,
        roughness,
        metalness,
        wireframe: showFraming,
        transparent: showFraming,
        opacity: showFraming ? 0.25 : 1.0,
      });
    };

    const sidingMat = createPanelMat(materials.sidingColor, 0.42, 0.18);
    const wainscotMat = createPanelMat(materials.wainscotColor, 0.38, 0.25);
    const roofMat = createPanelMat(materials.roofColor, 0.30, 0.28);

    // 3D Physical Ag-Panel Rib Materials (3/4" high ribs @ 9" O.C.)
    const sidingRibMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(materials.sidingColor),
      roughness: 0.40,
      metalness: 0.22,
      wireframe: showFraming,
      transparent: showFraming,
      opacity: showFraming ? 0.25 : 1.0,
    });
    const wainscotRibMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(materials.wainscotColor),
      roughness: 0.38,
      metalness: 0.28,
      wireframe: showFraming,
      transparent: showFraming,
      opacity: showFraming ? 0.25 : 1.0,
    });
    const roofRibMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(materials.roofColor),
      roughness: 0.30,
      metalness: 0.32,
      wireframe: showFraming,
      transparent: showFraming,
      opacity: showFraming ? 0.25 : 1.0,
    });

    // Trim materials (solid, opaque with clean architectural sheen)
    const cornerTrimMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(cornerTrimColor), roughness: 0.32, metalness: 0.35 });
    const eaveTrimMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(eaveTrimColor), roughness: 0.32, metalness: 0.35 });
    const rakeTrimMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(rakeTrimColor), roughness: 0.32, metalness: 0.35 });
    const ridgeCapMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(ridgeCapColor), roughness: 0.32, metalness: 0.35 });
    const doorTrimMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(doorTrimColor), roughness: 0.32, metalness: 0.35 });
    const wainscotCapMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(wainscotCapColor), roughness: 0.32, metalness: 0.35 });
    const ratGuardMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(ratGuardColor), roughness: 0.35, metalness: 0.35 });
    const dripEdgeMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(dripEdgeColor), roughness: 0.32, metalness: 0.35 });
    const fasciaMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(fasciaTrimColor), roughness: 0.32, metalness: 0.35 });
    const soffitTex = createSoffitTexture(soffitColor);
    const soffitMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(soffitColor),
      map: soffitTex,
      roughness: 0.52,
      metalness: 0.18,
      wireframe: showFraming,
      transparent: showFraming,
      opacity: showFraming ? 0.25 : 1.0,
    });
    const snowGuardMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(snowGuardColor), roughness: 0.25, metalness: 0.6 });
    const gutterMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(gutterColor), roughness: 0.35, metalness: 0.35 });
    const glassMat = new THREE.MeshStandardMaterial({ color: '#1e293b', roughness: 0.05, metalness: 0.95, transparent: true, opacity: 0.75 });
    const concreteMat = new THREE.MeshStandardMaterial({ color: '#94a3b8', roughness: 0.95, metalness: 0.05 });
    const framingTimberMat = new THREE.MeshStandardMaterial({ color: '#ca8a04', roughness: 0.8, metalness: 0.1 });

    // Foundation ambient contact shadow
    const contactShadow = createContactShadowPlane(width, length);
    buildingGroup.add(contactShadow);

    // 0. Realistic Compacted Crushed Stone Pad & Foreground Access Driveway
    const padMargin = 10; // Clean 10-foot crushed limestone buffer around all 4 sides
    const padThick = 0.35; // 4.2" compacted engineered limestone base
    const padMat = new THREE.MeshStandardMaterial({
      map: createGravelTexture(),
      bumpMap: createGravelBumpMap(),
      bumpScale: 0.045,
      roughness: 0.94,
      metalness: 0.04,
    });

    const concreteApronMat = new THREE.MeshStandardMaterial({
      map: createConcreteApronTexture(),
      roughness: 0.88,
      metalness: 0.04,
    });

    // Main flat compacted aggregate pad
    const padGeo = new THREE.BoxGeometry(width + padMargin * 2, padThick, length + padMargin * 2);
    const gravelPad = new THREE.Mesh(padGeo, padMat);
    gravelPad.position.set(0, padThick / 2, 0);
    gravelPad.receiveShadow = true;
    buildingGroup.add(gravelPad);

    // Graded aggregate perimeter shoulder (clean sloped aggregate edge)
    const shoulderW = 4.0;
    const shoulderThick = 0.20;
    const shoulderGeo = new THREE.BoxGeometry(width + (padMargin + shoulderW) * 2, shoulderThick, length + (padMargin + shoulderW) * 2);
    const shoulder = new THREE.Mesh(shoulderGeo, padMat);
    shoulder.position.set(0, shoulderThick / 2, 0);
    shoulder.receiveShadow = true;
    buildingGroup.add(shoulder);

    // Foreground Crushed Limestone Access Driveway (Extends out toward the foreground road)
    const driveW = Math.max(24, width * 0.55);
    const driveL = 80;
    const driveThick = 0.30;
    const driveGeo = new THREE.BoxGeometry(driveW, driveThick, driveL);
    const driveway = new THREE.Mesh(driveGeo, padMat);
    // Position extending from front of pad (+Z) into the foreground
    driveway.position.set(0, driveThick / 2, halfL + padMargin + driveL / 2 - 1.0);
    driveway.receiveShadow = true;
    buildingGroup.add(driveway);

    // Driveway side shoulder flares / transition strips
    const flareThick = 0.18;
    const flareGeo = new THREE.BoxGeometry(driveW + 8, flareThick, driveL + 4);
    const flare = new THREE.Mesh(flareGeo, padMat);
    flare.position.set(0, flareThick / 2, halfL + padMargin + driveL / 2 - 1.0);
    flare.receiveShadow = true;
    buildingGroup.add(flare);

    // Front & Back architectural entrance aprons for vehicle & walk access (brushed concrete)
    openings.forEach((op) => {
      if (op.type === 'overhead_door' || op.type === 'walk_door') {
        const isOverhead = op.type === 'overhead_door';
        const apronW = Math.max(isOverhead ? 10 : 5, op.widthFt + (isOverhead ? 3 : 2));
        const apronL = isOverhead ? 14 : 5.5;
        const apronThick = 0.40;
        const apronGeo = new THREE.BoxGeometry(apronW, apronThick, apronL);
        const apron = new THREE.Mesh(apronGeo, concreteApronMat);
        apron.receiveShadow = true;
        apron.castShadow = true;

        if (op.side === 'front') {
          apron.position.set(-halfW + op.positionOffsetFt + op.widthFt / 2, apronThick / 2, halfL + apronL / 2);
        } else if (op.side === 'back') {
          apron.position.set(-halfW + op.positionOffsetFt + op.widthFt / 2, apronThick / 2, -halfL - apronL / 2);
        } else if (op.side === 'left') {
          apron.rotation.y = Math.PI / 2;
          apron.position.set(-halfW - apronL / 2, apronThick / 2, -halfL + op.positionOffsetFt + op.widthFt / 2);
        } else if (op.side === 'right') {
          apron.rotation.y = Math.PI / 2;
          apron.position.set(halfW + apronL / 2, apronThick / 2, -halfL + op.positionOffsetFt + op.widthFt / 2);
        }
        buildingGroup.add(apron);
      }
    });

    // 1. Concrete Slab Foundation with realistic architectural concrete texture
    const slabThick = 0.5;
    const slabGeo = new THREE.BoxGeometry(width + 0.8, slabThick, length + 0.8);
    const slabMesh = new THREE.Mesh(slabGeo, concreteApronMat);
    slabMesh.position.set(0, slabThick / 2, 0);
    slabMesh.receiveShadow = true;
    slabMesh.castShadow = true;
    buildingGroup.add(slabMesh);

    // 2. Sidewalls (Left Wall at -X, Right Wall at +X)
    // Left Wall (-halfW)
    if (walls.left.enclosed) {
      const leftWallH = style === 'single_slope' ? singleSlopeHighEaveY : eaveHeight;
      const leftSidH = leftWallH - wainscotH;
      if (wainscotH > 0 && walls.left.hasWainscot) {
        // Wainscot lower part
        const leftWainGeo = new THREE.BoxGeometry(0.2, wainscotH, length);
        const leftWain = new THREE.Mesh(leftWainGeo, wainscotMat);
        leftWain.position.set(-halfW, wainscotH / 2, 0);
        leftWain.castShadow = true;
        leftWain.receiveShadow = true;
        buildingGroup.add(leftWain);

        // Upper siding
        const leftSidGeo = new THREE.BoxGeometry(0.2, leftSidH, length);
        const leftSid = new THREE.Mesh(leftSidGeo, sidingMat);
        leftSid.position.set(-halfW, wainscotH + leftSidH / 2, 0);
        leftSid.castShadow = true;
        leftSid.receiveShadow = true;
        buildingGroup.add(leftSid);

        // Wainscot Z-flashing trim
        const wainTrimGeo = new THREE.BoxGeometry(0.3, 0.15, length);
        const wainTrim = new THREE.Mesh(wainTrimGeo, wainscotCapMat);
        wainTrim.position.set(-halfW, wainscotH, 0);
        buildingGroup.add(wainTrim);
      } else {
        const leftWallGeo = new THREE.BoxGeometry(0.2, leftWallH, length);
        const leftWall = new THREE.Mesh(leftWallGeo, sidingMat);
        leftWall.position.set(-halfW, leftWallH / 2, 0);
        leftWall.castShadow = true;
        leftWall.receiveShadow = true;
        buildingGroup.add(leftWall);
      }
    }

    // Right Wall (+halfW)
    if (walls.right.enclosed) {
      if (wainscotH > 0 && walls.right.hasWainscot) {
        const rightWainGeo = new THREE.BoxGeometry(0.2, wainscotH, length);
        const rightWain = new THREE.Mesh(rightWainGeo, wainscotMat);
        rightWain.position.set(halfW, wainscotH / 2, 0);
        rightWain.castShadow = true;
        rightWain.receiveShadow = true;
        buildingGroup.add(rightWain);

        const rightSidGeo = new THREE.BoxGeometry(0.2, sidingH, length);
        const rightSid = new THREE.Mesh(rightSidGeo, sidingMat);
        rightSid.position.set(halfW, wainscotH + sidingH / 2, 0);
        rightSid.castShadow = true;
        rightSid.receiveShadow = true;
        buildingGroup.add(rightSid);

        const wainTrimGeo = new THREE.BoxGeometry(0.3, 0.15, length);
        const wainTrim = new THREE.Mesh(wainTrimGeo, wainscotCapMat);
        wainTrim.position.set(halfW, wainscotH, 0);
        buildingGroup.add(wainTrim);
      } else {
        const rightWallGeo = new THREE.BoxGeometry(0.2, eaveHeight, length);
        const rightWall = new THREE.Mesh(rightWallGeo, sidingMat);
        rightWall.position.set(halfW, eaveHeight / 2, 0);
        rightWall.castShadow = true;
        rightWall.receiveShadow = true;
        buildingGroup.add(rightWall);
      }
    }

    // Raised Center Clerestory Longitudinal Sidewalls (Only when style === 'monitor')
    if (style === 'monitor') {
      const clerestoryTrimMat = cornerTrimMat;
      const glassMat = new THREE.MeshPhysicalMaterial({
        color: '#7dd3fc',
        transmission: 0.8,
        opacity: 0.9,
        transparent: true,
        roughness: 0.1,
        metalness: 0.15,
        reflectivity: 0.9,
      });

      const addClerestoryLongitudinalWall = (xPos: number) => {
        const clWallGroup = new THREE.Group();
        // Solid siding panel
        const clGeo = new THREE.BoxGeometry(0.2, monitorClerestoryH, length);
        const clMesh = new THREE.Mesh(clGeo, sidingMat);
        clMesh.position.set(0, monitorClerestoryH / 2, 0);
        clMesh.castShadow = true;
        clWallGroup.add(clMesh);

        // Ribbon of Clerestory Daylighting Windows along the wall
        const winW = 3.0;
        const winH = Math.min(2.0, monitorClerestoryH * 0.6);
        const winInterval = 6.0;
        const count = Math.max(1, Math.floor(length / winInterval));
        const step = length / (count + 1);

        for (let i = 1; i <= count; i++) {
          const wz = -halfL + i * step;
          // Frame
          const frameGeo = new THREE.BoxGeometry(0.28, winH + 0.3, winW + 0.3);
          const frameMesh = new THREE.Mesh(frameGeo, clerestoryTrimMat);
          frameMesh.position.set(0, monitorClerestoryH / 2, wz);
          clWallGroup.add(frameMesh);

          // Glass pane
          const glassGeo = new THREE.BoxGeometry(0.3, winH, winW);
          const glassMesh = new THREE.Mesh(glassGeo, glassMat);
          glassMesh.position.set(0, monitorClerestoryH / 2, wz);
          clWallGroup.add(glassMesh);
        }

        clWallGroup.position.set(xPos, monitorWingTopY, 0);
        buildingGroup.add(clWallGroup);
      };

      addClerestoryLongitudinalWall(-monitorHalfCenterW);
      addClerestoryLongitudinalWall(monitorHalfCenterW);
    }

    // Helper for Architectural Endwall (Front at +halfL, Back at -halfL)
    const createArchitecturalEndwall = (zPos: number, hasWainscotWall: boolean, isFrontWall: boolean) => {
      const endwallGroup = new THREE.Group();
      const effectiveWainscotH = wainscotH > 0 && hasWainscotWall ? wainscotH : 0;
      const yStart = effectiveWainscotH;

      // 1. Lower rectangular wainscot (if enabled)
      if (effectiveWainscotH > 0) {
        const wainGeo = new THREE.BoxGeometry(width, effectiveWainscotH, 0.2);
        const wainMesh = new THREE.Mesh(wainGeo, wainscotMat);
        wainMesh.position.set(0, effectiveWainscotH / 2, 0);
        wainMesh.castShadow = true;
        wainMesh.receiveShadow = true;
        endwallGroup.add(wainMesh);

        // Wainscot Z-flashing cap trim
        const wainTrimGeo = new THREE.BoxGeometry(width + 0.2, 0.15, 0.3);
        const wainTrim = new THREE.Mesh(wainTrimGeo, wainscotCapMat);
        wainTrim.position.set(0, effectiveWainscotH, 0);
        endwallGroup.add(wainTrim);
      }

      // 2. Upper siding profile built with THREE.Shape according to selected style
      const wallShape = new THREE.Shape();
      wallShape.moveTo(-halfW, yStart);
      wallShape.lineTo(halfW, yStart);

      if (style === 'single_slope') {
        wallShape.lineTo(halfW, eaveHeight);
        wallShape.lineTo(-halfW, singleSlopeHighEaveY);
      } else if (style === 'monitor') {
        wallShape.lineTo(halfW, eaveHeight);
        wallShape.lineTo(monitorHalfCenterW, monitorWingTopY);
        wallShape.lineTo(monitorHalfCenterW, monitorRaisedEaveY);
        wallShape.lineTo(0, monitorRaisedRidgeY);
        wallShape.lineTo(-monitorHalfCenterW, monitorRaisedEaveY);
        wallShape.lineTo(-monitorHalfCenterW, monitorWingTopY);
        wallShape.lineTo(-halfW, eaveHeight);
      } else if (style === 'gambrel') {
        wallShape.lineTo(halfW, eaveHeight);
        wallShape.lineTo(gambrelKnuckleX, gambrelKnuckleY);
        wallShape.lineTo(0, gambrelRidgeY);
        wallShape.lineTo(-gambrelKnuckleX, gambrelKnuckleY);
        wallShape.lineTo(-halfW, eaveHeight);
      } else if (style === 'commercial' && isFrontWall) {
        // Commercial front wall: dramatic rectangular parapet storefront facade!
        wallShape.lineTo(halfW, commercialParapetY);
        wallShape.lineTo(-halfW, commercialParapetY);
      } else {
        // Gable (or commercial back wall)
        wallShape.lineTo(halfW, eaveHeight);
        wallShape.lineTo(0, standardRidgeY);
        wallShape.lineTo(-halfW, eaveHeight);
      }

      wallShape.closePath();

      const extrudeSettings = { depth: 0.2, bevelEnabled: false };
      const shapeGeo = new THREE.ExtrudeGeometry(wallShape, extrudeSettings);
      const shapeMesh = new THREE.Mesh(shapeGeo, sidingMat);
      shapeMesh.position.set(0, 0, -0.1);
      shapeMesh.castShadow = true;
      shapeMesh.receiveShadow = true;
      endwallGroup.add(shapeMesh);

      endwallGroup.position.z = zPos;
      return endwallGroup;
    };

    if (walls.front.enclosed) {
      buildingGroup.add(createArchitecturalEndwall(halfL, walls.front.hasWainscot, true));
    }
    if (walls.back.enclosed) {
      buildingGroup.add(createArchitecturalEndwall(-halfL, walls.back.hasWainscot, false));
    }

    // 2B. 3D Physical Ag-Panel Ribs on Walls (3/4" high ribs spaced every 9" O.C.)
    const wallRibsGroup = buildWallAgPanelRibs({
      width,
      length,
      eaveHeight,
      roofPitch,
      style,
      walls,
      openings,
      wainscotH,
      sidingRibMat,
      wainscotRibMat,
    });
    buildingGroup.add(wallRibsGroup);

    // 3. ROOF SLOPES & 3D AG-PANEL RIBS (Built to match selected architectural style)
    const roofLengthWithOverhang = length + 2 * overhangFt;
    const roofThickness = 0.25;

    if (style === 'single_slope') {
      // 1 Large continuous mono-slope roof plane (high at left wall, sloping down to right eave)
      const ssRoofGeo = new THREE.BoxGeometry(singleSlopeRafterLen, roofThickness, roofLengthWithOverhang);
      const ssRoof = new THREE.Mesh(ssRoofGeo, roofMat);
      const ssCenterY = eaveHeight + singleSlopeHighRise / 2;
      ssRoof.position.set(0, ssCenterY, 0);
      ssRoof.rotation.z = -singleSlopeAngle;
      ssRoof.castShadow = true;
      ssRoof.receiveShadow = true;

      const ssRibs = buildRoofAgPanelRibs(singleSlopeRafterLen, roofLengthWithOverhang, roofThickness, roofRibMat);
      ssRoof.add(ssRibs);
      buildingGroup.add(ssRoof);

      // Trims for Single Slope:
      // High eave fascia trim along left crest
      const highFasciaGeo = new THREE.BoxGeometry(0.06, eaveFasciaHeight, roofLengthWithOverhang + 0.08);
      const highFascia = new THREE.Mesh(highFasciaGeo, fasciaMat);
      highFascia.position.set(-halfW - overhangFt + 0.03, singleSlopeHighEaveY + overhangFt * Math.tan(singleSlopeAngle) - eaveFasciaHeight / 2, 0);
      buildingGroup.add(highFascia);

      // Low eave fascia cover along right edge (plumb face)
      const lowFasciaTopY = eaveHeight - overhangFt * Math.tan(singleSlopeAngle);
      const lowFasciaCenterY = lowFasciaTopY - eaveFasciaHeight / 2;
      const lowFascia = new THREE.Mesh(highFasciaGeo, fasciaMat);
      lowFascia.position.set(halfW + overhangFt - 0.03, lowFasciaCenterY, 0);
      buildingGroup.add(lowFascia);

      // Low eave drip edge
      const ssDripEdge = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.14, roofLengthWithOverhang + 0.12), dripEdgeMat);
      ssDripEdge.position.set(halfW + overhangFt + 0.02, lowFasciaTopY - 0.04, 0);
      buildingGroup.add(ssDripEdge);

      // Horizontal soffit under low overhang
      if (overhangFt > 0) {
        const ssSoffit = new THREE.Mesh(new THREE.BoxGeometry(overhangFt, 0.04, roofLengthWithOverhang), soffitMat);
        ssSoffit.position.set(halfW + overhangFt / 2, lowFasciaTopY - eaveFasciaHeight + 0.03, 0);
        buildingGroup.add(ssSoffit);
      }

      // Optional gutters (disabled by default)
      if (hasGutters) {
        const ssGutter = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.44, roofLengthWithOverhang), gutterMat);
        ssGutter.position.set(halfW + overhangFt + 0.22, lowFasciaCenterY + 0.04, 0);
        buildingGroup.add(ssGutter);
      }

      // Finished Architectural Single-Slope Rake Trims and Gable Soffits
      const ssRakeFaceGeo = new THREE.BoxGeometry(singleSlopeRafterLen, eaveFasciaHeight * Math.cos(singleSlopeAngle), 0.06);
      const ssTopFlangeGeo = new THREE.BoxGeometry(singleSlopeRafterLen, 0.035, 0.38);

      const addSingleSlopeRake = (zPos: number, wallZ: number, isFront: boolean) => {
        const ssGroup = new THREE.Group();

        // 1. Vertical Rake Fascia Face
        const rFace = new THREE.Mesh(ssRakeFaceGeo, rakeTrimMat);
        rFace.position.set(0, ssCenterY - 0.02, zPos);
        rFace.rotation.z = -singleSlopeAngle;
        rFace.castShadow = true;
        ssGroup.add(rFace);

        // 2. Top Rake Flange
        const zFlangeOffset = isFront ? -0.19 : 0.19;
        const rTop = new THREE.Mesh(ssTopFlangeGeo, rakeTrimMat);
        rTop.position.set(0, ssCenterY + roofThickness / 2 + 0.015, zPos + zFlangeOffset);
        rTop.rotation.z = -singleSlopeAngle;
        rTop.castShadow = true;
        ssGroup.add(rTop);

        // 3. Finished Sloped Gable Soffit under overhang
        if (overhangFt > 0) {
          const ssSoffitGeo = new THREE.BoxGeometry(singleSlopeRafterLen, 0.03, overhangFt);
          const ssSoffitMesh = new THREE.Mesh(ssSoffitGeo, soffitMat);
          ssSoffitMesh.position.set(0, ssCenterY - roofThickness / 2 - 0.08, (wallZ + zPos) / 2);
          ssSoffitMesh.rotation.z = -singleSlopeAngle;
          ssSoffitMesh.receiveShadow = true;
          ssGroup.add(ssSoffitMesh);

          // Wall receiver trim
          const ssReceiver = new THREE.Mesh(new THREE.BoxGeometry(singleSlopeRafterLen, 0.08, 0.08), cornerTrimMat);
          ssReceiver.position.set(0, ssCenterY - roofThickness / 2 - 0.10, wallZ + (isFront ? 0.04 : -0.04));
          ssReceiver.rotation.z = -singleSlopeAngle;
          ssGroup.add(ssReceiver);

          // Boxed eave corner returns
          const lowReturn = new THREE.Mesh(new THREE.BoxGeometry(overhangFt + 0.04, eaveFasciaHeight, 0.08), rakeTrimMat);
          lowReturn.position.set(halfW + overhangFt / 2, lowFasciaCenterY, zPos);
          ssGroup.add(lowReturn);

          const highReturn = new THREE.Mesh(new THREE.BoxGeometry(overhangFt + 0.04, eaveFasciaHeight, 0.08), rakeTrimMat);
          highReturn.position.set(-halfW - overhangFt / 2, singleSlopeHighEaveY + overhangFt * Math.tan(singleSlopeAngle) - eaveFasciaHeight / 2, zPos);
          ssGroup.add(highReturn);
        }

        buildingGroup.add(ssGroup);
      };
      addSingleSlopeRake(halfL + overhangFt, halfL, true);
      addSingleSlopeRake(-halfL - overhangFt, -halfL, false);

    } else if (style === 'monitor') {
      // 4 Roof Planes: Left wing, Right wing, Center left slope, Center right slope
      const wingRoofLength = roofLengthWithOverhang;
      const raisedRoofLength = roofLengthWithOverhang;

      // 1. Left Wing Roof Plane
      const lWingGeo = new THREE.BoxGeometry(monitorWingRafterLen, roofThickness, wingRoofLength);
      const lWing = new THREE.Mesh(lWingGeo, roofMat);
      const lWingCenterX = -halfW + monitorWingWidth / 2 - (overhangFt * Math.cos(monitorWingAngle)) / 2;
      const lWingCenterY = eaveHeight + monitorWingRise / 2 - (overhangFt * Math.sin(monitorWingAngle)) / 2;
      lWing.position.set(lWingCenterX, lWingCenterY, 0);
      lWing.rotation.z = monitorWingAngle;
      lWing.castShadow = true;
      lWing.receiveShadow = true;
      lWing.add(buildRoofAgPanelRibs(monitorWingRafterLen, wingRoofLength, roofThickness, roofRibMat));
      buildingGroup.add(lWing);

      // 2. Right Wing Roof Plane
      const rWingGeo = new THREE.BoxGeometry(monitorWingRafterLen, roofThickness, wingRoofLength);
      const rWing = new THREE.Mesh(rWingGeo, roofMat);
      const rWingCenterX = halfW - monitorWingWidth / 2 + (overhangFt * Math.cos(monitorWingAngle)) / 2;
      const rWingCenterY = eaveHeight + monitorWingRise / 2 - (overhangFt * Math.sin(monitorWingAngle)) / 2;
      rWing.position.set(rWingCenterX, rWingCenterY, 0);
      rWing.rotation.z = -monitorWingAngle;
      rWing.castShadow = true;
      rWing.receiveShadow = true;
      rWing.add(buildRoofAgPanelRibs(monitorWingRafterLen, wingRoofLength, roofThickness, roofRibMat));
      buildingGroup.add(rWing);

      // 3. Raised Center Left Slope
      const clGeo = new THREE.BoxGeometry(monitorCenterRafterLen, roofThickness, raisedRoofLength);
      const clMesh = new THREE.Mesh(clGeo, roofMat);
      const clCenterX = -monitorHalfCenterW / 2;
      const clCenterY = monitorRaisedEaveY + monitorCenterRise / 2;
      clMesh.position.set(clCenterX, clCenterY, 0);
      clMesh.rotation.z = monitorCenterAngle;
      clMesh.castShadow = true;
      clMesh.receiveShadow = true;
      clMesh.add(buildRoofAgPanelRibs(monitorCenterRafterLen, raisedRoofLength, roofThickness, roofRibMat));
      buildingGroup.add(clMesh);

      // 4. Raised Center Right Slope
      const crGeo = new THREE.BoxGeometry(monitorCenterRafterLen, roofThickness, raisedRoofLength);
      const crMesh = new THREE.Mesh(crGeo, roofMat);
      const crCenterX = monitorHalfCenterW / 2;
      const crCenterY = monitorRaisedEaveY + monitorCenterRise / 2;
      crMesh.position.set(crCenterX, crCenterY, 0);
      crMesh.rotation.z = -monitorCenterAngle;
      crMesh.castShadow = true;
      crMesh.receiveShadow = true;
      crMesh.add(buildRoofAgPanelRibs(monitorCenterRafterLen, raisedRoofLength, roofThickness, roofRibMat));
      buildingGroup.add(crMesh);

      // Trims for Monitor:
      // Wing Eave Trims (outer edges - plumb fascia wrap)
      const monitorWingFasciaTopY = eaveHeight - overhangFt * Math.tan(monitorWingAngle);
      const monitorWingFasciaCenterY = monitorWingFasciaTopY - eaveFasciaHeight / 2;
      const wingFasciaGeo = new THREE.BoxGeometry(0.06, eaveFasciaHeight, wingRoofLength + 0.08);

      const leftWingEave = new THREE.Mesh(wingFasciaGeo, fasciaMat);
      leftWingEave.position.set(-(halfW + overhangFt - 0.03), monitorWingFasciaCenterY, 0);
      buildingGroup.add(leftWingEave);

      const rightWingEave = new THREE.Mesh(wingFasciaGeo, fasciaMat);
      rightWingEave.position.set(halfW + overhangFt - 0.03, monitorWingFasciaCenterY, 0);
      buildingGroup.add(rightWingEave);

      // Wing Drip Edge
      const wingDripGeo = new THREE.BoxGeometry(0.06, 0.14, wingRoofLength + 0.12);
      const leftWingDrip = new THREE.Mesh(wingDripGeo, dripEdgeMat);
      leftWingDrip.position.set(-(halfW + overhangFt + 0.02), monitorWingFasciaTopY - 0.04, 0);
      buildingGroup.add(leftWingDrip);

      const rightWingDrip = new THREE.Mesh(wingDripGeo, dripEdgeMat);
      rightWingDrip.position.set(halfW + overhangFt + 0.02, monitorWingFasciaTopY - 0.04, 0);
      buildingGroup.add(rightWingDrip);

      // Horizontal soffit under wing overhangs
      if (overhangFt > 0) {
        const wingSoffitGeo = new THREE.BoxGeometry(overhangFt, 0.04, wingRoofLength);
        const lSoffit = new THREE.Mesh(wingSoffitGeo, soffitMat);
        lSoffit.position.set(-(halfW + overhangFt / 2), monitorWingFasciaTopY - eaveFasciaHeight + 0.03, 0);
        buildingGroup.add(lSoffit);

        const rSoffit = new THREE.Mesh(wingSoffitGeo, soffitMat);
        rSoffit.position.set(halfW + overhangFt / 2, monitorWingFasciaTopY - eaveFasciaHeight + 0.03, 0);
        buildingGroup.add(rSoffit);
      }

      // Optional Gutters on Monitor wings (disabled by default)
      if (hasGutters) {
        const wingGutterGeo = new THREE.BoxGeometry(0.42, 0.44, wingRoofLength);
        const lGutter = new THREE.Mesh(wingGutterGeo, gutterMat);
        lGutter.position.set(-(halfW + overhangFt + 0.22), monitorWingFasciaCenterY + 0.04, 0);
        buildingGroup.add(lGutter);

        const rGutter = new THREE.Mesh(wingGutterGeo, gutterMat);
        rGutter.position.set(halfW + overhangFt + 0.22, monitorWingFasciaCenterY + 0.04, 0);
        buildingGroup.add(rGutter);
      }

      // Raised Center Eave Trims
      const raisedFasciaGeo = new THREE.BoxGeometry(0.06, 0.40, raisedRoofLength + 0.08);
      const leftRaisedEave = new THREE.Mesh(raisedFasciaGeo, fasciaMat);
      leftRaisedEave.position.set(-monitorHalfCenterW - 0.02, monitorRaisedEaveY - 0.20, 0);
      buildingGroup.add(leftRaisedEave);

      const rightRaisedEave = new THREE.Mesh(raisedFasciaGeo, fasciaMat);
      rightRaisedEave.position.set(monitorHalfCenterW + 0.02, monitorRaisedEaveY - 0.20, 0);
      buildingGroup.add(rightRaisedEave);

      // Ridge Cap on Raised Center
      const monitorRidgeCap = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.2, raisedRoofLength + 0.4), ridgeCapMat);
      monitorRidgeCap.position.set(0, monitorRaisedRidgeY + 0.15, 0);
      monitorRidgeCap.castShadow = true;
      buildingGroup.add(monitorRidgeCap);

      // Finished Architectural Monitor Rake Trims and Gable Soffits
      const wingRakeFaceGeo = new THREE.BoxGeometry(monitorWingRafterLen, eaveFasciaHeight * Math.cos(monitorWingAngle), 0.06);
      const wingTopFlangeGeo = new THREE.BoxGeometry(monitorWingRafterLen, 0.035, 0.38);
      const centerRakeFaceGeo = new THREE.BoxGeometry(monitorCenterRafterLen, eaveFasciaHeight * Math.cos(monitorCenterAngle), 0.06);
      const centerTopFlangeGeo = new THREE.BoxGeometry(monitorCenterRafterLen, 0.035, 0.38);

      const addMonitorRakes = (zPos: number, wallZ: number, isFront: boolean) => {
        const monGroup = new THREE.Group();
        const zFlangeOffset = isFront ? -0.19 : 0.19;

        // Wing rakes: Left & Right
        const wl = new THREE.Mesh(wingRakeFaceGeo, rakeTrimMat);
        wl.position.set(lWingCenterX, lWingCenterY - 0.02, zPos);
        wl.rotation.z = monitorWingAngle;
        wl.castShadow = true;
        monGroup.add(wl);

        const wlTop = new THREE.Mesh(wingTopFlangeGeo, rakeTrimMat);
        wlTop.position.set(lWingCenterX, lWingCenterY + roofThickness / 2 + 0.015, zPos + zFlangeOffset);
        wlTop.rotation.z = monitorWingAngle;
        monGroup.add(wlTop);

        const wr = new THREE.Mesh(wingRakeFaceGeo, rakeTrimMat);
        wr.position.set(rWingCenterX, rWingCenterY - 0.02, zPos);
        wr.rotation.z = -monitorWingAngle;
        wr.castShadow = true;
        monGroup.add(wr);

        const wrTop = new THREE.Mesh(wingTopFlangeGeo, rakeTrimMat);
        wrTop.position.set(rWingCenterX, rWingCenterY + roofThickness / 2 + 0.015, zPos + zFlangeOffset);
        wrTop.rotation.z = -monitorWingAngle;
        monGroup.add(wrTop);

        // Center rakes: Left & Right
        const clRake = new THREE.Mesh(centerRakeFaceGeo, rakeTrimMat);
        clRake.position.set(clCenterX, clCenterY - 0.02, zPos);
        clRake.rotation.z = monitorCenterAngle;
        clRake.castShadow = true;
        monGroup.add(clRake);

        const clTop = new THREE.Mesh(centerTopFlangeGeo, rakeTrimMat);
        clTop.position.set(clCenterX, clCenterY + roofThickness / 2 + 0.015, zPos + zFlangeOffset);
        clTop.rotation.z = monitorCenterAngle;
        monGroup.add(clTop);

        const crRake = new THREE.Mesh(centerRakeFaceGeo, rakeTrimMat);
        crRake.position.set(crCenterX, crCenterY - 0.02, zPos);
        crRake.rotation.z = -monitorCenterAngle;
        crRake.castShadow = true;
        monGroup.add(crRake);

        const crTop = new THREE.Mesh(centerTopFlangeGeo, rakeTrimMat);
        crTop.position.set(crCenterX, crCenterY + roofThickness / 2 + 0.015, zPos + zFlangeOffset);
        crTop.rotation.z = -monitorCenterAngle;
        monGroup.add(crTop);

        // Center Apex Cap
        const monApex = new THREE.Mesh(new THREE.BoxGeometry(0.75, 0.35, 0.12), rakeTrimMat);
        monApex.position.set(0, monitorRaisedRidgeY + 0.05, zPos);
        monGroup.add(monApex);

        // Finished Gable Soffits under overhangs
        if (overhangFt > 0) {
          const soffitZ = (wallZ + zPos) / 2;

          // Wing soffits
          const wlSoffit = new THREE.Mesh(new THREE.BoxGeometry(monitorWingRafterLen, 0.03, overhangFt), soffitMat);
          wlSoffit.position.set(lWingCenterX, lWingCenterY - roofThickness / 2 - 0.08, soffitZ);
          wlSoffit.rotation.z = monitorWingAngle;
          monGroup.add(wlSoffit);

          const wrSoffit = new THREE.Mesh(new THREE.BoxGeometry(monitorWingRafterLen, 0.03, overhangFt), soffitMat);
          wrSoffit.position.set(rWingCenterX, rWingCenterY - roofThickness / 2 - 0.08, soffitZ);
          wrSoffit.rotation.z = -monitorWingAngle;
          monGroup.add(wrSoffit);

          // Center soffits
          const clSoffit = new THREE.Mesh(new THREE.BoxGeometry(monitorCenterRafterLen, 0.03, overhangFt), soffitMat);
          clSoffit.position.set(clCenterX, clCenterY - roofThickness / 2 - 0.08, soffitZ);
          clSoffit.rotation.z = monitorCenterAngle;
          monGroup.add(clSoffit);

          const crSoffit = new THREE.Mesh(new THREE.BoxGeometry(monitorCenterRafterLen, 0.03, overhangFt), soffitMat);
          crSoffit.position.set(crCenterX, crCenterY - roofThickness / 2 - 0.08, soffitZ);
          crSoffit.rotation.z = -monitorCenterAngle;
          monGroup.add(crSoffit);

          // Eave boxed corner returns on wings
          const lReturn = new THREE.Mesh(new THREE.BoxGeometry(overhangFt + 0.04, eaveFasciaHeight, 0.08), rakeTrimMat);
          lReturn.position.set(-halfW - overhangFt / 2, eaveHeight - eaveFasciaHeight / 2, zPos);
          monGroup.add(lReturn);

          const rReturn = new THREE.Mesh(new THREE.BoxGeometry(overhangFt + 0.04, eaveFasciaHeight, 0.08), rakeTrimMat);
          rReturn.position.set(halfW + overhangFt / 2, eaveHeight - eaveFasciaHeight / 2, zPos);
          monGroup.add(rReturn);
        }

        buildingGroup.add(monGroup);
      };
      addMonitorRakes(halfL + overhangFt, halfL, true);
      addMonitorRakes(-halfL - overhangFt, -halfL, false);

    } else if (style === 'gambrel') {
      // 4 Roof Planes: Lower Left, Lower Right, Upper Left, Upper Right
      // 1. Lower Left Steep Slope
      const llGeo = new THREE.BoxGeometry(gambrelLowerRafterLen, roofThickness, roofLengthWithOverhang);
      const llMesh = new THREE.Mesh(llGeo, roofMat);
      const llCenterX = -halfW + gambrelLowerSpan / 2 - (overhangFt * Math.cos(gambrelLowerAngle)) / 2;
      const llCenterY = eaveHeight + gambrelKnuckleRise / 2 - (overhangFt * Math.sin(gambrelLowerAngle)) / 2;
      llMesh.position.set(llCenterX, llCenterY, 0);
      llMesh.rotation.z = gambrelLowerAngle;
      llMesh.castShadow = true;
      llMesh.receiveShadow = true;
      llMesh.add(buildRoofAgPanelRibs(gambrelLowerRafterLen, roofLengthWithOverhang, roofThickness, roofRibMat));
      buildingGroup.add(llMesh);

      // 2. Lower Right Steep Slope
      const lrGeo = new THREE.BoxGeometry(gambrelLowerRafterLen, roofThickness, roofLengthWithOverhang);
      const lrMesh = new THREE.Mesh(lrGeo, roofMat);
      const lrCenterX = halfW - gambrelLowerSpan / 2 + (overhangFt * Math.cos(gambrelLowerAngle)) / 2;
      const lrCenterY = eaveHeight + gambrelKnuckleRise / 2 - (overhangFt * Math.sin(gambrelLowerAngle)) / 2;
      lrMesh.position.set(lrCenterX, lrCenterY, 0);
      lrMesh.rotation.z = -gambrelLowerAngle;
      lrMesh.castShadow = true;
      lrMesh.receiveShadow = true;
      lrMesh.add(buildRoofAgPanelRibs(gambrelLowerRafterLen, roofLengthWithOverhang, roofThickness, roofRibMat));
      buildingGroup.add(lrMesh);

      // 3. Upper Left Shallow Slope
      const ulGeo = new THREE.BoxGeometry(gambrelUpperRafterLen, roofThickness, roofLengthWithOverhang);
      const ulMesh = new THREE.Mesh(ulGeo, roofMat);
      const ulCenterX = -gambrelKnuckleX / 2;
      const ulCenterY = gambrelKnuckleY + gambrelUpperRise / 2;
      ulMesh.position.set(ulCenterX, ulCenterY, 0);
      ulMesh.rotation.z = gambrelUpperAngle;
      ulMesh.castShadow = true;
      ulMesh.receiveShadow = true;
      ulMesh.add(buildRoofAgPanelRibs(gambrelUpperRafterLen, roofLengthWithOverhang, roofThickness, roofRibMat));
      buildingGroup.add(ulMesh);

      // 4. Upper Right Shallow Slope
      const urGeo = new THREE.BoxGeometry(gambrelUpperRafterLen, roofThickness, roofLengthWithOverhang);
      const urMesh = new THREE.Mesh(urGeo, roofMat);
      const urCenterX = gambrelKnuckleX / 2;
      const urCenterY = gambrelKnuckleY + gambrelUpperRise / 2;
      urMesh.position.set(urCenterX, urCenterY, 0);
      urMesh.rotation.z = -gambrelUpperAngle;
      urMesh.castShadow = true;
      urMesh.receiveShadow = true;
      urMesh.add(buildRoofAgPanelRibs(gambrelUpperRafterLen, roofLengthWithOverhang, roofThickness, roofRibMat));
      buildingGroup.add(urMesh);

      // Knuckle Transition Flashing Trims along joints
      const knuckleFlashingGeo = new THREE.BoxGeometry(0.5, 0.15, roofLengthWithOverhang + 0.2);
      const leftKnuckleFlashing = new THREE.Mesh(knuckleFlashingGeo, eaveTrimMat);
      leftKnuckleFlashing.position.set(-gambrelKnuckleX, gambrelKnuckleY + 0.05, 0);
      buildingGroup.add(leftKnuckleFlashing);

      const rightKnuckleFlashing = new THREE.Mesh(knuckleFlashingGeo, eaveTrimMat);
      rightKnuckleFlashing.position.set(gambrelKnuckleX, gambrelKnuckleY + 0.05, 0);
      buildingGroup.add(rightKnuckleFlashing);

      // Eave Trims (plumb fascia cover & drip edge)
      const gambrelFasciaTopY = eaveHeight - overhangFt * Math.tan(gambrelLowerAngle);
      const gambrelFasciaCenterY = gambrelFasciaTopY - eaveFasciaHeight / 2;
      const gambrelFasciaGeo = new THREE.BoxGeometry(0.06, eaveFasciaHeight, roofLengthWithOverhang + 0.08);

      const leftEaveTrim = new THREE.Mesh(gambrelFasciaGeo, fasciaMat);
      leftEaveTrim.position.set(-(halfW + overhangFt - 0.03), gambrelFasciaCenterY, 0);
      buildingGroup.add(leftEaveTrim);

      const rightEaveTrim = new THREE.Mesh(gambrelFasciaGeo, fasciaMat);
      rightEaveTrim.position.set(halfW + overhangFt - 0.03, gambrelFasciaCenterY, 0);
      buildingGroup.add(rightEaveTrim);

      // Low Eave Drip Edge
      const gambrelDripGeo = new THREE.BoxGeometry(0.06, 0.14, roofLengthWithOverhang + 0.12);
      const leftGambrelDrip = new THREE.Mesh(gambrelDripGeo, dripEdgeMat);
      leftGambrelDrip.position.set(-(halfW + overhangFt + 0.02), gambrelFasciaTopY - 0.04, 0);
      buildingGroup.add(leftGambrelDrip);

      const rightGambrelDrip = new THREE.Mesh(gambrelDripGeo, dripEdgeMat);
      rightGambrelDrip.position.set(halfW + overhangFt + 0.02, gambrelFasciaTopY - 0.04, 0);
      buildingGroup.add(rightGambrelDrip);

      // Horizontal soffit under gambrel eave overhangs
      if (overhangFt > 0) {
        const gSoffitGeo = new THREE.BoxGeometry(overhangFt, 0.04, roofLengthWithOverhang);
        const lGSoffit = new THREE.Mesh(gSoffitGeo, soffitMat);
        lGSoffit.position.set(-(halfW + overhangFt / 2), gambrelFasciaTopY - eaveFasciaHeight + 0.03, 0);
        buildingGroup.add(lGSoffit);

        const rGSoffit = new THREE.Mesh(gSoffitGeo, soffitMat);
        rGSoffit.position.set(halfW + overhangFt / 2, gambrelFasciaTopY - eaveFasciaHeight + 0.03, 0);
        buildingGroup.add(rGSoffit);
      }

      // Optional gutters (disabled by default)
      if (hasGutters) {
        const gGutterGeo = new THREE.BoxGeometry(0.42, 0.44, roofLengthWithOverhang);
        const lGutter = new THREE.Mesh(gGutterGeo, gutterMat);
        lGutter.position.set(-(halfW + overhangFt + 0.22), gambrelFasciaCenterY + 0.04, 0);
        buildingGroup.add(lGutter);

        const rGutter = new THREE.Mesh(gGutterGeo, gutterMat);
        rGutter.position.set(halfW + overhangFt + 0.22, gambrelFasciaCenterY + 0.04, 0);
        buildingGroup.add(rGutter);
      }

      // Ridge Cap
      const gambrelRidgeCap = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.2, roofLengthWithOverhang + 0.4), ridgeCapMat);
      gambrelRidgeCap.position.set(0, gambrelRidgeY + 0.15, 0);
      gambrelRidgeCap.castShadow = true;
      buildingGroup.add(gambrelRidgeCap);

      // Finished Architectural Gambrel Rake Trims and Gable Soffits
      const gLowerRakeFaceGeo = new THREE.BoxGeometry(gambrelLowerRafterLen, eaveFasciaHeight * Math.cos(gambrelLowerAngle), 0.06);
      const gLowerTopFlangeGeo = new THREE.BoxGeometry(gambrelLowerRafterLen, 0.035, 0.38);
      const gUpperRakeFaceGeo = new THREE.BoxGeometry(gambrelUpperRafterLen, eaveFasciaHeight * Math.cos(gambrelUpperAngle), 0.06);
      const gUpperTopFlangeGeo = new THREE.BoxGeometry(gambrelUpperRafterLen, 0.035, 0.38);

      const addGambrelRakes = (zPos: number, wallZ: number, isFront: boolean) => {
        const gamGroup = new THREE.Group();
        const zFlangeOffset = isFront ? -0.19 : 0.19;

        // 1. Lower Rakes
        const llRake = new THREE.Mesh(gLowerRakeFaceGeo, rakeTrimMat);
        llRake.position.set(llCenterX, llCenterY - 0.02, zPos);
        llRake.rotation.z = gambrelLowerAngle;
        llRake.castShadow = true;
        gamGroup.add(llRake);

        const llTop = new THREE.Mesh(gLowerTopFlangeGeo, rakeTrimMat);
        llTop.position.set(llCenterX, llCenterY + roofThickness / 2 + 0.015, zPos + zFlangeOffset);
        llTop.rotation.z = gambrelLowerAngle;
        gamGroup.add(llTop);

        const lrRake = new THREE.Mesh(gLowerRakeFaceGeo, rakeTrimMat);
        lrRake.position.set(lrCenterX, lrCenterY - 0.02, zPos);
        lrRake.rotation.z = -gambrelLowerAngle;
        lrRake.castShadow = true;
        gamGroup.add(lrRake);

        const lrTop = new THREE.Mesh(gLowerTopFlangeGeo, rakeTrimMat);
        lrTop.position.set(lrCenterX, lrCenterY + roofThickness / 2 + 0.015, zPos + zFlangeOffset);
        lrTop.rotation.z = -gambrelLowerAngle;
        gamGroup.add(lrTop);

        // 2. Upper Rakes
        const ulRake = new THREE.Mesh(gUpperRakeFaceGeo, rakeTrimMat);
        ulRake.position.set(ulCenterX, ulCenterY - 0.02, zPos);
        ulRake.rotation.z = gambrelUpperAngle;
        ulRake.castShadow = true;
        gamGroup.add(ulRake);

        const ulTop = new THREE.Mesh(gUpperTopFlangeGeo, rakeTrimMat);
        ulTop.position.set(ulCenterX, ulCenterY + roofThickness / 2 + 0.015, zPos + zFlangeOffset);
        ulTop.rotation.z = gambrelUpperAngle;
        gamGroup.add(ulTop);

        const urRake = new THREE.Mesh(gUpperRakeFaceGeo, rakeTrimMat);
        urRake.position.set(urCenterX, urCenterY - 0.02, zPos);
        urRake.rotation.z = -gambrelUpperAngle;
        urRake.castShadow = true;
        gamGroup.add(urRake);

        const urTop = new THREE.Mesh(gUpperTopFlangeGeo, rakeTrimMat);
        urTop.position.set(urCenterX, urCenterY + roofThickness / 2 + 0.015, zPos + zFlangeOffset);
        urTop.rotation.z = -gambrelUpperAngle;
        gamGroup.add(urTop);

        // Knuckle transition caps
        const knuckleCapGeo = new THREE.BoxGeometry(0.5, 0.4, 0.12);
        const lKnuckleCap = new THREE.Mesh(knuckleCapGeo, rakeTrimMat);
        lKnuckleCap.position.set(-gambrelKnuckleX, gambrelKnuckleY, zPos);
        gamGroup.add(lKnuckleCap);

        const rKnuckleCap = new THREE.Mesh(knuckleCapGeo, rakeTrimMat);
        rKnuckleCap.position.set(gambrelKnuckleX, gambrelKnuckleY, zPos);
        gamGroup.add(rKnuckleCap);

        // Ridge Apex Cap
        const gRidgeCap = new THREE.Mesh(new THREE.BoxGeometry(0.75, 0.35, 0.12), rakeTrimMat);
        gRidgeCap.position.set(0, gambrelRidgeY + 0.05, zPos);
        gamGroup.add(gRidgeCap);

        // Finished Gable Soffits under overhangs
        if (overhangFt > 0) {
          const soffitZ = (wallZ + zPos) / 2;

          const llSoffit = new THREE.Mesh(new THREE.BoxGeometry(gambrelLowerRafterLen, 0.03, overhangFt), soffitMat);
          llSoffit.position.set(llCenterX, llCenterY - roofThickness / 2 - 0.08, soffitZ);
          llSoffit.rotation.z = gambrelLowerAngle;
          gamGroup.add(llSoffit);

          const lrSoffit = new THREE.Mesh(new THREE.BoxGeometry(gambrelLowerRafterLen, 0.03, overhangFt), soffitMat);
          lrSoffit.position.set(lrCenterX, lrCenterY - roofThickness / 2 - 0.08, soffitZ);
          lrSoffit.rotation.z = -gambrelLowerAngle;
          gamGroup.add(lrSoffit);

          const ulSoffit = new THREE.Mesh(new THREE.BoxGeometry(gambrelUpperRafterLen, 0.03, overhangFt), soffitMat);
          ulSoffit.position.set(ulCenterX, ulCenterY - roofThickness / 2 - 0.08, soffitZ);
          ulSoffit.rotation.z = gambrelUpperAngle;
          gamGroup.add(ulSoffit);

          const urSoffit = new THREE.Mesh(new THREE.BoxGeometry(gambrelUpperRafterLen, 0.03, overhangFt), soffitMat);
          urSoffit.position.set(urCenterX, urCenterY - roofThickness / 2 - 0.08, soffitZ);
          urSoffit.rotation.z = -gambrelUpperAngle;
          gamGroup.add(urSoffit);

          // Eave boxed returns
          const lBox = new THREE.Mesh(new THREE.BoxGeometry(overhangFt + 0.04, eaveFasciaHeight, 0.08), rakeTrimMat);
          lBox.position.set(-(halfW + overhangFt / 2), gambrelFasciaCenterY, zPos);
          gamGroup.add(lBox);

          const rBox = new THREE.Mesh(new THREE.BoxGeometry(overhangFt + 0.04, eaveFasciaHeight, 0.08), rakeTrimMat);
          rBox.position.set(halfW + overhangFt / 2, gambrelFasciaCenterY, zPos);
          gamGroup.add(rBox);
        }

        buildingGroup.add(gamGroup);
      };
      addGambrelRakes(halfL + overhangFt, halfL, true);
      addGambrelRakes(-halfL - overhangFt, -halfL, false);

    } else {
      // Gable and Commercial styles
      const leftRoofGeo = new THREE.BoxGeometry(standardRafterLen, roofThickness, roofLengthWithOverhang);
      const leftRoof = new THREE.Mesh(leftRoofGeo, roofMat);
      const leftCenterX = -(halfW + overhangFt + standardMetalLip * Math.cos(standardRoofAngle)) / 2;
      const leftCenterY = (standardRidgeY + (standardFasciaTopY - standardMetalLip * Math.sin(standardRoofAngle))) / 2;
      leftRoof.position.set(leftCenterX, leftCenterY, 0);
      leftRoof.rotation.z = standardRoofAngle;
      leftRoof.castShadow = true;
      leftRoof.receiveShadow = true;
      leftRoof.add(buildRoofAgPanelRibs(standardRafterLen, roofLengthWithOverhang, roofThickness, roofRibMat));
      buildingGroup.add(leftRoof);

      const rightRoofGeo = new THREE.BoxGeometry(standardRafterLen, roofThickness, roofLengthWithOverhang);
      const rightRoof = new THREE.Mesh(rightRoofGeo, roofMat);
      const rightCenterX = -leftCenterX;
      const rightCenterY = leftCenterY;
      rightRoof.position.set(rightCenterX, rightCenterY, 0);
      rightRoof.rotation.z = -standardRoofAngle;
      rightRoof.castShadow = true;
      rightRoof.receiveShadow = true;
      rightRoof.add(buildRoofAgPanelRibs(standardRafterLen, roofLengthWithOverhang, roofThickness, roofRibMat));
      buildingGroup.add(rightRoof);

      // Plumb Metal Fascia Wraps along left and right eaves (contractor build standard)
      const fasciaGeo = new THREE.BoxGeometry(0.06, eaveFasciaHeight, roofLengthWithOverhang + 0.08);
      
      const leftFascia = new THREE.Mesh(fasciaGeo, fasciaMat);
      leftFascia.position.set(-(halfW + overhangFt - 0.03), standardFasciaCenterY, 0);
      leftFascia.castShadow = true;
      buildingGroup.add(leftFascia);

      const rightFascia = new THREE.Mesh(fasciaGeo, fasciaMat);
      rightFascia.position.set(halfW + overhangFt - 0.03, standardFasciaCenterY, 0);
      rightFascia.castShadow = true;
      buildingGroup.add(rightFascia);

      // Low Eave Drip Edge Flashing (hugs top edge of fascia under metal roof overhang lip)
      const dripEdgeGeo = new THREE.BoxGeometry(0.06, 0.14, roofLengthWithOverhang + 0.12);
      
      const leftDripEdge = new THREE.Mesh(dripEdgeGeo, dripEdgeMat);
      leftDripEdge.position.set(-(halfW + overhangFt + 0.02), standardFasciaTopY - 0.04, 0);
      buildingGroup.add(leftDripEdge);

      const rightDripEdge = new THREE.Mesh(dripEdgeGeo, dripEdgeMat);
      rightDripEdge.position.set(halfW + overhangFt + 0.02, standardFasciaTopY - 0.04, 0);
      buildingGroup.add(rightDripEdge);

      // Horizontal Soffit Panels under eave overhangs
      if (overhangFt > 0) {
        const soffitThick = 0.04;
        const soffitY = standardFasciaTopY - eaveFasciaHeight + 0.03;
        
        const soffitGeo = new THREE.BoxGeometry(overhangFt, soffitThick, roofLengthWithOverhang);
        
        const leftSoffit = new THREE.Mesh(soffitGeo, soffitMat);
        leftSoffit.position.set(-(halfW + overhangFt / 2), soffitY, 0);
        buildingGroup.add(leftSoffit);

        const rightSoffit = new THREE.Mesh(soffitGeo, soffitMat);
        rightSoffit.position.set(halfW + overhangFt / 2, soffitY, 0);
        buildingGroup.add(rightSoffit);

      }

      // Optional Gutters & Downspouts (Disabled by default / No Gutters per contractor build photo)
      if (hasGutters) {
        const gutterGeo = new THREE.BoxGeometry(0.42, 0.44, roofLengthWithOverhang);
        const leftGutter = new THREE.Mesh(gutterGeo, gutterMat);
        leftGutter.position.set(-(halfW + overhangFt + 0.22), standardFasciaCenterY + 0.04, 0);
        buildingGroup.add(leftGutter);

        const rightGutter = new THREE.Mesh(gutterGeo, gutterMat);
        rightGutter.position.set(halfW + overhangFt + 0.22, standardFasciaCenterY + 0.04, 0);
        buildingGroup.add(rightGutter);

        // Downspouts (3"x4" vertical pipes)
        const dsH = standardFasciaCenterY + 0.04;
        const dsGeo = new THREE.BoxGeometry(0.25, dsH, 0.3);
        const addDownspout = (xPos: number, zPos: number) => {
          const ds = new THREE.Mesh(dsGeo, gutterMat);
          ds.position.set(xPos, dsH / 2, zPos);
          buildingGroup.add(ds);
        };
        addDownspout(-(halfW + overhangFt + 0.15), halfL + overhangFt * 0.8);
        addDownspout(-(halfW + overhangFt + 0.15), -(halfL + overhangFt * 0.8));
        addDownspout(halfW + overhangFt + 0.15, halfL + overhangFt * 0.8);
        addDownspout(halfW + overhangFt + 0.15, -(halfL + overhangFt * 0.8));
      }

      // Snow Guards Rail System (installed on top of roof panels 3' to 4' up from eave)
      const snowGuardsActive = materials.hasSnowGuards ?? (state.snowLoad >= 30);
      if (snowGuardsActive) {
        const snowGuardDistUpSlope = 3.5;
        const sgRailGeo = new THREE.BoxGeometry(0.18, 0.35, roofLengthWithOverhang);
        
        // Left roof snow guard rail
        const sgLeft = new THREE.Mesh(sgRailGeo, snowGuardMat);
        const sgLeftX = -(halfW + overhangFt) + snowGuardDistUpSlope * Math.cos(standardRoofAngle);
        const sgLeftY = standardFasciaTopY + snowGuardDistUpSlope * Math.sin(standardRoofAngle) + 0.22;
        sgLeft.position.set(sgLeftX, sgLeftY, 0);
        sgLeft.rotation.z = standardRoofAngle;
        sgLeft.castShadow = true;
        buildingGroup.add(sgLeft);

        // Right roof snow guard rail
        const sgRight = new THREE.Mesh(sgRailGeo, snowGuardMat);
        const sgRightX = -sgLeftX;
        const sgRightY = sgLeftY;
        sgRight.position.set(sgRightX, sgRightY, 0);
        sgRight.rotation.z = -standardRoofAngle;
        sgRight.castShadow = true;
        buildingGroup.add(sgRight);
      }

      // Ridge Cap
      const ridgeCapGeo = new THREE.BoxGeometry(0.8, 0.2, roofLengthWithOverhang + 0.4);
      const ridgeCap = new THREE.Mesh(ridgeCapGeo, ridgeCapMat);
      ridgeCap.position.set(0, standardRidgeY + 0.15, 0);
      ridgeCap.castShadow = true;
      buildingGroup.add(ridgeCap);

      // Architectural Gable Rake Trims & Finished Under-Overhang Soffit Package
      // (Faithfully reflects post-frame construction per reference photo)
      const rakeFaceH = eaveFasciaHeight; // ~0.52 ft plumb face
      const rakeFaceThick = 0.06;
      const topFlangeWidth = 0.38; // ~4.5 inches wide top flange over roof ribs
      const topFlangeThick = 0.035;

      const rakeFaceGeo = new THREE.BoxGeometry(standardRafterLen, rakeFaceH * Math.cos(standardRoofAngle), rakeFaceThick);
      const topFlangeGeo = new THREE.BoxGeometry(standardRafterLen, topFlangeThick, topFlangeWidth);
      const apexCapGeo = new THREE.BoxGeometry(0.75, 0.35, 0.12);

      const addGableRakePackage = (zPos: number, wallZ: number, isFront: boolean) => {
        const rakeGroup = new THREE.Group();

        // 1. Vertical Plumb Rake Fascia Faces (drops down to cover fly rafter & soffit edge)
        const leftFace = new THREE.Mesh(rakeFaceGeo, rakeTrimMat);
        leftFace.position.set(leftCenterX, leftCenterY - 0.02, zPos);
        leftFace.rotation.z = standardRoofAngle;
        leftFace.castShadow = true;
        rakeGroup.add(leftFace);

        const rightFace = new THREE.Mesh(rakeFaceGeo, rakeTrimMat);
        rightFace.position.set(rightCenterX, rightCenterY - 0.02, zPos);
        rightFace.rotation.z = -standardRoofAngle;
        rightFace.castShadow = true;
        rakeGroup.add(rightFace);

        // 2. Top Rake Flanges (laps over top of metal roof ribs along gable edge)
        const zFlangeOffset = isFront ? -topFlangeWidth / 2 : topFlangeWidth / 2;
        const leftTopFlange = new THREE.Mesh(topFlangeGeo, rakeTrimMat);
        leftTopFlange.position.set(leftCenterX, leftCenterY + roofThickness / 2 + 0.015, zPos + zFlangeOffset);
        leftTopFlange.rotation.z = standardRoofAngle;
        leftTopFlange.castShadow = true;
        rakeGroup.add(leftTopFlange);

        const rightTopFlange = new THREE.Mesh(topFlangeGeo, rakeTrimMat);
        rightTopFlange.position.set(rightCenterX, rightCenterY + roofThickness / 2 + 0.015, zPos + zFlangeOffset);
        rightTopFlange.rotation.z = -standardRoofAngle;
        rightTopFlange.castShadow = true;
        rakeGroup.add(rightTopFlange);

        // 3. Ridge Apex Mitered Peak Cap
        const apexCap = new THREE.Mesh(apexCapGeo, rakeTrimMat);
        apexCap.position.set(0, standardRidgeY + 0.05, zPos);
        apexCap.castShadow = true;
        rakeGroup.add(apexCap);

        // 4. Finished Gable Soffit under overhang (encloses underside of lookouts/fly rafters)
        if (overhangFt > 0) {
          const soffitSpanAlongSlope = standardSlopeToFascia;
          const soffitCenterY = (standardRidgeY + standardFasciaTopY) / 2 - roofThickness / 2 - 0.08;
          const soffitCenterZ = (wallZ + zPos) / 2;
          const gableSoffitGeo = new THREE.BoxGeometry(soffitSpanAlongSlope, 0.03, overhangFt);

          // Left sloped soffit panel
          const leftSoffit = new THREE.Mesh(gableSoffitGeo, soffitMat);
          leftSoffit.position.set(-(halfW + overhangFt) / 2, soffitCenterY, soffitCenterZ);
          leftSoffit.rotation.z = standardRoofAngle;
          leftSoffit.receiveShadow = true;
          rakeGroup.add(leftSoffit);

          // Right sloped soffit panel
          const rightSoffit = new THREE.Mesh(gableSoffitGeo, soffitMat);
          rightSoffit.position.set((halfW + overhangFt) / 2, soffitCenterY, soffitCenterZ);
          rightSoffit.rotation.z = -standardRoofAngle;
          rightSoffit.receiveShadow = true;
          rakeGroup.add(rightSoffit);

          // F & J-channel receiver trim against gable siding
          const receiverGeo = new THREE.BoxGeometry(soffitSpanAlongSlope, 0.08, 0.08);
          const leftReceiver = new THREE.Mesh(receiverGeo, cornerTrimMat);
          leftReceiver.position.set(-(halfW + overhangFt) / 2, soffitCenterY - 0.02, wallZ + (isFront ? 0.04 : -0.04));
          leftReceiver.rotation.z = standardRoofAngle;
          rakeGroup.add(leftReceiver);

          const rightReceiver = new THREE.Mesh(receiverGeo, cornerTrimMat);
          rightReceiver.position.set((halfW + overhangFt) / 2, soffitCenterY - 0.02, wallZ + (isFront ? 0.04 : -0.04));
          rightReceiver.rotation.z = -standardRoofAngle;
          rakeGroup.add(rightReceiver);

          // 5. Boxed Corner Return at Eave Junction (Capping eave fascia & tying into soffit)
          const cornerBoxReturnGeo = new THREE.BoxGeometry(overhangFt + 0.04, eaveFasciaHeight, 0.08);
          const leftBoxReturn = new THREE.Mesh(cornerBoxReturnGeo, rakeTrimMat);
          leftBoxReturn.position.set(-(halfW + overhangFt / 2), standardFasciaCenterY, zPos);
          leftBoxReturn.castShadow = true;
          rakeGroup.add(leftBoxReturn);

          const rightBoxReturn = new THREE.Mesh(cornerBoxReturnGeo, rakeTrimMat);
          rightBoxReturn.position.set(halfW + overhangFt / 2, standardFasciaCenterY, zPos);
          rightBoxReturn.castShadow = true;
          rakeGroup.add(rightBoxReturn);
        }

        buildingGroup.add(rakeGroup);
      };

      if (style !== 'commercial') {
        addGableRakePackage(halfL + overhangFt, halfL, true);
      }
      addGableRakePackage(-halfL - overhangFt, -halfL, false);

      // Extra Commercial Enhancements (Parapet Coping Cap, Corner Returns & Entry Canopy)
      if (style === 'commercial') {
        // 1. Heavy Commercial Parapet Coping Cap along top front edge
        const copingGeo = new THREE.BoxGeometry(width + 0.8, 0.45, 0.7);
        const copingMesh = new THREE.Mesh(copingGeo, cornerTrimMat);
        copingMesh.position.set(0, commercialParapetY + 0.22, halfL);
        copingMesh.castShadow = true;
        buildingGroup.add(copingMesh);

        // 2. Parapet Side Corner Returns
        const parapetReturnGeo = new THREE.BoxGeometry(0.5, commercialParapetY - eaveHeight, 3.5);
        const leftReturn = new THREE.Mesh(parapetReturnGeo, cornerTrimMat);
        leftReturn.position.set(-halfW, eaveHeight + (commercialParapetY - eaveHeight) / 2, halfL - 1.75);
        buildingGroup.add(leftReturn);

        const rightReturn = new THREE.Mesh(parapetReturnGeo, cornerTrimMat);
        rightReturn.position.set(halfW, eaveHeight + (commercialParapetY - eaveHeight) / 2, halfL - 1.75);
        buildingGroup.add(rightReturn);

        // 3. Cantilevered Commercial Entry Canopy / Eyebrow Over Main Entrance
        const canopyGroup = new THREE.Group();
        const canW = 10.0;
        const canDepth = 5.0;
        const canH = 0.5;
        const canopyRoof = new THREE.Mesh(new THREE.BoxGeometry(canW, canH, canDepth), cornerTrimMat);
        canopyRoof.position.set(0, 0, canDepth / 2);
        canopyRoof.castShadow = true;
        canopyGroup.add(canopyRoof);

        // Diagonal steel support rods
        const rodGeo = new THREE.CylinderGeometry(0.04, 0.04, 5.5);
        const rodMat = new THREE.MeshStandardMaterial({ color: '#334155', metalness: 0.8, roughness: 0.2 });
        const leftRod = new THREE.Mesh(rodGeo, rodMat);
        leftRod.position.set(-canW / 2 + 0.5, 1.8, canDepth / 2);
        leftRod.rotation.x = -Math.PI / 4;
        canopyGroup.add(leftRod);

        const rightRod = new THREE.Mesh(rodGeo, rodMat);
        rightRod.position.set(canW / 2 - 0.5, 1.8, canDepth / 2);
        rightRod.rotation.x = -Math.PI / 4;
        canopyGroup.add(rightRod);

        canopyGroup.position.set(0, eaveHeight * 0.72, halfL + 0.15);
        buildingGroup.add(canopyGroup);
      }
    }

    // 4. ARCHITECTURAL TRIMS (Rendered in 3D in their specific colors!)
    // A. 4 Corner Trims (Running vertically along the 4 building corners)
    const cornerTrimSize = 0.45;
    const standardSoffitBottomY = overhangFt > 0 ? (standardFasciaTopY - eaveFasciaHeight + 0.03) : eaveHeight;
    const corners = [
      { x: -halfW, z: -halfL, h: style === 'single_slope' ? (overhangFt > 0 ? singleSlopeHighEaveY - eaveFasciaHeight : singleSlopeHighEaveY) : (style === 'commercial' ? eaveHeight : standardSoffitBottomY) },
      { x: -halfW, z: halfL, h: style === 'commercial' ? commercialParapetY : (style === 'single_slope' ? (overhangFt > 0 ? singleSlopeHighEaveY - eaveFasciaHeight : singleSlopeHighEaveY) : standardSoffitBottomY) },
      { x: halfW, z: -halfL, h: style === 'single_slope' ? (overhangFt > 0 ? singleSlopeLowEaveY - eaveFasciaHeight : eaveHeight) : (style === 'commercial' ? eaveHeight : standardSoffitBottomY) },
      { x: halfW, z: halfL, h: style === 'commercial' ? commercialParapetY : (style === 'single_slope' ? (overhangFt > 0 ? singleSlopeLowEaveY - eaveFasciaHeight : eaveHeight) : standardSoffitBottomY) },
    ];
    corners.forEach((c) => {
      const cGeo = new THREE.BoxGeometry(cornerTrimSize, c.h, cornerTrimSize);
      const cMesh = new THREE.Mesh(cGeo, cornerTrimMat);
      cMesh.position.set(c.x, c.h / 2, c.z);
      cMesh.castShadow = true;
      buildingGroup.add(cMesh);
    });

    // B. Base Trim / Rat Guard (Horizontally along bottom perimeter on skirt board)
    const baseTrimThick = 0.22;
    const baseTrimH = 0.40;
    const baseTrimSideGeo = new THREE.BoxGeometry(baseTrimThick, baseTrimH, length + 0.4);
    const leftBase = new THREE.Mesh(baseTrimSideGeo, ratGuardMat);
    leftBase.position.set(-halfW - 0.05, baseTrimH / 2, 0);
    buildingGroup.add(leftBase);

    const rightBase = new THREE.Mesh(baseTrimSideGeo, ratGuardMat);
    rightBase.position.set(halfW + 0.05, baseTrimH / 2, 0);
    buildingGroup.add(rightBase);

    const baseTrimFrontGeo = new THREE.BoxGeometry(width + 0.4, baseTrimH, baseTrimThick);
    const frontBase = new THREE.Mesh(baseTrimFrontGeo, ratGuardMat);
    frontBase.position.set(0, baseTrimH / 2, halfL + 0.05);
    buildingGroup.add(frontBase);

    const backBase = new THREE.Mesh(baseTrimFrontGeo, ratGuardMat);
    backBase.position.set(0, baseTrimH / 2, -halfL - 0.05);
    buildingGroup.add(backBase);

    // C. Wainscot Double Angle Transition Drip Ledge (Around walls with wainscot)
    if (Object.values(walls).some((w) => w.hasWainscot)) {
      const daThick = 0.16;
      const daH = 0.14;
      if (walls.left.hasWainscot) {
        const daLeft = new THREE.Mesh(new THREE.BoxGeometry(daThick, daH, length + 0.1), wainscotCapMat);
        daLeft.position.set(-halfW - 0.03, wainscotH, 0);
        buildingGroup.add(daLeft);
      }
      if (walls.right.hasWainscot) {
        const daRight = new THREE.Mesh(new THREE.BoxGeometry(daThick, daH, length + 0.1), wainscotCapMat);
        daRight.position.set(halfW + 0.03, wainscotH, 0);
        buildingGroup.add(daRight);
      }
      if (walls.front.hasWainscot) {
        const daFront = new THREE.Mesh(new THREE.BoxGeometry(width + 0.1, daH, daThick), wainscotCapMat);
        daFront.position.set(0, wainscotH, halfL + 0.03);
        buildingGroup.add(daFront);
      }
      if (walls.back.hasWainscot) {
        const daBack = new THREE.Mesh(new THREE.BoxGeometry(width + 0.1, daH, daThick), wainscotCapMat);
        daBack.position.set(0, wainscotH, -halfL - 0.03);
        buildingGroup.add(daBack);
      }
    }

    // 5. DOORS, WINDOWS & WALL OPENINGS
    openings.forEach((op) => {
      const opGroup = new THREE.Group();
      const opW = op.widthFt;
      const opH = op.heightFt;
      const opBottom = op.bottomOffsetFt ?? (op.type === 'window' ? 3 : 0);
      const trimBorder = 0.35;

      // Outer Casing / J-Channel (Captures and hides cut metal panel edges)
      const casingGeo = new THREE.BoxGeometry(opW + trimBorder * 2, opH + trimBorder, 0.3);
      const casingMesh = new THREE.Mesh(casingGeo, doorTrimMat);
      casingMesh.position.set(0, opH / 2, 0);
      opGroup.add(casingMesh);

      if (op.type === 'overhead_door') {
        // Overhead Door Top Header Wrap (wraps around top header wood framing)
        const ohTopWrapGeo = new THREE.BoxGeometry(opW + 0.6, 0.35, 0.38);
        const ohTopWrap = new THREE.Mesh(ohTopWrapGeo, doorTrimMat);
        ohTopWrap.position.set(0, opH + 0.15, 0.05);
        opGroup.add(ohTopWrap);

        // Overhead Door Side Stud Wraps (wraps around vertical posts/studs)
        const ohSideWrapGeo = new THREE.BoxGeometry(0.35, opH, 0.38);
        const ohLeftWrap = new THREE.Mesh(ohSideWrapGeo, doorTrimMat);
        ohLeftWrap.position.set(-opW / 2 - 0.12, opH / 2, 0.05);
        opGroup.add(ohLeftWrap);

        const ohRightWrap = new THREE.Mesh(ohSideWrapGeo, doorTrimMat);
        ohRightWrap.position.set(opW / 2 + 0.12, opH / 2, 0.05);
        opGroup.add(ohRightWrap);

        // Overhead Door Body
        const doorGeo = new THREE.BoxGeometry(opW, opH, 0.35);
        const doorMat = new THREE.MeshStandardMaterial({ color: '#1e293b', roughness: 0.5, metalness: 0.3 });
        const doorMesh = new THREE.Mesh(doorGeo, doorMat);
        doorMesh.position.set(0, opH / 2, 0.05);
        opGroup.add(doorMesh);

        // Horizontal panel dividers
        const panelCount = Math.max(3, Math.round(opH / 2.5));
        for (let p = 1; p < panelCount; p++) {
          const divGeo = new THREE.BoxGeometry(opW - 0.2, 0.08, 0.4);
          const divMat = new THREE.MeshStandardMaterial({ color: '#475569' });
          const divMesh = new THREE.Mesh(divGeo, divMat);
          divMesh.position.set(0, (opH / panelCount) * p, 0.06);
          opGroup.add(divMesh);
        }

        // Window row if enabled
        if (op.hasWindows) {
          const winH = opH / panelCount - 0.4;
          const winRowY = opH - (opH / panelCount) * 0.5;
          const glassPane = new THREE.Mesh(new THREE.BoxGeometry(opW - 0.8, winH, 0.4), glassMat);
          glassPane.position.set(0, winRowY, 0.07);
          opGroup.add(glassPane);
        }
      } else if (op.type === 'walk_door') {
        // Drip Cap right above walk door frame
        const dripCapGeo = new THREE.BoxGeometry(opW + 0.7, 0.14, 0.45);
        const dripCap = new THREE.Mesh(dripCapGeo, doorTrimMat);
        dripCap.position.set(0, opH + 0.18, 0.08);
        opGroup.add(dripCap);

        const doorGeo = new THREE.BoxGeometry(opW, opH, 0.35);
        const doorMat = new THREE.MeshStandardMaterial({ color: '#0f172a', roughness: 0.6, metalness: 0.2 });
        const doorMesh = new THREE.Mesh(doorGeo, doorMat);
        doorMesh.position.set(0, opH / 2, 0.05);
        opGroup.add(doorMesh);

        // Hardware Handle
        const handleGeo = new THREE.CylinderGeometry(0.08, 0.08, 0.4, 8);
        const handleMat = new THREE.MeshStandardMaterial({ color: '#f59e0b', metalness: 0.8, roughness: 0.2 });
        const handleMesh = new THREE.Mesh(handleGeo, handleMat);
        handleMesh.position.set(opW / 2 - 0.4, opH * 0.5, 0.25);
        handleMesh.rotation.z = Math.PI / 2;
        opGroup.add(handleMesh);

        if (op.insulated) {
          const winGeo = new THREE.BoxGeometry(opW * 0.6, opH * 0.35, 0.38);
          const winMesh = new THREE.Mesh(winGeo, glassMat);
          winMesh.position.set(0, opH * 0.68, 0.06);
          opGroup.add(winMesh);
        }
      } else if (op.type === 'window') {
        const sillH = 0; // vertical placement is applied to the opening group

        // Drip Cap right above window frame
        const dripCapGeo = new THREE.BoxGeometry(opW + 0.7, 0.14, 0.45);
        const dripCap = new THREE.Mesh(dripCapGeo, doorTrimMat);
        dripCap.position.set(0, sillH + opH + 0.18, 0.08);
        opGroup.add(dripCap);

        const winGeo = new THREE.BoxGeometry(opW, opH, 0.35);
        const winMesh = new THREE.Mesh(winGeo, glassMat);
        winMesh.position.set(0, sillH + opH / 2, 0.05);
        opGroup.add(winMesh);

        // Window mullion cross
        const mullionMat = new THREE.MeshStandardMaterial({ color: '#f8fafc' });
        const vMullion = new THREE.Mesh(new THREE.BoxGeometry(0.08, opH, 0.38), mullionMat);
        vMullion.position.set(0, sillH + opH / 2, 0.06);
        opGroup.add(vMullion);

        const hMullion = new THREE.Mesh(new THREE.BoxGeometry(opW, 0.08, 0.38), mullionMat);
        hMullion.position.set(0, sillH + opH / 2, 0.06);
        opGroup.add(hMullion);
      } else if (op.type === 'sliding_barn_door') {
        // Vertical sliding door jambs
        const jambGeo = new THREE.BoxGeometry(0.35, opH, 0.4);
        const leftJamb = new THREE.Mesh(jambGeo, doorTrimMat);
        leftJamb.position.set(-opW / 2 - 0.1, opH / 2, 0.04);
        opGroup.add(leftJamb);

        const rightJamb = new THREE.Mesh(jambGeo, doorTrimMat);
        rightJamb.position.set(opW / 2 + 0.1, opH / 2, 0.04);
        opGroup.add(rightJamb);

        const barnDoorMat = new THREE.MeshStandardMaterial({ color: '#1e293b', roughness: 0.7 });
        const leftLeaf = new THREE.Mesh(new THREE.BoxGeometry(opW / 2 - 0.1, opH, 0.35), barnDoorMat);
        leftLeaf.position.set(-opW / 4, opH / 2, 0.05);
        opGroup.add(leftLeaf);

        const rightLeaf = new THREE.Mesh(new THREE.BoxGeometry(opW / 2 - 0.1, opH, 0.35), barnDoorMat);
        rightLeaf.position.set(opW / 4, opH / 2, 0.05);
        opGroup.add(rightLeaf);

        // Overhead Track
        const trackGeo = new THREE.BoxGeometry(opW * 1.3, 0.2, 0.4);
        const trackMat = new THREE.MeshStandardMaterial({ color: '#64748b', metalness: 0.7 });
        const trackMesh = new THREE.Mesh(trackGeo, trackMat);
        trackMesh.position.set(0, opH + 0.2, 0.1);
        opGroup.add(trackMesh);

        // Track Cover (mounted horizontally directly over sliding door trolley track)
        const trackCoverGeo = new THREE.BoxGeometry(opW * 1.35, 0.38, 0.55);
        const trackCoverMesh = new THREE.Mesh(trackCoverGeo, doorTrimMat);
        trackCoverMesh.position.set(0, opH + 0.35, 0.12);
        trackCoverMesh.castShadow = true;
        opGroup.add(trackCoverMesh);
      }

      // Position opening onto appropriate wall
      if (op.side === 'front') {
        const posX = -halfW + op.positionOffsetFt + opW / 2;
        opGroup.position.set(posX, opBottom, halfL + 0.08);
      } else if (op.side === 'back') {
        const posX = halfW - op.positionOffsetFt - opW / 2;
        opGroup.position.set(posX, opBottom, -halfL - 0.08);
        opGroup.rotation.y = Math.PI;
      } else if (op.side === 'left') {
        const posZ = halfL - op.positionOffsetFt - opW / 2;
        opGroup.position.set(-halfW - 0.08, opBottom, posZ);
        opGroup.rotation.y = -Math.PI / 2;
      } else if (op.side === 'right') {
        const posZ = -halfL + op.positionOffsetFt + opW / 2;
        opGroup.position.set(halfW + 0.08, opBottom, posZ);
        opGroup.rotation.y = Math.PI / 2;
      }

      buildingGroup.add(opGroup);
    });

    // 6. LEAN-TO PORCH EXTENSION (If enabled)
    if (leanTo.enabled) {
      const ltWidth = Math.max(4, leanTo.widthFt || 10);
      const hostWallLen = leanTo.side === 'front' || leanTo.side === 'back' ? width : length;
      const ltLength = Math.max(6, Math.min(hostWallLen, leanTo.lengthFt || hostWallLen));
      const maxOffset = Math.max(0, hostWallLen - ltLength);
      const ltOffset = Math.max(0, Math.min(maxOffset, leanTo.startOffsetFt ?? 0));
      
      const ltDrop = Math.max(0, leanTo.dropBelowEaveFt ?? 2);
      const attachmentHeight = Math.max(6.5, eaveHeight - ltDrop);
      
      // Calculate outer post eave height from either outerEaveHeightFt or pitch
      const ltEaveH = leanTo.outerEaveHeightFt
        ? Math.max(6.0, Math.min(attachmentHeight - 0.5, leanTo.outerEaveHeightFt))
        : Math.max(6.0, attachmentHeight - (ltWidth * ((leanTo.pitch || 2) / 12)));
      
      const ltSlopeRise = attachmentHeight - ltEaveH;
      const ltSlopeLen = Math.sqrt(Math.pow(ltWidth, 2) + Math.pow(ltSlopeRise, 2)) + overhangFt;
      const ltAngle = Math.atan2(ltSlopeRise, ltWidth);

      const ltGroup = new THREE.Group();

      // A. Porch Roof Plane (high at building wall, sloping down to outer posts)
      const ltRoofGeo = new THREE.BoxGeometry(ltSlopeLen, roofThickness, ltLength + overhangFt * 2);
      const ltRoof = new THREE.Mesh(ltRoofGeo, roofMat);
      ltRoof.position.set(-ltWidth / 2, ltEaveH + ltSlopeRise / 2, 0);
      ltRoof.rotation.z = ltAngle;
      ltRoof.castShadow = true;
      ltRoof.receiveShadow = true;

      // 3D Physical Ag-Panel Ribs on Lean-to Porch Roof (every 9" O.C., 3/4" high)
      const ltRibs = buildRoofAgPanelRibs(ltSlopeLen, ltLength + overhangFt * 2, roofThickness, roofRibMat);
      ltRoof.add(ltRibs);
      ltGroup.add(ltRoof);

      // B. Finished Architectural Porch Rake Trims and Gable Soffits
      const ltRakeFaceGeo = new THREE.BoxGeometry(ltSlopeLen, eaveFasciaHeight * Math.cos(ltAngle), 0.06);
      const ltTopFlangeGeo = new THREE.BoxGeometry(ltSlopeLen, 0.035, 0.38);

      const addLtRake = (zPos: number, wallZ: number, isFront: boolean) => {
        const pGroup = new THREE.Group();
        const zFlangeOffset = isFront ? -0.19 : 0.19;

        // 1. Vertical Rake Face
        const rFace = new THREE.Mesh(ltRakeFaceGeo, rakeTrimMat);
        rFace.position.set(-ltWidth / 2, ltEaveH + ltSlopeRise / 2 - 0.02, zPos);
        rFace.rotation.z = ltAngle;
        rFace.castShadow = true;
        pGroup.add(rFace);

        // 2. Top Rake Flange
        const rTop = new THREE.Mesh(ltTopFlangeGeo, rakeTrimMat);
        rTop.position.set(-ltWidth / 2, ltEaveH + ltSlopeRise / 2 + roofThickness / 2 + 0.015, zPos + zFlangeOffset);
        rTop.rotation.z = ltAngle;
        rTop.castShadow = true;
        pGroup.add(rTop);

        // 3. Sloped Gable Soffit under overhang
        if (overhangFt > 0) {
          const ltSoffitMesh = new THREE.Mesh(new THREE.BoxGeometry(ltSlopeLen, 0.03, overhangFt), soffitMat);
          ltSoffitMesh.position.set(-ltWidth / 2, ltEaveH + ltSlopeRise / 2 - roofThickness / 2 - 0.08, (wallZ + zPos) / 2);
          ltSoffitMesh.rotation.z = ltAngle;
          ltSoffitMesh.receiveShadow = true;
          pGroup.add(ltSoffitMesh);

          // Boxed corner return at outer porch eave
          const pReturn = new THREE.Mesh(new THREE.BoxGeometry(overhangFt + 0.04, eaveFasciaHeight, 0.08), rakeTrimMat);
          pReturn.position.set(-ltWidth - overhangFt / 2, ltFasciaCenterY, zPos);
          pGroup.add(pReturn);
        }

        ltGroup.add(pGroup);
      };
      addLtRake(ltLength / 2 + overhangFt, ltLength / 2, true);
      addLtRake(-ltLength / 2 - overhangFt, -ltLength / 2, false);

      // C. Porch Outer Eave Fascia / Drip Edge / Soffit (plumb face)
      const ltFasciaTopY = ltEaveH - overhangFt * Math.tan(ltAngle);
      const ltFasciaCenterY = ltFasciaTopY - eaveFasciaHeight / 2;
      const ltFasciaGeo = new THREE.BoxGeometry(0.06, eaveFasciaHeight, ltLength + overhangFt * 2 + 0.08);

      const ltFasciaMesh = new THREE.Mesh(ltFasciaGeo, fasciaMat);
      ltFasciaMesh.position.set(-ltWidth - overhangFt + 0.03, ltFasciaCenterY, 0);
      ltGroup.add(ltFasciaMesh);

      // Porch low drip edge
      const ltDripMesh = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.14, ltLength + overhangFt * 2 + 0.12), dripEdgeMat);
      ltDripMesh.position.set(-ltWidth - overhangFt - 0.02, ltFasciaTopY - 0.04, 0);
      ltGroup.add(ltDripMesh);

      // Porch horizontal soffit
      if (overhangFt > 0) {
        const ltSoffit = new THREE.Mesh(new THREE.BoxGeometry(overhangFt, 0.04, ltLength + overhangFt * 2), soffitMat);
        ltSoffit.position.set(-ltWidth - overhangFt / 2, ltFasciaTopY - eaveFasciaHeight + 0.03, 0);
        ltGroup.add(ltSoffit);
      }

      // Optional gutters on porch outer eave (disabled by default)
      if (hasGutters) {
        const ltGutter = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.44, ltLength + overhangFt * 2), gutterMat);
        ltGutter.position.set(-ltWidth - overhangFt - 0.22, ltFasciaCenterY + 0.04, 0);
        ltGroup.add(ltGutter);
      }

      // D. Enclosure Walls vs Open Bay Columns
      if (leanTo.enclosed) {
        // Fully enclosed outer wall
        const outerWallGeo = new THREE.BoxGeometry(0.2, ltEaveH, ltLength);
        const outerWall = new THREE.Mesh(outerWallGeo, sidingMat);
        outerWall.position.set(-ltWidth, ltEaveH / 2, 0);
        outerWall.castShadow = true;
        outerWall.receiveShadow = true;
        ltGroup.add(outerWall);

        // Enclosed trapezoidal endwalls
        const createLtEndwall = (zPos: number) => {
          const endShape = new THREE.Shape();
          endShape.moveTo(0, 0);
          endShape.lineTo(-ltWidth, 0);
          endShape.lineTo(-ltWidth, ltEaveH);
          endShape.lineTo(0, attachmentHeight);
          endShape.closePath();

          const endGeo = new THREE.ExtrudeGeometry(endShape, { depth: 0.2, bevelEnabled: false });
          const endMesh = new THREE.Mesh(endGeo, sidingMat);
          endMesh.position.set(0, 0, zPos - 0.1);
          endMesh.castShadow = true;
          endMesh.receiveShadow = true;
          return endMesh;
        };
        ltGroup.add(createLtEndwall(ltLength / 2));
        ltGroup.add(createLtEndwall(-ltLength / 2));

        // Corner Trims on outer corners
        const c1 = new THREE.Mesh(new THREE.BoxGeometry(0.45, ltEaveH, 0.45), cornerTrimMat);
        c1.position.set(-ltWidth, ltEaveH / 2, ltLength / 2);
        ltGroup.add(c1);

        const c2 = new THREE.Mesh(new THREE.BoxGeometry(0.45, ltEaveH, 0.45), cornerTrimMat);
        c2.position.set(-ltWidth, ltEaveH / 2, -ltLength / 2);
        ltGroup.add(c2);
      } else {
        // Open Bay Columns (6x6 timber posts spaced every 8 - 10 ft)
        const postCount = Math.max(2, Math.ceil(ltLength / 10) + 1);
        const postSpacing = ltLength / (postCount - 1);
        const postGeo = new THREE.BoxGeometry(0.5, ltEaveH, 0.5);

        for (let p = 0; p < postCount; p++) {
          const postMesh = new THREE.Mesh(postGeo, cornerTrimMat);
          postMesh.position.set(-ltWidth, ltEaveH / 2, -ltLength / 2 + p * postSpacing);
          postMesh.castShadow = true;
          ltGroup.add(postMesh);
        }

        // Structural Header Beam across top of outer columns (2-ply 2x10)
        const beamGeo = new THREE.BoxGeometry(0.3, 0.8, ltLength);
        const beamMesh = new THREE.Mesh(beamGeo, new THREE.MeshStandardMaterial({ color: '#d97706', roughness: 0.7 }));
        beamMesh.position.set(-ltWidth, ltEaveH - 0.4, 0);
        ltGroup.add(beamMesh);
      }

      // E. Porch Concrete Foundation Pad
      const ltPad = new THREE.Mesh(new THREE.BoxGeometry(ltWidth + 0.4, 0.4, ltLength + 0.4), concreteMat);
      ltPad.position.set(-ltWidth / 2, 0.2, 0);
      ltPad.receiveShadow = true;
      ltGroup.add(ltPad);

      // F. Position and Orient along selected building wall side
      if (leanTo.side === 'left') {
        const centerZ = -halfL + ltOffset + ltLength / 2;
        ltGroup.position.set(-halfW, 0, centerZ);
        ltGroup.rotation.y = 0;
      } else if (leanTo.side === 'right') {
        const centerZ = -halfL + ltOffset + ltLength / 2;
        ltGroup.position.set(halfW, 0, centerZ);
        ltGroup.rotation.y = Math.PI;
      } else if (leanTo.side === 'front') {
        const centerX = -halfW + ltOffset + ltLength / 2;
        ltGroup.position.set(centerX, 0, halfL);
        ltGroup.rotation.y = Math.PI / 2; // Extends outward into exterior front (+Z)
      } else if (leanTo.side === 'back') {
        const centerX = -halfW + ltOffset + ltLength / 2;
        ltGroup.position.set(centerX, 0, -halfL);
        ltGroup.rotation.y = -Math.PI / 2; // Extends outward into exterior back (-Z)
      }

      buildingGroup.add(ltGroup);
    }

    // 7. INTERNAL TIMBER TRUSSES, WEIGHT-BEARING HEADERS & FRAMING (Visible especially in framing mode)
    if (showFraming) {
      const framingGroup = new THREE.Group();

      // A. WEIGHT-BEARING WALL HEADERS ((2) 2x12s for 8' O.C. posts along Left & Right Eave Walls)
      // 2x12 nominal = 1.5" x 11.25" (~0.125 ft x 0.94 ft)
      const headerThick = 0.125;
      const headerDepth = 0.94;
      const headerGeo = new THREE.BoxGeometry(headerThick, headerDepth, length);
      const headerMat = new THREE.MeshStandardMaterial({
        color: '#d97706', // Rich amber structural Douglas Fir / SYP
        roughness: 0.65,
        metalness: 0.15,
      });

      // Left Weight-Bearing Wall (Outer and Inner 2x12 Plies)
      const leftHeaderY = (style === 'single_slope' ? singleSlopeHighEaveY : eaveHeight) - headerDepth / 2;
      const leftHeaderOuter = new THREE.Mesh(headerGeo, headerMat);
      leftHeaderOuter.position.set(-halfW + 0.08, leftHeaderY, 0);
      leftHeaderOuter.castShadow = true;
      framingGroup.add(leftHeaderOuter);

      const leftHeaderInner = new THREE.Mesh(headerGeo, headerMat);
      leftHeaderInner.position.set(-halfW + 0.38, leftHeaderY, 0);
      leftHeaderInner.castShadow = true;
      framingGroup.add(leftHeaderInner);

      // Right Weight-Bearing Wall (Outer and Inner 2x12 Plies)
      const rightHeaderY = eaveHeight - headerDepth / 2;
      const rightHeaderOuter = new THREE.Mesh(headerGeo, headerMat);
      rightHeaderOuter.position.set(halfW - 0.08, rightHeaderY, 0);
      rightHeaderOuter.castShadow = true;
      framingGroup.add(rightHeaderOuter);

      const rightHeaderInner = new THREE.Mesh(headerGeo, headerMat);
      rightHeaderInner.position.set(halfW - 0.38, rightHeaderY, 0);
      rightHeaderInner.castShadow = true;
      framingGroup.add(rightHeaderInner);

      // B. Structural Treated Timber Posts Spaced at 8' On-Center (postSpacing)
      const pSpacing = dimensions.postSpacing || 8;
      const bayCount = Math.max(1, Math.round(length / pSpacing));
      const actualPostStep = length / bayCount;
      const postMat = new THREE.MeshStandardMaterial({
        color: '#ca8a04',
        roughness: 0.8,
        metalness: 0.1,
      });

      const leftPostH = style === 'single_slope' ? singleSlopeHighEaveY : eaveHeight;
      const leftPostColGeo = new THREE.BoxGeometry(0.45, leftPostH, 0.45);
      const rightPostColGeo = new THREE.BoxGeometry(0.45, eaveHeight, 0.45);

      for (let p = 0; p <= bayCount; p++) {
        const pZ = -halfL + p * actualPostStep;

        // Left wall post
        const leftPost = new THREE.Mesh(leftPostColGeo, postMat);
        leftPost.position.set(-halfW + 0.23, leftPostH / 2, pZ);
        leftPost.castShadow = true;
        framingGroup.add(leftPost);

        // Right wall post
        const rightPost = new THREE.Mesh(rightPostColGeo, postMat);
        rightPost.position.set(halfW - 0.23, eaveHeight / 2, pZ);
        rightPost.castShadow = true;
        framingGroup.add(rightPost);
      }

      // C. Gable Endwall Studs (Front & Rear Walls)
      const endGirtCount = Math.max(2, Math.round(width / 8));
      const endGirtStep = width / endGirtCount;
      for (let g = 1; g < endGirtCount; g++) {
        const gX = -halfW + g * endGirtStep;
        const gTopY = getRoofProfileY(gX, width, eaveHeight, roofPitch, style);
        const endStudGeo = new THREE.BoxGeometry(0.35, gTopY, 0.35);
        const frontStud = new THREE.Mesh(endStudGeo, postMat);
        frontStud.position.set(gX, gTopY / 2, halfL - 0.2);
        framingGroup.add(frontStud);

        const backStud = new THREE.Mesh(endStudGeo, postMat);
        backStud.position.set(gX, gTopY / 2, -halfL + 0.2);
        framingGroup.add(backStud);
      }

      // D. Engineered Roof Trusses (Landing directly on top of the (2) 2x12 headers)
      const trussCount = pricing.trusses.totalTrussesNeeded;
      const trussStep = length / (trussCount - 1);

      for (let t = 0; t < trussCount; t++) {
        const tZ = -halfL + t * trussStep;
        const trussGroup = new THREE.Group();

        if (style === 'single_slope') {
          // Continuous mono-slope rafter beam
          const ssRafterGeo = new THREE.BoxGeometry(singleSlopeRafterLen - overhangFt * 2, 0.45, 0.2);
          const ssRafterMesh = new THREE.Mesh(ssRafterGeo, framingTimberMat);
          ssRafterMesh.position.set(0, eaveHeight + singleSlopeHighRise / 2, 0);
          ssRafterMesh.rotation.z = -singleSlopeAngle;
          trussGroup.add(ssRafterMesh);

          // Horizontal bottom tie chord
          const chordGeo = new THREE.BoxGeometry(width, 0.35, 0.2);
          const chordMesh = new THREE.Mesh(chordGeo, framingTimberMat);
          chordMesh.position.set(0, eaveHeight, 0);
          trussGroup.add(chordMesh);

          // Vertical intermediate strut posts
          const strutCount = Math.max(2, Math.floor(width / 8));
          for (let s = 1; s <= strutCount; s++) {
            const sx = -halfW + (width / (strutCount + 1)) * s;
            const sy = getRoofProfileY(sx, width, eaveHeight, roofPitch, 'single_slope');
            const sh = Math.max(0.2, sy - eaveHeight);
            const sGeo = new THREE.BoxGeometry(0.25, sh, 0.15);
            const sMesh = new THREE.Mesh(sGeo, framingTimberMat);
            sMesh.position.set(sx, eaveHeight + sh / 2, 0);
            trussGroup.add(sMesh);
          }

        } else if (style === 'monitor') {
          // Bottom chord across full width
          const chordGeo = new THREE.BoxGeometry(width, 0.35, 0.2);
          const chordMesh = new THREE.Mesh(chordGeo, framingTimberMat);
          chordMesh.position.set(0, eaveHeight, 0);
          trussGroup.add(chordMesh);

          // Two vertical monitor tower uprights
          const towerH = monitorRaisedEaveY - eaveHeight;
          const towerColGeo = new THREE.BoxGeometry(0.35, towerH, 0.2);
          const leftTower = new THREE.Mesh(towerColGeo, framingTimberMat);
          leftTower.position.set(-monitorHalfCenterW, eaveHeight + towerH / 2, 0);
          trussGroup.add(leftTower);

          const rightTower = new THREE.Mesh(towerColGeo, framingTimberMat);
          rightTower.position.set(monitorHalfCenterW, eaveHeight + towerH / 2, 0);
          trussGroup.add(rightTower);

          // Side wing rafters
          const wingRafterGeo = new THREE.BoxGeometry(monitorWingRafterLen - overhangFt, 0.35, 0.2);
          const lwMesh = new THREE.Mesh(wingRafterGeo, framingTimberMat);
          lwMesh.position.set(-halfW + monitorWingWidth / 2, eaveHeight + monitorWingRise / 2, 0);
          lwMesh.rotation.z = monitorWingAngle;
          trussGroup.add(lwMesh);

          const rwMesh = new THREE.Mesh(wingRafterGeo, framingTimberMat);
          rwMesh.position.set(halfW - monitorWingWidth / 2, eaveHeight + monitorWingRise / 2, 0);
          rwMesh.rotation.z = -monitorWingAngle;
          trussGroup.add(rwMesh);

          // Center monitor top chords & kingpost
          const centerRafterGeo = new THREE.BoxGeometry(monitorCenterRafterLen, 0.35, 0.2);
          const lcMesh = new THREE.Mesh(centerRafterGeo, framingTimberMat);
          lcMesh.position.set(-monitorHalfCenterW / 2, monitorRaisedEaveY + monitorCenterRise / 2, 0);
          lcMesh.rotation.z = monitorCenterAngle;
          trussGroup.add(lcMesh);

          const rcMesh = new THREE.Mesh(centerRafterGeo, framingTimberMat);
          rcMesh.position.set(monitorHalfCenterW / 2, monitorRaisedEaveY + monitorCenterRise / 2, 0);
          rcMesh.rotation.z = -monitorCenterAngle;
          trussGroup.add(rcMesh);

          const kpMesh = new THREE.Mesh(new THREE.BoxGeometry(0.2, monitorCenterRise, 0.2), framingTimberMat);
          kpMesh.position.set(0, monitorRaisedEaveY + monitorCenterRise / 2, 0);
          trussGroup.add(kpMesh);

        } else if (style === 'gambrel') {
          // Bottom chord
          const chordGeo = new THREE.BoxGeometry(width, 0.35, 0.2);
          const chordMesh = new THREE.Mesh(chordGeo, framingTimberMat);
          chordMesh.position.set(0, eaveHeight, 0);
          trussGroup.add(chordMesh);

          // Lower steep chords
          const llGeo = new THREE.BoxGeometry(gambrelLowerRafterLen - overhangFt, 0.35, 0.2);
          const llRafter = new THREE.Mesh(llGeo, framingTimberMat);
          llRafter.position.set(-halfW + gambrelLowerSpan / 2, eaveHeight + gambrelKnuckleRise / 2, 0);
          llRafter.rotation.z = gambrelLowerAngle;
          trussGroup.add(llRafter);

          const lrRafter = new THREE.Mesh(llGeo, framingTimberMat);
          lrRafter.position.set(halfW - gambrelLowerSpan / 2, eaveHeight + gambrelKnuckleRise / 2, 0);
          lrRafter.rotation.z = -gambrelLowerAngle;
          trussGroup.add(lrRafter);

          // Knuckle collar cross tie
          const collarGeo = new THREE.BoxGeometry(gambrelKnuckleX * 2, 0.3, 0.2);
          const collarMesh = new THREE.Mesh(collarGeo, framingTimberMat);
          collarMesh.position.set(0, gambrelKnuckleY, 0);
          trussGroup.add(collarMesh);

          // Upper shallow chords
          const ulGeo = new THREE.BoxGeometry(gambrelUpperRafterLen, 0.35, 0.2);
          const ulRafter = new THREE.Mesh(ulGeo, framingTimberMat);
          ulRafter.position.set(-gambrelKnuckleX / 2, gambrelKnuckleY + gambrelUpperRise / 2, 0);
          ulRafter.rotation.z = gambrelUpperAngle;
          trussGroup.add(ulRafter);

          const urRafter = new THREE.Mesh(ulGeo, framingTimberMat);
          urRafter.position.set(gambrelKnuckleX / 2, gambrelKnuckleY + gambrelUpperRise / 2, 0);
          urRafter.rotation.z = -gambrelUpperAngle;
          trussGroup.add(urRafter);

          // Kingpost from collar to peak
          const kpMesh = new THREE.Mesh(new THREE.BoxGeometry(0.2, gambrelUpperRise, 0.2), framingTimberMat);
          kpMesh.position.set(0, gambrelKnuckleY + gambrelUpperRise / 2, 0);
          trussGroup.add(kpMesh);

        } else {
          // Standard Gable & Commercial
          const chordGeo = new THREE.BoxGeometry(width, 0.35, 0.2);
          const chordMesh = new THREE.Mesh(chordGeo, framingTimberMat);
          chordMesh.position.set(0, eaveHeight, 0);
          trussGroup.add(chordMesh);

          const rafterInsideLen = halfW / Math.cos(standardRoofAngle);
          const rafterTGeo = new THREE.BoxGeometry(rafterInsideLen, 0.35, 0.2);
          const leftRafterT = new THREE.Mesh(rafterTGeo, framingTimberMat);
          leftRafterT.position.set(-halfW / 2, eaveHeight + standardPeakRise / 2, 0);
          leftRafterT.rotation.z = standardRoofAngle;
          trussGroup.add(leftRafterT);

          const rightRafterT = new THREE.Mesh(rafterTGeo, framingTimberMat);
          rightRafterT.position.set(halfW / 2, eaveHeight + standardPeakRise / 2, 0);
          rightRafterT.rotation.z = -standardRoofAngle;
          trussGroup.add(rightRafterT);

          const kingpostGeo = new THREE.BoxGeometry(0.2, standardPeakRise, 0.2);
          const kingpost = new THREE.Mesh(kingpostGeo, framingTimberMat);
          kingpost.position.set(0, eaveHeight + standardPeakRise / 2, 0);
          trussGroup.add(kingpost);

          if (width >= 30) {
            const webDiagGeo = new THREE.BoxGeometry(width * 0.28, 0.2, 0.15);
            const leftWeb = new THREE.Mesh(webDiagGeo, framingTimberMat);
            leftWeb.position.set(-width * 0.25, eaveHeight + standardPeakRise * 0.35, 0);
            leftWeb.rotation.z = -standardRoofAngle * 0.7;
            trussGroup.add(leftWeb);

            const rightWeb = new THREE.Mesh(webDiagGeo, framingTimberMat);
            rightWeb.position.set(width * 0.25, eaveHeight + standardPeakRise * 0.35, 0);
            rightWeb.rotation.z = standardRoofAngle * 0.7;
            trussGroup.add(rightWeb);
          }

          // Commercial front parapet framing extensions
          if (style === 'commercial' && t === trussCount - 1) {
            const pExtensionH = commercialParapetY - eaveHeight;
            const pExtGeo = new THREE.BoxGeometry(0.35, pExtensionH, 0.25);
            const pCount = Math.max(3, Math.round(width / 6));
            for (let pe = 0; pe <= pCount; pe++) {
              const peX = -halfW + pe * (width / pCount);
              const peMesh = new THREE.Mesh(pExtGeo, framingTimberMat);
              peMesh.position.set(peX, eaveHeight + pExtensionH / 2, 0);
              trussGroup.add(peMesh);
            }
          }
        }

        trussGroup.position.z = tZ;
        framingGroup.add(trussGroup);
      }

      buildingGroup.add(framingGroup);
    }

    scene.add(buildingGroup);
  }, [state, pricing, showFraming, cornerTrimColor, eaveTrimColor, rakeTrimColor, ridgeCapColor, doorTrimColor, wainscotCapColor]);

  // Compute displayed peak elevation based on style
  const displayedPeakY = style === 'single_slope' 
    ? getRoofProfileY(-width / 2, width, eaveHeight, roofPitch, style)
    : (style === 'commercial' 
      ? eaveHeight + (width / 2) * (roofPitch / 12) + 2.5 
      : getRoofProfileY(0, width, eaveHeight, roofPitch, style));

  const handleZoom = (factor: number) => {
    const camera = cameraRef.current;
    const controls = controlsRef.current;
    if (!camera || !controls) return;
    camera.position.multiplyScalar(factor);
    controls.update();
  };

  const handleResetCamera = () => {
    const camera = cameraRef.current;
    const controls = controlsRef.current;
    if (!camera || !controls) return;
    const targetY = eaveHeight * 0.5;
    controls.target.set(0, targetY, 0);
    camera.position.set(width * 1.3, eaveHeight * 1.6, length * 1.3);
    controls.update();
  };

  // Register camera controls to parent component for top island controls
  useEffect(() => {
    if (onRegisterCameraControls) {
      onRegisterCameraControls({
        zoom: handleZoom,
        reset: handleResetCamera,
      });
    }
  }, [onRegisterCameraControls, width, length, eaveHeight]);

  // Sync auto-rotation state to Three.js controls
  useEffect(() => {
    if (controlsRef.current) {
      controlsRef.current.autoRotate = !!isAutoRotating;
    }
  }, [isAutoRotating]);

  // Sync Pan mode state to OrbitControls
  useEffect(() => {
    if (controlsRef.current) {
      if (isPanMode) {
        controlsRef.current.touches.ONE = THREE.TOUCH.PAN;
        controlsRef.current.mouseButtons.LEFT = THREE.MOUSE.PAN;
      } else {
        controlsRef.current.touches.ONE = THREE.TOUCH.ROTATE;
        controlsRef.current.mouseButtons.LEFT = THREE.MOUSE.ROTATE;
      }
    }
  }, [isPanMode]);

  const getStyleDisplayName = (s: string) => {
    switch (s) {
      case 'gable':
        return 'Classic Gable';
      case 'monitor':
        return 'Raised Monitor';
      case 'gambrel':
        return 'Dutch Gambrel';
      case 'single_slope':
        return 'Mono-Slope / Shed';
      default:
        return 'Commercial Parapet';
    }
  };

  return (
    <div className="relative w-full flex flex-col bg-slate-100 dark:bg-slate-950 select-none transition-colors">
      {/* 3D Rendering Stage */}
      <div className="w-full flex items-center justify-center p-2.5 sm:p-4 bg-slate-100/80 dark:bg-[#070b12] overflow-hidden">
        {/* Square Material 3 Expressive Pill Container */}
        <div className="relative w-full max-w-[460px] sm:max-w-[500px] aspect-square rounded-[32px] sm:rounded-[38px] overflow-hidden border border-slate-200/90 dark:border-white/[0.12] bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 shadow-xl dark:shadow-2xl ring-1 ring-black/5 dark:ring-white/5">
          {/* Pristine WebGL Canvas - 100% free of overlay elements */}
          <div 
            ref={containerRef} 
            className="w-full h-full cursor-grab active:cursor-grabbing"
          />
        </div>
      </div>

      {/* Bottom Section: Category Navigation Tabs (Dimensions, Style, Framing, Sides & Openings, Colors, Interior Options) */}
      <div className="w-full bg-white border-t border-slate-200/90 py-2 sm:py-2.5 flex items-center justify-center transition-colors">
        <CategoryNavigationTabs
          activeTab={activeTab as any}
          onOpenCategoryModal={onOpenCategoryModal}
          dimensions={dimensions}
        />
      </div>
    </div>
  );
};
