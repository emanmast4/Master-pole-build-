import React, { useState } from 'react';
import { UnitPricingRates } from '../types';
import { DEFAULT_UNIT_RATES } from '../utils/constants';
import { 
  X, 
  RotateCcw, 
  Check, 
  DollarSign, 
  Sliders, 
  ShieldCheck, 
  Search, 
  Tag, 
  Layers, 
  Hammer, 
  Home, 
  DoorClosed, 
  SquareAsterisk, 
  Sparkles 
} from 'lucide-react';

interface UnitPricingEditorModalProps {
  rates: UnitPricingRates;
  onUpdateRates: (rates: UnitPricingRates) => void;
  onClose: () => void;
}

type PricingCategoryTab = 
  | 'all'
  | 'trims'
  | 'framing'
  | 'sheeting'
  | 'openings'
  | 'foundation'
  | 'interior'
  | 'labor';

export const UnitPricingEditorModal: React.FC<UnitPricingEditorModalProps> = ({
  rates,
  onUpdateRates,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<PricingCategoryTab>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const handleChange = (key: keyof UnitPricingRates, val: number) => {
    onUpdateRates({
      ...rates,
      [key]: Math.max(0, val),
    });
  };

  const handleResetDefaults = () => {
    onUpdateRates({ ...DEFAULT_UNIT_RATES });
  };

  // Helper rate input card
  const RateInputCard = ({
    fieldKey,
    label,
    value,
    unit,
    step = 0.25,
    description,
    badge,
  }: {
    fieldKey: keyof UnitPricingRates;
    label: string;
    value: number;
    unit: string;
    step?: number;
    description: string;
    badge?: string;
  }) => {
    // If search active, check if matches
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match = label.toLowerCase().includes(q) || description.toLowerCase().includes(q) || (badge && badge.toLowerCase().includes(q));
      if (!match) return null;
    }

    return (
      <div className="p-3.5 bg-white rounded-2xl border border-sky-100/90 shadow-2xs hover:shadow-xs transition-all duration-200 flex flex-col justify-between space-y-2 group">
        <div>
          <div className="flex items-start justify-between gap-1.5 mb-1">
            <label className="text-xs font-bold text-[#075985] group-hover:text-[#0c4a6e] transition-colors leading-tight">
              {label}
            </label>
            {badge && (
              <span className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded-full bg-cyan-50 text-[#0284C7] border border-cyan-200 shrink-0">
                {badge}
              </span>
            )}
          </div>
          <p className="text-[10px] text-[#0369A1]/80 leading-relaxed mb-2 line-clamp-2">
            {description}
          </p>
        </div>

        <div className="flex items-center gap-2 pt-1 border-t border-sky-50">
          <div className="relative flex-1">
            <span className="absolute left-2.5 top-2 text-[#0369A1]/60 text-xs font-mono font-bold">$</span>
            <input
              type="number"
              step={step}
              value={value ?? 0}
              onChange={(e) => handleChange(fieldKey, Number(e.target.value))}
              className="w-full bg-sky-50/40 focus:bg-white border border-sky-200 rounded-xl pl-6 pr-2 py-1.5 text-xs text-[#075985] font-mono font-bold focus:border-[#06B6D4] focus:ring-2 focus:ring-[#06B6D4]/30 focus:outline-none transition-all"
            />
          </div>
          <span className="text-[11px] font-mono text-[#0284C7] font-semibold shrink-0">
            {unit}
          </span>
        </div>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#075985]/40 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white border border-sky-200/80 rounded-3xl w-full max-w-5xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 transition-all text-[#075985]">
        {/* Header */}
        <div className="bg-white/95 backdrop-blur-md px-6 py-4 border-b border-sky-100 flex flex-wrap items-center justify-between gap-3 text-[#075985] shadow-xs">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-full bg-cyan-50 text-[#06B6D4] border border-cyan-200 shadow-sm">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#075985] flex items-center gap-2">
                <span>Dynamic Pricing Engine — Unit Rates & Trim Cost Manager</span>
              </h3>
              <p className="text-xs text-[#0369A1]/80">
                Directly customize the price of every pole barn trim, opening wrap, engineered truss, panel, and framing component.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleResetDefaults}
              className="text-xs flex items-center gap-1.5 px-4 py-2 rounded-full text-[#075985] hover:text-[#0c4a6e] bg-cyan-50 hover:bg-cyan-100 border border-cyan-200 cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-95 font-bold shadow-xs focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4]"
              title="Reset all prices to standard regional market averages"
            >
              <RotateCcw className="w-3.5 h-3.5 text-[#06B6D4]" />
              <span>Reset Market Averages</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-[#0369A1] hover:text-[#075985] rounded-full hover:bg-sky-100 cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-90 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4]"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filter Pills & Search Bar */}
        <div className="px-6 py-3 bg-sky-50/40 border-b border-sky-100 flex flex-wrap items-center justify-between gap-3 text-xs">
          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto py-0.5">
            {[
              { id: 'all', label: 'All Components' },
              { id: 'trims', label: 'Pole Barn Trims (20+)' },
              { id: 'framing', label: 'Trusses & Framing' },
              { id: 'sheeting', label: 'Metal Sheeting' },
              { id: 'openings', label: 'Doors & Windows' },
              { id: 'foundation', label: 'Foundation' },
              { id: 'interior', label: 'Interior & Liner' },
              { id: 'labor', label: 'Labor & Margin' },
            ].map((tab) => {
              const isSelected = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as PricingCategoryTab)}
                  className={`relative px-3.5 py-1.5 rounded-full transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] cursor-pointer text-xs active:scale-95 whitespace-nowrap focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
                    isSelected
                      ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] font-black shadow-sm ring-2 ring-[#06B6D4]/30'
                      : 'bg-white text-[#0369A1] hover:text-[#075985] hover:bg-sky-50 border border-sky-200/80 font-semibold'
                  }`}
                >
                  {tab.label}
                  {isSelected && (
                    <span className="absolute -bottom-[2px] inset-x-2.5 h-0.5 bg-[#06B6D4] rounded-full shadow-xs" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Quick Search */}
          <div className="relative min-w-[200px] flex-1 sm:flex-initial">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-[#0369A1]/60" />
            <input
              type="text"
              placeholder="Search component or trim..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-white border border-sky-200 rounded-full text-[#075985] placeholder-[#0369A1]/50 focus:border-[#06B6D4] focus:ring-2 focus:ring-[#06B6D4]/30 focus:outline-none transition-all font-medium"
            />
          </div>
        </div>

        {/* Scrollable Rate Inputs Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-[#075985]">
          {/* SECTION 1: POLE BARN TRIMS (All 20+ Breakdown Trims) */}
          {(activeTab === 'all' || activeTab === 'trims') && (
            <div className="bg-white p-5 rounded-2xl border border-sky-100 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-sky-100 pb-2">
                <h4 className="text-xs font-bold text-[#0284C7] uppercase tracking-wider flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#06B6D4]" />
                  <span>Pole Barn Trim & Flashing Components (20+ Items)</span>
                </h4>
                <span className="text-[11px] font-mono text-[#0284C7] font-semibold">
                  Lower Wall, Openings, Corners, Eaves, & Peak
                </span>
              </div>

              {/* Lower Wall & Base Foundations */}
              <div className="space-y-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#0369A1] block">
                  1. Lower Wall & Base Foundations
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  <RateInputCard
                    fieldKey="ratGuardRate"
                    label="Rat Guard Base Trim"
                    value={rates.ratGuardRate ?? 2.50}
                    unit="/ Lin Ft"
                    step={0.10}
                    description="Fastened horizontally to treated splash plank (skirt board) at very bottom perimeter before siding is hung; sloped ledge holds metal."
                    badge="10'6&quot; or 12'"
                  />
                  <RateInputCard
                    fieldKey="doubleAngleRate"
                    label="Wainscot Double Angle Drip Ledge"
                    value={rates.doubleAngleRate ?? 2.75}
                    unit="/ Lin Ft"
                    step={0.10}
                    description="Horizontal drip ledge roughly 3-4 ft off ground preventing water seepage between lower wainscot and upper wall siding."
                    badge="10'6&quot; or 12'"
                  />
                  <RateInputCard
                    fieldKey="wainscotPerSqFt"
                    label="Wainscot Accent Metal Panels"
                    value={rates.wainscotPerSqFt ?? 4.05}
                    unit="/ Sq Ft"
                    step={0.10}
                    description="3-ft wide lower accent panels (either 3 or 4 ft tall) with custom transition drip ledge."
                    badge="3' or 4' Tall"
                  />
                </div>
              </div>

              {/* Openings (Doors & Windows) */}
              <div className="space-y-2 pt-2 border-t border-sky-50">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#0369A1] block">
                  2. Openings & Door Framing Trims
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  <RateInputCard
                    fieldKey="overheadDoorTopWrapRate"
                    label="Overhead Door Top Header Wrap"
                    value={rates.overheadDoorTopWrapRate ?? 32.00}
                    unit="/ Piece"
                    step={1.00}
                    description="Wraps around top header wood framing of overhead garage door openings to protect raw wood from weather."
                    badge="10'6&quot; or 12'"
                  />
                  <RateInputCard
                    fieldKey="overheadDoorSideWrapRate"
                    label="Overhead Door Side Jamb Wrap"
                    value={rates.overheadDoorSideWrapRate ?? 32.00}
                    unit="/ Piece"
                    step={1.00}
                    description="Wraps around vertical side studs or posts of overhead garage door openings to protect wood framing."
                    badge="10'6&quot; or 12'"
                  />
                  <RateInputCard
                    fieldKey="slidingDoorSideWrapRate"
                    label="Sliding Barn Door Side Jambs"
                    value={rates.slidingDoorSideWrapRate ?? 32.00}
                    unit="/ Piece"
                    step={1.00}
                    description="Installed along vertical side jambs of sliding barn door openings for weather protection."
                    badge="10'6&quot; or 12'"
                  />
                  <RateInputCard
                    fieldKey="slidingDoorTrackCoverRate"
                    label="Sliding Door Trolley Track Cover"
                    value={rates.slidingDoorTrackCoverRate ?? 38.00}
                    unit="/ Piece"
                    step={1.00}
                    description="Mounted horizontally directly over top metal sliding trolley track, shielding rollers from snow, ice, and rain."
                    badge="10'6&quot; or 12'"
                  />
                  <RateInputCard
                    fieldKey="dripCapRate"
                    label="Window & Walk Door Drip Cap"
                    value={rates.dripCapRate ?? 22.00}
                    unit="/ Piece"
                    step={1.00}
                    description="Fastened horizontally right above window frames and service doors to deflect descending water outward."
                    badge="10'6&quot; or 12'"
                  />
                  <RateInputCard
                    fieldKey="jChannelRate"
                    label="J-Channel (J-Trim)"
                    value={rates.jChannelRate ?? 28.00}
                    unit="/ Piece"
                    step={1.00}
                    description="Fitted around side and bottom edges of windows, man doors, and sliding doors to capture and hide raw cut metal edges."
                    badge="10'6&quot; or 12'"
                  />
                  <RateInputCard
                    fieldKey="fAndJTrimRate"
                    label="F&J Dual-Purpose Transition Trim"
                    value={rates.fAndJTrimRate ?? 32.00}
                    unit="/ Piece"
                    step={1.00}
                    description="Bridges vertical wall panels with horizontal soffit under overhangs; J-receiver captures metal, F-leg secures soffit against hornets/birds."
                    badge="10'6&quot; or 12'"
                  />
                </div>
              </div>

              {/* Corners & Vertical Transitions */}
              <div className="space-y-2 pt-2 border-t border-sky-50">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#0369A1] block">
                  3. Corners & Vertical Transitions
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  <RateInputCard
                    fieldKey="outsideCornerRate"
                    label="Outside Corner Trim"
                    value={rates.outsideCornerRate ?? 3.25}
                    unit="/ Lin Ft"
                    step={0.10}
                    description="Installed vertically on outside 90-degree corners covering panel seams (10'6&quot; min up to 30' cut-to-length)."
                    badge="Up to 30'"
                  />
                  <RateInputCard
                    fieldKey="insideCornerRate"
                    label="Inside Corner Trim"
                    value={rates.insideCornerRate ?? 30.00}
                    unit="/ Piece"
                    step={1.00}
                    description="Placed vertically inside interior room corners or where two exterior walls form an internal angle."
                    badge="10'6&quot; or 12'"
                  />
                </div>
              </div>

              {/* Roof-to-Wall Interfaces */}
              <div className="space-y-2 pt-2 border-t border-sky-50">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#0369A1] block">
                  4. Roof-to-Wall Interfaces
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  <RateInputCard
                    fieldKey="sidewallFlashingRate"
                    label="Sidewall Flashing"
                    value={rates.sidewallFlashingRate ?? 34.00}
                    unit="/ Piece"
                    step={1.00}
                    description="Along sloped roofline where roof runs parallel to and meets an adjacent vertical wall (lean-to or side porch attachment)."
                    badge="10'6&quot; or 12'"
                  />
                  <RateInputCard
                    fieldKey="endwallFlashingRate"
                    label="Endwall Flashing"
                    value={rates.endwallFlashingRate ?? 34.00}
                    unit="/ Piece"
                    step={1.00}
                    description="Placed horizontally across top slope where high end of lean-to roof meets adjacent vertical wall."
                    badge="10'6&quot; or 12'"
                  />
                  <RateInputCard
                    fieldKey="valleyFlashingRate"
                    label="Valley Gutter Flashing"
                    value={rates.valleyFlashingRate ?? 36.00}
                    unit="/ Piece"
                    step={1.00}
                    description="Laid down inside internal diagonal channels where two sloping roof sections intersect (dormers or additions)."
                    badge="10'6&quot; or 12'"
                  />
                </div>
              </div>

              {/* Eaves, Overhangs & Gables */}
              <div className="space-y-2 pt-2 border-t border-sky-50">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#0369A1] block">
                  5. Eaves, Overhangs & Gables
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  <RateInputCard
                    fieldKey="dripEdgeRate"
                    label="Low Eave Drip Edge"
                    value={rates.dripEdgeRate ?? 28.00}
                    unit="/ Piece"
                    step={1.00}
                    description="Fastened along low horizontal roof edge before roof panels, directing rain runoff clear of fascia wrap."
                    badge="10'6&quot; or 12'"
                  />
                  <RateInputCard
                    fieldKey="fasciaCoverRate"
                    label="Metal Fascia Cover"
                    value={rates.fasciaCoverRate ?? 35.00}
                    unit="/ Piece"
                    step={1.00}
                    description="Installed over wood fascia boards along eaves and gables; holds bottom lip under outer edge of soffit panels."
                    badge="10'6&quot; or 12'"
                  />
                  <RateInputCard
                    fieldKey="soffitPanel1ftRate"
                    label="1-Ft Soffit Panels (11½&quot; Cut)"
                    value={rates.soffitPanel1ftRate ?? 14.50}
                    unit="/ 3-Ft Sheet"
                    step={0.50}
                    description="3-ft wide pre-cut 11½&quot; panels for 1-ft overhangs (vented for eaves, solid for gables)."
                    badge="11½&quot; Cut"
                  />
                  <RateInputCard
                    fieldKey="soffitPanel2ftRate"
                    label="2-Ft Soffit Panels (23½&quot; Cut)"
                    value={rates.soffitPanel2ftRate ?? 26.00}
                    unit="/ 3-Ft Sheet"
                    step={0.50}
                    description="3-ft wide pre-cut 23½&quot; panels for 2-ft overhangs (vented for eaves, solid for gables)."
                    badge="23½&quot; Cut"
                  />
                  <RateInputCard
                    fieldKey="seamlessGutterRate"
                    label="6&quot; Seamless K-Style Gutter"
                    value={rates.seamlessGutterRate ?? 8.50}
                    unit="/ Lin Ft"
                    step={0.25}
                    description="Heavy-gauge seamless aluminum/steel gutter (optional add-on; default is no gutters per build photo)."
                    badge="Optional"
                  />
                  <RateInputCard
                    fieldKey="downspoutRate"
                    label="3x4 Downspout Assembly"
                    value={rates.downspoutRate ?? 45.00}
                    unit="/ Assembly"
                    step={1.00}
                    description="Complete 10-ft downspout with A/B elbows and ground splash adapter (optional add-on)."
                    badge="Optional"
                  />
                  <RateInputCard
                    fieldKey="residentialRakeRate"
                    label="Residential Gable Rake Flashing"
                    value={rates.residentialRakeRate ?? 3.25}
                    unit="/ Lin Ft"
                    step={0.10}
                    description="Installed along sloped gable edges from eave corner up to roof peak (10'6&quot; up to 30')."
                    badge="Up to 30'"
                  />
                </div>
              </div>

              {/* Peak & Roof Penetrations */}
              <div className="space-y-2 pt-2 border-t border-sky-50">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#0369A1] block">
                  6. Peak & Roof Penetrations
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  <RateInputCard
                    fieldKey="ridgeCapRate"
                    label="Heavy-Duty Ridge Cap"
                    value={rates.ridgeCapRate ?? 3.50}
                    unit="/ Lin Ft"
                    step={0.10}
                    description="Placed along absolute peak (ridge line) where opposing sloped roof panels meet (10'6&quot; up to 30')."
                    badge="Peak Flashing"
                  />
                  <RateInputCard
                    fieldKey="ventedClosureFoam20ftRate"
                    label="Vented Ridge Closure Foam"
                    value={rates.ventedClosureFoam20ftRate ?? 22.00}
                    unit="/ 20' Roll"
                    step={1.00}
                    description="Sandwiched directly beneath both sides of ridge cap on roof ribs, venting attic heat while sealing weather."
                    badge="20-Ft Roll"
                  />
                  <RateInputCard
                    fieldKey="snowGuardRailRate"
                    label="Continuous Snow Guard Roof Rail"
                    value={rates.snowGuardRailRate ?? 12.50}
                    unit="/ Lin Ft"
                    step={0.50}
                    description="Extruded rail mounted on top of roof panel ribs 3' to 4' from eave, preventing snow/ice avalanches."
                    badge="3'-4' From Eave"
                  />
                  <RateInputCard
                    fieldKey="insideClosuresStripRate"
                    label="Inside Foam Rib Closures"
                    value={rates.insideClosuresStripRate ?? 4.50}
                    unit="/ 36&quot; Strip"
                    step={0.25}
                    description="Continuous inside foam strips sealing underside of metal ribs along eave overhangs."
                  />
                  <RateInputCard
                    fieldKey="outsideClosuresStripRate"
                    label="Outside Foam Rib Closures"
                    value={rates.outsideClosuresStripRate ?? 4.50}
                    unit="/ 36&quot; Strip"
                    step={0.25}
                    description="Outside foam strips sealing top of metal ribs under ridge cap."
                  />
                  <RateInputCard
                    fieldKey="butylTapeRollRate"
                    label="Butyl Mastic Sealant Tape"
                    value={rates.butylTapeRollRate ?? 14.00}
                    unit="/ 45' Roll"
                    step={0.50}
                    description="Heavy-duty 3/8&quot; non-drying butyl tape for sealing trim laps, ridge caps, and end seams."
                  />
                  <RateInputCard
                    fieldKey="woodgripScrewsBoxRate"
                    label="Woodgrip Screws (1-1/2&quot; Box 250)"
                    value={rates.woodgripScrewsBoxRate ?? 38.00}
                    unit="/ 250 Box"
                    step={1.00}
                    description="#10 Hi-Lo mechanical fasteners with vulcanized EPDM neoprene sealing washers in color match."
                  />
                  <RateInputCard
                    fieldKey="stitchScrewsBoxRate"
                    label="Lap Stitch Screws (7/8&quot; Box 250)"
                    value={rates.stitchScrewsBoxRate ?? 32.00}
                    unit="/ 250 Box"
                    step={1.00}
                    description="1/4&quot; hex head color-matched stitch screws for securing metal panel side laps every 18&quot; O.C."
                  />
                </div>
              </div>
            </div>
          )}

          {/* SECTION 2: TRUSSES & STRUCTURAL FRAMING */}
          {(activeTab === 'all' || activeTab === 'framing') && (
            <div className="bg-white p-5 rounded-2xl border border-sky-100 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-sky-100 pb-2">
                <h4 className="text-xs font-bold text-[#0284C7] uppercase tracking-wider flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#06B6D4]" />
                  <span>Engineered Trusses & Structural Framing</span>
                </h4>
                <span className="text-[11px] font-mono text-[#0284C7] font-semibold">
                  Posts, Headers, Purlins & Ties
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                <RateInputCard
                  fieldKey="trussBasePerFootSpan"
                  label="Truss Base Rate"
                  value={rates.trussBasePerFootSpan}
                  unit="/ LF Span"
                  step={0.25}
                  description="Base rate per foot of clear-span width (multiplied directly by building width)."
                />
                <RateInputCard
                  fieldKey="trussPitchMultiplierWeight"
                  label="Pitch Slope Multiplier Weight"
                  value={rates.trussPitchMultiplierWeight}
                  unit="Factor"
                  step={0.05}
                  description="Scales chord lumber and web materials for steeper roof pitch rises."
                />
                <RateInputCard
                  fieldKey="trussHeavyLoadFactor"
                  label="Snow Load Step Multiplier"
                  value={rates.trussHeavyLoadFactor}
                  unit="Multiplier"
                  step={0.02}
                  description="Scales lumber size (2x4 -> 2x6 -> 2x8) per 20 PSF snow load tier above 20 PSF."
                />
                <RateInputCard
                  fieldKey="trussGussetPlateBase"
                  label="Truss Gusset Plates Set"
                  value={rates.trussGussetPlateBase}
                  unit="/ Truss"
                  step={1.00}
                  description="Heavy stamped gang-nail metal connector plates at apex, heels, and internal web nodes."
                />
                <RateInputCard
                  fieldKey="trussDeliveryCraneSetup"
                  label="Truss Delivery & Crane Rigging"
                  value={rates.trussDeliveryCraneSetup}
                  unit="Flat Setup"
                  step={25.00}
                  description="Wide-load highway transport permit routing and hydraulic boom crane staging fee."
                />
                <RateInputCard
                  fieldKey="trussCarriersPerLinFt"
                  label="2x12 Weight-Bearing Wall Headers"
                  value={rates.trussCarriersPerLinFt}
                  unit="/ Lin Ft"
                  step={0.10}
                  description="#1 Structural 2x12 timber headers for double (2-ply) 2x12 header beams spanning 8' O.C. posts."
                />
                <RateInputCard
                  fieldKey="postsTreatedPerLinFt"
                  label="6x6 Treated Structural Columns"
                  value={rates.postsTreatedPerLinFt}
                  unit="/ Lin Ft"
                  step={0.25}
                  description="CCA/ACQ ground-contact pressure-treated structural solid timber posts."
                />
                <RateInputCard
                  fieldKey="purlinsGirtsPerLinFt"
                  label="Purlins & Wall Girts"
                  value={rates.purlinsGirtsPerLinFt}
                  unit="/ Lin Ft"
                  step={0.05}
                  description="#2 SPF 2x4 & 2x6 framing runners spaced 24&quot; on center across roof and sidewalls."
                />
                <RateInputCard
                  fieldKey="hurricaneTieRate"
                  label="Simpson Strong-Tie H1 Anchors"
                  value={rates.hurricaneTieRate ?? 2.85}
                  unit="/ Tie"
                  step={0.10}
                  description="Galvanized hurricane tie-down brackets (2 per truss) securing trusses to carrier headers."
                />
              </div>
            </div>
          )}

          {/* SECTION 3: METAL SHEETING & ROOFING */}
          {(activeTab === 'all' || activeTab === 'sheeting') && (
            <div className="bg-white p-5 rounded-2xl border border-sky-100 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-sky-100 pb-2">
                <h4 className="text-xs font-bold text-[#0284C7] uppercase tracking-wider flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#06B6D4]" />
                  <span>36&quot; Ag-Panel & Commercial Steel Sheeting</span>
                </h4>
                <span className="text-[11px] font-mono text-[#0284C7] font-semibold">
                  36&quot; Net Coverage Rates ($ / Sq Ft)
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                <RateInputCard
                  fieldKey="siding29gaPerSqFt"
                  label="29-Gauge Ribbed Ag-Panel Siding"
                  value={rates.siding29gaPerSqFt}
                  unit="/ Sq Ft"
                  step={0.10}
                  description="Standard 29-gauge ribbed wall siding with 3/4&quot; ribs spaced 9&quot; on center."
                />
                <RateInputCard
                  fieldKey="siding26gaPerSqFt"
                  label="26-Gauge Commercial Siding"
                  value={rates.siding26gaPerSqFt}
                  unit="/ Sq Ft"
                  step={0.10}
                  description="Heavy-gauge commercial high-tensile steel panel for industrial durability."
                />
                <RateInputCard
                  fieldKey="wainscotPerSqFt"
                  label="Wainscot Accent Panels"
                  value={rates.wainscotPerSqFt ?? 4.05}
                  unit="/ Sq Ft"
                  step={0.10}
                  description="3-ft wide lower accent panels (3 or 4 ft tall) in premium color finish."
                />
                <RateInputCard
                  fieldKey="roofRibbedSteelPerSqFt"
                  label="36&quot; Ribbed Ag-Panel Roofing"
                  value={rates.roofRibbedSteelPerSqFt}
                  unit="/ Sq Ft"
                  step={0.10}
                  description="3/4&quot; major rib profile roof steel with anti-siphon capillary groove."
                />
                <RateInputCard
                  fieldKey="roofStandingSeamPerSqFt"
                  label="Architectural Standing Seam Roof"
                  value={rates.roofStandingSeamPerSqFt}
                  unit="/ Sq Ft"
                  step={0.25}
                  description="Concealed fastener architectural standing seam steel roofing."
                />
              </div>
            </div>
          )}

          {/* SECTION 4: DOORS & WINDOWS */}
          {(activeTab === 'all' || activeTab === 'openings') && (
            <div className="bg-white p-5 rounded-2xl border border-sky-100 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-sky-100 pb-2">
                <h4 className="text-xs font-bold text-[#0284C7] uppercase tracking-wider flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#06B6D4]" />
                  <span>Doors, Windows & Opening Hardware</span>
                </h4>
                <span className="text-[11px] font-mono text-[#0284C7] font-semibold">
                  Commercial Overhead, Sliding & Man Doors
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                <RateInputCard
                  fieldKey="overheadDoorBasePerSqFt"
                  label="Overhead Door Base Price"
                  value={rates.overheadDoorBasePerSqFt}
                  unit="/ Sq Ft"
                  step={0.50}
                  description="Base rate per square foot of opening for commercial steel overhead sectional doors."
                />
                <RateInputCard
                  fieldKey="overheadDoorInsulatedAddon"
                  label="Overhead Door R-10+ Insulation Addon"
                  value={rates.overheadDoorInsulatedAddon}
                  unit="/ Door"
                  step={10.00}
                  description="Thermal polyurethane injected core insulation add-on per door."
                />
                <RateInputCard
                  fieldKey="walkDoorCommercialStandard"
                  label="Commercial Walk / Man Door Standard"
                  value={rates.walkDoorCommercialStandard}
                  unit="/ Door"
                  step={15.00}
                  description="3'x6'8&quot; insulated steel entry door with commercial lever lockset."
                />
                <RateInputCard
                  fieldKey="walkDoorInsulatedGlass"
                  label="Deluxe Walk Door with Window Insert"
                  value={rates.walkDoorInsulatedGlass}
                  unit="/ Door"
                  step={20.00}
                  description="Commercial entry door featuring insulated thermal double-pane lite."
                />
                <RateInputCard
                  fieldKey="windowSliderStandard"
                  label="Vinyl Sliding Window Unit"
                  value={rates.windowSliderStandard}
                  unit="/ Window"
                  step={10.00}
                  description="Low-E insulated double-hung/sliding vinyl window with screen and J-trim flange."
                />
                <RateInputCard
                  fieldKey="slidingBarnDoorDouble"
                  label="Double Split Sliding Barn Door"
                  value={rates.slidingBarnDoorDouble}
                  unit="/ Pair"
                  step={25.00}
                  description="Split sliding door package including steel trolley track, brackets, and stay rollers."
                />
              </div>
            </div>
          )}

          {/* SECTION 5: FOUNDATION & EARTHWORK */}
          {(activeTab === 'all' || activeTab === 'foundation') && (
            <div className="bg-white p-5 rounded-2xl border border-sky-100 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-sky-100 pb-2">
                <h4 className="text-xs font-bold text-[#0284C7] uppercase tracking-wider flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#06B6D4]" />
                  <span>Foundation & Earthwork</span>
                </h4>
                <span className="text-[11px] font-mono text-[#0284C7] font-semibold">
                  Slabs, Pads & Columns
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                <RateInputCard
                  fieldKey="concrete4inPerSqFt"
                  label="4&quot; Concrete Slab with Fiber Mesh"
                  value={rates.concrete4inPerSqFt}
                  unit="/ Sq Ft"
                  step={0.25}
                  description="4000 PSI concrete slab poured over 4&quot; stone base with smooth troweled finish."
                />
                <RateInputCard
                  fieldKey="concrete6inPerSqFt"
                  label="6&quot; Heavy-Duty Rebar Concrete Slab"
                  value={rates.concrete6inPerSqFt}
                  unit="/ Sq Ft"
                  step={0.25}
                  description="6-inch commercial pour with steel rebar grid on chairs for heavy machinery."
                />
                <RateInputCard
                  fieldKey="dirtGravelPrepPerSqFt"
                  label="Compacted Gravel Pad Site Prep"
                  value={rates.dirtGravelPrepPerSqFt}
                  unit="/ Sq Ft"
                  step={0.10}
                  description="Subgrade leveling, excavation, and compacted crushed limestone aggregate base."
                />
                <RateInputCard
                  fieldKey="piersPermaColumnPerUnit"
                  label="Perma-Column Concrete Pier Upgrades"
                  value={rates.piersPermaColumnPerUnit}
                  unit="/ Column"
                  step={5.00}
                  description="Precast concrete foundation column preventing wood post ground contact."
                />
              </div>
            </div>
          )}

          {/* SECTION 6: INTERIOR & INSULATION */}
          {(activeTab === 'all' || activeTab === 'interior') && (
            <div className="bg-white p-5 rounded-2xl border border-sky-100 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-sky-100 pb-2">
                <h4 className="text-xs font-bold text-[#0284C7] uppercase tracking-wider flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#06B6D4]" />
                  <span>Interior, Insulation & Electrical</span>
                </h4>
                <span className="text-[11px] font-mono text-[#0284C7] font-semibold">
                  Batt, Foam, Liner & Loft
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                <RateInputCard
                  fieldKey="insulationVaporBarrierPerSqFt"
                  label="Vapor Barrier Foil Insulation"
                  value={rates.insulationVaporBarrierPerSqFt}
                  unit="/ Sq Ft"
                  step={0.05}
                  description="Double reflective radiant barrier bubble insulation preventing condensation."
                />
                <RateInputCard
                  fieldKey="insulationR19BattPerSqFt"
                  label="R-19 Fiberglass Batt Insulation"
                  value={rates.insulationR19BattPerSqFt}
                  unit="/ Sq Ft"
                  step={0.10}
                  description="6-inch thick thermal fiberglass batts installed between framing posts."
                />
                <RateInputCard
                  fieldKey="insulationSprayFoam2inPerSqFt"
                  label="2&quot; Closed-Cell Spray Foam"
                  value={rates.insulationSprayFoam2inPerSqFt}
                  unit="/ Sq Ft"
                  step={0.15}
                  description="High density closed-cell polyurethane foam forming an airtight vapor seal."
                />
                <RateInputCard
                  fieldKey="insulationSprayFoam3inPerSqFt"
                  label="3&quot; Closed-Cell Spray Foam"
                  value={rates.insulationSprayFoam3inPerSqFt}
                  unit="/ Sq Ft"
                  step={0.15}
                  description="Maximum performance continuous thermal barrier for year-round climate control."
                />
                <RateInputCard
                  fieldKey="linerSteelPerSqFt"
                  label="Steel Liner Panel (Walls & Ceiling)"
                  value={rates.linerSteelPerSqFt}
                  unit="/ Sq Ft"
                  step={0.10}
                  description="Bright white washable 29-gauge ribbed interior metal liner panels."
                />
                <RateInputCard
                  fieldKey="linerOsbPerSqFt"
                  label="OSB / Plywood Interior Liner"
                  value={rates.linerOsbPerSqFt}
                  unit="/ Sq Ft"
                  step={0.10}
                  description="7/16&quot; heavy structural oriented strand board for hanging tools."
                />
                <RateInputCard
                  fieldKey="electricalBasicPerSqFt"
                  label="Basic Workshop Electrical Package"
                  value={rates.electricalBasicPerSqFt}
                  unit="/ Sq Ft"
                  step={0.15}
                  description="100A panel, LED high-bay fixtures, and perimeter convenience duplex receptacles."
                />
                <RateInputCard
                  fieldKey="electricalDeluxePerSqFt"
                  label="Deluxe Commercial 200A Electrical"
                  value={rates.electricalDeluxePerSqFt}
                  unit="/ Sq Ft"
                  step={0.25}
                  description="200A service, 240V welder outlets, exterior flood lights, and commercial conduit."
                />
                <RateInputCard
                  fieldKey="loftPerSqFt"
                  label="Mezzanine Storage Loft Framing"
                  value={rates.loftPerSqFt}
                  unit="/ Sq Ft"
                  step={0.50}
                  description="Engineered floor joists with heavy 3/4&quot; tongue-and-groove decking."
                />
              </div>
            </div>
          )}

          {/* SECTION 7: LABOR & OVERHEAD MARGIN */}
          {(activeTab === 'all' || activeTab === 'labor') && (
            <div className="bg-white p-5 rounded-2xl border border-sky-100 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-sky-100 pb-2">
                <h4 className="text-xs font-bold text-[#0284C7] uppercase tracking-wider flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#06B6D4]" />
                  <span>Labor Erection & Contractor Contingency</span>
                </h4>
                <span className="text-[11px] font-mono text-[#0284C7] font-semibold">
                  Crew Rates & Overhead Margin
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <RateInputCard
                  fieldKey="laborFramingPerSqFt"
                  label="Framing Crew Erection Labor"
                  value={rates.laborFramingPerSqFt}
                  unit="/ Sq Ft"
                  step={0.25}
                  description="Post setting, truss raising, purlin, girt, and header framing labor."
                />
                <RateInputCard
                  fieldKey="laborSidingRoofPerSqFt"
                  label="Siding, Roofing & Trim Installation"
                  value={rates.laborSidingRoofPerSqFt}
                  unit="/ Sq Ft"
                  step={0.25}
                  description="Metal panel fastening, screw installation, closures, and architectural trim flashing labor."
                />
                <RateInputCard
                  fieldKey="contingencyMarginPercent"
                  label="Contractor Margin / Contingency"
                  value={rates.contingencyMarginPercent}
                  unit="%"
                  step={0.50}
                  description="Percentage added to total direct materials and labor for overhead, permit contingency, and builder margin."
                />
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-white px-6 py-4 border-t border-sky-100 flex items-center justify-between transition-colors shadow-xs">
          <span className="text-xs text-[#0284C7] flex items-center gap-1.5 font-medium">
            <ShieldCheck className="w-4 h-4 text-[#06B6D4]" />
            <span>All customized rates calculate instantly across the 3D visualizer, BOM takeoff, and price summary.</span>
          </span>

          <button
            onClick={onClose}
            className="px-6 py-2.5 rounded-full text-xs font-bold bg-[#06B6D4] hover:bg-[#0891b2] text-white cursor-pointer shadow-md active:scale-95 transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] flex items-center gap-2 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4]"
          >
            <Check className="w-4 h-4 stroke-[2.5]" />
            <span>Apply Rates & Close</span>
          </button>
        </div>
      </div>
    </div>
  );
};
