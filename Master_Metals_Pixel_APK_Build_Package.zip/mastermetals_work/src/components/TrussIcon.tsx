import React from 'react';

interface TrussIconProps {
  className?: string;
  width?: number | string;
  height?: number | string;
  strokeWidth?: number;
}

/**
 * Architectural Howe Gable Truss Icon
 * Exact vector replica of the engineered truss icon in user image 1790221986724.png:
 * Tight aspect ratio viewBox (100x42) so the wide truss proportions can be rendered at full width/height.
 */
export const TrussIcon: React.FC<TrussIconProps> = ({
  className = 'w-9 h-4.5',
  width,
  height,
  strokeWidth = 1.35,
}) => {
  return (
    <svg
      viewBox="2 16 96 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`inline-block shrink-0 ${className}`}
      style={{
        width,
        height,
      }}
      aria-hidden="true"
    >
      <g
        stroke="currentColor"
        strokeWidth={strokeWidth}
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        {/* Top Chord - Outer Ridge to Eaves */}
        <polyline points="4,48 50,18 96,48" strokeWidth={strokeWidth} />

        {/* Eave End Cuts */}
        <line x1="4" y1="48" x2="6" y2="52" strokeWidth={strokeWidth} />
        <line x1="96" y1="48" x2="94" y2="52" strokeWidth={strokeWidth} />

        {/* Top Chord - Underside Lines */}
        <line x1="6" y1="52" x2="50" y2="23" strokeWidth={strokeWidth} />
        <line x1="94" y1="52" x2="50" y2="23" strokeWidth={strokeWidth} />

        {/* Bottom Chord (Horizontal double line) */}
        <line x1="10" y1="49.5" x2="90" y2="49.5" strokeWidth={strokeWidth} />
        <line x1="10" y1="53.5" x2="90" y2="53.5" strokeWidth={strokeWidth} />
        <line x1="10" y1="49.5" x2="10" y2="53.5" strokeWidth={strokeWidth} />
        <line x1="90" y1="49.5" x2="90" y2="53.5" strokeWidth={strokeWidth} />

        {/* Center King Post (Vertical double line) */}
        <line x1="48.4" y1="23" x2="48.4" y2="49.5" strokeWidth={strokeWidth * 0.9} />
        <line x1="51.6" y1="23" x2="51.6" y2="49.5" strokeWidth={strokeWidth * 0.9} />

        {/* LEFT HALF STRUCTURAL WEBS */}
        <line x1="36" y1="31.8" x2="36" y2="49.5" strokeWidth={strokeWidth * 0.85} />
        <line x1="38.5" y1="33.4" x2="38.5" y2="49.5" strokeWidth={strokeWidth * 0.85} />

        <line x1="22.5" y1="40.5" x2="22.5" y2="49.5" strokeWidth={strokeWidth * 0.85} />
        <line x1="25" y1="42" x2="25" y2="49.5" strokeWidth={strokeWidth * 0.85} />

        {/* Inner Left Diagonal */}
        <line x1="37.2" y1="32.5" x2="48.4" y2="49.5" strokeWidth={strokeWidth * 0.85} />
        {/* Middle Left Diagonal */}
        <line x1="23.8" y1="41.2" x2="36" y2="49.5" strokeWidth={strokeWidth * 0.85} />
        {/* Outer Left Diagonal */}
        <line x1="23" y1="42.5" x2="11.5" y2="49.5" strokeWidth={strokeWidth * 0.85} />

        {/* RIGHT HALF STRUCTURAL WEBS (Symmetrical) */}
        <line x1="61.5" y1="33.4" x2="61.5" y2="49.5" strokeWidth={strokeWidth * 0.85} />
        <line x1="64" y1="31.8" x2="64" y2="49.5" strokeWidth={strokeWidth * 0.85} />

        <line x1="75" y1="42" x2="75" y2="49.5" strokeWidth={strokeWidth * 0.85} />
        <line x1="77.5" y1="40.5" x2="77.5" y2="49.5" strokeWidth={strokeWidth * 0.85} />

        {/* Inner Right Diagonal */}
        <line x1="62.8" y1="32.5" x2="51.6" y2="49.5" strokeWidth={strokeWidth * 0.85} />
        {/* Middle Right Diagonal */}
        <line x1="76.2" y1="41.2" x2="64" y2="49.5" strokeWidth={strokeWidth * 0.85} />
        {/* Outer Right Diagonal */}
        <line x1="77" y1="42.5" x2="88.5" y2="49.5" strokeWidth={strokeWidth * 0.85} />
      </g>
    </svg>
  );
};
