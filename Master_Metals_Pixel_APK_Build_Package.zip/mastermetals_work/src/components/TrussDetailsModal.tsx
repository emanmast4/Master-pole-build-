import React, { useEffect } from 'react';
import { CustomBuildingState, PricingBreakdown } from '../types';
import { X } from 'lucide-react';
import { TrussPricingCard } from './TrussPricingCard';

interface TrussDetailsModalProps {
  state: CustomBuildingState;
  pricing: PricingBreakdown;
  onUpdateState: (updater: (prev: CustomBuildingState) => CustomBuildingState) => void;
  onOpenUnitPricing: () => void;
  onClose: () => void;
}

export const TrussDetailsModal: React.FC<TrussDetailsModalProps> = ({
  state,
  pricing,
  onUpdateState,
  onOpenUnitPricing,
  onClose,
}) => {
  const { width, roofPitch } = state.dimensions;

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  return (
    <div 
      className="fixed inset-0 z-50 bg-[#075985]/40 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-y-auto"
      onClick={onClose}
    >
      <div 
        className="bg-white border border-sky-200/80 rounded-3xl w-full max-w-5xl max-h-[94vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 transition-all text-[#075985]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="bg-white/95 backdrop-blur-md px-4 sm:px-6 py-3.5 sm:py-4 border-b border-sky-100 flex items-center justify-between transition-colors text-[#075985] shrink-0 shadow-xs">
          <div>
            <h3 className="text-sm sm:text-base font-bold text-[#075985] flex items-center gap-2">
              <span>Engineered Truss Details & Dynamic Pricing</span>
            </h3>
            <p className="text-xs text-[#0369A1]/80 font-medium">
              {width}' Span @ {roofPitch}:12 Pitch • {state.snowLoad} PSF Snow Load • {pricing.trusses.totalTrussesNeeded} Trusses Total
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="p-2 text-[#0369A1] hover:text-[#075985] rounded-full hover:bg-sky-100 cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-90 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4]"
              aria-label="Close truss details modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body with TrussPricingCard */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-6 bg-sky-50/40">
          <TrussPricingCard
            state={state}
            trussData={pricing.trusses}
            onUpdateState={onUpdateState}
            onOpenUnitPricing={onOpenUnitPricing}
          />
        </div>
      </div>
    </div>
  );
};
