import React, { useState, useEffect } from 'react';
import { BuildingDimensions } from '../types';
import { 
  X, 
  Ruler, 
  Check, 
  Minus, 
  Plus, 
  Maximize2, 
  AlertCircle,
  Sparkles,
  ArrowRight
} from 'lucide-react';

interface DimensionsEditModalProps {
  isOpen: boolean;
  onClose: () => void;
  dimensions: BuildingDimensions;
  onSave: (updatedDimensions: { length: number; width: number; eaveHeight: number }) => void;
}

export const DimensionsEditModal: React.FC<DimensionsEditModalProps> = ({
  isOpen,
  onClose,
  dimensions,
  onSave,
}) => {
  // Local numerical states for Length, Width, Height
  const [length, setLength] = useState<number>(dimensions.length);
  const [width, setWidth] = useState<number>(dimensions.width);
  const [height, setHeight] = useState<number>(dimensions.eaveHeight);
  const [error, setError] = useState<string | null>(null);

  // Sync state when modal opens or dimensions prop changes
  useEffect(() => {
    if (isOpen) {
      setLength(dimensions.length);
      setWidth(dimensions.width);
      setHeight(dimensions.eaveHeight);
      setError(null);
    }
  }, [isOpen, dimensions]);

  // Handle Escape key to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  // Validation limits
  const MIN_LENGTH = 12;
  const MAX_LENGTH = 240;
  const MIN_WIDTH = 12;
  const MAX_WIDTH = 100;
  const MIN_HEIGHT = 8;
  const MAX_HEIGHT = 32;

  const handleApply = (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    // Validation checks
    if (isNaN(length) || length < MIN_LENGTH || length > MAX_LENGTH) {
      setError(`Length must be between ${MIN_LENGTH} ft and ${MAX_LENGTH} ft.`);
      return;
    }
    if (isNaN(width) || width < MIN_WIDTH || width > MAX_WIDTH) {
      setError(`Width must be between ${MIN_WIDTH} ft and ${MAX_WIDTH} ft.`);
      return;
    }
    if (isNaN(height) || height < MIN_HEIGHT || height > MAX_HEIGHT) {
      setError(`Eave height must be between ${MIN_HEIGHT} ft and ${MAX_HEIGHT} ft.`);
      return;
    }

    // Call onSave with rounded valid numbers
    onSave({
      length: Math.round(length),
      width: Math.round(width),
      eaveHeight: Math.round(height),
    });

    onClose();
  };

  const QUICK_LENGTHS = [30, 40, 48, 60, 80, 100];
  const QUICK_WIDTHS = [24, 30, 36, 40, 50, 60];
  const QUICK_HEIGHTS = [10, 12, 14, 16, 18, 20];

  const calculatedArea = (length || 0) * (width || 0);

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-md transition-all duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      {/* Floating Pop-Up Modal Window */}
      <div 
        id="dimensions-edit-modal-window"
        className="w-full max-w-lg max-h-[92vh] bg-white border border-slate-200/90 rounded-xl shadow-[0_4px_6px_-1px_rgba(0,0,0,0.1),0_2px_4px_-2px_rgba(0,0,0,0.06)] overflow-hidden transition-all duration-200 flex flex-col text-[#0F172A]"
        role="dialog"
        aria-modal="true"
        aria-labelledby="dimensions-modal-title"
      >
        {/* Modal Header */}
        <div className="px-6 py-4 bg-[#0F172A] border-b border-slate-800 flex items-center justify-between shrink-0 text-white">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-sky-500/20 text-[#38BDF8] border border-sky-500/40 flex items-center justify-center shadow-sm">
              <Ruler className="w-4.5 h-4.5" />
            </div>
            <div>
              <h3 id="dimensions-modal-title" className="text-base font-bold text-white">
                Edit Building Dimensions
              </h3>
              <p className="text-xs text-slate-300">
                Update structural Length, Width, and Eave Height
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0284C7]"
            title="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body Form */}
        <form onSubmit={handleApply} className="p-5 sm:p-6 space-y-4 sm:space-y-5 overflow-y-auto flex-1">
          {/* Error Message if validation fails */}
          {error && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-600 dark:text-rose-400 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Active Footprint Real-Time Preview Badge */}
          <div className="p-3.5 rounded-xl bg-white border border-slate-200/90 shadow-xs flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-mono font-bold text-[#0F172A]">
              <Sparkles className="w-3.5 h-3.5 text-[#0284C7]" />
              <span>Footprint Preview:</span>
            </div>
            <div className="text-right">
              <span className="text-sm font-black font-mono text-[#0284C7]">
                {calculatedArea.toLocaleString()} SQ FT
              </span>
              <span className="text-[11px] text-slate-500 block font-mono">
                {length}' L × {width}' W × {height}' H
              </span>
            </div>
          </div>

          {/* 1. Numerical Input Field: Length */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label htmlFor="input-dimension-length" className="text-xs font-bold text-[#0F172A]">
                Length (ft) - Building Depth
              </label>
              <span className="text-[11px] text-slate-500 font-mono">
                {MIN_LENGTH}' - {MAX_LENGTH}'
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setLength((prev) => Math.max(MIN_LENGTH, prev - 2))}
                className="w-10 h-10 rounded-lg bg-white hover:bg-slate-50 text-[#0F172A] flex items-center justify-center cursor-pointer transition-all active:scale-95 border border-slate-200 shadow-2xs focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0284C7]"
                title="Decrease Length by 2 ft"
              >
                <Minus className="w-4 h-4" />
              </button>
              <input
                id="input-dimension-length"
                type="number"
                min={MIN_LENGTH}
                max={MAX_LENGTH}
                step="1"
                value={length}
                onChange={(e) => setLength(Number(e.target.value))}
                className="flex-1 h-10 px-3.5 rounded-lg bg-white border border-slate-200 text-[#0F172A] font-mono font-bold text-center text-base focus:outline-none focus:ring-2 focus:ring-[#0284C7] focus:border-[#0284C7] shadow-2xs transition-all"
                required
              />
              <button
                type="button"
                onClick={() => setLength((prev) => Math.min(MAX_LENGTH, prev + 2))}
                className="w-10 h-10 rounded-lg bg-white hover:bg-slate-50 text-[#0F172A] flex items-center justify-center cursor-pointer transition-all active:scale-95 border border-slate-200 shadow-2xs focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0284C7]"
                title="Increase Length by 2 ft"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
            {/* Quick Chips for Length */}
            <div className="flex gap-1.5 flex-wrap pt-0.5">
              {QUICK_LENGTHS.map((val) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => setLength(val)}
                  className={`text-[11px] px-2.5 py-0.5 rounded-md font-mono transition-all cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0284C7] ${
                    length === val
                      ? 'bg-[#0284C7] text-white font-bold shadow-xs'
                      : 'bg-white text-slate-700 hover:text-[#0F172A] hover:bg-slate-50 border border-slate-200 shadow-2xs'
                  }`}
                >
                  {val}'
                </button>
              ))}
            </div>
          </div>

          {/* 2. Numerical Input Field: Width */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label htmlFor="input-dimension-width" className="text-xs font-bold text-[#0F172A]">
                Width (ft) - Clear Truss Span
              </label>
              <span className="text-[11px] text-slate-500 font-mono">
                {MIN_WIDTH}' - {MAX_WIDTH}'
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setWidth((prev) => Math.max(MIN_WIDTH, prev - 2))}
                className="w-10 h-10 rounded-lg bg-white hover:bg-slate-50 text-[#0F172A] flex items-center justify-center cursor-pointer transition-all active:scale-95 border border-slate-200 shadow-2xs focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0284C7]"
                title="Decrease Width by 2 ft"
              >
                <Minus className="w-4 h-4" />
              </button>
              <input
                id="input-dimension-width"
                type="number"
                min={MIN_WIDTH}
                max={MAX_WIDTH}
                step="1"
                value={width}
                onChange={(e) => setWidth(Number(e.target.value))}
                className="flex-1 h-10 px-3.5 rounded-lg bg-white border border-slate-200 text-[#0F172A] font-mono font-bold text-center text-base focus:outline-none focus:ring-2 focus:ring-[#0284C7] focus:border-[#0284C7] shadow-2xs transition-all"
                required
              />
              <button
                type="button"
                onClick={() => setWidth((prev) => Math.min(MAX_WIDTH, prev + 2))}
                className="w-10 h-10 rounded-lg bg-white hover:bg-slate-50 text-[#0F172A] flex items-center justify-center cursor-pointer transition-all active:scale-95 border border-slate-200 shadow-2xs focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0284C7]"
                title="Increase Width by 2 ft"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
            {/* Quick Chips for Width */}
            <div className="flex gap-1.5 flex-wrap pt-0.5">
              {QUICK_WIDTHS.map((val) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => setWidth(val)}
                  className={`text-[11px] px-2.5 py-0.5 rounded-md font-mono transition-all cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0284C7] ${
                    width === val
                      ? 'bg-[#0284C7] text-white font-bold shadow-xs'
                      : 'bg-white text-slate-700 hover:text-[#0F172A] hover:bg-slate-50 border border-slate-200 shadow-2xs'
                  }`}
                >
                  {val}'
                </button>
              ))}
            </div>
          </div>

          {/* 3. Numerical Input Field: Height */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label htmlFor="input-dimension-height" className="text-xs font-bold text-[#0F172A]">
                Height (ft) - Eave Wall Clearance
              </label>
              <span className="text-[11px] text-slate-500 font-mono">
                {MIN_HEIGHT}' - {MAX_HEIGHT}'
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setHeight((prev) => Math.max(MIN_HEIGHT, prev - 1))}
                className="w-10 h-10 rounded-lg bg-white hover:bg-slate-50 text-[#0F172A] flex items-center justify-center cursor-pointer transition-all active:scale-95 border border-slate-200 shadow-2xs focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0284C7]"
                title="Decrease Height by 1 ft"
              >
                <Minus className="w-4 h-4" />
              </button>
              <input
                id="input-dimension-height"
                type="number"
                min={MIN_HEIGHT}
                max={MAX_HEIGHT}
                step="1"
                value={height}
                onChange={(e) => setHeight(Number(e.target.value))}
                className="flex-1 h-10 px-3.5 rounded-lg bg-white border border-slate-200 text-[#0F172A] font-mono font-bold text-center text-base focus:outline-none focus:ring-2 focus:ring-[#0284C7] focus:border-[#0284C7] shadow-2xs transition-all"
                required
              />
              <button
                type="button"
                onClick={() => setHeight((prev) => Math.min(MAX_HEIGHT, prev + 1))}
                className="w-10 h-10 rounded-lg bg-white hover:bg-slate-50 text-[#0F172A] flex items-center justify-center cursor-pointer transition-all active:scale-95 border border-slate-200 shadow-2xs focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0284C7]"
                title="Increase Height by 1 ft"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
            {/* Quick Chips for Height */}
            <div className="flex gap-1.5 flex-wrap pt-0.5">
              {QUICK_HEIGHTS.map((val) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => setHeight(val)}
                  className={`text-[11px] px-2.5 py-0.5 rounded-md font-mono transition-all cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0284C7] ${
                    height === val
                      ? 'bg-[#0284C7] text-white font-bold shadow-xs'
                      : 'bg-white text-slate-700 hover:text-[#0F172A] hover:bg-slate-50 border border-slate-200 shadow-2xs'
                  }`}
                >
                  {val}'
                </button>
              ))}
            </div>
          </div>

          {/* Modal Action Buttons (Save / Apply / Cancel) */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              type="button"
              id="btn-cancel-dimensions-modal"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-600 hover:text-[#0F172A] hover:bg-slate-100 transition-all cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0284C7]"
            >
              Cancel
            </button>
            <button
              type="submit"
              id="btn-apply-dimensions-modal"
              className="px-5 py-2 rounded-lg text-xs font-bold bg-[#0284C7] hover:bg-sky-600 text-white shadow-xs flex items-center gap-2 cursor-pointer active:scale-95 transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0284C7]"
            >
              <Check className="w-4 h-4 stroke-[2.5]" />
              <span>Apply Changes</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
