import React, { useState } from 'react';
import { CustomBuildingState, MaterialsConfig } from '../../types';
import { COLOR_PALETTE } from '../../utils/constants';
import { Palette, Layers, ShieldCheck, Check, Sliders, Pipette, Sparkles } from 'lucide-react';
import { ColorOptionPill } from '../ColorOptionPill';

interface MaterialsTabProps {
  state: CustomBuildingState;
  onUpdateState: (updater: (prev: CustomBuildingState) => CustomBuildingState) => void;
  onOpenUnitPricing?: () => void;
}

export const MaterialsTab: React.FC<MaterialsTabProps> = ({ state, onUpdateState, onOpenUnitPricing }) => {
  const { materials } = state;

  const updateMaterials = (patch: Partial<MaterialsConfig>) => {
    onUpdateState((prev) => ({
      ...prev,
      materials: {
        ...prev.materials,
        ...patch,
      },
    }));
  };

  // Helper to find color name from hex, or return hex
  const getColorName = (hex: string) => {
    const found = COLOR_PALETTE.find((c) => c.hex.toLowerCase() === hex.toLowerCase());
    return found ? found.name : `Custom (${hex.toUpperCase()})`;
  };

  // Preset Color Palettes for 1-click harmony
  const PRESET_SCHEMES = [
    {
      name: 'Modern Farmhouse',
      desc: 'White siding, matte black roof & trims',
      siding: '#f8fafc',
      sidingName: 'Bright White',
      roof: '#18181b',
      roofName: 'Matte Black',
      trim: '#18181b',
      trimName: 'Matte Black',
      wainscot: '#374151',
      wainscotName: 'Charcoal Gray',
    },
    {
      name: 'Classic Heritage Barn',
      desc: 'Barn red siding, white trims, charcoal roof',
      siding: '#991b1b',
      sidingName: 'Classic Barn Red',
      roof: '#374151',
      roofName: 'Charcoal Gray',
      trim: '#f8fafc',
      trimName: 'Bright White',
      wainscot: '#475569',
      wainscotName: 'Burnished Slate',
    },
    {
      name: 'Industrial Slate',
      desc: 'Burnished slate siding & roof, bright white trim',
      siding: '#475569',
      sidingName: 'Burnished Slate',
      roof: '#374151',
      roofName: 'Charcoal Gray',
      trim: '#f8fafc',
      trimName: 'Bright White',
      wainscot: '#18181b',
      wainscotName: 'Matte Black',
    },
    {
      name: 'Forest Workshop',
      desc: 'Light sand siding, evergreen roof & accents',
      siding: '#d6d3d1',
      sidingName: 'Light Stone / Sand',
      roof: '#166534',
      roofName: 'Forest Green',
      trim: '#166534',
      trimName: 'Forest Green',
      wainscot: '#166534',
      wainscotName: 'Forest Green',
    },
    {
      name: 'Mountain Rustic',
      desc: 'Dark bronze siding, burnished slate wainscot',
      siding: '#3b2f2f',
      sidingName: 'Dark Bronze',
      roof: '#18181b',
      roofName: 'Matte Black',
      trim: '#b45309',
      trimName: 'Copper Metallic',
      wainscot: '#a8715a',
      wainscotName: 'Desert Clay / Tan',
    },
    {
      name: 'Monochrome Stealth',
      desc: 'Matte black body, trims, and standing seam roof',
      siding: '#18181b',
      sidingName: 'Matte Black',
      roof: '#18181b',
      roofName: 'Matte Black',
      trim: '#18181b',
      trimName: 'Matte Black',
      wainscot: '#374151',
      wainscotName: 'Charcoal Gray',
    },
  ];

  const applyScheme = (scheme: typeof PRESET_SCHEMES[0]) => {
    updateMaterials({
      sidingColor: scheme.siding,
      sidingColorName: scheme.sidingName,
      roofColor: scheme.roof,
      roofColorName: scheme.roofName,
      trimColor: scheme.trim,
      trimColorName: scheme.trimName,
      wainscotColor: scheme.wainscot,
      wainscotColorName: scheme.wainscotName,
      cornerTrimColor: scheme.trim,
      cornerTrimColorName: scheme.trimName,
      eaveTrimColor: scheme.trim,
      eaveTrimColorName: scheme.trimName,
      rakeTrimColor: scheme.trim,
      rakeTrimColorName: scheme.trimName,
      ridgeCapColor: scheme.trim,
      ridgeCapColorName: scheme.trimName,
      doorTrimColor: scheme.trim,
      doorTrimColorName: scheme.trimName,
      wainscotCapColor: scheme.trim,
      wainscotCapColorName: scheme.trimName,
    });
  };

  // Reusable Color Selector Component
  const ColorSelector = ({
    label,
    currentColor,
    currentColorName,
    onSelect,
  }: {
    label: string;
    currentColor: string;
    currentColorName: string;
    onSelect: (hex: string, name: string) => void;
  }) => {
    return (
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs text-[#0F172A] font-semibold">{label}</span>
          <div className="flex items-center gap-2 bg-slate-100 px-3 py-1 rounded-full border border-slate-200">
            <span
              className="w-3.5 h-3.5 rounded-full border border-slate-300 shadow-2xs"
              style={{ backgroundColor: currentColor }}
            />
            <span className="text-xs text-[#0F172A] font-mono font-bold">{currentColorName}</span>
          </div>
        </div>

        {/* Swatches Grid */}
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
          {COLOR_PALETTE.map((c) => {
            const isSelected = currentColor.toLowerCase() === c.hex.toLowerCase();
            return (
              <button
                key={c.name}
                onClick={() => onSelect(c.hex, c.name)}
                className={`relative px-3 py-2 rounded-full border flex items-center gap-2 cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] text-left active:scale-95 hover:scale-[1.02] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
                  isSelected
                    ? 'border-2 border-[#06B6D4] ring-2 ring-[#06B6D4]/30 bg-cyan-50 text-[#075985] shadow-sm font-black'
                    : 'border-sky-200/80 bg-white hover:border-sky-300 hover:bg-sky-50/70 shadow-2xs font-semibold text-[#0369A1]'
                }`}
              >
                <span
                  className="w-3.5 h-3.5 rounded-full border border-black/20 shrink-0 shadow-2xs"
                  style={{ backgroundColor: c.hex }}
                />
                <span className={`text-[11px] truncate ${isSelected ? 'text-[#075985] font-black' : 'text-[#0369A1]'}`}>{c.name}</span>
                {isSelected && (
                  <span className="absolute -bottom-[2px] inset-x-2.5 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
                )}
              </button>
            );
          })}
        </div>

        {/* Custom Hex / Eyedropper Picker */}
        <div className="flex items-center justify-end gap-2.5 pt-1">
          <label className="text-[11px] text-slate-500 flex items-center gap-1.5 cursor-pointer font-medium">
            <Pipette className="w-3.5 h-3.5 text-[#0284C7]" />
            <span>Custom Hex:</span>
          </label>
          <input
            type="color"
            value={currentColor}
            onChange={(e) => onSelect(e.target.value, getColorName(e.target.value))}
            className="w-8 h-8 rounded-full border border-slate-300 bg-white cursor-pointer overflow-hidden p-0"
            title="Pick custom hex color"
          />
          <input
            type="text"
            value={currentColor.toUpperCase()}
            onChange={(e) => {
              if (e.target.value.startsWith('#') || e.target.value.length === 6) {
                const hex = e.target.value.startsWith('#') ? e.target.value : `#${e.target.value}`;
                onSelect(hex, getColorName(hex));
              }
            }}
            className="w-24 px-3 py-1 bg-slate-50 border border-slate-300 rounded-full text-xs font-mono font-bold text-[#0F172A] uppercase focus:border-[#0284C7] focus:outline-none"
            placeholder="#HEX"
          />
        </div>
      </div>
    );
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const hasWainscotEnabled = Object.values(state.walls).some((w) => w.hasWainscot);

  return (
    <div className="space-y-6">
      {/* Active Component Palette Pills - Quick Overview & Navigation */}
      <div className="bg-white border border-slate-200/90 p-4 sm:p-5 rounded-xl shadow-[0_4px_6px_-1px_rgba(0,0,0,0.1),0_2px_4px_-2px_rgba(0,0,0,0.06)] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Palette className="w-4 h-4 text-[#0284C7]" />
          <span className="text-xs sm:text-sm font-bold text-[#0F172A]">Current Building Colors:</span>
        </div>

        {/* Roof, Siding, and Trims Pill Shaped Indicators */}
        <div className="flex items-center gap-2 flex-wrap">
          <ColorOptionPill
            id="mat-pill-roof"
            name="Roof"
            color={materials.roofColor}
            colorName={materials.roofColorName}
            onClick={() => scrollToSection('section-roof')}
            size="md"
          />

          <ColorOptionPill
            id="mat-pill-siding"
            name="Siding"
            color={materials.sidingColor}
            colorName={materials.sidingColorName}
            onClick={() => scrollToSection('section-siding')}
            size="md"
          />

          {hasWainscotEnabled && (
            <ColorOptionPill
              id="mat-pill-wainscot"
              name="Wainscot"
              color={materials.wainscotColor}
              colorName={materials.wainscotColorName}
              onClick={() => scrollToSection('section-wainscot')}
              size="md"
            />
          )}

          <ColorOptionPill
            id="mat-pill-trims"
            name="Trims"
            color={materials.trimColor}
            colorName={materials.trimColorName}
            onClick={() => scrollToSection('section-trims')}
            size="md"
          />
        </div>
      </div>

      {/* Quick Color Scheme Presets */}
      <div className="bg-white border border-slate-200/90 p-5 sm:p-6 rounded-xl shadow-[0_4px_6px_-1px_rgba(0,0,0,0.1),0_2px_4px_-2px_rgba(0,0,0,0.06)] space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-sm font-bold text-[#0F172A] flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#0284C7]" />
            <span>Curated Architectural Color Schemes</span>
          </label>
          <span className="text-[11px] text-[#0284C7] font-mono font-semibold">1-Click Fast Harmony</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
          {PRESET_SCHEMES.map((scheme) => (
            <button
              key={scheme.name}
              onClick={() => applyScheme(scheme)}
              className="p-3 rounded-xl border border-slate-200/90 bg-white hover:border-[#0284C7] hover:bg-sky-50/40 text-left transition-all cursor-pointer group active:scale-95 shadow-2xs"
            >
              <div className="flex items-center gap-1.5 mb-2">
                <span className="w-3.5 h-3.5 rounded-full border border-black/20 shadow-2xs" style={{ backgroundColor: scheme.siding }} title="Siding" />
                <span className="w-3.5 h-3.5 rounded-full border border-black/20 shadow-2xs" style={{ backgroundColor: scheme.wainscot }} title="Wainscot" />
                <span className="w-3.5 h-3.5 rounded-full border border-black/20 shadow-2xs" style={{ backgroundColor: scheme.roof }} title="Roof" />
                <span className="w-3.5 h-3.5 rounded-full border border-black/20 shadow-2xs" style={{ backgroundColor: scheme.trim }} title="Trim" />
              </div>
              <span className="text-xs font-bold text-slate-800 group-hover:text-[#0F172A] block leading-tight truncate">
                {scheme.name}
              </span>
              <span className="text-[10px] text-slate-500 block truncate mt-0.5">{scheme.desc}</span>
            </button>
          ))}
        </div>
      </div>

      {/* 1. Roof Profile & Color */}
      <div id="section-roof" className="bg-white border border-slate-200/90 p-5 sm:p-6 rounded-xl shadow-[0_4px_6px_-1px_rgba(0,0,0,0.1),0_2px_4px_-2px_rgba(0,0,0,0.06)] space-y-5">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3 gap-2 flex-wrap">
          <label className="text-sm font-bold text-[#0F172A] flex items-center gap-2">
            <span className="w-6 h-6 rounded-md bg-sky-100 text-[#0284C7] text-xs flex items-center justify-center font-bold">1</span>
            <span>Roof Metal Profile & Color</span>
            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-sky-100 text-[#0284C7] border border-sky-200">
              36" Net Coverage
            </span>
          </label>
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-600 font-medium hidden sm:inline">{materials.roofColorName}</span>
            <ColorOptionPill
              name="Roof"
              color={materials.roofColor}
              colorName={materials.roofColorName}
              size="sm"
            />
          </div>
        </div>

        <ColorSelector
          label="Roof Metal Color"
          currentColor={materials.roofColor}
          currentColorName={materials.roofColorName}
          onSelect={(hex, name) => updateMaterials({ roofColor: hex, roofColorName: name })}
        />
      </div>

      {/* 2. Wall Siding Material & Color */}
      <div id="section-siding" className="bg-white border border-slate-200/90 p-5 sm:p-6 rounded-xl shadow-[0_4px_6px_-1px_rgba(0,0,0,0.1),0_2px_4px_-2px_rgba(0,0,0,0.06)] space-y-5">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3 gap-2 flex-wrap">
          <label className="text-sm font-bold text-[#0F172A] flex items-center gap-2">
            <span className="w-6 h-6 rounded-md bg-sky-100 text-[#0284C7] text-xs flex items-center justify-center font-bold">2</span>
            <span>Wall Siding Profile & Color</span>
            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-sky-100 text-[#0284C7] border border-sky-200">
              36" Net Coverage
            </span>
          </label>
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-600 font-medium hidden sm:inline">{materials.sidingColorName}</span>
            <ColorOptionPill
              name="Siding"
              color={materials.sidingColor}
              colorName={materials.sidingColorName}
              size="sm"
            />
          </div>
        </div>

        {/* Siding Color Selector */}
        <ColorSelector
          label="Wall Siding Metal Color"
          currentColor={materials.sidingColor}
          currentColorName={materials.sidingColorName}
          onSelect={(hex, name) => updateMaterials({ sidingColor: hex, sidingColorName: name })}
        />
      </div>

      {/* 3. Architectural Trim & Flashing Colors */}
      <div id="section-trims" className="bg-white border border-slate-200/90 p-5 sm:p-6 rounded-xl shadow-[0_4px_6px_-1px_rgba(0,0,0,0.1),0_2px_4px_-2px_rgba(0,0,0,0.06)] space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-3">
            <div>
              <label className="text-sm font-bold text-[#0F172A] flex items-center gap-2">
                <span className="w-6 h-6 rounded-md bg-sky-100 text-[#0284C7] text-xs flex items-center justify-center font-bold">3</span>
                <span>Architectural Trim & Flashing Package</span>
              </label>
              <p className="text-xs text-slate-500 mt-0.5">
                Corners, eave fascia, gable rakes, ridge cap, and door/window casing
              </p>
            </div>
            <ColorOptionPill
              name="Trims"
              color={materials.trimColor}
              colorName={materials.trimColorName}
              size="sm"
            />
          </div>

          {/* Controls: Price Manager & Toggle */}
          <div className="flex flex-wrap items-center gap-2">
            {onOpenUnitPricing && (
              <button
                type="button"
                onClick={onOpenUnitPricing}
                className="text-xs flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-[#075985] hover:text-[#0c4a6e] bg-cyan-50 hover:bg-cyan-100 border border-cyan-200 cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-95 font-bold shadow-2xs focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4]"
                title="Change the price of every component and trim"
              >
                <Sliders className="w-3.5 h-3.5 text-[#06B6D4]" />
                <span>Change Trim Prices</span>
              </button>
            )}

            {/* Toggle between All Trims Single Color vs Granular Trims */}
            <div className="flex items-center gap-1 bg-sky-50/80 p-1 rounded-full border border-sky-200">
              <button
                onClick={() => updateMaterials({ customTrimColorsEnabled: false })}
                className={`relative px-4 py-1.5 rounded-full text-xs font-bold cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
                  !materials.customTrimColorsEnabled
                    ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] shadow-sm font-black ring-2 ring-[#06B6D4]/30'
                    : 'text-[#0369A1] hover:text-[#075985]'
                }`}
              >
                All Trims Uniform
                {!materials.customTrimColorsEnabled && (
                  <span className="absolute -bottom-[2px] inset-x-2.5 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
                )}
              </button>
              <button
                onClick={() => updateMaterials({ customTrimColorsEnabled: true })}
                className={`relative px-4 py-1.5 rounded-full text-xs font-bold cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] flex items-center gap-1.5 active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
                  materials.customTrimColorsEnabled
                    ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] shadow-sm font-black ring-2 ring-[#06B6D4]/30'
                    : 'text-[#0369A1] hover:text-[#075985]'
                }`}
              >
                <Sliders className={`w-3.5 h-3.5 ${materials.customTrimColorsEnabled ? 'text-[#06B6D4]' : 'text-[#0369A1]'}`} />
                <span>Granular Controls</span>
                {materials.customTrimColorsEnabled && (
                  <span className="absolute -bottom-[2px] inset-x-2.5 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Trim Stock Length & Snow Guard Systems Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-4 bg-sky-50/50 rounded-2xl border border-sky-100">
          {/* Trim Stock Length Selector */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#075985]">Trim Stock Length</span>
              <span className="text-[11px] font-mono text-[#0284C7] bg-white px-2 py-0.5 rounded-full border border-sky-200">
                {materials.trimStockLength === '12ft' ? `12'-0" Pieces` : `10'-6" Pieces`}
              </span>
            </div>
            <div className="flex items-center gap-2">
              {[
                { id: '10ft6in', label: `10'-6" Standard`, desc: 'Common 10.5 ft' },
                { id: '12ft', label: `12'-0" Extended`, desc: 'Commercial 12 ft' },
              ].map((opt) => {
                const isSelected = (materials.trimStockLength || '10ft6in') === opt.id;
                return (
                  <button
                    key={opt.id}
                    onClick={() => updateMaterials({ trimStockLength: opt.id as '10ft6in' | '12ft' })}
                    className={`flex-1 py-1.5 px-3 rounded-full text-xs font-bold transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] border active:scale-95 text-center cursor-pointer ${
                      isSelected
                        ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] shadow-sm font-black ring-2 ring-[#06B6D4]/30'
                        : 'bg-white text-[#0369A1] border-sky-200 hover:bg-sky-50'
                    }`}
                  >
                    {opt.label}
                  </button>
                );
              })}
            </div>
            <p className="text-[10px] text-[#0369A1]/80">Standard pieces with 6" overlap allowance for Rat Guard, Drip Edge, Fascia, and Casings.</p>
          </div>

          {/* Heavy-Duty Snow Guards System */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#075985]">Snow Guard Rails</span>
              <span className="text-[11px] font-bold text-[#0284C7]">
                {(materials.hasSnowGuards ?? (state.snowLoad >= 30)) ? 'Active (3-4 Ft Up)' : 'Disabled'}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => updateMaterials({ hasSnowGuards: !(materials.hasSnowGuards ?? (state.snowLoad >= 30)) })}
                className={`flex-1 py-1.5 px-3 rounded-full text-xs font-bold transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] border active:scale-95 text-center cursor-pointer ${
                  (materials.hasSnowGuards ?? (state.snowLoad >= 30))
                    ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] shadow-sm font-black ring-2 ring-[#06B6D4]/30'
                    : 'bg-white text-[#0369A1] border-sky-200 hover:bg-sky-50'
                }`}
              >
                {(materials.hasSnowGuards ?? (state.snowLoad >= 30)) ? '✓ Installed on Roof' : '+ Add Snow Guards'}
              </button>
              {(materials.hasSnowGuards ?? (state.snowLoad >= 30)) && (
                <button
                  onClick={() =>
                    updateMaterials({
                      snowGuardSides: materials.snowGuardSides === 'both' ? 'left' : 'both',
                    })
                  }
                  className="py-1.5 px-3 rounded-full text-xs font-bold bg-white text-[#075985] border border-sky-200 hover:bg-sky-50 transition-all cursor-pointer"
                >
                  {materials.snowGuardSides === 'left' ? 'Single Side' : 'Both Eaves'}
                </button>
              )}
            </div>
            <p className="text-[10px] text-[#0369A1]/80">Mounted 3' to 4' up from roof eave to stop snow and ice sheets from sliding off.</p>
          </div>

          {/* Seamless Gutters & Downspouts - OFF by default per user requirement */}
          <div className="space-y-1.5 pt-2 border-t border-sky-100">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#075985]">Seamless Gutters & Downspouts</span>
              <span className="text-[11px] font-bold text-[#0284C7]">
                {materials.hasGutters ? 'Enabled (6" K-Style + 3x4 Downspouts)' : 'No Gutters (Default Clean Eave & Fascia)'}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => updateMaterials({ hasGutters: !materials.hasGutters })}
                className={`flex-1 py-1.5 px-3 rounded-full text-xs font-bold transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] border active:scale-95 text-center cursor-pointer ${
                  materials.hasGutters
                    ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] shadow-sm font-black ring-2 ring-[#06B6D4]/30'
                    : 'bg-white text-[#0369A1] border-sky-200 hover:bg-sky-50'
                }`}
              >
                {materials.hasGutters ? '✓ Gutters & Downspouts Active' : 'No Gutters Added (Default Clean Eave)'}
              </button>
            </div>
            <p className="text-[10px] text-[#0369A1]/80">
              By default, post-frame buildings feature clean metal drip edge overhanging the fascia wrap without gutters.
            </p>
          </div>
        </div>

        {!materials.customTrimColorsEnabled ? (
          /* Single Master Trim Color */
          <ColorSelector
            label="Master Trim Color (Corners, Eaves, Rake, Ridge Cap, and Casings)"
            currentColor={materials.trimColor}
            currentColorName={materials.trimColorName}
            onSelect={(hex, name) =>
              updateMaterials({
                trimColor: hex,
                trimColorName: name,
                cornerTrimColor: hex,
                cornerTrimColorName: name,
                eaveTrimColor: hex,
                eaveTrimColorName: name,
                rakeTrimColor: hex,
                rakeTrimColorName: name,
                ridgeCapColor: hex,
                ridgeCapColorName: name,
                doorTrimColor: hex,
                doorTrimColorName: name,
                wainscotCapColor: hex,
                wainscotCapColorName: name,
                ratGuardColor: hex,
                ratGuardColorName: name,
                dripEdgeColor: hex,
                dripEdgeColorName: name,
                fasciaTrimColor: hex,
                fasciaTrimColorName: name,
                snowGuardColor: hex,
                snowGuardColorName: name,
              })
            }
          />
        ) : (
          /* Granular Individual Trim Selectors */
          <div className="space-y-4 pt-1">
            <div className="bg-white p-4 sm:p-5 rounded-2xl border border-sky-100 shadow-sm space-y-4">
              <div className="border-b border-sky-100 pb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-[#0284C7]">Corners & Vertical Flashings</span>
              </div>
              <ColorSelector
                label="1. Outside Corner Trims (4 Building Corners + Lean-To • 10'6&quot; up to 30' cut-to-length)"
                currentColor={materials.cornerTrimColor || materials.trimColor}
                currentColorName={materials.cornerTrimColorName || materials.trimColorName}
                onSelect={(hex, name) => updateMaterials({ cornerTrimColor: hex, cornerTrimColorName: name })}
              />

              <div className="pt-3 border-t border-slate-100">
                <div className="border-b border-sky-100 pb-2 mb-3">
                  <span className="text-xs font-bold uppercase tracking-wider text-[#0284C7]">Eaves, Gables & Roofline</span>
                </div>
                <ColorSelector
                  label="2. Residential Gable Rake Trims (Front & Back Sloped Gable Edges • 10'6&quot; up to 30' cut-to-length)"
                  currentColor={materials.rakeTrimColor || materials.trimColor}
                  currentColorName={materials.rakeTrimColorName || materials.trimColorName}
                  onSelect={(hex, name) => updateMaterials({ rakeTrimColor: hex, rakeTrimColorName: name })}
                />
              </div>

              <div className="pt-3 border-t border-slate-100">
                <ColorSelector
                  label="3. Eave & Fascia Covers (Horizontal Sidewall Overhangs & Metal Fascia Wrap • 10'6&quot; or 12' pieces)"
                  currentColor={materials.fasciaTrimColor || materials.eaveTrimColor || materials.trimColor}
                  currentColorName={materials.fasciaTrimColorName || materials.eaveTrimColorName || materials.trimColorName}
                  onSelect={(hex, name) => updateMaterials({ fasciaTrimColor: hex, fasciaTrimColorName: name, eaveTrimColor: hex, eaveTrimColorName: name })}
                />
              </div>

              <div className="pt-3 border-t border-slate-100">
                <ColorSelector
                  label="4. Low Eave Drip Edge (Along Low Horizontal Edge before Panels • 10'6&quot; or 12' pieces)"
                  currentColor={materials.dripEdgeColor || materials.eaveTrimColor || materials.trimColor}
                  currentColorName={materials.dripEdgeColorName || materials.eaveTrimColorName || materials.trimColorName}
                  onSelect={(hex, name) => updateMaterials({ dripEdgeColor: hex, dripEdgeColorName: name })}
                />
              </div>

              <div className="pt-3 border-t border-slate-100">
                <ColorSelector
                  label="5. Ridge Cap Flashing (Roof Peak Apex with 20' Vented Closure Foam • 10'6&quot; up to 30')"
                  currentColor={materials.ridgeCapColor || materials.trimColor}
                  currentColorName={materials.ridgeCapColorName || materials.trimColorName}
                  onSelect={(hex, name) => updateMaterials({ ridgeCapColor: hex, ridgeCapColorName: name })}
                />
              </div>

              <div className="pt-3 border-t border-slate-100">
                <div className="border-b border-sky-100 pb-2 mb-3">
                  <span className="text-xs font-bold uppercase tracking-wider text-[#0284C7]">Openings & Door Framing</span>
                </div>
                <ColorSelector
                  label="6. Door & Window Exterior Casing / J-Channel (10'6&quot; or 12' pieces)"
                  currentColor={materials.doorTrimColor || materials.trimColor}
                  currentColorName={materials.doorTrimColorName || materials.trimColorName}
                  onSelect={(hex, name) => updateMaterials({ doorTrimColor: hex, doorTrimColorName: name })}
                />
              </div>

              <div className="pt-3 border-t border-slate-100">
                <div className="border-b border-sky-100 pb-2 mb-3">
                  <span className="text-xs font-bold uppercase tracking-wider text-[#0284C7]">Base Foundation & Wainscot</span>
                </div>
                <ColorSelector
                  label="7. Wainscot Double Angle Drip Ledge (Transition between Siding and Wainscot • 10'6&quot; or 12')"
                  currentColor={materials.wainscotCapColor || materials.trimColor}
                  currentColorName={materials.wainscotCapColorName || materials.trimColorName}
                  onSelect={(hex, name) => updateMaterials({ wainscotCapColor: hex, wainscotCapColorName: name })}
                />
              </div>

              <div className="pt-3 border-t border-slate-100">
                <ColorSelector
                  label="8. Base Rat Guard (Fastened to Splash Plank at Bottom Perimeter • 10'6&quot; or 12' pieces)"
                  currentColor={materials.ratGuardColor || materials.trimColor}
                  currentColorName={materials.ratGuardColorName || materials.trimColorName}
                  onSelect={(hex, name) => updateMaterials({ ratGuardColor: hex, ratGuardColorName: name })}
                />
              </div>

              <div className="pt-3 border-t border-slate-100">
                <ColorSelector
                  label="9. Soffit Panels (Pre-Cut 11½&quot; or 23½&quot; Panels • Vented Eaves / Solid Gables)"
                  currentColor={materials.soffitColor || '#f8fafc'}
                  currentColorName={materials.soffitColorName || 'Bright White'}
                  onSelect={(hex, name) => updateMaterials({ soffitColor: hex, soffitColorName: name })}
                />
              </div>
            </div>
          </div>
        )}

        {/* Pole Barn Trims Location & Specification Reference Guide */}
        <div className="p-4 sm:p-5 bg-white border border-sky-100 rounded-2xl shadow-sm space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-md bg-cyan-100 text-[#0284C7] text-xs flex items-center justify-center font-bold">📋</span>
              <h4 className="text-sm font-bold text-[#075985]">Pole Barn Trim Breakdown & Location Guide</h4>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-mono font-bold text-[#0284C7] bg-sky-50 px-2.5 py-1 rounded-full border border-sky-200">
                6 Component Zones
              </span>
              {onOpenUnitPricing && (
                <button
                  type="button"
                  onClick={onOpenUnitPricing}
                  className="text-xs flex items-center gap-1.5 px-3 py-1 rounded-full text-[#075985] hover:text-[#0c4a6e] bg-cyan-50 hover:bg-cyan-100 border border-cyan-200 cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-95 font-bold shadow-2xs focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4]"
                  title="Customize the price of each trim piece"
                >
                  <Sliders className="w-3 h-3 text-[#06B6D4]" />
                  <span>Edit Trim Prices</span>
                </button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 pt-1">
            {/* 1. Lower Wall & Base Foundations */}
            <div className="p-3.5 bg-sky-50/60 rounded-xl border border-sky-100 space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-[#075985]">
                <span className="w-2 h-2 rounded-full bg-[#06B6D4]" />
                <span>Lower Wall & Base</span>
              </div>
              <ul className="text-[11px] text-[#0369A1] space-y-1.5 leading-relaxed">
                <li><strong className="text-[#075985]">Rat Guard:</strong> Fastened to treated splash plank (skirt board) along bottom perimeter before metal is hung. Sloped ledge holds wall metal/wainscot. (10'6" or 12')</li>
                <li><strong className="text-[#075985]">Wainscot Panels:</strong> 3-ft wide panels (3 or 4 ft tall) at exterior accent height.</li>
                <li><strong className="text-[#075985]">Double Angle:</strong> Horizontal drip ledge preventing water from seeping into the joint between lower wainscot and upper wall siding. (10'6" or 12')</li>
              </ul>
            </div>

            {/* 2. Openings (Doors & Windows) */}
            <div className="p-3.5 bg-sky-50/60 rounded-xl border border-sky-100 space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-[#075985]">
                <span className="w-2 h-2 rounded-full bg-[#06B6D4]" />
                <span>Openings & Hardware</span>
              </div>
              <ul className="text-[11px] text-[#0369A1] space-y-1.5 leading-relaxed">
                <li><strong className="text-[#075985]">Overhead Door Top:</strong> Wraps top header wood framing to shield raw wood from weather. (10'6" or 12')</li>
                <li><strong className="text-[#075985]">Overhead Door Side:</strong> Wraps vertical side studs/posts. (10'6" or 12')</li>
                <li><strong className="text-[#075985]">Sliding Door Sides & Track Cover:</strong> Side jamb covers plus horizontal track hood shielding trolley roller hardware from snow/rain. (10'6" or 12')</li>
                <li><strong className="text-[#075985]">Drip Cap & J-Channel:</strong> Drip cap deflects water above windows/doors; J-channel captures cut metal edges. (10'6" or 12')</li>
                <li><strong className="text-[#075985]">F&J Transition:</strong> Bridges wall metal to soffit under overhangs; J-receiver captures metal, F-leg secures soffit against hornets/birds. (10'6" or 12')</li>
              </ul>
            </div>

            {/* 3. Corners & Vertical Transitions */}
            <div className="p-3.5 bg-sky-50/60 rounded-xl border border-sky-100 space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-[#075985]">
                <span className="w-2 h-2 rounded-full bg-[#06B6D4]" />
                <span>Corners & Vertical</span>
              </div>
              <ul className="text-[11px] text-[#0369A1] space-y-1.5 leading-relaxed">
                <li><strong className="text-[#075985]">Outside Corner:</strong> Placed vertically on outside 90° corners covering panel seams. (10'6" min up to 30' cut-to-length)</li>
                <li><strong className="text-[#075985]">Inside Corner:</strong> Inside interior corners or where walls form an internal angle / porch return. (10'6" or 12')</li>
              </ul>
            </div>

            {/* 4. Roof-to-Wall Interfaces */}
            <div className="p-3.5 bg-sky-50/60 rounded-xl border border-sky-100 space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-[#075985]">
                <span className="w-2 h-2 rounded-full bg-[#06B6D4]" />
                <span>Roof-to-Wall Interfaces</span>
              </div>
              <ul className="text-[11px] text-[#0369A1] space-y-1.5 leading-relaxed">
                <li><strong className="text-[#075985]">Sidewall:</strong> Along sloped roofline where roof runs parallel to and meets an adjacent vertical wall (porch/lean-to). (10'6" or 12')</li>
                <li><strong className="text-[#075985]">Endwall:</strong> Across top slope where high end of lean-to roof meets wall. (10'6" or 12')</li>
                <li><strong className="text-[#075985]">Valley:</strong> Laid inside internal diagonal channels where sloping roofs intersect. (10'6" or 12')</li>
              </ul>
            </div>

            {/* 5. Eaves, Overhangs & Gables */}
            <div className="p-3.5 bg-sky-50/60 rounded-xl border border-sky-100 space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-[#075985]">
                <span className="w-2 h-2 rounded-full bg-[#06B6D4]" />
                <span>Eaves & Overhangs</span>
              </div>
              <ul className="text-[11px] text-[#0369A1] space-y-1.5 leading-relaxed">
                <li><strong className="text-[#075985]">Drip Edge:</strong> Fastened along low roof edge before panels, directing rain runoff clear of fascia wrap. (10'6" or 12')</li>
                <li><strong className="text-[#075985]">Fascia:</strong> Installed before drip edge & rakes; covers wood fascia and holds outer soffit edge. (10'6" or 12')</li>
                <li><strong className="text-[#075985]">Soffit Panels:</strong> 3-ft wide panels cut 11½" (1-ft overhang) or 23½" (2-ft overhang); vented for eaves, solid for gables.</li>
                <li><strong className="text-[#075985]">Residential Rake:</strong> Sloped gable edges from eave corner up to roof peak. (10'6" up to 30')</li>
              </ul>
            </div>

            {/* 6. Peak & Roof Penetrations */}
            <div className="p-3.5 bg-sky-50/60 rounded-xl border border-sky-100 space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-[#075985]">
                <span className="w-2 h-2 rounded-full bg-[#06B6D4]" />
                <span>Peak & Protection</span>
              </div>
              <ul className="text-[11px] text-[#0369A1] space-y-1.5 leading-relaxed">
                <li><strong className="text-[#075985]">Ridge Cap:</strong> Placed along absolute peak where opposing slopes meet. (10'6" up to 30')</li>
                <li><strong className="text-[#075985]">Vented Closure Foam:</strong> Sandwiched directly beneath both sides of ridge cap on top of ribs, letting attic heat exhaust out. (20' rolls)</li>
                <li><strong className="text-[#075985]">Snow Guards:</strong> Continuous rail mounted on roof ribs 3' to 4' from eave, preventing snow & ice slides.</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* 4. Wainscot (2-Tone Lower Wall) */}
      <div id="section-wainscot" className="bg-white border border-slate-200/90 p-5 sm:p-6 rounded-xl shadow-[0_4px_6px_-1px_rgba(0,0,0,0.1),0_2px_4px_-2px_rgba(0,0,0,0.06)] space-y-5">
        {(() => {
          const hasAnyWainscot = Object.values(state.walls).some((w) => w.hasWainscot);
          const wainscotCount = Object.values(state.walls).filter((w) => w.hasWainscot).length;

          const toggleAllWainscot = () => {
            const nextVal = !hasAnyWainscot;
            onUpdateState((prev) => ({
              ...prev,
              walls: {
                front: { ...prev.walls.front, hasWainscot: nextVal },
                back: { ...prev.walls.back, hasWainscot: nextVal },
                left: { ...prev.walls.left, hasWainscot: nextVal },
                right: { ...prev.walls.right, hasWainscot: nextVal },
              },
            }));
          };

          return (
            <>
              <div className="flex flex-wrap items-center justify-between border-b border-slate-100 pb-3 gap-3">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-md bg-sky-100 text-[#0284C7] text-xs flex items-center justify-center font-bold">4</span>
                  <label className="text-sm font-bold text-[#0F172A]">
                    Designer 2-Tone Wainscot
                  </label>
                  <span
                    className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${
                      hasAnyWainscot
                        ? 'bg-sky-100 text-[#0284C7] border-sky-300'
                        : 'bg-slate-100 text-slate-600 border-slate-200'
                    }`}
                  >
                    {hasAnyWainscot ? `Active (${wainscotCount}/4 walls)` : 'Disabled (Clean Full Siding)'}
                  </span>
                  {hasAnyWainscot && (
                    <ColorOptionPill
                      name="Wainscot"
                      color={materials.wainscotColor}
                      colorName={materials.wainscotColorName}
                      size="sm"
                    />
                  )}
                </div>

                <div className="flex items-center gap-2.5 flex-wrap">
                  <button
                    onClick={toggleAllWainscot}
                    className={`px-4 py-1.5 rounded-full text-xs font-bold cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-95 border ${
                      hasAnyWainscot
                        ? 'bg-rose-50 text-rose-800 border-rose-300 hover:bg-rose-100'
                        : 'bg-[#06B6D4] text-white border-[#06B6D4] hover:bg-[#0891b2] shadow-xs'
                    }`}
                  >
                    {hasAnyWainscot ? 'Remove Wainscot' : '+ Enable Wainscot on Building'}
                  </button>

                  <div className="flex items-center gap-1.5 pl-2 border-l border-sky-100">
                    <span className="text-xs text-[#0369A1] font-medium">Height:</span>
                    {[3, 4].map((h) => {
                      const isSelected = materials.wainscotHeightFt === h;
                      return (
                        <button
                          key={h}
                          onClick={() => updateMaterials({ wainscotHeightFt: h })}
                          className={`relative text-xs px-3 py-1 rounded-full font-mono font-bold cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] border active:scale-95 hover:scale-[1.03] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
                            isSelected
                              ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] shadow-sm font-black ring-2 ring-[#06B6D4]/30'
                              : 'bg-white text-[#0369A1] border-sky-200/80 hover:text-[#075985] hover:bg-sky-50 font-semibold'
                          }`}
                        >
                          {h} FT
                          {isSelected && (
                            <span className="absolute -bottom-[2px] inset-x-1.5 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {!hasAnyWainscot && (
                <div className="p-3 bg-slate-50/70 rounded-lg border border-slate-200 text-xs text-slate-600 flex items-center justify-between gap-3 shadow-2xs">
                  <span>Wainscot is currently inactive. The building has clean full-height siding without lower transition trim.</span>
                  <button
                    onClick={toggleAllWainscot}
                    className="text-[#0284C7] hover:text-[#0369a1] font-semibold cursor-pointer underline text-[11px] whitespace-nowrap"
                  >
                    Add Wainscot Now
                  </button>
                </div>
              )}

              <ColorSelector
                label="Wainscot Base Metal Color (Applied when wainscot is enabled)"
                currentColor={materials.wainscotColor}
                currentColorName={materials.wainscotColorName}
                onSelect={(hex, name) => updateMaterials({ wainscotColor: hex, wainscotColorName: name })}
              />
            </>
          );
        })()}
      </div>
    </div>
  );
};
