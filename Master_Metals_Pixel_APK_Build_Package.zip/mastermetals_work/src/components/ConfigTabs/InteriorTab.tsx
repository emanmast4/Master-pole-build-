import React from 'react';
import { CustomBuildingState, InteriorConfig } from '../../types';
import { Flame, Zap, Layers, Home, ShieldCheck } from 'lucide-react';

interface InteriorTabProps {
  state: CustomBuildingState;
  onUpdateState: (updater: (prev: CustomBuildingState) => CustomBuildingState) => void;
}

export const InteriorTab: React.FC<InteriorTabProps> = ({ state, onUpdateState }) => {
  const { interior } = state;

  const updateInterior = (patch: Partial<InteriorConfig>) => {
    onUpdateState((prev) => ({
      ...prev,
      interior: {
        ...prev.interior,
        ...patch,
      },
    }));
  };

  return (
    <div className="space-y-6">
      {/* 1. Thermal Insulation Package */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-sky-100 shadow-sm space-y-4 text-[#075985]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-sky-100 pb-3 gap-2">
          <label className="text-sm font-bold text-[#075985] flex items-center gap-2.5">
            <span className="w-6 h-6 rounded-full bg-cyan-50 text-[#06B6D4] text-xs flex items-center justify-center font-bold">1</span>
            Thermal Insulation & Moisture Barrier
          </label>
          <span className="text-xs text-[#0369A1]/70 font-mono">Controls condensation and HVAC costs</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {[
            {
              id: 'none' as const,
              name: 'None (Unconditioned)',
              desc: 'Best for open equipment sheds & cold agricultural storage',
              badge: 'Zero Add-on',
            },
            {
              id: 'vapor_bubble' as const,
              name: 'Radiant Vapor Barrier',
              desc: 'Prevents roof condensation drips and blocks 95% of radiant heat',
              badge: 'Condensation Stop',
            },
            {
              id: 'r19_batt' as const,
              name: 'R-19 Fiberglass Batt',
              desc: 'Kraft-faced batt insulation for walls and ceiling roof cavities',
              badge: 'Heating Envelope',
            },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => updateInterior({ insulation: item.id })}
              className={`relative p-4 rounded-2xl border text-left cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-95 hover:scale-[1.02] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
                interior.insulation === item.id
                  ? 'bg-cyan-50 border-2 border-[#06B6D4] text-[#075985] font-black shadow-sm ring-2 ring-[#06B6D4]/30'
                  : 'bg-white border-sky-200/80 text-[#0369A1] hover:border-sky-300 hover:text-[#075985] hover:bg-sky-50/70 shadow-2xs font-semibold'
              }`}
            >
              <div className="flex justify-between items-start">
                <span className="text-xs font-bold text-[#075985]">{item.name}</span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                  interior.insulation === item.id ? 'bg-[#06B6D4] text-white border-[#06B6D4]' : 'bg-sky-100 text-[#075985] border-sky-200'
                }`}>{item.badge}</span>
              </div>
              <span className="text-[11px] text-[#0369A1]/80 block mt-2 leading-relaxed">{item.desc}</span>
              {interior.insulation === item.id && (
                <span className="absolute -bottom-[2px] inset-x-3 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* 2. Interior Wall & Ceiling Liner Panels */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-sky-100 shadow-sm space-y-4 text-[#075985]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-sky-100 pb-3 gap-2">
          <label className="text-sm font-bold text-[#075985] flex items-center gap-2.5">
            <span className="w-6 h-6 rounded-full bg-cyan-50 text-[#06B6D4] text-xs flex items-center justify-center font-bold">2</span>
            Interior Liner Panels & Finish
          </label>
          <span className="text-xs text-[#0369A1]/70 font-mono">Encloses framing posts and purlins</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {[
            {
              id: 'none' as const,
              name: 'Exposed Framing',
              desc: 'Open posts & roof truss chords',
            },
            {
              id: 'steel_liner_all' as const,
              name: 'Steel Liner Package (All)',
              desc: 'Bright white washable 29-ga steel covering ceiling and all 4 walls',
            },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => updateInterior({ linerPanel: item.id })}
              className={`relative p-4 rounded-2xl border text-left cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-95 hover:scale-[1.02] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
                interior.linerPanel === item.id
                  ? 'bg-cyan-50 border-2 border-[#06B6D4] text-[#075985] font-black shadow-sm ring-2 ring-[#06B6D4]/30'
                  : 'bg-white border-sky-200/80 text-[#0369A1] hover:border-sky-300 hover:text-[#075985] hover:bg-sky-50/70 shadow-2xs font-semibold'
              }`}
            >
              <span className="text-xs font-bold block text-[#075985]">{item.name}</span>
              <span className="text-[11px] text-[#0369A1]/80 block mt-1.5 leading-relaxed">{item.desc}</span>
              {interior.linerPanel === item.id && (
                <span className="absolute -bottom-[2px] inset-x-3 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* 3. Foundation & Floor Base */}
      <div className="bg-white border border-sky-100 p-5 sm:p-6 rounded-2xl shadow-sm space-y-4 text-[#075985]">
        <label className="text-sm font-bold text-[#075985] flex items-center gap-2">
          <span className="w-6 h-6 rounded-full bg-cyan-50 text-[#06B6D4] text-xs flex items-center justify-center font-bold">3</span>
          Foundation & Floor Base
        </label>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {[
            {
              id: 'slab_4in' as const,
              name: 'Concrete Slab',
              spec: '4" 4000 PSI + Fiber mesh + Vapor barrier',
              badge: 'Most Popular',
            },
            {
              id: 'dirt' as const,
              name: 'Dirt Floor',
              spec: 'Unimproved dirt floor base & site grading',
              badge: 'Basic / Standard',
            },
            {
              id: 'crushed_gravel' as const,
              name: 'Crushed Gravel',
              spec: '4" compacted stone base',
              badge: 'Storage & Ag',
            },
          ].map((item) => {
            const isSelected = state.materials.foundation === item.id || (item.id === 'dirt' && state.materials.foundation === 'dirt_gravel');
            return (
              <button
                key={item.id}
                onClick={() =>
                  onUpdateState((prev) => ({
                    ...prev,
                    materials: {
                      ...prev.materials,
                      foundation: item.id,
                    },
                  }))
                }
                className={`relative p-3.5 rounded-2xl border text-left cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-95 hover:scale-[1.02] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
                  isSelected
                    ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] shadow-sm font-black ring-2 ring-[#06B6D4]/30'
                    : 'bg-white border-sky-200/80 text-[#0369A1] hover:text-[#075985] hover:bg-sky-50/70 shadow-2xs font-semibold'
                }`}
              >
                <span className={`text-xs block ${isSelected ? 'font-black text-[#075985]' : 'font-bold text-[#075985]'}`}>
                  {item.name}
                </span>
                <span className={`text-[10px] font-bold block mt-0.5 ${isSelected ? 'text-[#06B6D4]' : 'text-[#0369A1]'}`}>
                  {item.badge}
                </span>
                <span className={`text-[10px] block mt-1 ${isSelected ? 'text-[#075985] font-medium' : 'text-[#0369A1]/80'}`}>
                  {item.spec}
                </span>
                {isSelected && (
                  <span className="absolute -bottom-[2px] inset-x-3 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
