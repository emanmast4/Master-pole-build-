import React from 'react';
import { 
  BuildingStyle, 
  CustomBuildingState, 
  BuildingDimensions, 
  PostSpacing, 
  SnowLoadRating, 
  TrussSpacing 
} from '../../types';
import { Compass } from 'lucide-react';

interface StyleAndSizeTabProps {
  state: CustomBuildingState;
  onUpdateState: React.Dispatch<React.SetStateAction<CustomBuildingState>>;
  mode?: 'all' | 'style' | 'framing';
}

const BUILDING_STYLES: { id: BuildingStyle; name: string; description: string; badge: string }[] = [
  {
    id: 'gable',
    name: 'Classic Gable',
    description: 'A-frame pitched roof with balanced dual slopes, standard peak ridge, and maximum structural efficiency.',
    badge: 'Most Popular',
  },
  {
    id: 'monitor',
    name: 'Raised Center Monitor',
    description: 'Stepped raised center roof with clerestory sidewalls. Perfect for horse barns, RV bays, and center lofts.',
    badge: 'Barn Classic',
  },
  {
    id: 'gambrel',
    name: 'Dutch Gambrel',
    description: 'Dual-pitched barn roof providing enormous overhead attic storage and iconic country barn appeal.',
    badge: 'Max Loft Space',
  },
  {
    id: 'single_slope',
    name: 'Mono-Slope / Shed',
    description: 'Modern single-direction sloped roof line, ideal for solar panels, drainage diversion, and lean-to expansions.',
    badge: 'Modern Lean',
  },
  {
    id: 'commercial',
    name: 'Commercial Parapet',
    description: 'Low-slope roof with raised perimeter perimeter walls hiding rooftop equipment for retail and warehouse use.',
    badge: 'Industrial',
  },
];

const QUICK_PITCHES = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];

export const StyleAndSizeTab: React.FC<StyleAndSizeTabProps> = ({ state, onUpdateState, mode = 'all' }) => {
  const { dimensions, style, snowLoad } = state;
  const { width, length, eaveHeight, roofPitch, trussSpacing, postSpacing, overhangInches } = dimensions;
  const eaveOverhangInches = dimensions.eaveOverhangInches ?? overhangInches;
  const gableOverhangInches = dimensions.gableOverhangInches ?? overhangInches;

  const updateDimensions = (patch: Partial<BuildingDimensions>) => {
    onUpdateState((prev) => ({
      ...prev,
      dimensions: {
        ...prev.dimensions,
        ...patch,
      },
    }));
  };

  const showStyle = mode === 'all' || mode === 'style';
  const showFraming = mode === 'all' || mode === 'framing';

  return (
    <div className="space-y-6">
      {/* 1. Building Style Architecture */}
      {showStyle && (
        <div className="bg-white border border-sky-100 p-5 sm:p-6 rounded-2xl shadow-sm text-[#075985]">
          <div className="flex items-center justify-between mb-4">
            <label className="text-sm font-bold text-[#075985] flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-cyan-50 text-[#06B6D4] text-xs flex items-center justify-center font-bold">
                {mode === 'style' ? '★' : '1'}
              </span>
              <span>Building Style Architecture</span>
            </label>
            <span className="text-xs text-[#0369A1]/80 font-medium">Structural profile & truss type</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {BUILDING_STYLES.map((item) => {
              const isSelected = style === item.id;
              return (
                <button
                  key={item.id}
                  id={`style-btn-${item.id}`}
                  onClick={() => onUpdateState((prev) => ({ ...prev, style: item.id }))}
                  className={`text-left p-4 rounded-2xl border transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] cursor-pointer relative overflow-hidden active:scale-95 hover:scale-[1.02] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
                    isSelected
                      ? 'bg-cyan-50 border-2 border-[#06B6D4] shadow-sm text-[#075985] ring-2 ring-[#06B6D4]/30 font-black'
                      : 'bg-white border-sky-200/80 text-[#0369A1] hover:text-[#075985] hover:bg-sky-50/70 shadow-2xs font-semibold'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <h4 className="font-bold text-sm tracking-wide text-[#075985]">{item.name}</h4>
                    <span
                      className={`text-[10px] px-2.5 py-0.5 rounded-full font-semibold ${
                        isSelected
                          ? 'bg-[#06B6D4] text-white font-bold'
                          : 'bg-sky-100 text-[#075985] border border-sky-200'
                      }`}
                    >
                      {item.badge}
                    </span>
                  </div>
                  <p className="text-xs text-[#0369A1]/80 mt-2 leading-relaxed">
                    {item.description}
                  </p>
                  {isSelected && (
                    <span className="absolute -bottom-[2px] inset-x-3 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* 2. Roof Pitch & Engineering Configuration */}
      {showFraming && (
        <div className="bg-white border border-sky-100 p-5 sm:p-6 rounded-2xl shadow-sm text-[#075985] space-y-5">
          <div className="flex items-center justify-between border-b border-sky-100 pb-3">
            <label className="text-sm font-bold text-[#075985] flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-cyan-50 text-[#06B6D4] text-xs flex items-center justify-center font-bold">
                {mode === 'framing' ? '★' : '2'}
              </span>
              <span>Roof Pitch & Truss Framing Specs</span>
            </label>
            <span className="text-xs text-[#075985] flex items-center gap-1.5 font-mono font-bold bg-cyan-50 border border-cyan-200 px-3 py-1 rounded-full">
              <Compass className="w-3.5 h-3.5 text-[#06B6D4]" />
              {roofPitch}:12 Pitch
            </span>
          </div>

        {/* Pitch Slider & Quick buttons */}
        <div className="space-y-2.5">
          <div className="flex justify-between text-xs">
            <span className="text-[#0369A1] font-medium">Slope Pitch (Rise per 12" Run)</span>
            <span className="font-mono text-[#075985] text-xs font-bold">
              Ridge Peak: +{((width / 2) * (roofPitch / 12)).toFixed(1)}' above eave (+{(eaveHeight + (width / 2) * (roofPitch / 12)).toFixed(1)}' total)
            </span>
          </div>
          <input
            id="slider-roof-pitch"
            type="range"
            min="1"
            max="12"
            step="1"
            value={roofPitch}
            onChange={(e) => updateDimensions({ roofPitch: Number(e.target.value) })}
            className="w-full accent-[#06B6D4] cursor-pointer h-2.5 bg-sky-200 rounded-full transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4]"
          />
          <div className="grid grid-cols-4 sm:grid-cols-6 gap-1.5">
            {QUICK_PITCHES.map((p) => {
              const isSelected = roofPitch === p;
              return (
                <button
                  key={p}
                  onClick={() => updateDimensions({ roofPitch: p })}
                  className={`relative text-xs py-2 rounded-full font-mono transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] cursor-pointer text-center active:scale-95 hover:scale-[1.03] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
                    isSelected
                      ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] shadow-sm font-black ring-2 ring-[#06B6D4]/30'
                      : 'bg-white text-[#0369A1] hover:text-[#075985] hover:bg-sky-50 border border-sky-200/80 font-semibold'
                  }`}
                >
                  {p}:12
                  {isSelected && (
                    <span className="absolute -bottom-[2px] inset-x-2 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Truss Spacing & Overhang */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
          <div>
            <label className="text-xs font-semibold text-[#0369A1] block mb-2">
              Truss Spacing (On-Center)
            </label>
            <div className="grid grid-cols-4 gap-1.5">
              {([4, 8, 10, 12] as TrussSpacing[]).map((spacing) => {
                const isSelected = trussSpacing === spacing;
                return (
                  <button
                    key={spacing}
                    onClick={() => updateDimensions({ trussSpacing: spacing })}
                    className={`relative text-xs py-2 rounded-full font-mono transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] cursor-pointer text-center active:scale-95 hover:scale-[1.03] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
                      isSelected
                        ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] shadow-sm font-black ring-2 ring-[#06B6D4]/30'
                        : 'bg-white text-[#0369A1] hover:text-[#075985] border border-sky-200/80 hover:bg-sky-50 font-semibold'
                    }`}
                  >
                    {spacing}' O.C.
                    {isSelected && (
                      <span className="absolute -bottom-[2px] inset-x-2 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
                    )}
                  </button>
                );
              })}
            </div>
            <span className="text-[11px] text-[#0369A1]/70 block mt-1.5 font-medium">
              {Math.ceil(length / trussSpacing) + 1} trusses required
            </span>
          </div>

          <div>
            <label className="text-xs font-semibold text-[#0369A1] block mb-2">
              Post Spacing (On-Center)
            </label>
            <div className="grid grid-cols-4 gap-1.5">
              {([6, 8, 10, 12] as PostSpacing[]).map((spacing) => {
                const isSelected = postSpacing === spacing;
                return (
                  <button
                    key={spacing}
                    onClick={() => updateDimensions({ postSpacing: spacing })}
                    className={`relative text-xs py-2 rounded-full font-mono transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] cursor-pointer text-center active:scale-95 hover:scale-[1.03] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
                      isSelected
                        ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] shadow-sm font-black ring-2 ring-[#06B6D4]/30'
                        : 'bg-white text-[#0369A1] hover:text-[#075985] border border-sky-200/80 hover:bg-sky-50 font-semibold'
                    }`}
                  >
                    {spacing}' O.C.
                    {isSelected && (
                      <span className="absolute -bottom-[2px] inset-x-2 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
                    )}
                  </button>
                );
              })}
            </div>
            <span className="text-[11px] text-[#075985] block mt-1.5 font-mono font-medium">
              {postSpacing === 8 ? "8' Standard • (2) 2x12 Headers" : `${postSpacing}' O.C. post grid`}
            </span>
          </div>

          <div className="sm:col-span-1">
            <label className="text-xs font-semibold text-[#0369A1] block mb-2">Eave Overhang</label>
            <div className="grid grid-cols-4 gap-1.5">
              {[0, 12, 18, 24].map((oh) => (
                <button key={oh} onClick={() => updateDimensions({ eaveOverhangInches: oh, gableOverhangInches, overhangInches: oh })}
                  className={`text-xs py-2 rounded-full font-mono border ${eaveOverhangInches === oh ? 'bg-cyan-50 text-[#075985] border-[#06B6D4] font-black' : 'bg-white text-[#0369A1] border-sky-200'}`}>
                  {oh === 0 ? 'Flush' : `${oh}\"`}
                </button>
              ))}
            </div>
            <span className="text-[11px] text-[#0369A1]/70 block mt-1.5">Soffit/fascia only where overhang exists</span>
          </div>
          <div>
            <label className="text-xs font-semibold text-[#0369A1] block mb-2">Gable Overhang</label>
            <div className="grid grid-cols-4 gap-1.5">
              {[0, 12, 18, 24].map((oh) => (
                <button key={oh} onClick={() => updateDimensions({ gableOverhangInches: oh, eaveOverhangInches, overhangInches: oh })}
                  className={`text-xs py-2 rounded-full font-mono border ${gableOverhangInches === oh ? 'bg-cyan-50 text-[#075985] border-[#06B6D4] font-black' : 'bg-white text-[#0369A1] border-sky-200'}`}>
                  {oh === 0 ? 'Flush' : `${oh}\"`}
                </button>
              ))}
            </div>
            <span className="text-[11px] text-[#0369A1]/70 block mt-1.5">Independent from eave overhang</span>
          </div>
        </div>

        {/* Snow Load Rating */}
        <div className="pt-3 border-t border-sky-100">
          <label className="text-xs font-semibold text-[#0369A1] flex items-center justify-between mb-2">
            <span>Snow & Live Load Engineering Code</span>
            <span className="text-[#06B6D4] font-mono text-xs font-bold">{snowLoad} PSF</span>
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {([20, 30, 40, 60] as SnowLoadRating[]).map((rating) => {
              const isSelected = snowLoad === rating;
              return (
                <button
                  key={rating}
                  onClick={() => onUpdateState((prev) => ({ ...prev, snowLoad: rating }))}
                  className={`relative p-2.5 rounded-full text-center cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-95 hover:scale-[1.03] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
                    isSelected
                      ? 'bg-cyan-50 border-2 border-[#06B6D4] text-[#075985] font-black shadow-sm ring-2 ring-[#06B6D4]/30'
                      : 'bg-white border border-sky-200/80 text-[#0369A1] hover:text-[#075985] hover:bg-sky-50 font-semibold'
                  }`}
                >
                  <span className="text-xs font-bold block">{rating} PSF</span>
                  <span className="text-[10px] text-[#0369A1]/70 block">
                    {rating === 20 ? 'Southern / Low' : rating === 30 ? 'Standard IBC' : rating === 40 ? 'Northern' : 'Alpine Snow'}
                  </span>
                  {isSelected && (
                    <span className="absolute -bottom-[2px] inset-x-3 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>
      )}
    </div>
  );
};
