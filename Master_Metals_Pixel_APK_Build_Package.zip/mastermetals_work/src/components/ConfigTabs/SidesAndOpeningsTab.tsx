import React, { useState } from 'react';
import { CustomBuildingState, OpeningType, WallOpening, WallSide } from '../../types';
import { DoorClosed, DoorOpen, Plus, Trash2, Home, ArrowRight, Check } from 'lucide-react';

interface SidesAndOpeningsTabProps {
  state: CustomBuildingState;
  onUpdateState: (updater: (prev: CustomBuildingState) => CustomBuildingState) => void;
}

export const SidesAndOpeningsTab: React.FC<SidesAndOpeningsTabProps> = ({ state, onUpdateState }) => {
  const [activeSide, setActiveSide] = useState<WallSide>('front');
  const [showAddOpening, setShowAddOpening] = useState(false);

  // New opening draft state
  const [newType, setNewType] = useState<OpeningType>('overhead_door');
  const [newSize, setNewSize] = useState<string>('10x10');
  const [newInsulated, setNewInsulated] = useState<boolean>(true);
  const [newHasWindows, setNewHasWindows] = useState<boolean>(true);
  const [newOffset, setNewOffset] = useState<number>(4);

  const { walls, openings, dimensions, leanTo } = state;
  const currentWall = walls[activeSide];
  const wallLengthFt = activeSide === 'front' || activeSide === 'back' ? dimensions.width : dimensions.length;

  const currentSideOpenings = openings.filter((op) => op.side === activeSide);

  const toggleWallEnclosed = () => {
    onUpdateState((prev) => ({
      ...prev,
      walls: {
        ...prev.walls,
        [activeSide]: {
          ...prev.walls[activeSide],
          enclosed: !prev.walls[activeSide].enclosed,
        },
      },
    }));
  };

  const toggleWallWainscot = () => {
    onUpdateState((prev) => ({
      ...prev,
      walls: {
        ...prev.walls,
        [activeSide]: {
          ...prev.walls[activeSide],
          hasWainscot: !prev.walls[activeSide].hasWainscot,
        },
      },
    }));
  };

  const handleAddOpening = () => {
    const [wStr, hStr] = newSize.split('x');
    const w = Number(wStr);
    const h = Number(hStr);

    let label = '';
    if (newType === 'overhead_door') label = `${newSize} Overhead Garage Door`;
    if (newType === 'walk_door') label = `${newSize} Steel Walk Door`;
    if (newType === 'window') label = `${newSize} Insulated Window`;
    if (newType === 'sliding_barn_door') label = `${newSize} Split Barn Slider`;

    const newOpening: WallOpening = {
      id: `op-${Date.now()}`,
      side: activeSide,
      type: newType,
      widthFt: w,
      heightFt: h,
      positionOffsetFt: Math.max(0, Math.min(newOffset, wallLengthFt - w)),
      bottomOffsetFt: newType === 'window' ? 3 : 0,
      label,
      insulated: newInsulated,
      hasWindows: newType === 'overhead_door' ? newHasWindows : false,
    };

    onUpdateState((prev) => ({
      ...prev,
      openings: [...prev.openings, newOpening],
    }));

    setShowAddOpening(false);
  };

  const handleRemoveOpening = (id: string) => {
    onUpdateState((prev) => ({
      ...prev,
      openings: prev.openings.filter((op) => op.id !== id),
    }));
  };

  const handleUpdatePosition = (id: string, offset: number) => {
    onUpdateState((prev) => ({
      ...prev,
      openings: prev.openings.map((op) => (op.id === id ? { ...op, positionOffsetFt: Math.max(0, offset) } : op)),
    }));
  };

  const handleUpdateBottomOffset = (id: string, bottomOffsetFt: number) => {
    onUpdateState((prev) => ({
      ...prev,
      openings: prev.openings.map((op) => op.id === id ? { ...op, bottomOffsetFt: Math.max(0, bottomOffsetFt) } : op),
    }));
  };

  const hasAnyWainscot = Object.values(walls).some((w) => w.hasWainscot);
  const toggleAllWainscot = (targetVal: boolean) => {
    onUpdateState((prev) => ({
      ...prev,
      walls: {
        front: { ...prev.walls.front, hasWainscot: targetVal },
        back: { ...prev.walls.back, hasWainscot: targetVal },
        left: { ...prev.walls.left, hasWainscot: targetVal },
        right: { ...prev.walls.right, hasWainscot: targetVal },
      },
    }));
  };

  const handleClearWallOpenings = () => {
    onUpdateState((prev) => ({
      ...prev,
      openings: prev.openings.filter((op) => op.side !== activeSide),
    }));
  };

  const handleClearAllOpenings = () => {
    onUpdateState((prev) => ({
      ...prev,
      openings: [],
    }));
  };

  const SIZES_BY_TYPE: Record<OpeningType, string[]> = {
    overhead_door: ['8x8', '9x8', '10x10', '10x12', '12x12', '12x14', '14x14', '16x14'],
    walk_door: ['3x7', '4x7', '6x7'],
    window: ['3x3', '4x3', '4x5', '5x4'],
    sliding_barn_door: ['10x10', '12x12', '14x14'],
  };

  return (
    <div className="space-y-6">
      {/* 1. Wall Elevation & Options (Combined in One Card) */}
      <div className="bg-white border border-slate-200/90 p-5 sm:p-6 rounded-xl shadow-[0_4px_6px_-1px_rgba(0,0,0,0.1),0_2px_4px_-2px_rgba(0,0,0,0.06)] space-y-5">
        <div className="flex items-center justify-between">
          <label className="text-sm font-bold text-[#0F172A] flex items-center gap-2">
            <span className="w-6 h-6 rounded-md bg-sky-100 text-[#0284C7] text-xs flex items-center justify-center font-bold">
              1
            </span>
            <span>Select Building Wall Elevation</span>
          </label>
          <span className="text-xs text-slate-500 font-medium">Configure doors, windows & bay openings</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {(['front', 'back', 'left', 'right'] as WallSide[]).map((side) => {
            const count = openings.filter((op) => op.side === side).length;
            const isSelected = activeSide === side;
            const isGable = side === 'front' || side === 'back';
            const sideFt = isGable ? dimensions.width : dimensions.length;

            return (
              <button
                key={side}
                id={`wall-tab-${side}`}
                onClick={() => setActiveSide(side)}
                className={`p-3.5 rounded-2xl border text-center transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] cursor-pointer relative active:scale-95 hover:scale-[1.02] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
                  isSelected
                    ? 'bg-cyan-50 text-[#075985] font-black shadow-sm border-2 border-[#06B6D4] ring-2 ring-[#06B6D4]/30'
                    : 'bg-white border-sky-200/80 text-[#0369A1] hover:text-[#075985] hover:bg-sky-50/70 shadow-2xs font-semibold'
                }`}
              >
                <span className={`text-xs uppercase tracking-wider block ${isSelected ? 'text-[#075985] font-black' : 'text-[#0369A1] font-bold'}`}>
                  {side} Elevation
                </span>
                <span className={`text-[11px] block mt-0.5 ${isSelected ? 'text-[#075985] font-bold' : 'text-[#0369A1]/70'}`}>
                  {isGable ? 'Gable End' : 'Eave Side'} • {sideFt} FT
                </span>
                <span
                  className={`text-[10px] mt-1.5 inline-block px-2.5 py-0.5 rounded-full font-bold ${
                    isSelected
                      ? 'bg-[#06B6D4] text-white shadow-2xs'
                      : count > 0
                      ? 'bg-sky-100 text-[#075985] border border-sky-200 font-semibold'
                      : 'bg-sky-50 text-[#0369A1]/80'
                  }`}
                >
                  {count} {count === 1 ? 'opening' : 'openings'}
                </span>
                {isSelected && (
                  <span className="absolute -bottom-[2px] inset-x-3 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
                )}
              </button>
            );
          })}
        </div>

        {/* Wall Enclosure & Wainscot Settings */}
        <div className="pt-4 border-t border-sky-100 flex flex-wrap items-center justify-start gap-2.5">
          <button
            onClick={toggleWallEnclosed}
            className={`relative px-4 py-2 rounded-full text-xs flex items-center gap-2 transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] cursor-pointer border active:scale-95 hover:scale-[1.02] shadow-xs focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
              currentWall.enclosed
                ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] ring-2 ring-[#06B6D4]/30 font-black shadow-sm'
                : 'bg-white text-[#0369A1] hover:text-[#075985] border-sky-200/80 font-semibold'
            }`}
          >
            {currentWall.enclosed ? <DoorClosed className="w-3.5 h-3.5 text-[#06B6D4]" /> : <DoorOpen className="w-3.5 h-3.5 text-[#0369A1]" />}
            <span>{currentWall.enclosed ? 'Enclosed Wall' : 'Open Bay (Run-In)'}</span>
            {currentWall.enclosed && (
              <span className="absolute -bottom-[2px] inset-x-3 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
            )}
          </button>

          <button
            onClick={toggleWallWainscot}
            className={`relative px-4 py-2 rounded-full text-xs flex items-center gap-2 transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] cursor-pointer border active:scale-95 hover:scale-[1.02] shadow-xs focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
              currentWall.hasWainscot
                ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] ring-2 ring-[#06B6D4]/30 font-black shadow-sm'
                : 'bg-white text-[#0369A1] hover:text-[#075985] border-sky-200/80 font-semibold'
            }`}
          >
            <span>{currentWall.hasWainscot ? 'Wainscot Active on Wall' : 'No Wainscot on Wall'}</span>
            {currentWall.hasWainscot && (
              <span className="absolute -bottom-[2px] inset-x-3 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
            )}
          </button>

          <button
            onClick={() => toggleAllWainscot(!hasAnyWainscot)}
            className="px-4 py-2 rounded-full text-xs font-semibold text-[#0369A1] hover:text-[#075985] bg-sky-50/70 hover:bg-sky-100 border border-sky-200 transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-95 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4]"
          >
            {hasAnyWainscot ? 'Remove Wainscot All Walls' : '+ Wainscot All Walls'}
          </button>
        </div>
      </div>

      {/* 2. Openings List on this Wall */}
      <div className="bg-white border border-slate-200/90 p-5 sm:p-6 rounded-xl shadow-[0_4px_6px_-1px_rgba(0,0,0,0.1),0_2px_4px_-2px_rgba(0,0,0,0.06)] space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <label className="text-sm font-bold text-[#0F172A] flex items-center gap-2">
            <span className="w-6 h-6 rounded-md bg-sky-100 text-[#0284C7] text-xs flex items-center justify-center font-bold">
              2
            </span>
            <span>Doors, Windows & Openings ({currentSideOpenings.length} on this wall)</span>
          </label>

          <div className="flex items-center gap-2 flex-wrap">
            {currentSideOpenings.length > 0 && (
              <button
                onClick={handleClearWallOpenings}
                className="text-xs text-rose-700 hover:text-rose-800 px-3 py-1.5 rounded-full bg-rose-50 hover:bg-rose-100 border border-rose-200 transition-all cursor-pointer flex items-center gap-1.5"
                title="Clear all openings from this wall"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear Wall</span>
              </button>
            )}

            {openings.length > 0 && (
              <button
                onClick={handleClearAllOpenings}
                className="text-xs text-slate-600 hover:text-[#0F172A] px-3 py-1.5 rounded-full bg-slate-100 hover:bg-slate-200 border border-slate-200 transition-all cursor-pointer"
                title="Clear all openings across all 4 walls"
              >
                <span>Clear All ({openings.length})</span>
              </button>
            )}

            <button
              id="btn-add-opening"
              onClick={() => setShowAddOpening(true)}
              className="text-xs bg-[#0284C7] hover:bg-[#0369a1] text-white font-bold px-4 py-2 rounded-full flex items-center gap-2 transition-all cursor-pointer shadow-md shadow-sky-600/20 active:scale-95"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>Add Opening</span>
            </button>
          </div>
        </div>

        {/* Existing Openings Cards */}
        {currentSideOpenings.length === 0 ? (
          <div className="p-8 text-center bg-slate-50/60 rounded-xl border border-dashed border-slate-200 shadow-2xs">
            <DoorOpen className="w-8 h-8 text-slate-400 mx-auto mb-2 opacity-80" />
            <p className="text-sm text-slate-700 font-medium">No openings placed on the {activeSide} wall yet.</p>
            <p className="text-xs text-slate-500 mt-1">
              Click "+ Add Opening" to place overhead garage doors, walk-in doors, or windows.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {currentSideOpenings.map((op) => (
              <div
                key={op.id}
                className="bg-white p-4 rounded-xl border border-slate-200/90 flex flex-col sm:flex-row sm:items-center justify-between gap-3.5 shadow-2xs"
              >
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-bold text-[#0F172A]">{op.label}</span>
                    <span className="text-[11px] font-mono px-2.5 py-0.5 rounded-full bg-slate-50 text-[#0F172A] font-bold border border-slate-200">
                      {op.widthFt}' W × {op.heightFt}' H
                    </span>
                    {op.insulated && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200 font-semibold">
                        Insulated
                      </span>
                    )}
                    {op.hasWindows && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-sky-100 text-sky-800 border border-sky-200 font-semibold">
                        Window Inserts
                      </span>
                    )}
                  </div>
                  <span className="text-xs text-slate-500 mt-1 block">
                    Horizontal offset: {op.positionOffsetFt} FT from left corner · Sill: {op.bottomOffsetFt ?? 0} FT above floor
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-full border border-slate-200">
                    <span className="text-[11px] text-slate-500">Position:</span>
                    <input
                      type="range"
                      min="0"
                      max={Math.max(0, wallLengthFt - op.widthFt)}
                      step="1"
                      value={op.positionOffsetFt}
                      onChange={(e) => handleUpdatePosition(op.id, Number(e.target.value))}
                      className="w-28 accent-[#0284C7] cursor-pointer h-2 bg-slate-200 rounded-full"
                    />
                    <span className="text-xs font-mono font-bold text-[#0F172A] w-9 text-right">{op.positionOffsetFt}ft</span>
                  </div>
                  {op.type === 'window' && (
                    <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-full border border-slate-200">
                      <span className="text-[11px] text-slate-500">Sill:</span>
                      <input type="range" min="0" max={Math.max(0, dimensions.eaveHeight - op.heightFt)} step="0.5" value={Math.min(op.bottomOffsetFt ?? 3, Math.max(0, dimensions.eaveHeight - op.heightFt))} onChange={(e) => handleUpdateBottomOffset(op.id, Number(e.target.value))} className="w-20 accent-[#0284C7] cursor-pointer h-2 bg-slate-200 rounded-full" />
                      <span className="text-xs font-mono font-bold text-[#0F172A]">{op.bottomOffsetFt ?? 3}ft</span>
                    </div>
                  )}

                  <button
                    onClick={() => handleRemoveOpening(op.id)}
                    className="p-2 text-slate-400 hover:text-red-600 rounded-full hover:bg-red-50 cursor-pointer transition-all active:scale-90"
                    title="Delete Opening"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Modal / Dialog for Adding an Opening */}
        {showAddOpening && (
          <div className="p-5 bg-sky-50/60 border border-cyan-200 rounded-2xl space-y-4 animate-in fade-in shadow-sm">
            <div className="flex items-center justify-between border-b border-sky-100 pb-3">
              <h4 className="text-sm font-bold text-[#075985] flex items-center gap-2">
                <Plus className="w-4 h-4 text-[#06B6D4] stroke-[2.5]" />
                Add Opening to {activeSide.toUpperCase()} Elevation
              </h4>
              <button
                onClick={() => setShowAddOpening(false)}
                className="text-xs text-[#0369A1] hover:text-[#075985] cursor-pointer px-3 py-1 rounded-full hover:bg-sky-100 transition-colors"
              >
                Cancel
              </button>
            </div>

            {/* Type selector */}
            <div>
              <label className="text-xs font-semibold text-[#0369A1] block mb-2">Opening Type</label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'overhead_door' as const, label: 'Overhead Garage' },
                  { id: 'walk_door' as const, label: 'Walk-In Entry' },
                  { id: 'window' as const, label: 'Wall Window' },
                  { id: 'sliding_barn_door' as const, label: 'Barn Slider' },
                ].map((item) => {
                  const isSelected = newType === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        setNewType(item.id);
                        setNewSize(SIZES_BY_TYPE[item.id][0]);
                      }}
                      className={`relative text-xs py-2 px-3 rounded-full font-bold transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] cursor-pointer text-center active:scale-95 hover:scale-[1.03] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
                        isSelected
                          ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] shadow-sm font-black ring-2 ring-[#06B6D4]/30'
                          : 'bg-white border border-sky-200/80 text-[#0369A1] hover:text-[#075985] hover:bg-sky-50 font-semibold'
                      }`}
                    >
                      {item.label}
                      {isSelected && (
                        <span className="absolute -bottom-[2px] inset-x-2.5 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Size selector */}
            <div>
              <label className="text-xs font-semibold text-[#0369A1] block mb-2">Dimensions (Width × Height)</label>
              <div className="grid grid-cols-4 gap-2">
                {SIZES_BY_TYPE[newType].map((sz) => {
                  const isSelected = newSize === sz;
                  return (
                    <button
                      key={sz}
                      onClick={() => setNewSize(sz)}
                      className={`relative text-xs py-2 rounded-full font-mono transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] cursor-pointer text-center active:scale-95 hover:scale-[1.03] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
                        isSelected
                          ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] font-black shadow-sm ring-2 ring-[#06B6D4]/30'
                          : 'bg-white text-[#0369A1] border border-sky-200/80 hover:text-[#075985] hover:bg-sky-50 font-semibold'
                      }`}
                    >
                      {sz}'
                      {isSelected && (
                        <span className="absolute -bottom-[2px] inset-x-2 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Options */}
            <div className="flex flex-wrap items-center gap-4 text-xs pt-1">
              <label className="flex items-center gap-2 cursor-pointer text-slate-700 font-medium">
                <input
                  type="checkbox"
                  checked={newInsulated}
                  onChange={(e) => setNewInsulated(e.target.checked)}
                  className="rounded accent-[#0284C7] cursor-pointer w-4 h-4"
                />
                <span>Insulated Weather-tight Package</span>
              </label>

              {newType === 'overhead_door' && (
                <label className="flex items-center gap-2 cursor-pointer text-slate-700 font-medium">
                  <input
                    type="checkbox"
                    checked={newHasWindows}
                    onChange={(e) => setNewHasWindows(e.target.checked)}
                    className="rounded accent-[#0284C7] cursor-pointer w-4 h-4"
                  />
                  <span>Glass Window Top Insert</span>
                </label>
              )}
            </div>

            {/* Position offset */}
            <div>
              <div className="flex justify-between text-xs mb-1.5">
                <span className="text-slate-600 font-medium">Position along wall (offset from left corner)</span>
                <span className="font-mono text-[#0F172A] font-bold">{newOffset} FT</span>
              </div>
              <input
                type="range"
                min="1"
                max={Math.max(1, wallLengthFt - 10)}
                step="1"
                value={newOffset}
                onChange={(e) => setNewOffset(Number(e.target.value))}
                className="w-full accent-[#0284C7] cursor-pointer h-2.5 bg-slate-200 rounded-full transition-all"
              />
            </div>

            <div className="flex justify-end gap-2.5 pt-3 border-t border-slate-200">
              <button
                onClick={() => setShowAddOpening(false)}
                className="px-4 py-2 rounded-full text-xs text-slate-600 hover:text-[#0F172A] cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleAddOpening}
                className="px-5 py-2 rounded-full text-xs font-bold bg-[#0284C7] hover:bg-[#0369a1] text-white cursor-pointer shadow-md shadow-sky-600/20 active:scale-95"
              >
                Place Opening
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 3. Lean-to / Porch Extension Section */}
      <div className="bg-white border border-slate-200/90 p-5 sm:p-6 rounded-xl shadow-[0_4px_6px_-1px_rgba(0,0,0,0.1),0_2px_4px_-2px_rgba(0,0,0,0.06)] space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-sky-100 text-[#0284C7] flex items-center justify-center font-bold border border-sky-200">
                <Home className="w-4 h-4 text-[#0284C7]" />
              </div>
              <div>
                <label className="text-sm font-bold text-[#0F172A] flex items-center gap-2">
                  Attached Lean-to / Porch Extension
                </label>
                <p className="text-xs text-slate-500 mt-0.5">
                  Adds covered shelter, equipment bay, open patio, or fully enclosed extension
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {leanTo.enabled && (
              <span className="text-xs font-mono text-[#0F172A] bg-sky-50 px-3 py-1.5 rounded-full border border-sky-200 font-semibold">
                {(leanTo.widthFt || 10) * (leanTo.lengthFt || (leanTo.side === 'front' || leanTo.side === 'back' ? dimensions.width : dimensions.length))} sq ft covered
              </span>
            )}
            <button
              onClick={() =>
                onUpdateState((prev) => ({
                  ...prev,
                  leanTo: {
                    ...prev.leanTo,
                    enabled: !prev.leanTo.enabled,
                    lengthFt: prev.leanTo.lengthFt || (prev.leanTo.side === 'front' || prev.leanTo.side === 'back' ? prev.dimensions.width : prev.dimensions.length),
                  },
                }))
              }
              className={`px-5 py-2.5 rounded-full text-xs font-bold transition-all cursor-pointer border active:scale-95 shadow-xs ${
                leanTo.enabled
                  ? 'bg-[#0284C7] text-white border-[#0284C7] shadow-md shadow-sky-600/20'
                  : 'bg-slate-50 text-slate-700 border-slate-200 hover:text-[#0F172A] hover:bg-slate-100'
              }`}
            >
              {leanTo.enabled ? 'Extension Enabled' : 'Add Lean-To Extension'}
            </button>
          </div>
        </div>

        {leanTo.enabled && (() => {
          const hostWallLength = leanTo.side === 'front' || leanTo.side === 'back' ? dimensions.width : dimensions.length;
          const currentWidth = leanTo.widthFt || 10;
          const currentLength = Math.min(hostWallLength, leanTo.lengthFt || hostWallLength);
          const currentDrop = leanTo.dropBelowEaveFt ?? 2;
          const attachmentElev = Math.max(6.5, dimensions.eaveHeight - currentDrop);
          const currentOuterElev = leanTo.outerEaveHeightFt
            ? Math.max(6.0, Math.min(attachmentElev - 0.5, leanTo.outerEaveHeightFt))
            : Math.max(6.0, attachmentElev - currentWidth * ((leanTo.pitch || 2) / 12));
          const calculatedSlope = Math.max(0.5, Number((((attachmentElev - currentOuterElev) / currentWidth) * 12).toFixed(1)));
          const maxOffset = Math.max(0, hostWallLength - currentLength);
          const currentOffset = Math.max(0, Math.min(maxOffset, leanTo.startOffsetFt ?? 0));

          return (
            <div className="space-y-6">
              {/* Row 1: Wall Attachment Side & Enclosure Type */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-slate-700 font-semibold block mb-2">Attached Wall Location</label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {[
                      { id: 'right' as const, label: 'Right (East)' },
                      { id: 'left' as const, label: 'Left (West)' },
                      { id: 'front' as const, label: 'Front (South)' },
                      { id: 'back' as const, label: 'Back (North)' },
                    ].map((s) => (
                      <button
                        key={s.id}
                        onClick={() => {
                          const newHostLen = s.id === 'front' || s.id === 'back' ? dimensions.width : dimensions.length;
                          onUpdateState((prev) => ({
                            ...prev,
                            leanTo: {
                              ...prev.leanTo,
                              side: s.id,
                              lengthFt: Math.min(newHostLen, prev.leanTo.lengthFt || newHostLen),
                              startOffsetFt: 0,
                            },
                          }));
                        }}
                        className={`text-xs py-2.5 px-2 rounded-xl font-bold transition-all cursor-pointer border text-center ${
                          leanTo.side === s.id
                            ? 'bg-[#0284C7] text-white font-bold border-[#0284C7] shadow-xs'
                            : 'bg-slate-50 text-slate-700 border-slate-200 hover:text-[#0F172A] hover:bg-slate-100'
                        }`}
                      >
                        {s.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-xs text-slate-700 font-semibold block mb-2">Architecture & Framing Style</label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { val: false, label: 'Open Bay Porch', desc: '6x6 Timber Posts & Open Bay' },
                      { val: true, label: 'Fully Enclosed Bay', desc: 'Siding Walls & Metal Endwalls' },
                    ].map((item) => (
                      <button
                        key={item.label}
                        onClick={() =>
                          onUpdateState((prev) => ({
                            ...prev,
                            leanTo: { ...prev.leanTo, enclosed: item.val, openSides: { host: !item.val, outerEave: !item.val, frontGable: !item.val, backGable: !item.val } },
                          }))
                        }
                        className={`text-left p-2.5 rounded-xl transition-all cursor-pointer border ${
                          leanTo.enclosed === item.val
                            ? 'bg-[#0284C7] text-white border-[#0284C7] shadow-xs'
                            : 'bg-slate-50 text-slate-700 border-slate-200 hover:text-[#0F172A] hover:bg-slate-100'
                        }`}
                      >
                        <div className="text-xs font-bold">{item.label}</div>
                        <div className={`text-[10px] mt-0.5 ${leanTo.enclosed === item.val ? 'text-white/80' : 'text-slate-500'}`}>
                          {item.desc}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="bg-sky-50/70 border border-sky-100 rounded-xl p-4">
                <div className="text-xs font-bold text-slate-800 mb-1">Individual Lean-to Side Configuration</div>
                <p className="text-[11px] text-slate-500 mb-3">Choose which exterior faces receive siding. The attached host side is normally not an exterior wall.</p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {([
                    ['host', 'Host / attachment side'],
                    ['outerEave', 'Outside eave side'],
                    ['frontGable', 'Front end'],
                    ['backGable', 'Back end'],
                  ] as const).map(([key, label]) => {
                    const sideCfg = leanTo.openSides ?? { host: !leanTo.enclosed, outerEave: !leanTo.enclosed, frontGable: !leanTo.enclosed, backGable: !leanTo.enclosed };
                    const isOpen = sideCfg[key];
                    return <label key={key} className="flex items-center gap-2 text-xs text-slate-700 bg-white border border-slate-200 rounded-lg p-2.5 cursor-pointer">
                      <input type="checkbox" checked={isOpen} onChange={(e) => onUpdateState((prev) => ({ ...prev, leanTo: { ...prev.leanTo, openSides: { ...(prev.leanTo.openSides ?? { host: !prev.leanTo.enclosed, outerEave: !prev.leanTo.enclosed, frontGable: !prev.leanTo.enclosed, backGable: !prev.leanTo.enclosed }), [key]: e.target.checked } } }))} />
                      <span>{label} <span className="block text-[10px] text-slate-400">{isOpen ? 'Open' : 'Enclosed'}</span></span>
                    </label>;
                  })}
                </div>
              </div>

              <label className="flex items-center gap-2 text-xs text-slate-700 bg-white border border-slate-200 rounded-lg p-3">
                <input type="checkbox" checked={leanTo.hasOutsideEaveOverhang ?? true} onChange={(e) => onUpdateState((prev) => ({ ...prev, leanTo: { ...prev.leanTo, hasOutsideEaveOverhang: e.target.checked } }))} />
                <span><strong>Lean-to outside eave overhang</strong><span className="block text-[10px] text-slate-500">When enabled, include soffit and fascia cover at the outside eave.</span></span>
              </label>

              {/* Row 2: Width & Length Controls */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5 bg-slate-50 p-4 sm:p-5 rounded-xl border border-slate-200/90">
                {/* Outward Width / Projection */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xs font-bold text-[#0F172A]">Outward Width (Projection)</span>
                      <p className="text-[11px] text-slate-500">Distance extended out from building wall</p>
                    </div>
                    <div className="flex items-center gap-1.5 bg-white px-3 py-1 rounded-xl border border-slate-200">
                      <input
                        type="number"
                        min="6"
                        max="36"
                        step="1"
                        value={currentWidth}
                        onChange={(e) => {
                          const val = Math.max(6, Math.min(36, Number(e.target.value) || 6));
                          onUpdateState((prev) => ({
                            ...prev,
                            leanTo: { ...prev.leanTo, widthFt: val },
                          }));
                        }}
                        className="w-10 bg-transparent text-[#0F172A] font-mono font-bold text-sm text-right focus:outline-none"
                      />
                      <span className="text-xs text-slate-500 font-mono">ft</span>
                    </div>
                  </div>

                  <input
                    type="range"
                    min="6"
                    max="36"
                    step="1"
                    value={currentWidth}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      onUpdateState((prev) => ({
                        ...prev,
                        leanTo: { ...prev.leanTo, widthFt: val },
                      }));
                    }}
                    className="w-full accent-[#0284C7] cursor-pointer h-2 bg-slate-200 rounded-full"
                  />

                  {/* Preset quick chips */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {[8, 10, 12, 14, 16, 20, 24].map((w) => (
                      <button
                        key={w}
                        onClick={() =>
                          onUpdateState((prev) => ({
                            ...prev,
                            leanTo: { ...prev.leanTo, widthFt: w },
                          }))
                        }
                        className={`text-[11px] px-2.5 py-1 rounded-lg font-mono font-semibold transition-all cursor-pointer border ${
                          currentWidth === w
                            ? 'bg-[#0284C7] text-white font-bold border-[#0284C7]'
                            : 'bg-white text-slate-600 border-slate-200 hover:text-[#0F172A]'
                        }`}
                      >
                        {w}'
                      </button>
                    ))}
                  </div>
                </div>

                {/* Longitudinal Porch Length */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xs font-bold text-[#0F172A]">Porch Length (Run)</span>
                      <p className="text-[11px] text-slate-500">Total length along the {hostWallLength}' wall</p>
                    </div>
                    <div className="flex items-center gap-1.5 bg-white px-3 py-1 rounded-xl border border-slate-200">
                      <input
                        type="number"
                        min="8"
                        max={hostWallLength}
                        step="2"
                        value={currentLength}
                        onChange={(e) => {
                          const val = Math.max(8, Math.min(hostWallLength, Number(e.target.value) || 8));
                          onUpdateState((prev) => ({
                            ...prev,
                            leanTo: {
                              ...prev.leanTo,
                              lengthFt: val,
                              startOffsetFt: Math.min(prev.leanTo.startOffsetFt || 0, Math.max(0, hostWallLength - val)),
                            },
                          }));
                        }}
                        className="w-12 bg-transparent text-[#0F172A] font-mono font-bold text-sm text-right focus:outline-none"
                      />
                      <span className="text-xs text-slate-500 font-mono">ft</span>
                    </div>
                  </div>

                  <input
                    type="range"
                    min="8"
                    max={hostWallLength}
                    step="2"
                    value={currentLength}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      onUpdateState((prev) => ({
                        ...prev,
                        leanTo: {
                          ...prev.leanTo,
                          lengthFt: val,
                          startOffsetFt: Math.min(prev.leanTo.startOffsetFt || 0, Math.max(0, hostWallLength - val)),
                        },
                      }));
                    }}
                    className="w-full accent-[#0284C7] cursor-pointer h-2 bg-slate-200 rounded-full"
                  />

                  {/* Preset quick buttons */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    <button
                      onClick={() =>
                        onUpdateState((prev) => ({
                          ...prev,
                          leanTo: { ...prev.leanTo, lengthFt: hostWallLength, startOffsetFt: 0 },
                        }))
                      }
                      className={`text-[11px] px-3 py-1 rounded-lg font-mono font-semibold transition-all cursor-pointer border ${
                        currentLength === hostWallLength
                          ? 'bg-[#0284C7] text-white font-bold border-[#0284C7]'
                          : 'bg-white text-slate-600 border-slate-200 hover:text-[#0F172A]'
                      }`}
                    >
                      Full Wall ({hostWallLength}')
                    </button>
                    <button
                      onClick={() =>
                        onUpdateState((prev) => ({
                          ...prev,
                          leanTo: { ...prev.leanTo, lengthFt: Math.round(hostWallLength * 0.75), startOffsetFt: 0 },
                        }))
                      }
                      className="text-[11px] px-2.5 py-1 rounded-lg font-mono font-semibold bg-white text-slate-600 border border-slate-200 hover:text-[#0F172A] cursor-pointer"
                    >
                      3/4 ({Math.round(hostWallLength * 0.75)}')
                    </button>
                    <button
                      onClick={() =>
                        onUpdateState((prev) => ({
                          ...prev,
                          leanTo: { ...prev.leanTo, lengthFt: Math.round(hostWallLength * 0.5), startOffsetFt: 0 },
                        }))
                      }
                      className="text-[11px] px-2.5 py-1 rounded-lg font-mono font-semibold bg-white text-slate-600 border border-slate-200 hover:text-[#0F172A] cursor-pointer"
                    >
                      1/2 ({Math.round(hostWallLength * 0.5)}')
                    </button>
                  </div>
                </div>
              </div>

              {/* Row 2B: Offset along wall (If partial length) */}
              {currentLength < hostWallLength && (
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/90 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xs font-bold text-[#0F172A]">Placement Offset along Wall</span>
                      <p className="text-[11px] text-slate-500">Position along the {hostWallLength}' host wall</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() =>
                          onUpdateState((prev) => ({
                            ...prev,
                            leanTo: { ...prev.leanTo, startOffsetFt: 0 },
                          }))
                        }
                        className={`text-[10px] px-2.5 py-1 rounded-lg font-bold border transition-all cursor-pointer ${
                          currentOffset === 0
                            ? 'bg-[#0284C7] text-white border-[#0284C7]'
                            : 'bg-white text-slate-600 border-slate-200 hover:text-[#0F172A]'
                        }`}
                      >
                        Flush Start
                      </button>
                      <button
                        onClick={() =>
                          onUpdateState((prev) => ({
                            ...prev,
                            leanTo: { ...prev.leanTo, startOffsetFt: Math.round((hostWallLength - currentLength) / 2) },
                          }))
                        }
                        className={`text-[10px] px-2.5 py-1 rounded-lg font-bold border transition-all cursor-pointer ${
                          currentOffset === Math.round((hostWallLength - currentLength) / 2)
                            ? 'bg-[#0284C7] text-white border-[#0284C7]'
                            : 'bg-white text-slate-600 border-slate-200 hover:text-[#0F172A]'
                        }`}
                      >
                        Centered
                      </button>
                      <button
                        onClick={() =>
                          onUpdateState((prev) => ({
                            ...prev,
                            leanTo: { ...prev.leanTo, startOffsetFt: maxOffset },
                          }))
                        }
                        className={`text-[10px] px-2.5 py-1 rounded-lg font-bold border transition-all cursor-pointer ${
                          currentOffset === maxOffset
                            ? 'bg-[#0284C7] text-white border-[#0284C7]'
                            : 'bg-white text-slate-600 border-slate-200 hover:text-[#0F172A]'
                        }`}
                      >
                        Flush End
                      </button>
                      <span className="text-xs font-mono font-bold text-[#0F172A] bg-white px-2.5 py-1 rounded-xl border border-slate-200">
                        +{currentOffset}' offset
                      </span>
                    </div>
                  </div>

                  <input
                    type="range"
                    min="0"
                    max={maxOffset}
                    step="1"
                    value={currentOffset}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      onUpdateState((prev) => ({
                        ...prev,
                        leanTo: { ...prev.leanTo, startOffsetFt: val },
                      }));
                    }}
                    className="w-full accent-[#0284C7] cursor-pointer h-2 bg-slate-200 rounded-full"
                  />
                </div>
              )}

              {/* Row 3: Height & Slope Architectural Controls */}
              <div className="bg-slate-50 p-4 sm:p-5 rounded-xl border border-slate-200/90 space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-3">
                  <div>
                    <span className="text-xs font-bold text-[#0F172A] uppercase tracking-wider">
                      Height & Pitch Architecture
                    </span>
                    <p className="text-[11px] text-slate-500">
                      Coordinates ledger board attachment and outer post clearance height
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono px-3 py-1 rounded-full bg-sky-100 text-[#0284C7] border border-sky-200 font-bold">
                      Slope: {calculatedSlope}:12
                    </span>
                    <span className="text-xs font-mono px-3 py-1 rounded-full bg-sky-50 text-[#0F172A] border border-sky-200 font-bold">
                      Ledger: {attachmentElev.toFixed(1)}' Y
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Ledger Board Drop below Main Eave */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-xs font-bold text-[#0F172A]">Ledger Attachment Drop</span>
                        <p className="text-[11px] text-slate-500">
                          {currentDrop === 0 ? 'Flush with main roof eave' : `${currentDrop.toFixed(1)}' below ${dimensions.eaveHeight}' eave`}
                        </p>
                      </div>
                      <div className="flex items-center gap-1.5 bg-white px-3 py-1 rounded-xl border border-slate-200">
                        <input
                          type="number"
                          min="0"
                          max={Math.min(8, dimensions.eaveHeight - 7)}
                          step="0.5"
                          value={currentDrop}
                          onChange={(e) => {
                            const val = Math.max(0, Math.min(8, Number(e.target.value) || 0));
                            onUpdateState((prev) => ({
                              ...prev,
                              leanTo: { ...prev.leanTo, dropBelowEaveFt: val },
                            }));
                          }}
                          className="w-10 bg-transparent text-[#0F172A] font-mono font-bold text-sm text-right focus:outline-none"
                        />
                        <span className="text-xs text-slate-500 font-mono">ft</span>
                      </div>
                    </div>

                    <input
                      type="range"
                      min="0"
                      max={Math.min(8, dimensions.eaveHeight - 7)}
                      step="0.5"
                      value={currentDrop}
                      onChange={(e) => {
                        const val = Number(e.target.value);
                        onUpdateState((prev) => ({
                          ...prev,
                          leanTo: { ...prev.leanTo, dropBelowEaveFt: val },
                        }));
                      }}
                      className="w-full accent-[#0284C7] cursor-pointer h-2 bg-slate-200 rounded-full"
                    />

                    {/* Quick drop chips */}
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {[0, 1, 2, 3, 4].filter((d) => dimensions.eaveHeight - d >= 7).map((d) => (
                        <button
                          key={d}
                          onClick={() =>
                            onUpdateState((prev) => ({
                              ...prev,
                              leanTo: { ...prev.leanTo, dropBelowEaveFt: d },
                            }))
                          }
                          className={`text-[11px] px-2.5 py-1 rounded-lg font-mono font-semibold transition-all cursor-pointer border ${
                            currentDrop === d
                              ? 'bg-[#0284C7] text-white font-bold border-[#0284C7]'
                              : 'bg-white text-slate-600 border-slate-200 hover:text-[#0F172A]'
                          }`}
                        >
                          {d === 0 ? 'Flush (0\')' : `-${d} ft`}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Outer Post / Clearance Height */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-xs font-bold text-[#0F172A]">Outer Post Eave Height</span>
                        <p className="text-[11px] text-slate-500">Clearance at outer columns / fascia</p>
                      </div>
                      <div className="flex items-center gap-1.5 bg-white px-3 py-1 rounded-xl border border-slate-200">
                        <input
                          type="number"
                          min="6"
                          max={Math.max(6.5, attachmentElev - 0.5)}
                          step="0.5"
                          value={currentOuterElev}
                          onChange={(e) => {
                            const val = Math.max(6, Math.min(attachmentElev - 0.5, Number(e.target.value) || 6));
                            const newPitch = Number((((attachmentElev - val) / currentWidth) * 12).toFixed(1));
                            onUpdateState((prev) => ({
                              ...prev,
                              leanTo: {
                                ...prev.leanTo,
                                outerEaveHeightFt: val,
                                pitch: newPitch,
                              },
                            }));
                          }}
                          className="w-10 bg-transparent text-[#0F172A] font-mono font-bold text-sm text-right focus:outline-none"
                        />
                        <span className="text-xs text-slate-500 font-mono">ft</span>
                      </div>
                    </div>

                    <input
                      type="range"
                      min="6"
                      max={Math.max(6.5, attachmentElev - 0.5)}
                      step="0.5"
                      value={currentOuterElev}
                      onChange={(e) => {
                        const val = Number(e.target.value);
                        const newPitch = Number((((attachmentElev - val) / currentWidth) * 12).toFixed(1));
                        onUpdateState((prev) => ({
                          ...prev,
                          leanTo: {
                            ...prev.leanTo,
                            outerEaveHeightFt: val,
                            pitch: newPitch,
                          },
                        }));
                      }}
                      className="w-full accent-[#0284C7] cursor-pointer h-2 bg-slate-200 rounded-full"
                    />

                    {/* Quick Outer Post Height chips */}
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {[8, 9, 10, 12, 14].filter((h) => h < attachmentElev).map((h) => (
                        <button
                          key={h}
                          onClick={() => {
                            const newPitch = Number((((attachmentElev - h) / currentWidth) * 12).toFixed(1));
                            onUpdateState((prev) => ({
                              ...prev,
                              leanTo: {
                                ...prev.leanTo,
                                outerEaveHeightFt: h,
                                pitch: newPitch,
                              },
                            }));
                          }}
                          className={`text-[11px] px-2.5 py-1 rounded-lg font-mono font-semibold transition-all cursor-pointer border ${
                            Math.abs(currentOuterElev - h) < 0.2
                              ? 'bg-[#0284C7] text-white font-bold border-[#0284C7]'
                              : 'bg-white text-slate-600 border-slate-200 hover:text-[#0F172A]'
                          }`}
                        >
                          {h}' Post
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Pitch Sync Selector */}
                <div className="pt-2 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
                  <span className="text-xs font-semibold text-slate-700">Lean-to roof pitch (independent):</span>
                  <div className="flex flex-wrap gap-1.5">
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((p) => {
                      const targetOuterH = Math.max(0, attachmentElev - currentWidth * (p / 12));
                      return (
                        <button
                          key={p}
                          onClick={() =>
                            onUpdateState((prev) => ({
                              ...prev,
                              leanTo: {
                                ...prev.leanTo,
                                pitch: p,
                                outerEaveHeightFt: targetOuterH,
                              },
                            }))
                          }
                          className={`text-xs px-3 py-1.5 rounded-xl font-mono font-bold transition-all cursor-pointer border ${
                            Math.abs(calculatedSlope - p) < 0.2
                              ? 'bg-[#0284C7] text-white border-[#0284C7] shadow-xs'
                              : 'bg-white text-slate-700 border-slate-200 hover:text-[#0F172A]'
                          }`}
                        >
                          {p}:12 Pitch ({targetOuterH.toFixed(1)}' Eave)
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          );
        })()}
      </div>
    </div>
  );
};
