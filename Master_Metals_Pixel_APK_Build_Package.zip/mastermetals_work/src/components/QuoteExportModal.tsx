import React, { useState } from 'react';
import { CustomBuildingState, PricingBreakdown } from '../types';
import { X, Printer, Download, Building, CheckCircle2, ShieldCheck, Phone, Mail, MapPin, Ruler } from 'lucide-react';

interface QuoteExportModalProps {
  state: CustomBuildingState;
  pricing: PricingBreakdown;
  onClose: () => void;
}

export const QuoteExportModal: React.FC<QuoteExportModalProps> = ({ state, pricing, onClose }) => {
  const [clientName, setClientName] = useState('');
  const [projectAddress, setProjectAddress] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [quoteNumber] = useState(`SC-${Math.floor(100000 + Math.random() * 900000)}`);
  const [quoteDate] = useState(new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }));

  const { dimensions, materials, interior, snowLoad, trussType, leanTo } = state;
  const { width, length, eaveHeight, roofPitch, trussSpacing } = dimensions;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#075985]/40 backdrop-blur-md flex items-center justify-center p-2 sm:p-6 overflow-y-auto">
      <div className="bg-white border border-sky-200/80 rounded-3xl w-full max-w-4xl max-h-[94vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 print:fixed print:inset-0 print:m-0 print:p-0 print:border-none print:rounded-none print:bg-white print:text-black transition-all text-[#075985]">
        {/* Modal Controls Bar (hidden during print) */}
        <div className="bg-white/95 backdrop-blur-md px-6 py-4 border-b border-sky-100 flex items-center justify-between print:hidden transition-colors text-[#075985] shadow-xs">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-full bg-cyan-50 text-[#06B6D4] border border-cyan-200 shadow-sm">
              <Building className="w-5 h-5" />
            </div>
            <h3 className="text-sm sm:text-base font-bold text-[#075985]">Official Custom Building Proposal & Quote</h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-4 py-2 rounded-full text-xs font-bold bg-[#06B6D4] hover:bg-[#0891b2] text-white flex items-center gap-1.5 cursor-pointer shadow-xs active:scale-95 transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4]"
            >
              <Printer className="w-4 h-4" />
              <span>Print Formal Quote</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-[#0369A1] hover:text-[#075985] rounded-full hover:bg-sky-100 cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-90 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4]"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Container */}
        <div className="p-6 sm:p-8 overflow-y-auto bg-white text-[#0F172A] print:bg-white print:text-slate-900 print:p-8 space-y-6 transition-colors">
          {/* Header & Logo */}
          <div className="flex flex-col sm:flex-row justify-between items-start gap-4 border-b border-slate-200 print:border-slate-300 pb-6">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-2xl font-black tracking-tight text-[#0F172A] print:text-slate-950">MASTER METALS</span>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-sky-100 text-sky-900 border border-sky-300 print:border-slate-400 font-mono font-semibold">ENGINEERED BUILDINGS</span>
              </div>
              <p className="text-xs text-slate-600 print:text-slate-600 mt-1 font-medium">
                Post-Frame & Structural Timber Building Systems • Complete Materials Takeoff
              </p>
            </div>

            <div className="text-right text-xs font-mono">
              <div className="text-slate-500 dark:text-slate-400 print:text-slate-600">QUOTE REF: <strong className="text-slate-900 dark:text-white print:text-black font-bold">{quoteNumber}</strong></div>
              <div className="text-slate-500 dark:text-slate-400 print:text-slate-600">DATE: {quoteDate}</div>
              <div className="text-emerald-600 dark:text-emerald-400 print:text-emerald-700 font-semibold">VALID FOR 30 DAYS</div>
            </div>
          </div>

          {/* Client & Project Info */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-white print:bg-slate-50 p-4 rounded-xl border border-slate-200/90 shadow-xs text-xs">
            <div>
              <span className="text-[10px] uppercase font-bold text-[#0284C7] print:text-slate-700 tracking-wider block mb-1">CLIENT INFORMATION</span>
              <input
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                className="font-bold text-[#0F172A] print:text-black bg-transparent border-b border-slate-300 print:border-slate-300 w-full mb-1 focus:outline-none focus:border-[#0284C7] focus:ring-1 focus:ring-[#0284C7] rounded px-1 transition-all"
                placeholder="Client Name"
              />
              <input
                value={clientPhone}
                onChange={(e) => setClientPhone(e.target.value)}
                className="text-slate-600 print:text-slate-700 bg-transparent border-b border-slate-300 print:border-slate-300 w-full focus:outline-none focus:border-[#0284C7] focus:ring-1 focus:ring-[#0284C7] rounded px-1 transition-all"
                placeholder="Phone Number"
              />
            </div>

            <div>
              <span className="text-[10px] uppercase font-bold text-[#0284C7] print:text-slate-700 tracking-wider block mb-1">JOBSITE LOCATION</span>
              <input
                value={projectAddress}
                onChange={(e) => setProjectAddress(e.target.value)}
                className="text-slate-800 print:text-slate-800 bg-transparent border-b border-slate-300 print:border-slate-300 w-full focus:outline-none focus:border-[#0284C7] focus:ring-1 focus:ring-[#0284C7] rounded px-1 transition-all"
                placeholder="Jobsite Street Address"
              />
              <div className="text-slate-500 print:text-slate-600 mt-1 font-mono">
                {pricing.squareFootage.toLocaleString()} SQ FT • {width}'W × {length}'L × {eaveHeight}'H
              </div>
            </div>
          </div>

          {/* Building Specifications Grid */}
          <div>
            <h4 className="text-xs font-bold text-[#0F172A] print:text-black uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-[#0284C7] print:text-blue-800" />
              Building Architectural Specifications
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
              <div className="p-3 rounded-lg bg-white print:bg-slate-50 border border-slate-200/90 shadow-xs">
                <span className="text-[10px] text-slate-500 print:text-slate-500 block">Footprint Size</span>
                <span className="font-bold text-[#0F172A] print:text-black">{width}' × {length}' ({pricing.squareFootage.toLocaleString()} sq ft)</span>
              </div>
              <div className="p-3 rounded-lg bg-white print:bg-slate-50 border border-slate-200/90 shadow-xs">
                <span className="text-[10px] text-slate-500 print:text-slate-500 block">Eave Wall Height</span>
                <span className="font-bold text-[#0F172A] print:text-black">{eaveHeight}' Clear Eave</span>
              </div>
              <div className="p-3 rounded-lg bg-white print:bg-slate-50 border border-slate-200/90 shadow-xs">
                <span className="text-[10px] text-slate-500 print:text-slate-500 block">Roof Pitch</span>
                <span className="font-bold text-[#0F172A] print:text-black">{roofPitch}:12 Slope</span>
              </div>
              <div className="p-3 rounded-lg bg-white print:bg-slate-50 border border-slate-200/90 shadow-xs">
                <span className="text-[10px] text-slate-500 print:text-slate-500 block">Ridge Peak Height</span>
                <span className="font-bold text-[#0F172A] print:text-black">+{(eaveHeight + pricing.trusses.apexPeakHeightFt).toFixed(1)}' Apex</span>
              </div>
              <div className="p-3 rounded-lg bg-white print:bg-slate-50 border border-slate-200/90 shadow-xs">
                <span className="text-[10px] text-slate-500 print:text-slate-500 block">Siding Color & Profile</span>
                <span className="font-bold text-[#0F172A] print:text-black">{materials.sidingColorName}</span>
              </div>
              <div className="p-3 rounded-lg bg-white print:bg-slate-50 border border-slate-200/90 shadow-xs">
                <span className="text-[10px] text-slate-500 print:text-slate-500 block">Roof Color & Material</span>
                <span className="font-bold text-[#0F172A] print:text-black">{materials.roofColorName}</span>
              </div>
              <div className="p-3 rounded-lg bg-white print:bg-slate-50 border border-slate-200/90 shadow-xs">
                <span className="text-[10px] text-slate-500 print:text-slate-500 block">Foundation Floor</span>
                <span className="font-bold text-[#0F172A] print:text-black">{materials.foundation.replace('_', ' ').toUpperCase()}</span>
              </div>
              <div className="p-3 rounded-lg bg-white print:bg-slate-50 border border-slate-200/90 shadow-xs">
                <span className="text-[10px] text-slate-500 print:text-slate-500 block">Insulation Package</span>
                <span className="font-bold text-[#0F172A] print:text-black">{interior.insulation.replace('_', ' ').toUpperCase()}</span>
              </div>
            </div>
          </div>

          {/* Specialized Truss Engineering Block */}
          <div className="p-4 rounded-xl bg-white print:bg-blue-50 border border-sky-200/90 shadow-xs text-xs">
            <div className="flex justify-between items-center mb-2">
              <span className="font-bold text-[#0284C7] print:text-blue-900 uppercase tracking-wide flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4" />
                Adaptive Engineered Truss Package Specification
              </span>
              <span className="font-mono text-[#0F172A] print:text-blue-950 font-bold">
                Package Cost: ${pricing.trusses.totalTrussPackageCost.toLocaleString()}
              </span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-[11px] text-slate-600 print:text-slate-700">
              <div>Span: <strong>{width} ft Clear Span</strong></div>
              <div>Rafter Length: <strong>{pricing.trusses.rafterLengthFt} ft</strong></div>
              <div>Slope Factor: <strong>{pricing.trusses.slopeFactor}x</strong></div>
              <div>Trusses Count: <strong>{pricing.trusses.totalTrussesNeeded} ({trussSpacing}' O.C.)</strong></div>
              <div>Snow Load: <strong>{snowLoad} PSF</strong></div>
              <div>Connector Plates: <strong>{pricing.trusses.plateConnectorsCount} Gang-Nail</strong></div>
              <div>Truss Type: <strong>{trussType.replace('_', ' ').toUpperCase()}</strong></div>
              <div>Shipping Envelope: <strong>{pricing.trusses.piggybackRequired ? 'Piggyback Required' : 'Standard Transport'}</strong></div>
            </div>
          </div>

          {/* Specialized Weight-Bearing Wall Framing Block */}
          {pricing.weightBearingHeaders && (
            <div className="p-3.5 rounded-xl bg-white print:bg-blue-50 border border-sky-200/90 shadow-xs text-xs">
              <div className="flex justify-between items-center mb-1.5">
                <span className="font-bold text-[#0284C7] print:text-blue-900 uppercase tracking-wide flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4" />
                  Weight-Bearing Wall Framing: (2) 2x12 Headers @ {pricing.weightBearingHeaders.postSpacing}' O.C. Posts
                </span>
                <span className="font-mono text-[#0F172A] print:text-blue-950 font-bold">
                  Headers Cost: ${pricing.weightBearingHeaders.totalHeaderCost.toLocaleString()}
                </span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono text-[11px] text-slate-600 print:text-slate-700">
                <div>Post Spacing: <strong>{pricing.weightBearingHeaders.postSpacing} ft O.C.</strong></div>
                <div>Header Beam: <strong>{pricing.weightBearingHeaders.headerSize} Structural</strong></div>
                <div>Weight Walls: <strong>2 Walls ({length} LF each)</strong></div>
                <div>Total 2x12 Lumber: <strong>{pricing.weightBearingHeaders.total2x12LinearFeet} LF ({pricing.weightBearingHeaders.standard16FtBoardsCount} pcs 16')</strong></div>
              </div>
            </div>
          )}

          {/* 36" Metal Sheeting Cut Schedule (Roll-Former & Supplier Order Spec) */}
          {pricing.metalTakeoff && (
            <div className="p-4 rounded-xl bg-white print:bg-slate-50 border border-slate-200/90 shadow-xs text-xs">
              <div className="flex flex-wrap justify-between items-center mb-2 gap-2">
                <span className="font-bold text-[#0F172A] print:text-black uppercase tracking-wide flex items-center gap-1.5">
                  <Ruler className="w-4 h-4 text-[#0284C7] print:text-blue-800" />
                  36" Metal Sheeting Cut Schedule & Roll-Former Order
                </span>
                <span className="font-mono text-[#0284C7] print:text-blue-900 font-bold">
                  {pricing.metalTakeoff.totalMetalSheets} Sheets • {pricing.metalTakeoff.totalMetalLinearFeet.toLocaleString()} LF Total Coil
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 font-mono text-[11px] mb-3">
                <div className="p-2.5 rounded-lg bg-white print:bg-white border border-slate-200/90 shadow-2xs">
                  <span className="text-slate-500 print:text-slate-500 block text-[10px]">Net Panel Width Coverage</span>
                  <strong className="text-[#0F172A] print:text-black">36 Inches (3.0 ft net coverage per sheet)</strong>
                </div>
                <div className="p-2.5 rounded-lg bg-white print:bg-white border border-slate-200/90 shadow-2xs">
                  <span className="text-slate-500 print:text-slate-500 block text-[10px]">Roof / Wall Sheeting Split</span>
                  <strong className="text-[#0F172A] print:text-black">
                    {pricing.metalTakeoff.totalRoofSheets} Roof Sheets | {pricing.metalTakeoff.totalWallSidingSheets} Wall Sheets {pricing.metalTakeoff.totalWainscotSheets > 0 ? `| ${pricing.metalTakeoff.totalWainscotSheets} Wainscot Sheets` : ''}
                  </strong>
                </div>
              </div>

              {/* Sheet breakdown list */}
              <div className="divide-y divide-slate-100 print:divide-slate-200 border border-slate-200/90 print:border-slate-200 rounded-lg overflow-hidden">
                {pricing.bom.filter(i => i.isMetalSheet).map((item) => (
                  <div key={item.id} className="p-2.5 flex justify-between items-center bg-white print:bg-white text-[11px]">
                    <div>
                      <span className="font-medium text-[#0F172A] print:text-black">{item.item}</span>
                      <span className="text-slate-500 print:text-slate-600 block text-[10px]">{item.description}</span>
                    </div>
                    <div className="text-right font-mono">
                      <span className="font-bold text-[#0284C7] print:text-blue-900">{item.quantity} Sheets</span>
                      {item.sheetLengthFormatted && (
                        <span className="text-slate-500 print:text-slate-600 block text-[10px]">@ {item.sheetLengthFormatted} ({item.sheetLengthFt} ft)</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Pricing Breakdown Summary */}
          <div>
            <h4 className="text-xs font-bold text-[#0F172A] print:text-black uppercase tracking-wider mb-2">
              Itemized Cost Schedule
            </h4>
            <div className="bg-white border border-slate-200/90 print:border-slate-300 rounded-xl shadow-xs overflow-hidden text-xs font-mono">
              <div className="divide-y divide-slate-100 print:divide-slate-200">
                <div className="p-3 flex justify-between bg-white print:bg-slate-100">
                  <span className="font-sans font-medium text-slate-700 print:text-slate-700">1. Engineered Roof Truss Package ({pricing.trusses.totalTrussesNeeded} Trusses + Crane Freight)</span>
                  <span className="font-bold text-[#0F172A] print:text-black">${pricing.trussPackageCost.toLocaleString()}</span>
                </div>
                <div className="p-3 flex justify-between">
                  <span className="font-sans font-medium text-slate-700 print:text-slate-700">2. Metal Roofing Sheeting & Ridge Cap Package</span>
                  <span className="font-bold text-[#0F172A] print:text-black">${pricing.roofSheetingCost.toLocaleString()}</span>
                </div>
                <div className="p-3 flex justify-between bg-white print:bg-slate-100">
                  <span className="font-sans font-medium text-slate-700 print:text-slate-700">3. Metal Wall Siding & Designer 2-Tone Wainscot Panels</span>
                  <span className="font-bold text-[#0F172A] print:text-black">${(pricing.wallSidingCost + pricing.wainscotCost).toLocaleString()}</span>
                </div>
                <div className="p-3 flex justify-between">
                  <span className="font-sans font-medium text-slate-700 print:text-slate-700">4. Architectural Trim, Flashing, Fasteners & Hi-Lo Screws</span>
                  <span className="font-bold text-[#0F172A] print:text-black">${pricing.trimAndFastenersCost.toLocaleString()}</span>
                </div>
                <div className="p-3 flex justify-between bg-white print:bg-slate-100">
                  <span className="font-sans font-medium text-slate-700 print:text-slate-700">5. Structural Timber Framing (Posts, (2) 2x12 Weight-Bearing Headers, Purlins, Girts)</span>
                  <span className="font-bold text-[#0F172A] print:text-black">${pricing.framingStructureCost.toLocaleString()}</span>
                </div>
                <div className="p-3 flex justify-between">
                  <span className="font-sans font-medium text-slate-700 print:text-slate-700">6. Concrete Foundation & Earthwork</span>
                  <span className="font-bold text-[#0F172A] print:text-black">${pricing.foundationCost.toLocaleString()}</span>
                </div>
                <div className="p-3 flex justify-between bg-white print:bg-slate-100">
                  <span className="font-sans font-medium text-slate-700 print:text-slate-700">7. Doors, Windows & Openings Package</span>
                  <span className="font-bold text-[#0F172A] print:text-black">${pricing.openingsCost.toLocaleString()}</span>
                </div>
                {leanTo.enabled && (
                  <div className="p-3 flex justify-between">
                    <span className="font-sans font-medium text-slate-700 print:text-slate-700">8. Lean-to Porch Extension ({leanTo.widthFt}'x{leanTo.lengthFt}')</span>
                    <span className="font-bold text-[#0F172A] print:text-black">${pricing.leanToCost.toLocaleString()}</span>
                  </div>
                )}
                {pricing.interiorCost > 0 && (
                  <div className="p-3 flex justify-between bg-white print:bg-slate-100">
                    <span className="font-sans font-medium text-slate-700 print:text-slate-700">9. Interior Insulation, Liner Panels & Electrical</span>
                    <span className="font-bold text-[#0F172A] print:text-black">${pricing.interiorCost.toLocaleString()}</span>
                  </div>
                )}
                <div className="p-3 flex justify-between">
                  <span className="font-sans font-medium text-slate-700 print:text-slate-700">10. Erection, Post Augering & Installation Crew Labor</span>
                  <span className="font-bold text-[#0F172A] print:text-black">${pricing.laborCost.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Grand Total Footer */}
          <div className="p-4 rounded-xl bg-white print:bg-slate-100 border border-slate-200/90 shadow-xs flex flex-col sm:flex-row justify-between items-center gap-3 transition-colors">
            <div>
              <span className="text-xs text-slate-600 print:text-slate-600 block">TOTAL ESTIMATED BUILDING INVESTMENT</span>
              <span className="text-xs text-[#0284C7] print:text-blue-900 font-mono font-bold">
                ${pricing.costPerSquareFoot} / SQ FT (TURNKEY MATERIALS & ERECTION)
              </span>
            </div>
            <div className="text-3xl font-black text-[#0F172A] print:text-slate-950 font-mono">
              ${pricing.grandTotal.toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </div>
          </div>

          {/* Signatures & Terms */}
          <div className="pt-4 border-t border-slate-200 dark:border-slate-800 print:border-slate-300 grid grid-cols-2 gap-8 text-[11px] text-slate-500 dark:text-slate-400 print:text-slate-600">
            <div>
              <p className="mb-8">Authorized Contractor Signature: _______________________</p>
              <p>Master Metals Engineered Post-Frame Division</p>
            </div>
            <div>
              <p className="mb-8">Client Acceptance Signature: _______________________</p>
              <p>Date Accepted: _______________________</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
