import React from 'react';

/**
 * Calculates whether dark text (#0f172a) or white text (#ffffff) provides higher contrast
 * against a given background hex color, based on standard relative luminance (WCAG 2.1).
 */
export function getContrastingTextColor(hexColor: string): '#ffffff' | '#0f172a' {
  if (!hexColor) return '#ffffff';
  let hex = hexColor.replace('#', '').trim();
  if (hex.length === 3) {
    hex = hex.split('').map((c) => c + c).join('');
  }
  if (hex.length !== 6) {
    return '#ffffff';
  }
  const r = parseInt(hex.substring(0, 2), 16);
  const g = parseInt(hex.substring(2, 4), 16);
  const b = parseInt(hex.substring(4, 6), 16);

  if (isNaN(r) || isNaN(g) || isNaN(b)) {
    return '#ffffff';
  }

  // Relative luminance according to WCAG 2.1 sRGB specification:
  const sR = r / 255 <= 0.03928 ? r / 255 / 12.92 : Math.pow((r / 255 + 0.055) / 1.055, 2.4);
  const sG = g / 255 <= 0.03928 ? g / 255 / 12.92 : Math.pow((g / 255 + 0.055) / 1.055, 2.4);
  const sB = b / 255 <= 0.03928 ? b / 255 / 12.92 : Math.pow((b / 255 + 0.055) / 1.055, 2.4);
  const luminance = 0.2126 * sR + 0.7152 * sG + 0.0722 * sB;

  // Threshold ~0.35 ensures optimal contrast ratio for both light and dark colors
  return luminance > 0.35 ? '#0f172a' : '#ffffff';
}

export interface ColorOptionPillProps {
  name: 'Roof' | 'Siding' | 'Trims' | 'Wainscot' | string;
  color: string;
  colorName?: string;
  onClick?: () => void;
  isActive?: boolean;
  size?: 'xs' | 'sm' | 'md' | 'lg';
  className?: string;
  showColorNameTooltip?: boolean;
  id?: string;
}

export const ColorOptionPill: React.FC<ColorOptionPillProps> = ({
  name,
  color,
  colorName,
  onClick,
  isActive = false,
  size = 'md',
  className = '',
  showColorNameTooltip = true,
  id,
}) => {
  const sizeClasses = {
    xs: 'px-2 py-0.5 text-[10px] min-w-[56px] gap-1',
    sm: 'px-2.5 py-1 text-xs min-w-[68px] gap-1.5',
    md: 'px-3.5 py-1 sm:py-1.5 text-xs font-bold min-w-[80px] gap-2',
    lg: 'px-4 py-2 text-sm font-bold min-w-[96px] gap-2.5',
  }[size];

  const dotSizeClasses = {
    xs: 'w-2.5 h-2.5',
    sm: 'w-3 h-3',
    md: 'w-3.5 h-3.5',
    lg: 'w-4 h-4',
  }[size];

  const titleText = colorName
    ? `${name}: ${colorName} (${color})`
    : `${name}: ${color}`;

  const commonClassNames = `
    inline-flex items-center justify-center text-center font-bold rounded-full
    transition-all select-none shadow-md shadow-black/40
    bg-gradient-to-b from-[#1E293B] via-[#162032] to-[#0F172A]
    border border-slate-600/80 text-slate-100
    ${sizeClasses}
    ${isActive ? 'ring-2 ring-[#0284C7] ring-offset-1 ring-offset-[#0F172A] border-[#0284C7] shadow-[#0284C7]/25 shadow-lg scale-105' : 'hover:border-[#0284C7]/80 hover:from-[#243249] hover:to-[#141f32]'}
    ${className}
  `.trim();

  if (onClick) {
    return (
      <button
        id={id}
        type="button"
        onClick={onClick}
        className={`${commonClassNames} cursor-pointer active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0284C7]`}
        title={showColorNameTooltip ? `${titleText} — Click to customize` : undefined}
        aria-label={`${name} color: ${colorName || color}`}
      >
        <span
          className={`${dotSizeClasses} rounded-full shrink-0 border border-white/80 shadow-xs ring-1 ring-black/40`}
          style={{ backgroundColor: color }}
        />
        <span className="truncate tracking-wide text-slate-100">{name}</span>
      </button>
    );
  }

  return (
    <span
      id={id}
      className={commonClassNames}
      title={showColorNameTooltip ? titleText : undefined}
      aria-label={`${name} color: ${colorName || color}`}
    >
      <span
        className={`${dotSizeClasses} rounded-full shrink-0 border border-white/80 shadow-xs ring-1 ring-black/40`}
        style={{ backgroundColor: color }}
      />
      <span className="truncate tracking-wide text-slate-100">{name}</span>
    </span>
  );
};
