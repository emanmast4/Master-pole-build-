import React, { useState } from 'react';
import { AppSettings, UnitPricingRates } from '../types';
import { DEFAULT_UNIT_RATES, DEFAULT_APP_SETTINGS } from '../utils/constants';
import {
  X,
  RotateCcw,
  Check,
  DollarSign,
  Sliders,
  Settings,
  Moon,
  Sun,
  Monitor,
  Ruler,
  Layers,
  Sparkles,
  Eye,
  ShieldCheck,
  Volume2,
  VolumeX,
  Gauge,
  Box,
  Compass
} from 'lucide-react';

interface AppSettingsModalProps {
  settings: AppSettings;
  rates: UnitPricingRates;
  onUpdateSettings: (settings: AppSettings) => void;
  onUpdateRates: (rates: UnitPricingRates) => void;
  onClose: () => void;
  onOpenPricingManager?: () => void;
}

export const AppSettingsModal: React.FC<AppSettingsModalProps> = ({
  settings,
  rates,
  onUpdateSettings,
  onUpdateRates,
  onClose,
  onOpenPricingManager,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'app_ui' | 'component_prices'>('app_ui');

  const handleRateChange = (key: keyof UnitPricingRates, val: number) => {
    onUpdateRates({
      ...rates,
      [key]: val,
    });
  };

  const handleSettingChange = <K extends keyof AppSettings>(key: K, val: AppSettings[K]) => {
    const updated = {
      ...settings,
      [key]: val,
    };
    onUpdateSettings(updated);
  };

  const handleResetRatesDefaults = () => {
    onUpdateRates({ ...DEFAULT_UNIT_RATES });
  };

  const handleResetSettingsDefaults = () => {
    onUpdateSettings({ ...DEFAULT_APP_SETTINGS });
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#075985]/40 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white border border-sky-200/80 rounded-3xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 transition-all text-[#075985]">
        
        {/* Top Header */}
        <div className="bg-white/95 backdrop-blur-md px-6 py-4 border-b border-sky-100 flex items-center justify-between transition-colors text-[#075985] shadow-xs">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-full bg-cyan-50 text-[#06B6D4] border border-cyan-200 shadow-sm">
              <Settings className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#075985] flex items-center gap-2">
                System Preferences & Component Pricing
              </h3>
              <p className="text-xs text-[#0369A1]/80">
                Customize app UI behavior, display units, and component material unit rates.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-[#0369A1] hover:text-[#075985] rounded-full hover:bg-sky-100 cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-90 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Navigation Tabs */}
        <div className="bg-sky-50/40 px-6 py-3 border-b border-sky-100 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveSubTab('app_ui')}
              className={`relative px-4 py-2 rounded-full text-xs font-bold transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] flex items-center gap-2 cursor-pointer active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
                activeSubTab === 'app_ui'
                  ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] shadow-sm font-black ring-2 ring-[#06B6D4]/30'
                  : 'group bg-white text-[#0369A1] hover:text-[#075985] hover:bg-sky-50 border border-sky-200/80 shadow-2xs font-semibold'
              }`}
            >
              <Sliders className={`w-4 h-4 transition-colors ${activeSubTab === 'app_ui' ? 'text-[#06B6D4]' : 'text-[#0369A1]'}`} />
              <span className={activeSubTab === 'app_ui' ? 'text-[#075985] font-black' : ''}>App & Display Settings</span>
              {activeSubTab === 'app_ui' && (
                <span className="absolute -bottom-[2px] inset-x-3 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
              )}
            </button>

            <button
              onClick={() => setActiveSubTab('component_prices')}
              className={`relative px-4 py-2 rounded-full text-xs font-bold transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] flex items-center gap-2 cursor-pointer active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
                activeSubTab === 'component_prices'
                  ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] shadow-sm font-black ring-2 ring-[#06B6D4]/30'
                  : 'group bg-white text-[#0369A1] hover:text-[#075985] hover:bg-sky-50 border border-sky-200/80 shadow-2xs font-semibold'
              }`}
            >
              <DollarSign className={`w-4 h-4 transition-colors ${activeSubTab === 'component_prices' ? 'text-[#06B6D4]' : 'text-[#0369A1]'}`} />
              <span className={activeSubTab === 'component_prices' ? 'text-[#075985] font-black' : ''}>Component Prices & Unit Rates</span>
              {activeSubTab === 'component_prices' && (
                <span className="absolute -bottom-[2px] inset-x-3 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
              )}
            </button>
          </div>

          {activeSubTab === 'component_prices' ? (
            <button
              onClick={handleResetRatesDefaults}
              className="text-xs flex items-center gap-1.5 px-4 py-1.5 rounded-full text-[#075985] hover:text-[#0c4a6e] bg-white hover:bg-sky-50 border border-sky-200 cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-95 font-bold shadow-xs focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4]"
              title="Reset all prices to standard regional market averages"
            >
              <RotateCcw className="w-3.5 h-3.5 text-[#06B6D4]" />
              <span>Reset Prices</span>
            </button>
          ) : (
            <button
              onClick={handleResetSettingsDefaults}
              className="text-xs flex items-center gap-1.5 px-4 py-1.5 rounded-full text-[#075985] hover:text-[#0c4a6e] bg-white hover:bg-sky-50 border border-sky-200 cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-95 font-bold shadow-xs focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4]"
            >
              <RotateCcw className="w-3.5 h-3.5 text-[#06B6D4]" />
              <span>Reset UI Settings</span>
            </button>
          )}
        </div>

        {/* Scrollable Body Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-slate-800">
          {activeSubTab === 'app_ui' && (
            <div className="space-y-6">
              {/* 1. Theme & Appearance */}
              <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-xs space-y-4">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <h4 className="text-sm font-bold text-[#0F172A] flex items-center gap-2">
                    <Sun className="w-4 h-4 text-[#0284C7]" />
                    <span>App Theme & Visual Appearance</span>
                  </h4>
                  <span className="text-xs text-slate-500">Live Color Scheme</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <button
                    onClick={() => handleSettingChange('theme', 'dark')}
                    className={`relative p-3.5 rounded-2xl border text-left transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] cursor-pointer flex items-center gap-3 active:scale-95 hover:scale-[1.02] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
                      settings.theme === 'dark'
                        ? 'bg-cyan-50 border-2 border-[#06B6D4] text-[#075985] font-black shadow-sm ring-2 ring-[#06B6D4]/30'
                        : 'bg-white border-sky-200/80 hover:border-sky-300 font-semibold text-[#0369A1]'
                    }`}
                  >
                    <div className="p-2.5 rounded-full bg-[#075985] text-white">
                      <Moon className="w-4 h-4 text-cyan-300" />
                    </div>
                    <div>
                      <span className="text-xs font-bold block text-[#075985]">Dark Mode</span>
                      <span className="text-[10px] text-[#0369A1]/70 block">High contrast CAD mode</span>
                    </div>
                    {settings.theme === 'dark' && (
                      <span className="absolute -bottom-[2px] inset-x-3 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
                    )}
                  </button>

                  <button
                    onClick={() => handleSettingChange('theme', 'light')}
                    className={`relative p-3.5 rounded-2xl border text-left transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] cursor-pointer flex items-center gap-3 active:scale-95 hover:scale-[1.02] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
                      settings.theme === 'light'
                        ? 'bg-cyan-50 border-2 border-[#06B6D4] text-[#075985] font-black shadow-sm ring-2 ring-[#06B6D4]/30'
                        : 'bg-white border-sky-200/80 hover:border-sky-300 font-semibold text-[#0369A1]'
                    }`}
                  >
                    <div className="p-2.5 rounded-full bg-cyan-50 text-[#06B6D4]">
                      <Sun className="w-4 h-4 text-[#06B6D4]" />
                    </div>
                    <div>
                      <span className="text-xs font-bold block text-[#075985]">Light Mode</span>
                      <span className="text-[10px] text-[#0369A1]/70 block">Bright studio canvas</span>
                    </div>
                    {settings.theme === 'light' && (
                      <span className="absolute -bottom-[2px] inset-x-3 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
                    )}
                  </button>

                  <button
                    onClick={() => handleSettingChange('theme', 'system')}
                    className={`relative p-3.5 rounded-2xl border text-left transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] cursor-pointer flex items-center gap-3 active:scale-95 hover:scale-[1.02] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
                      settings.theme === 'system'
                        ? 'bg-cyan-50 border-2 border-[#06B6D4] text-[#075985] font-black shadow-sm ring-2 ring-[#06B6D4]/30'
                        : 'bg-white border-sky-200/80 hover:border-sky-300 font-semibold text-[#0369A1]'
                    }`}
                  >
                    <div className="p-2.5 rounded-full bg-sky-100 text-[#075985]">
                      <Monitor className="w-4 h-4 text-[#075985]" />
                    </div>
                    <div>
                      <span className="text-xs font-bold block text-[#075985]">System Auto</span>
                      <span className="text-[10px] text-[#0369A1]/70 block">Match OS preference</span>
                    </div>
                    {settings.theme === 'system' && (
                      <span className="absolute -bottom-[2px] inset-x-3 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
                    )}
                  </button>
                </div>
              </div>

              {/* 2. Units of Measurement */}
              <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-xs space-y-4">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <h4 className="text-sm font-bold text-[#0F172A] flex items-center gap-2">
                    <Ruler className="w-4 h-4 text-[#0284C7]" />
                    <span>Units of Measurement</span>
                  </h4>
                  <span className="text-xs text-slate-500">Dimensions Display</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    onClick={() => handleSettingChange('unitSystem', 'imperial')}
                    className={`p-3.5 rounded-lg border text-left transition-all cursor-pointer flex items-center justify-between ${
                      settings.unitSystem === 'imperial'
                        ? 'bg-sky-50 border-[#0284C7] text-[#0284C7] font-bold shadow-xs'
                        : 'bg-white border-slate-200'
                    }`}
                  >
                    <div>
                      <span className="text-xs font-bold block text-[#0F172A]">Imperial System (Feet & Inches)</span>
                      <span className="text-[10px] text-slate-500 block">e.g. 30' W x 40' L x 14' H, 4:12 Pitch</span>
                    </div>
                    <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-800">FT / IN</span>
                  </button>

                  <button
                    onClick={() => handleSettingChange('unitSystem', 'metric')}
                    className={`p-3.5 rounded-lg border text-left transition-all cursor-pointer flex items-center justify-between ${
                      settings.unitSystem === 'metric'
                        ? 'bg-sky-50 border-[#0284C7] text-[#0284C7] font-bold shadow-xs'
                        : 'bg-white border-slate-200'
                    }`}
                  >
                    <div>
                      <span className="text-xs font-bold block text-[#0F172A]">Metric System (Meters)</span>
                      <span className="text-[10px] text-slate-500 block">e.g. 9.14m W x 12.19m L x 4.27m H</span>
                    </div>
                    <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-800">M / CM</span>
                  </button>
                </div>
              </div>

              {/* 3. 3D Engine & Canvas Controls */}
              <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-xs space-y-4">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <h4 className="text-sm font-bold text-[#0F172A] flex items-center gap-2">
                    <Box className="w-4 h-4 text-[#0284C7]" />
                    <span>3D Renderer & Canvas Overlay Settings</span>
                  </h4>
                  <span className="text-xs text-slate-500">Viewport Engine</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Shadow Quality */}
                  <div className="p-3 bg-white rounded-lg border border-slate-200 flex items-center justify-between shadow-xs">
                    <div>
                      <span className="text-xs font-bold block text-[#0F172A]">Lighting & Dynamic Shadows</span>
                      <span className="text-[10px] text-slate-500">High-detail solar shadows in 3D scene</span>
                    </div>
                    <button
                      onClick={() => handleSettingChange('renderQuality', settings.renderQuality === 'high' ? 'fast' : 'high')}
                      className={`px-3 py-1 rounded-full text-xs font-bold cursor-pointer transition-all ${
                        settings.renderQuality === 'high'
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {settings.renderQuality === 'high' ? 'High Quality' : 'Performance'}
                    </button>
                  </div>

                  {/* 3D Dimensions Overlay */}
                  <div className="p-3 bg-white rounded-lg border border-slate-200 flex items-center justify-between shadow-xs">
                    <div>
                      <span className="text-xs font-bold block text-[#0F172A]">3D Dimension Labels</span>
                      <span className="text-[10px] text-slate-500">Overlay width, length, and peak height markers</span>
                    </div>
                    <button
                      onClick={() => handleSettingChange('showDimensions3D', !settings.showDimensions3D)}
                      className={`px-3 py-1 rounded-full text-xs font-bold cursor-pointer transition-all ${
                        settings.showDimensions3D
                          ? 'bg-[#0F172A] text-white shadow-xs'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {settings.showDimensions3D ? 'Visible' : 'Hidden'}
                    </button>
                  </div>

                  {/* Grid Floor */}
                  <div className="p-3 bg-white rounded-lg border border-slate-200 flex items-center justify-between shadow-xs">
                    <div>
                      <span className="text-xs font-bold block text-[#0F172A]">3D Floor Grid Plane</span>
                      <span className="text-[10px] text-slate-500">Ground reference grid lines in 3D</span>
                    </div>
                    <button
                      onClick={() => handleSettingChange('showGrid3D', !settings.showGrid3D)}
                      className={`px-3 py-1 rounded-full text-xs font-bold cursor-pointer transition-all ${
                        settings.showGrid3D
                          ? 'bg-[#0F172A] text-white shadow-xs'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {settings.showGrid3D ? 'On' : 'Off'}
                    </button>
                  </div>

                  {/* Auto Rotate Camera */}
                  <div className="p-3 bg-white rounded-lg border border-slate-200 flex items-center justify-between shadow-xs">
                    <div>
                      <span className="text-xs font-bold block text-[#0F172A]">Auto Orbit Turntable</span>
                      <span className="text-[10px] text-slate-500">Continuous slow rotation preview when idle</span>
                    </div>
                    <button
                      onClick={() => handleSettingChange('autoRotate3D', !settings.autoRotate3D)}
                      className={`px-3 py-1 rounded-full text-xs font-bold cursor-pointer transition-all ${
                        settings.autoRotate3D
                          ? 'bg-[#0F172A] text-white shadow-xs'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {settings.autoRotate3D ? 'Active' : 'Disabled'}
                    </button>
                  </div>
                </div>
              </div>

              {/* 4. UI Behavior & Sound */}
              <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-xs space-y-4">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <h4 className="text-sm font-bold text-[#0F172A] flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-[#0284C7]" />
                    <span>Interface Behavior & Sound</span>
                  </h4>
                  <span className="text-xs text-slate-500">Quick Toggles</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-3 bg-white rounded-lg border border-slate-200 flex items-center justify-between shadow-xs">
                    <div>
                      <span className="text-xs font-bold block text-[#0F172A]">Live Floating Total Bar</span>
                      <span className="text-[10px] text-slate-500">Bottom price counter badge</span>
                    </div>
                    <button
                      onClick={() => handleSettingChange('showFloatingPriceBar', !settings.showFloatingPriceBar)}
                      className={`px-3 py-1 rounded-full text-xs font-bold cursor-pointer transition-all ${
                        settings.showFloatingPriceBar
                          ? 'bg-[#0F172A] text-white shadow-xs'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {settings.showFloatingPriceBar ? 'Enabled' : 'Hidden'}
                    </button>
                  </div>

                  <div className="p-3 bg-white rounded-lg border border-slate-200 flex items-center justify-between shadow-xs">
                    <div>
                      <span className="text-xs font-bold block text-[#0F172A]">Interactive Click Haptics / Sound</span>
                      <span className="text-[10px] text-slate-500">Audio feedback on options selection</span>
                    </div>
                    <button
                      onClick={() => handleSettingChange('soundEffects', !settings.soundEffects)}
                      className={`px-3 py-1 rounded-full text-xs font-bold cursor-pointer transition-all flex items-center gap-1.5 ${
                        settings.soundEffects
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {settings.soundEffects ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
                      <span>{settings.soundEffects ? 'Sound On' : 'Muted'}</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeSubTab === 'component_prices' && (
            <div className="space-y-6">
              {/* Comprehensive Trim & Component Pricing Quick Launch Banner */}
              <div className="p-4 bg-gradient-to-r from-sky-50 to-cyan-50 border border-cyan-200/90 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-2xs">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-cyan-100/80 text-[#0284C7] shrink-0">
                    <DollarSign className="w-5 h-5 stroke-[2.5]" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-[#075985]">
                      Full Pole Barn Trim & Component Pricing Manager
                    </h4>
                    <p className="text-[11px] text-[#0369A1] leading-relaxed">
                      Itemize and adjust every single piece: Rat Guard, Double Angle, Overhead Door wraps, Track Covers, Drip Caps, J-Channel, F&J trim, Ridge Cap, Snow Guards, and closures.
                    </p>
                  </div>
                </div>

                {onOpenPricingManager && (
                  <button
                    type="button"
                    onClick={onOpenPricingManager}
                    className="px-4 py-2 rounded-full text-xs font-bold bg-[#06B6D4] hover:bg-[#0891b2] text-white cursor-pointer shadow-xs active:scale-95 transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] whitespace-nowrap shrink-0 flex items-center gap-1.5 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4]"
                  >
                    <Sliders className="w-3.5 h-3.5" />
                    <span>Open Full Trim Manager</span>
                  </button>
                )}
              </div>

              {/* Section A: Truss Engineering Rates */}
              <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-xs space-y-4">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <h4 className="text-sm font-bold text-[#0284C7] uppercase tracking-wider flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#0284C7]" />
                    Adaptive Truss Pricing Variables
                  </h4>
                  <span className="text-xs text-slate-500">Width & Pitch Formula Constants</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  <div>
                    <label className="text-xs text-slate-600 block mb-1">
                      Truss Base Rate ($ / Lin Ft Span)
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.25"
                        value={rates.trussBasePerFootSpan}
                        onChange={(e) => handleRateChange('trussBasePerFootSpan', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">Multiplied directly by building width</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">
                      Pitch Slope Multiplier Weight
                    </label>
                    <input
                      type="number"
                      step="0.05"
                      value={rates.trussPitchMultiplierWeight}
                      onChange={(e) => handleRateChange('trussPitchMultiplierWeight', Number(e.target.value))}
                      className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                    />
                    <span className="text-[10px] text-slate-500 block mt-1">Scales lumber cost for steeper pitches (rise/12)</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">
                      Heavy Snow Load Step Factor
                    </label>
                    <input
                      type="number"
                      step="0.02"
                      value={rates.trussHeavyLoadFactor}
                      onChange={(e) => handleRateChange('trussHeavyLoadFactor', Number(e.target.value))}
                      className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                    />
                    <span className="text-[10px] text-slate-500 block mt-1">Chord lumber resizing per 20 PSF step</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">
                      Gusset Steel Plates Set ($ / truss)
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="1"
                        value={rates.trussGussetPlateBase}
                        onChange={(e) => handleRateChange('trussGussetPlateBase', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">Heavy stamped gang-nail metal connector plates</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">
                      Truss Delivery Freight & Crane Setup ($)
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="25"
                        value={rates.trussDeliveryCraneSetup}
                        onChange={(e) => handleRateChange('trussDeliveryCraneSetup', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">Wide-load hauling and hydraulic crane rigging</span>
                  </div>
                </div>
              </div>

              {/* Section B: Steel Siding & Roofing Sheeting */}
              <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-xs space-y-4">
                <h4 className="text-sm font-bold text-[#0F172A] uppercase tracking-wider flex items-center gap-2 border-b border-slate-200 pb-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#0284C7]" />
                  Metal Siding & Roofing Panels ($ / sq ft)
                </h4>

                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                  <div>
                    <label className="text-xs text-slate-600 block mb-1">29-Ga Ribbed Siding</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.10"
                        value={rates.siding29gaPerSqFt}
                        onChange={(e) => handleRateChange('siding29gaPerSqFt', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">26-Ga Commercial Siding</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.10"
                        value={rates.siding26gaPerSqFt}
                        onChange={(e) => handleRateChange('siding26gaPerSqFt', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Wainscot Accent Panels</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.10"
                        value={rates.wainscotPerSqFt ?? 4.05}
                        onChange={(e) => handleRateChange('wainscotPerSqFt', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Ribbed Roof Steel</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.10"
                        value={rates.roofRibbedSteelPerSqFt}
                        onChange={(e) => handleRateChange('roofRibbedSteelPerSqFt', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Standing Seam Roof</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.25"
                        value={rates.roofStandingSeamPerSqFt}
                        onChange={(e) => handleRateChange('roofStandingSeamPerSqFt', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Woodgrip Screws ($/250 Box)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="1.00"
                        value={rates.woodgripScrewsBoxRate ?? 38.00}
                        onChange={(e) => handleRateChange('woodgripScrewsBoxRate', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Lap Stitch Screws ($/250 Box)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="1.00"
                        value={rates.stitchScrewsBoxRate ?? 32.00}
                        onChange={(e) => handleRateChange('stitchScrewsBoxRate', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Fasteners & Screws ($/sq ft)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.05"
                        value={rates.fastenersScrewsPerSqFt}
                        onChange={(e) => handleRateChange('fastenersScrewsPerSqFt', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Section C: Pole Barn Trims & Flashing Pieces */}
              <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-xs space-y-4">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <h4 className="text-sm font-bold text-[#0F172A] uppercase tracking-wider flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#06B6D4]" />
                    Pole Barn Architectural Trims & Flashing
                  </h4>
                  <span className="text-[11px] font-mono text-[#0284C7] font-semibold">20+ Items</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Rat Guard Base Trim ($ / LF)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.10"
                        value={rates.ratGuardRate ?? 2.50}
                        onChange={(e) => handleRateChange('ratGuardRate', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">Splash plank skirt board base</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Wainscot Double Angle ($ / LF)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.10"
                        value={rates.doubleAngleRate ?? 2.75}
                        onChange={(e) => handleRateChange('doubleAngleRate', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">Lower/upper panel transition drip ledge</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Overhead Door Top Header Wrap ($ / Piece)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="1.00"
                        value={rates.overheadDoorTopWrapRate ?? 32.00}
                        onChange={(e) => handleRateChange('overheadDoorTopWrapRate', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">Wraps horizontal door header</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Overhead Door Side Jamb Wrap ($ / Piece)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="1.00"
                        value={rates.overheadDoorSideWrapRate ?? 32.00}
                        onChange={(e) => handleRateChange('overheadDoorSideWrapRate', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">Wraps vertical side studs/posts</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Sliding Barn Door Side Jambs ($ / Piece)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="1.00"
                        value={rates.slidingDoorSideWrapRate ?? 32.00}
                        onChange={(e) => handleRateChange('slidingDoorSideWrapRate', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">Vertical side jamb protective cover</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Sliding Door Track Cover ($ / Piece)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="1.00"
                        value={rates.slidingDoorTrackCoverRate ?? 38.00}
                        onChange={(e) => handleRateChange('slidingDoorTrackCoverRate', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">Trolley track weather shield</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Window & Walk Door Drip Cap ($ / Piece)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="1.00"
                        value={rates.dripCapRate ?? 22.00}
                        onChange={(e) => handleRateChange('dripCapRate', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">Head flashing above frames</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">J-Channel (J-Trim) ($ / Piece)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="1.00"
                        value={rates.jChannelRate ?? 28.00}
                        onChange={(e) => handleRateChange('jChannelRate', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">Receives and hides raw cut edges</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">F&J Soffit Transition Trim ($ / Piece)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="1.00"
                        value={rates.fAndJTrimRate ?? 32.00}
                        onChange={(e) => handleRateChange('fAndJTrimRate', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">Bridges wall panel to soffit</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Outside Corner Flashing ($ / LF)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.10"
                        value={rates.outsideCornerRate ?? 3.25}
                        onChange={(e) => handleRateChange('outsideCornerRate', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">Outside 90° corner trim</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Low Eave Drip Edge ($ / Piece)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="1.00"
                        value={rates.dripEdgeRate ?? 28.00}
                        onChange={(e) => handleRateChange('dripEdgeRate', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">Eave water runoff deflector</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Metal Fascia Cover ($ / Piece)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="1.00"
                        value={rates.fasciaCoverRate ?? 35.00}
                        onChange={(e) => handleRateChange('fasciaCoverRate', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">Fascia board metal wrapper</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">1-Ft Soffit Panels ($ / 3' Sheet)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.50"
                        value={rates.soffitPanel1ftRate ?? 14.50}
                        onChange={(e) => handleRateChange('soffitPanel1ftRate', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">11½" pre-cut soffit sheets</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">2-Ft Soffit Panels ($ / 3' Sheet)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.50"
                        value={rates.soffitPanel2ftRate ?? 26.00}
                        onChange={(e) => handleRateChange('soffitPanel2ftRate', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">23½" pre-cut soffit sheets</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">6" Seamless Gutters ($ / LF)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.25"
                        value={rates.seamlessGutterRate ?? 8.50}
                        onChange={(e) => handleRateChange('seamlessGutterRate', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">Optional K-Style seamless gutters</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Downspout Assembly ($ / Unit)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="1.00"
                        value={rates.downspoutRate ?? 45.00}
                        onChange={(e) => handleRateChange('downspoutRate', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">10' pipe + elbows + splash shoe</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Residential Gable Rake ($ / LF)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.10"
                        value={rates.residentialRakeRate ?? 3.25}
                        onChange={(e) => handleRateChange('residentialRakeRate', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">Sloped gable rake edge trim</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Ridge Cap Flashing ($ / LF)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.10"
                        value={rates.ridgeCapRate ?? 3.50}
                        onChange={(e) => handleRateChange('ridgeCapRate', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">Roof peak apex flashing</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Vented Closure Foam ($ / 20' Roll)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="1.00"
                        value={rates.ventedClosureFoam20ftRate ?? 22.00}
                        onChange={(e) => handleRateChange('ventedClosureFoam20ftRate', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">Attic venting under ridge cap</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Continuous Snow Guard Rail ($ / LF)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.50"
                        value={rates.snowGuardRailRate ?? 12.50}
                        onChange={(e) => handleRateChange('snowGuardRailRate', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">Snow/ice retention roof rail</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Inside Foam Rib Closures ($ / Strip)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.25"
                        value={rates.insideClosuresStripRate ?? 4.50}
                        onChange={(e) => handleRateChange('insideClosuresStripRate', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">36" eave underside foam seal</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Outside Foam Rib Closures ($ / Strip)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.25"
                        value={rates.outsideClosuresStripRate ?? 4.50}
                        onChange={(e) => handleRateChange('outsideClosuresStripRate', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">36" ridge top foam seal</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Butyl Mastic Tape ($ / 45' Roll)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.50"
                        value={rates.butylTapeRollRate ?? 14.00}
                        onChange={(e) => handleRateChange('butylTapeRollRate', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">Panel lap adhesive sealant</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Hurricane Ties ($ / Tie)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.10"
                        value={rates.hurricaneTieRate ?? 2.85}
                        onChange={(e) => handleRateChange('hurricaneTieRate', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">Simpson H1 truss anchors</span>
                  </div>
                </div>
              </div>

              {/* Section D: Structural Framing Lumber & Headers */}
              <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-xs space-y-4">
                <h4 className="text-sm font-bold text-[#0F172A] uppercase tracking-wider flex items-center justify-between border-b border-slate-200 pb-2">
                  <span className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#0284C7]" />
                    Structural Framing Lumber & Headers ($ / lin ft)
                  </span>
                  <span className="text-[11px] font-mono text-[#0284C7] font-normal">8' O.C. Post Header Spec</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="text-xs text-slate-600 block mb-1">
                      2x12 Weight-Bearing Wall Headers ($ / LF)
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.10"
                        value={rates.trussCarriersPerLinFt}
                        onChange={(e) => handleRateChange('trussCarriersPerLinFt', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">#1 Structural 2x12 lumber for (2) 2x12 header beams</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">
                      6x6 Treated Structural Posts ($ / LF)
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.25"
                        value={rates.postsTreatedPerLinFt}
                        onChange={(e) => handleRateChange('postsTreatedPerLinFt', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">CCA/ACQ pressure-treated ground-contact columns</span>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">
                      Purlins & Wall Girts ($ / LF)
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.05"
                        value={rates.purlinsGirtsPerLinFt}
                        onChange={(e) => handleRateChange('purlinsGirtsPerLinFt', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">#2 SPF 2x4 & 2x6 framing runners</span>
                  </div>
                </div>
              </div>

              {/* Section E: Doors, Windows & Openings */}
              <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-xs space-y-4">
                <h4 className="text-sm font-bold text-[#0F172A] uppercase tracking-wider flex items-center gap-2 border-b border-slate-200 pb-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#0284C7]" />
                  Doors, Windows & Opening Hardware
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Overhead Door Base ($ / Sq Ft)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.50"
                        value={rates.overheadDoorBasePerSqFt}
                        onChange={(e) => handleRateChange('overheadDoorBasePerSqFt', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Overhead Door Insulated Add-On ($)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="10.00"
                        value={rates.overheadDoorInsulatedAddon}
                        onChange={(e) => handleRateChange('overheadDoorInsulatedAddon', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Standard Commercial Walk Door ($)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="15.00"
                        value={rates.walkDoorCommercialStandard}
                        onChange={(e) => handleRateChange('walkDoorCommercialStandard', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Deluxe Walk Door with Window ($)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="20.00"
                        value={rates.walkDoorInsulatedGlass}
                        onChange={(e) => handleRateChange('walkDoorInsulatedGlass', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Vinyl Sliding Window Unit ($)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="10.00"
                        value={rates.windowSliderStandard}
                        onChange={(e) => handleRateChange('windowSliderStandard', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Double Split Sliding Barn Door ($/pair)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="25.00"
                        value={rates.slidingBarnDoorDouble}
                        onChange={(e) => handleRateChange('slidingBarnDoorDouble', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Section F: Concrete & Foundation */}
              <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-xs space-y-4">
                <h4 className="text-sm font-bold text-[#0F172A] uppercase tracking-wider flex items-center gap-2 border-b border-slate-200 pb-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  Concrete Foundation & Earthwork ($ / sq ft)
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div>
                    <label className="text-xs text-slate-600 block mb-1">4" Slab with Fiber Mesh</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.25"
                        value={rates.concrete4inPerSqFt}
                        onChange={(e) => handleRateChange('concrete4inPerSqFt', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">6" Heavy Duty Rebar Slab</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.25"
                        value={rates.concrete6inPerSqFt}
                        onChange={(e) => handleRateChange('concrete6inPerSqFt', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Dirt / Compacted Gravel Prep</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.10"
                        value={rates.dirtGravelPrepPerSqFt}
                        onChange={(e) => handleRateChange('dirtGravelPrepPerSqFt', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Perma-Column Piers ($ / unit)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="5.00"
                        value={rates.piersPermaColumnPerUnit}
                        onChange={(e) => handleRateChange('piersPermaColumnPerUnit', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Section G: Interior, Insulation & Electrical */}
              <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-xs space-y-4">
                <h4 className="text-sm font-bold text-[#0F172A] uppercase tracking-wider flex items-center gap-2 border-b border-slate-200 pb-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                  Interior, Insulation & Electrical ($ / sq ft)
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Vapor Barrier Foil Insulation</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.05"
                        value={rates.insulationVaporBarrierPerSqFt}
                        onChange={(e) => handleRateChange('insulationVaporBarrierPerSqFt', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">R-19 Batt Insulation</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.10"
                        value={rates.insulationR19BattPerSqFt}
                        onChange={(e) => handleRateChange('insulationR19BattPerSqFt', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">2" Spray Foam Insulation</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.15"
                        value={rates.insulationSprayFoam2inPerSqFt}
                        onChange={(e) => handleRateChange('insulationSprayFoam2inPerSqFt', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Steel Liner Panel (Walls/Ceiling)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.10"
                        value={rates.linerSteelPerSqFt}
                        onChange={(e) => handleRateChange('linerSteelPerSqFt', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">OSB / Plywood Interior Liner</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.10"
                        value={rates.linerOsbPerSqFt}
                        onChange={(e) => handleRateChange('linerOsbPerSqFt', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Basic Workshop Electrical</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.15"
                        value={rates.electricalBasicPerSqFt}
                        onChange={(e) => handleRateChange('electricalBasicPerSqFt', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Deluxe Commercial 200A Electrical</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.25"
                        value={rates.electricalDeluxePerSqFt}
                        onChange={(e) => handleRateChange('electricalDeluxePerSqFt', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Mezzanine Storage Loft</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.50"
                        value={rates.loftPerSqFt}
                        onChange={(e) => handleRateChange('loftPerSqFt', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Section H: Labor & Contingency Margin */}
              <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-xs space-y-4">
                <h4 className="text-sm font-bold text-[#0F172A] uppercase tracking-wider flex items-center gap-2 border-b border-slate-200 pb-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-purple-500" />
                  Labor Crew & Overhead Margin
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Framing Crew Labor ($ / sq ft)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.25"
                        value={rates.laborFramingPerSqFt}
                        onChange={(e) => handleRateChange('laborFramingPerSqFt', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Siding & Roof Labor ($ / sq ft)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs">$</span>
                      <input
                        type="number"
                        step="0.25"
                        value={rates.laborSidingRoofPerSqFt}
                        onChange={(e) => handleRateChange('laborSidingRoofPerSqFt', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-600 block mb-1">Contractor Margin / Contingency (%)</label>
                    <div className="relative">
                      <input
                        type="number"
                        step="1"
                        value={rates.contingencyMarginPercent}
                        onChange={(e) => handleRateChange('contingencyMarginPercent', Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-sm text-[#0F172A] font-mono focus:border-[#0284C7] focus:outline-none shadow-xs"
                      />
                      <span className="absolute right-3 top-2 text-slate-400 text-xs">%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex items-center justify-between transition-colors">
          <span className="text-xs text-emerald-700 flex items-center gap-1.5 font-medium">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Settings and prices apply instantly to CAD Engine & Estimate</span>
          </span>

          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-full text-xs font-bold bg-[#0F172A] hover:bg-slate-800 text-white cursor-pointer shadow-md active:scale-95 transition-all flex items-center gap-2"
          >
            <Check className="w-4 h-4" />
            <span>Save & Apply</span>
          </button>
        </div>
      </div>
    </div>
  );
};
