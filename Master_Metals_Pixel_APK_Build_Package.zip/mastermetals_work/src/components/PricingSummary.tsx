import React from 'react';
import { PricingBreakdown } from '../types';
import { 
  DollarSign, 
  Sliders, 
  TrendingUp, 
  ShieldCheck,
  Layers
} from 'lucide-react';

interface PricingSummaryProps {
  pricing: PricingBreakdown;
  onOpenUnitPricing?: () => void;
  onOpenBom?: () => void;
  onOpenQuote?: () => void;
}

export const PricingSummary: React.FC<PricingSummaryProps> = ({
  pricing,
  onOpenUnitPricing,
}) => {
  const {
    squareFootage,
    grandTotal,
    subtotal,
    contractorMarginAmount,
    costPerSquareFoot,
    trussPackageCost,
    roofSheetingCost,
    wallSidingCost,
    wainscotCost,
    trimAndFastenersCost,
    framingStructureCost,
    foundationCost,
    openingsCost,
    leanToCost,
    interiorCost,
    laborCost,
  } = pricing;

  const costCategories = [
    { label: 'Estimated Trusses & Freight', amount: trussPackageCost, highlight: true },
    { label: 'Roof Sheeting & Trim', amount: roofSheetingCost + trimAndFastenersCost },
    { label: 'Wall Siding & Wainscot', amount: wallSidingCost + wainscotCost },
    { 
      label: 'Structural Timber Framing', 
      amount: framingStructureCost,
      sublabel: `Includes (2) 2x12 headers on weight-bearing walls ($${pricing.weightBearingHeaders?.totalHeaderCost?.toLocaleString() || '0'})`
    },
    { label: 'Foundation & Earthwork', amount: foundationCost },
    { label: 'Doors & Windows Package', amount: openingsCost },
    ...(leanToCost > 0 ? [{ label: 'Lean-to Porch Extension', amount: leanToCost }] : []),
    ...(interiorCost > 0 ? [{ label: 'Interior, Liner & Electric', amount: interiorCost }] : []),
    { label: 'Erection & Installation Labor', amount: laborCost },
  ];

  return (
    <div id="pricing-summary-card" className="bg-white border border-sky-100 rounded-3xl p-5 sm:p-6 shadow-sm hover:shadow-md flex flex-col justify-between space-y-5 transition-all duration-300 text-[#075985]">
      {/* Total Banner */}
      <div>
        <div className="flex items-baseline justify-between gap-2 bg-sky-50/50 p-4 rounded-2xl border border-sky-100 shadow-2xs">
          <div className="text-3xl sm:text-4xl font-black text-[#075985] font-mono tracking-tight">
            ${grandTotal.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
          </div>
          <div className="text-right">
            <span className="text-sm font-bold text-[#075985] font-mono">${costPerSquareFoot}</span>
            <span className="text-[11px] text-[#0369A1]/80 block font-sans">/ sq ft est.</span>
          </div>
        </div>

        <p className="mt-3 rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-[11px] leading-relaxed text-amber-900">
          Preliminary estimate only. Unit rates are configurable assumptions, not verified live supplier quotes. Confirm prices, takeoff quantities, engineering, freight, taxes, and local code requirements before ordering or quoting a customer.
        </p>

        <div className="mt-3 text-xs text-[#0369A1] flex items-center justify-between px-1 font-mono">
          <span className="font-bold text-[#075985]">{squareFootage.toLocaleString()} SQ FT Footprint</span>
          <span className="text-[#0284C7] font-semibold">Preliminary Materials + Labor Estimate</span>
        </div>
      </div>

      {/* Category Breakdown List */}
      <div className="space-y-2.5 border-t border-b border-sky-100 py-4 text-xs">
        <div className="flex items-center justify-between text-[11px] font-bold text-[#0369A1] uppercase tracking-wider mb-1">
          <span>Component Breakdown</span>
          <span>Cost ($)</span>
        </div>

        {costCategories.map((cat) => {
          const pct = Math.round((cat.amount / grandTotal) * 100);
          return (
            <div key={cat.label} className="group">
              <div className="flex justify-between items-center text-[#0369A1] group-hover:text-[#075985] transition-colors">
                <span className={`truncate mr-2 ${cat.highlight ? 'text-[#075985] font-bold' : 'font-medium'}`}>
                  {cat.label}
                </span>
                <span className="font-mono font-bold text-[#075985] shrink-0">
                  ${cat.amount.toLocaleString()}
                </span>
              </div>
              {cat.sublabel && (
                <div className="text-[10px] text-[#0284C7] font-mono mt-0.5">
                  {cat.sublabel}
                </div>
              )}

              {/* Progress bar */}
              <div className="w-full h-1.5 bg-sky-100/60 rounded-full mt-1.5 overflow-hidden border border-sky-200/50">
                <div
                  className={`h-full rounded-full transition-all duration-300 ${
                    cat.highlight ? 'bg-gradient-to-r from-[#06B6D4] to-[#38BDF8]' : 'bg-sky-300'
                  }`}
                  style={{ width: `${Math.max(2, pct)}%` }}
                />
              </div>
            </div>
          );
        })}

        {/* Subtotal & Margin */}
        <div className="pt-2 mt-2 border-t border-sky-100 flex justify-between text-[11px] text-[#0369A1] font-mono">
          <span>Direct Material & Labor:</span>
          <span className="font-bold text-[#075985]">${subtotal.toLocaleString()}</span>
        </div>
        <div className="flex justify-between text-[11px] text-[#0369A1] font-mono">
          <span>Contractor Contingency/Margin:</span>
          <span className="text-[#0284C7] font-bold">+${contractorMarginAmount.toLocaleString()}</span>
        </div>
      </div>

      {/* Quick Action Footer */}
      {onOpenUnitPricing && (
        <div className="pt-2 border-t border-sky-100">
          <button
            onClick={onOpenUnitPricing}
            className="w-full py-2.5 text-center text-xs text-[#075985] hover:text-[#0c4a6e] flex items-center justify-center gap-2 transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-95 cursor-pointer rounded-full bg-cyan-50/70 hover:bg-cyan-100 border border-cyan-200/90 font-bold shadow-2xs focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4]"
            title="Open the pricing manager to change the unit price of every component and trim piece"
          >
            <Sliders className="w-4 h-4 text-[#06B6D4]" />
            <span>Change Every Component & Trim Price</span>
          </button>
        </div>
      )}
    </div>
  );
};
