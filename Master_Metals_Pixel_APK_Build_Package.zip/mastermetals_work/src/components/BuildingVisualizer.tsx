import React, { useState, useRef } from 'react';
import { CustomBuildingState, PricingBreakdown, WallOpening, WallSide } from '../types';
import { DEFAULT_BUILDING_STATE } from '../utils/constants';
import { Interactive3DBuilding } from './Interactive3DBuilding';
import { DetailedFloorPlan } from './DetailedFloorPlan';
import { TrussPricingCard } from './TrussPricingCard';
import { MasterCommandIsland } from './MasterCommandIsland';
import { CategoryNavigationTabs, CategoryTabId } from './CategoryNavigationTabs';
import { ColorOptionPill } from './ColorOptionPill';
import { getRoofProfileY } from './agPanel3d';
import { 
  Eye, 
  Layers, 
  Maximize2, 
  Ruler, 
  ZoomIn, 
  ZoomOut, 
  RefreshCcw,
  Compass,
  Orbit
} from 'lucide-react';

interface BuildingVisualizerProps {
  state: CustomBuildingState;
  pricing: PricingBreakdown;
  selectedSide?: WallSide;
  onSelectSide?: (side: WallSide) => void;
  viewMode?: ViewMode;
  onSelectViewMode?: (mode: ViewMode) => void;
  onUpdateDimensions?: (dimensions: { length: number; width: number; eaveHeight: number }) => void;
  onOpenCategoryModal?: (tabId: CategoryTabId) => void;
  activeTab?: string;
  onReset?: () => void;
  onOpenBom?: () => void;
  onOpenLiveQuote?: () => void;
  onOpenUnitRates?: () => void;
  onUpdateState?: (updater: (prev: CustomBuildingState) => CustomBuildingState) => void;
}

export type ViewMode = '3d_interactive' | 'floor_plan' | 'truss_details' | 'front_elevation' | 'side_elevation';

export const BuildingVisualizer: React.FC<BuildingVisualizerProps> = ({
  state,
  pricing,
  selectedSide = 'front',
  onSelectSide,
  viewMode: controlledViewMode,
  onSelectViewMode,
  onUpdateDimensions,
  onOpenCategoryModal,
  activeTab = 'style_size',
  onReset,
  onOpenBom,
  onOpenLiveQuote,
  onOpenUnitRates,
  onUpdateState,
}) => {
  const [internalViewMode, setInternalViewMode] = useState<ViewMode>('3d_interactive');
  const viewMode = controlledViewMode ?? internalViewMode;
  const setViewMode = (mode: ViewMode) => {
    if (onSelectViewMode) {
      onSelectViewMode(mode);
    } else {
      setInternalViewMode(mode);
    }
  };
  const [showDimensions, setShowDimensions] = useState<boolean>(true);
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [isAutoRotating, setIsAutoRotating] = useState<boolean>(false);
  const [showFraming, setShowFraming] = useState<boolean>(false);
  const [isPanMode, setIsPanMode] = useState<boolean>(false);
  const cameraControlsRef = useRef<{ zoom: (factor: number) => void; reset: () => void } | null>(null);

  const handleCameraZoom = (factor: number) => {
    if (cameraControlsRef.current) {
      cameraControlsRef.current.zoom(factor);
    }
  };

  const handleResetCamera = () => {
    if (cameraControlsRef.current) {
      cameraControlsRef.current.reset();
    }
    handleResetZoom();
    if (onReset) {
      onReset();
    } else if (onUpdateState) {
      onUpdateState((prev) => ({
        ...DEFAULT_BUILDING_STATE,
        unitRates: prev.unitRates || DEFAULT_BUILDING_STATE.unitRates,
      }));
    }
  };

  const { style = 'gable', dimensions, materials, openings, leanTo, walls } = state;
  const { width, length, eaveHeight, roofPitch, trussSpacing } = dimensions;
  const { apexPeakHeightFt } = pricing.trusses;

  // Colors
  const sidingColor = materials.sidingColor;
  const wainscotColor = materials.wainscotColor;
  const roofColor = materials.roofColor;
  const trimColor = materials.trimColor;
  const cornerTrimColor = materials.customTrimColorsEnabled && materials.cornerTrimColor ? materials.cornerTrimColor : trimColor;
  const eaveTrimColor = materials.customTrimColorsEnabled && materials.eaveTrimColor ? materials.eaveTrimColor : trimColor;
  const rakeTrimColor = materials.customTrimColorsEnabled && materials.rakeTrimColor ? materials.rakeTrimColor : trimColor;
  const ridgeCapColor = materials.customTrimColorsEnabled && materials.ridgeCapColor ? materials.ridgeCapColor : trimColor;
  const doorTrimColor = materials.customTrimColorsEnabled && materials.doorTrimColor ? materials.doorTrimColor : trimColor;
  const wainscotCapColor = materials.customTrimColorsEnabled && materials.wainscotCapColor ? materials.wainscotCapColor : trimColor;
  const hasWainscot = Object.values(walls).some((w) => w.hasWainscot);

  // SVG canvas dimensions
  const svgWidth = 800;
  const svgHeight = 440;

  // Zoom controls
  const handleZoom = (delta: number) => {
    setZoomLevel((prev) => Math.min(1.8, Math.max(0.7, Number((prev + delta).toFixed(1)))));
  };

  const handleResetZoom = () => setZoomLevel(1);

  // Helper to render opening in 2D elevation
  const renderElevationOpening = (
    op: WallOpening,
    scaleX: number,
    scaleY: number,
    wallBaseY: number,
    wallLeftX: number
  ) => {
    const x = wallLeftX + op.positionOffsetFt * scaleX;
    const w = op.widthFt * scaleX;
    const h = op.heightFt * scaleY;
    const sillHeightFt = op.bottomOffsetFt ?? (op.type === 'window' ? 3 : 0);
    const y = wallBaseY - (sillHeightFt + op.heightFt) * scaleY;

    if (op.type === 'overhead_door') {
      const panelCount = Math.max(3, Math.round(op.heightFt / 2.5));
      return (
        <g key={op.id}>
          {/* Door Frame */}
          <rect x={x} y={y} width={w} height={h} fill="#1e293b" stroke={trimColor} strokeWidth="2.5" rx="1" />
          {/* Panels */}
          {Array.from({ length: panelCount }).map((_, idx) => (
            <line
              key={idx}
              x1={x}
              y1={y + (h / panelCount) * (idx + 1)}
              x2={x + w}
              y2={y + (h / panelCount) * (idx + 1)}
              stroke="#475569"
              strokeWidth="1.5"
            />
          ))}
          {/* Vertical center track */}
          <line x1={x + w / 2} y1={y} x2={x + w / 2} y2={y + h} stroke="#334155" strokeWidth="1" strokeDasharray="2 2" />
          {/* Window inserts if enabled */}
          {op.hasWindows && (
            <g>
              <rect x={x + 4} y={y + 6} width={w - 8} height={h / panelCount - 12} fill="#bae6fd" opacity="0.85" rx="1" />
              <line x1={x + w / 3} y1={y + 6} x2={x + w / 3} y2={y + 6 + (h / panelCount - 12)} stroke="#0284c7" strokeWidth="1" />
              <line x1={x + (w * 2) / 3} y1={y + 6} x2={x + (w * 2) / 3} y2={y + 6 + (h / panelCount - 12)} stroke="#0284c7" strokeWidth="1" />
            </g>
          )}
          {/* Label */}
          <text x={x + w / 2} y={y + h - 6} fill="#94a3b8" fontSize="9" textAnchor="middle" fontFamily="sans-serif">
            {op.widthFt}'x{op.heightFt}'
          </text>
        </g>
      );
    }

    if (op.type === 'walk_door') {
      return (
        <g key={op.id}>
          <rect x={x} y={y} width={w} height={h} fill="#0f172a" stroke={trimColor} strokeWidth="2" rx="1" />
          {op.insulated && (
            <rect x={x + 4} y={y + 6} width={w - 8} height={h * 0.4} fill="#bae6fd" opacity="0.8" rx="1" stroke="#38bdf8" strokeWidth="0.5" />
          )}
          {/* Handle */}
          <circle cx={x + w - 4} cy={y + h * 0.55} r="2" fill="#f59e0b" />
          <text x={x + w / 2} y={y + h + 11} fill="#94a3b8" fontSize="8" textAnchor="middle">
            {op.widthFt}'x{op.heightFt}'
          </text>
        </g>
      );
    }

    if (op.type === 'window') {
      const windowSillY = wallBaseY - (h + 3.5 * scaleY); // 3.5ft sill height
      return (
        <g key={op.id}>
          <rect x={x} y={windowSillY} width={w} height={h} fill="#38bdf8" opacity="0.8" stroke={trimColor} strokeWidth="2" rx="1" />
          <line x1={x + w / 2} y1={windowSillY} x2={x + w / 2} y2={windowSillY + h} stroke="#0369a1" strokeWidth="1" />
          <line x1={x} y1={windowSillY + h / 2} x2={x + w} y2={windowSillY + h / 2} stroke="#0369a1" strokeWidth="1" />
          <text x={x + w / 2} y={windowSillY - 4} fill="#94a3b8" fontSize="8" textAnchor="middle">
            {op.widthFt}'x{op.heightFt}'
          </text>
        </g>
      );
    }

    if (op.type === 'sliding_barn_door') {
      return (
        <g key={op.id}>
          {/* Overhead Track */}
          <line x1={x - 8} y1={y - 4} x2={x + w + 8} y2={y - 4} stroke="#94a3b8" strokeWidth="3" />
          {/* Split slider */}
          <rect x={x} y={y} width={w / 2 - 2} height={h} fill="#1e293b" stroke={trimColor} strokeWidth="1.5" />
          <rect x={x + w / 2 + 2} y={y} width={w / 2 - 2} height={h} fill="#1e293b" stroke={trimColor} strokeWidth="1.5" />
          {/* Crossbucks X */}
          <line x1={x} y1={y} x2={x + w / 2 - 2} y2={y + h} stroke="#475569" strokeWidth="1" />
          <line x1={x} y1={y + h} x2={x + w / 2 - 2} y2={y} stroke="#475569" strokeWidth="1" />
          <line x1={x + w / 2 + 2} y1={y} x2={x + w} y2={y + h} stroke="#475569" strokeWidth="1" />
          <line x1={x + w / 2 + 2} y1={y + h} x2={x + w} y2={y} stroke="#475569" strokeWidth="1" />
        </g>
      );
    }

    return null;
  };

  return (
    <div className="w-full flex flex-col items-center">
      {/* Unified Master Command Island */}
      <MasterCommandIsland
        state={state}
        pricing={pricing}
        viewMode={viewMode}
        onSelectViewMode={setViewMode}
        onReset={onReset}
        onOpenUnitRates={onOpenUnitRates}
        onOpenBom={onOpenBom}
        onOpenLiveQuote={onOpenLiveQuote}
        onUpdateDimensions={onUpdateDimensions}
        onOpenCategoryModal={onOpenCategoryModal}
        activeTab={activeTab as any}
        isAutoRotating={isAutoRotating}
        onToggleAutoRotate={() => setIsAutoRotating((prev) => !prev)}
        showFraming={showFraming}
        onToggleFraming={() => setShowFraming((prev) => !prev)}
        onZoomIn={() => (viewMode === '3d_interactive' ? handleCameraZoom(0.85) : handleZoom(0.1))}
        onZoomOut={() => (viewMode === '3d_interactive' ? handleCameraZoom(1.15) : handleZoom(-0.1))}
        onResetCamera={handleResetCamera}
        isPanMode={isPanMode}
        onTogglePan={() => {
          if (viewMode !== '3d_interactive') {
            setViewMode('3d_interactive');
          }
          setIsPanMode((prev) => !prev);
        }}
      />

      {/* Visualizer Canvas Card */}
      <div id="building-visualizer-container" className="w-full bg-white border border-slate-200/90 rounded-xl overflow-hidden shadow-[0_4px_6px_-1px_rgba(0,0,0,0.1),0_2px_4px_-2px_rgba(0,0,0,0.06)] flex flex-col transition-colors duration-200">
      {/* 2D Elevation View Options Bar (only shown for 2D Front/Side Elevation) */}
      {viewMode !== '3d_interactive' && viewMode !== 'floor_plan' && viewMode !== 'truss_details' && (
        <div className="bg-white px-4 sm:px-5 py-2.5 border-b border-slate-200 flex items-center justify-between gap-3 text-[#0F172A] transition-colors">
          <div className="text-xs font-bold text-[#0F172A] font-mono flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#0284C7] animate-pulse shadow-xs" />
            <span>{viewMode === 'front_elevation' ? 'Front Gable Elevation (2D CAD)' : 'Side Eave Elevation (2D CAD)'}</span>
          </div>

          {/* Unified 2D Elevation Controls Pill */}
          <div className="inline-flex items-center gap-1 bg-slate-50 p-1 rounded-lg border border-slate-200 shadow-xs">
            {/* Toggle Dimensions */}
            <button
              id="btn-toggle-dimensions"
              onClick={() => setShowDimensions(!showDimensions)}
              className={`p-1.5 px-2.5 rounded-md text-xs flex items-center gap-1.5 cursor-pointer transition-all active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0284C7] ${
                showDimensions
                  ? 'bg-sky-50 text-[#0F172A] border-2 border-[#0284C7] font-black shadow-xs ring-2 ring-[#0284C7]/25'
                  : 'group bg-white text-slate-500 hover:text-[#0F172A] hover:bg-slate-100 border border-slate-200'
              }`}
              title="Toggle Dimensions & Callouts"
            >
              <Ruler className={`w-3.5 h-3.5 transition-colors ${showDimensions ? 'text-[#0F172A]' : 'text-slate-400 group-hover:text-[#0F172A]'}`} />
              <span className={`hidden sm:inline ${showDimensions ? 'font-black text-[#0F172A]' : 'font-semibold text-slate-600'}`}>Dimensions</span>
            </button>

            <div className="h-4 w-px bg-slate-200 mx-0.5" />

            {/* Zoom Controls */}
            <button
              onClick={() => handleZoom(0.1)}
              className="p-1 text-slate-400 hover:text-[#0F172A] rounded-md hover:bg-slate-200/60 cursor-pointer transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0284C7]"
              title="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <span className="text-[11px] font-mono font-black text-[#0F172A] px-1">{Math.round(zoomLevel * 100)}%</span>
            <button
              onClick={() => handleZoom(-0.1)}
              className="p-1 text-slate-400 hover:text-[#0F172A] rounded-md hover:bg-slate-200/60 cursor-pointer transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0284C7]"
              title="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={handleResetZoom}
              className="p-1 text-slate-400 hover:text-[#0F172A] rounded-md hover:bg-slate-200/60 cursor-pointer transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0284C7]"
              title="Reset Zoom"
            >
              <RefreshCcw className="w-3 h-3" />
            </button>
          </div>
        </div>
      )}

      {/* Main Canvas Viewport */}
      {viewMode === 'floor_plan' ? (
        <DetailedFloorPlan state={state} pricing={pricing} />
      ) : viewMode === 'truss_details' ? (
        <div className="w-full flex flex-col">
          <div className="bg-white px-4 sm:px-6 py-2.5 border-b border-slate-200 flex items-center justify-between gap-3 text-[#0F172A]">
            <div className="flex items-center gap-2 text-xs font-mono font-bold text-[#0F172A]">
              <span className="w-2 h-2 rounded-full bg-[#0284C7] animate-pulse" />
              <span>Engineered Truss Details & Dynamic Pricing</span>
            </div>
            <button
              type="button"
              onClick={() => setViewMode('3d_interactive')}
              className="px-3.5 py-1 text-xs font-bold rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 shadow-xs cursor-pointer active:scale-95 transition-all"
            >
              ← Back to 3D Orbit
            </button>
          </div>
          <TrussPricingCard
            state={state}
            trussData={pricing.trusses}
            onUpdateState={onUpdateState || (() => {})}
            onOpenUnitPricing={onOpenUnitRates || (() => {})}
          />
        </div>
      ) : viewMode === '3d_interactive' ? (
        <div className="relative w-full flex flex-col select-none transition-colors">
          <Interactive3DBuilding
            state={state}
            pricing={pricing}
            selectedSide={selectedSide}
            onSelectSide={onSelectSide}
            onUpdateDimensions={onUpdateDimensions}
            onOpenCategoryModal={onOpenCategoryModal}
            activeTab={activeTab}
            isAutoRotating={isAutoRotating}
            onToggleAutoRotate={() => setIsAutoRotating((prev) => !prev)}
            showFraming={showFraming}
            onToggleFraming={() => setShowFraming((prev) => !prev)}
            isPanMode={isPanMode}
            onRegisterCameraControls={(ctrls) => {
              cameraControlsRef.current = ctrls;
            }}
          />
        </div>
      ) : (
        <div className="relative w-full h-[480px] bg-slate-50 flex items-center justify-center overflow-hidden select-none transition-colors">
          {/* Subtle CAD Grid background */}
          <div 
            className="absolute inset-0 pointer-events-none opacity-20"
            style={{
              backgroundImage: `
                linear-gradient(to right, #64748b 1px, transparent 1px),
                linear-gradient(to bottom, #64748b 1px, transparent 1px)
              `,
              backgroundSize: '24px 24px',
            }}
          />

              {/* View Details Watermark */}
              <div className="absolute top-3 left-4 pointer-events-none z-10 flex flex-col gap-0.5">
                <span className="text-xs font-bold text-[#0F172A] tracking-wider uppercase font-mono flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  {viewMode === 'front_elevation' && 'FRONT GABLE ELEVATION (2D CAD SCALE)'}
                  {viewMode === 'side_elevation' && 'SIDE EAVE ELEVATION (2D CAD SCALE)'}
                </span>
                <span className="text-[11px] text-slate-500 font-mono">
                  {width}' W × {length}' L × {eaveHeight}' H | Pitch: {roofPitch}:12 | Apex: +{apexPeakHeightFt}'
                </span>
              </div>

              {/* SVG Drawing Canvas */}
              <div 
                className="w-full h-full flex items-center justify-center transition-transform duration-200"
                style={{ transform: `scale(${zoomLevel})` }}
              >
          {/* FRONT ELEVATION 2D CAD VIEW */}
          {viewMode === 'front_elevation' && (
            <svg
              viewBox={`0 0 ${svgWidth} ${svgHeight}`}
              className="w-full h-full"
              preserveAspectRatio="xMidYMid meet"
            >
              {(() => {
                const groundY = 360;
                const scale = Math.min(8.5, 460 / width);
                const wallW = width * scale;
                const wallH = eaveHeight * scale;
                const leftX = (svgWidth - wallW) / 2;
                const rightX = leftX + wallW;
                const centerX = leftX + wallW / 2;
                const eaveY = groundY - wallH;
                const wainscotH = (materials.wainscotHeightFt || 3) * scale;

                // Profile polygon points calculated from dynamic style
                const pts: string[] = [];
                pts.push(`${leftX},${groundY}`);
                pts.push(`${rightX},${groundY}`);
                const sampleCount = 60;
                for (let i = sampleCount; i >= 0; i--) {
                  const xFt = (width / sampleCount) * i;
                  const xLocal = xFt - width / 2;
                  const yElevFt = style === 'commercial'
                    ? eaveHeight + (width / 2) * (roofPitch / 12) + 2.5
                    : getRoofProfileY(xLocal, width, eaveHeight, roofPitch, style);
                  const px = leftX + xFt * scale;
                  const py = groundY - yElevFt * scale;
                  pts.push(`${px.toFixed(1)},${py.toFixed(1)}`);
                }
                const polygonPoints = pts.join(' ');

                // Dynamic peak elevation
                const peakElevationFt = style === 'single_slope'
                  ? getRoofProfileY(-width / 2, width, eaveHeight, roofPitch, style)
                  : (style === 'commercial'
                    ? eaveHeight + (width / 2) * (roofPitch / 12) + 2.5
                    : getRoofProfileY(0, width, eaveHeight, roofPitch, style));
                const peakY = groundY - peakElevationFt * scale;
                const peakH = (peakElevationFt - eaveHeight) * scale;

                return (
                  <g>
                    {/* Ground line */}
                    <line x1="40" y1={groundY} x2="760" y2={groundY} stroke="#475569" strokeWidth="2" />
                    <text x="50" y={groundY + 16} fill="#64748b" fontSize="10" fontFamily="monospace">FINISHED GRADE</text>

                    {/* Siding Base Wall */}
                    <polygon
                      points={polygonPoints}
                      fill={sidingColor}
                      stroke={trimColor}
                      strokeWidth="2.5"
                    />

                    {/* 36" Ag-Panel 9" Major Ribs & 36" Lap Seams */}
                    <g pointerEvents="none">
                      {Array.from({ length: Math.floor(width / 0.75) }).map((_, rIdx) => {
                        const ribFt = (rIdx + 1) * 0.75;
                        if (ribFt >= width - 0.2) return null;
                        const rx = leftX + ribFt * scale;
                        const xLocal = ribFt - width / 2;
                        const ribTopElev = style === 'commercial'
                          ? eaveHeight + (width / 2) * (roofPitch / 12) + 2.5
                          : getRoofProfileY(xLocal, width, eaveHeight, roofPitch, style);
                        const wallTopAtX = groundY - ribTopElev * scale;
                        const isSeam = (rIdx + 1) % 4 === 0;
                        return (
                          <line
                            key={rIdx}
                            x1={rx}
                            y1={groundY}
                            x2={rx}
                            y2={wallTopAtX}
                            stroke={isSeam ? '#ffffff' : '#000000'}
                            strokeWidth={isSeam ? '1.5' : '0.8'}
                            opacity={isSeam ? 0.45 : 0.25}
                          />
                        );
                      })}
                    </g>

                    {/* Wainscot */}
                    {hasWainscot && (
                      <rect
                        x={leftX}
                        y={groundY - wainscotH}
                        width={wallW}
                        height={wainscotH}
                        fill={wainscotColor}
                        stroke={trimColor}
                        strokeWidth="1.5"
                      />
                    )}

                    {/* Roof Rake Trim & Fascia */}
                    {style === 'single_slope' ? (
                      <line
                        x1={leftX - 8}
                        y1={groundY - peakElevationFt * scale}
                        x2={rightX + 8}
                        y2={eaveY}
                        stroke={trimColor}
                        strokeWidth="4"
                      />
                    ) : style === 'commercial' ? (
                      <line
                        x1={leftX - 6}
                        y1={peakY}
                        x2={rightX + 6}
                        y2={peakY}
                        stroke={trimColor}
                        strokeWidth="5"
                      />
                    ) : style === 'monitor' ? (
                      <g>
                        {/* Center Monitor Rakes */}
                        <line x1={centerX - (width * 0.2) * scale} y1={eaveY - ((width * 0.2) * (roofPitch * 0.75 / 12) + Math.max(3.5, eaveHeight * 0.25)) * scale} x2={centerX} y2={peakY - 4} stroke={trimColor} strokeWidth="3.5" />
                        <line x1={centerX + (width * 0.2) * scale} y1={eaveY - ((width * 0.2) * (roofPitch * 0.75 / 12) + Math.max(3.5, eaveHeight * 0.25)) * scale} x2={centerX} y2={peakY - 4} stroke={trimColor} strokeWidth="3.5" />
                        {/* Wing Rakes */}
                        <line x1={leftX - 6} y1={eaveY + 2} x2={centerX - (width * 0.2) * scale} y2={eaveY - ((width * 0.2) * (roofPitch * 0.75 / 12)) * scale} stroke={trimColor} strokeWidth="3.5" />
                        <line x1={rightX + 6} y1={eaveY + 2} x2={centerX + (width * 0.2) * scale} y2={eaveY - ((width * 0.2) * (roofPitch * 0.75 / 12)) * scale} stroke={trimColor} strokeWidth="3.5" />
                      </g>
                    ) : (
                      <g>
                        {/* Finished Gable Rake & Under-Overhang Soffit Package */}
                        {(() => {
                          const ovPx = ((dimensions.overhangInches || 12) / 12) * scale;
                          const ovDrop = ovPx * (roofPitch / 12);
                          const rakeTrim = materials.rakeTrimColor || trimColor;
                          const soffitCol = materials.soffitColor || '#f8fafc';
                          const eaveDropY = eaveY + ovDrop;
                          const leftRakeX = leftX - ovPx;
                          const rightRakeX = rightX + ovPx;

                          return (
                            <g>
                              {/* 1. Metal Roofing Overhang Lip */}
                              <line x1={leftRakeX - 2} y1={eaveDropY - 3} x2={centerX} y2={peakY - 5} stroke={roofColor} strokeWidth="4" />
                              <line x1={rightRakeX + 2} y1={eaveDropY - 3} x2={centerX} y2={peakY - 5} stroke={roofColor} strokeWidth="4" />

                              {/* 2. Top Rake Flashing Flange (Lapping over roof metal) */}
                              <line x1={leftRakeX} y1={eaveDropY - 2} x2={centerX} y2={peakY - 3} stroke={rakeTrim} strokeWidth="2.5" />
                              <line x1={rightRakeX} y1={eaveDropY - 2} x2={centerX} y2={peakY - 3} stroke={rakeTrim} strokeWidth="2.5" />

                              {/* 3. Vertical Plumb Rake Fascia Drop Face (Architectural Trim Band) */}
                              <line x1={leftRakeX} y1={eaveDropY + 2} x2={centerX} y2={peakY + 1} stroke={rakeTrim} strokeWidth="6" strokeLinecap="round" />
                              <line x1={rightRakeX} y1={eaveDropY + 2} x2={centerX} y2={peakY + 1} stroke={rakeTrim} strokeWidth="6" strokeLinecap="round" />

                              {/* 4. Sloped Gable Soffit under Overhang */}
                              {ovPx > 0 && (
                                <g>
                                  {/* Left sloped soffit panel reveal */}
                                  <line x1={leftRakeX} y1={eaveDropY + 5} x2={leftX} y2={eaveY + 5} stroke={soffitCol} strokeWidth="3" />
                                  {/* Right sloped soffit panel reveal */}
                                  <line x1={rightRakeX} y1={eaveDropY + 5} x2={rightX} y2={eaveY + 5} stroke={soffitCol} strokeWidth="3" />

                                  {/* 5. Boxed Corner Return at Eave Corners */}
                                  <rect x={leftRakeX} y={eaveY} width={ovPx} height="8" rx="1" fill={rakeTrim} stroke="#0f172a" strokeWidth="0.5" />
                                  <rect x={rightX} y={eaveY} width={ovPx} height="8" rx="1" fill={rakeTrim} stroke="#0f172a" strokeWidth="0.5" />
                                </g>
                              )}

                              {/* 6. Mitered Ridge Peak Cap */}
                              <polygon points={`${centerX - 6},${peakY - 6} ${centerX + 6},${peakY - 6} ${centerX},${peakY - 10}`} fill={materials.ridgeCapColor || trimColor} />
                            </g>
                          );
                        })()}
                      </g>
                    )}

                    {/* Attached Lean-To Porch Extension (Front Elevation) */}
                    {leanTo.enabled && (() => {
                      const ltW = (leanTo.widthFt || 10) * scale;
                      const ltAttElev = Math.max(6.5, eaveHeight - (leanTo.dropBelowEaveFt ?? 2));
                      const ltAttY = groundY - ltAttElev * scale;
                      const ltOuterElev = leanTo.outerEaveHeightFt
                        ? Math.max(6.0, Math.min(ltAttElev - 0.5, leanTo.outerEaveHeightFt))
                        : Math.max(6.0, ltAttElev - ((leanTo.widthFt || 10) * ((leanTo.pitch || 2) / 12)));
                      const ltOuterH = ltOuterElev * scale;
                      const ltOuterY = groundY - ltOuterH;

                      if (leanTo.side === 'left') {
                        const ltOuterX = leftX - ltW;
                        return (
                          <g>
                            {leanTo.enclosed ? (
                              <polygon
                                points={`${leftX},${ltAttY} ${ltOuterX},${ltOuterY} ${ltOuterX},${groundY} ${leftX},${groundY}`}
                                fill={sidingColor}
                                stroke={trimColor}
                                strokeWidth="2"
                              />
                            ) : (
                              <>
                                <line x1={leftX} y1={ltAttY} x2={ltOuterX - 4} y2={ltOuterY} stroke={roofColor} strokeWidth="5" />
                                <rect x={ltOuterX - 3} y={ltOuterY} width="6" height={ltOuterH} fill={trimColor} />
                              </>
                            )}
                            <text x={ltOuterX - 8} y={(ltOuterY + groundY) / 2} fill="#fbbf24" fontSize="9" fontFamily="monospace" textAnchor="end">
                              PORCH ({leanTo.widthFt}'W × {ltOuterElev.toFixed(1)}'H)
                            </text>
                          </g>
                        );
                      } else if (leanTo.side === 'right') {
                        const ltOuterX = rightX + ltW;
                        return (
                          <g>
                            {leanTo.enclosed ? (
                              <polygon
                                points={`${rightX},${ltAttY} ${ltOuterX},${ltOuterY} ${ltOuterX},${groundY} ${rightX},${groundY}`}
                                fill={sidingColor}
                                stroke={trimColor}
                                strokeWidth="2"
                              />
                            ) : (
                              <>
                                <line x1={rightX} y1={ltAttY} x2={ltOuterX + 4} y2={ltOuterY} stroke={roofColor} strokeWidth="5" />
                                <rect x={ltOuterX - 3} y={ltOuterY} width="6" height={ltOuterH} fill={trimColor} />
                              </>
                            )}
                            <text x={ltOuterX + 8} y={(ltOuterY + groundY) / 2} fill="#fbbf24" fontSize="9" fontFamily="monospace" textAnchor="start">
                              PORCH ({leanTo.widthFt}'W × {ltOuterElev.toFixed(1)}'H)
                            </text>
                          </g>
                        );
                      } else if (leanTo.side === 'front') {
                        const hostW = width;
                        const ltL = Math.min(hostW, leanTo.lengthFt || hostW);
                        const maxOff = Math.max(0, hostW - ltL);
                        const ltOff = Math.max(0, Math.min(maxOff, leanTo.startOffsetFt ?? 0));
                        const ltStartX = leftX + ltOff * scale;
                        const ltLenPx = ltL * scale;

                        return (
                          <g>
                            <rect
                              x={ltStartX}
                              y={ltOuterY}
                              width={ltLenPx}
                              height={ltAttY - ltOuterY}
                              fill={roofColor}
                              opacity="0.85"
                              stroke={trimColor}
                              strokeWidth="2"
                            />
                            {Array.from({ length: Math.max(2, Math.ceil(ltL / 10) + 1) }).map((_, cIdx, arr) => {
                              const colX = ltStartX + (cIdx / (arr.length - 1)) * ltLenPx;
                              return <rect key={cIdx} x={colX - 3} y={ltOuterY} width="6" height={ltOuterH} fill={trimColor} />;
                            })}
                            <text x={ltStartX + ltLenPx / 2} y={ltOuterY - 6} fill="#fbbf24" fontSize="9" fontFamily="monospace" textAnchor="middle">
                              FRONT PORCH ({leanTo.widthFt}' DEEP × {ltL}' RUN • {ltOuterElev.toFixed(1)}' EAVE)
                            </text>
                          </g>
                        );
                      }
                      return null;
                    })()}

                    {/* Front Openings */}
                    {openings
                      .filter((op) => op.side === 'front')
                      .map((op) => renderElevationOpening(op, scale, scale, groundY, leftX))}

                    {/* CAD Dimensions */}
                    {showDimensions && (
                      <g className="font-mono">
                        {/* Width */}
                        <line x1={leftX} y1={groundY + 28} x2={rightX} y2={groundY + 28} stroke="#38bdf8" strokeWidth="1.5" />
                        <line x1={leftX} y1={groundY + 22} x2={leftX} y2={groundY + 34} stroke="#38bdf8" strokeWidth="1.5" />
                        <line x1={rightX} y1={groundY + 22} x2={rightX} y2={groundY + 34} stroke="#38bdf8" strokeWidth="1.5" />
                        <text x={centerX} y={groundY + 44} fill="#38bdf8" fontSize="12" fontWeight="bold" textAnchor="middle">
                          {width}' - 0" BUILDING WIDTH
                        </text>

                        {/* Eave Height */}
                        <line x1={leftX - 28} y1={groundY} x2={leftX - 28} y2={eaveY} stroke="#fbbf24" strokeWidth="1.5" />
                        <line x1={leftX - 34} y1={groundY} x2={leftX - 22} y2={groundY} stroke="#fbbf24" strokeWidth="1.5" />
                        <line x1={leftX - 34} y1={eaveY} x2={leftX - 22} y2={eaveY} stroke="#fbbf24" strokeWidth="1.5" />
                        <text x={leftX - 38} y={(groundY + eaveY) / 2} fill="#fbbf24" fontSize="11" fontWeight="bold" textAnchor="end">
                          {eaveHeight}' EAVE
                        </text>

                        {/* Total Peak Height */}
                        <line x1={rightX + 28} y1={groundY} x2={rightX + 28} y2={peakY} stroke="#a855f7" strokeWidth="1.5" />
                        <line x1={rightX + 22} y1={groundY} x2={rightX + 34} y2={groundY} stroke="#a855f7" strokeWidth="1.5" />
                        <line x1={rightX + 22} y1={peakY} x2={rightX + 34} y2={peakY} stroke="#a855f7" strokeWidth="1.5" />
                        <text x={rightX + 38} y={(groundY + peakY) / 2} fill="#c084fc" fontSize="11" fontWeight="bold" textAnchor="start">
                          {peakElevationFt.toFixed(1)}' TOTAL PEAK
                        </text>

                        {/* Pitch Triangle */}
                        <g transform={`translate(${centerX + 40}, ${eaveY - peakH * 0.4})`}>
                          <polygon points="0,0 30,0 30,16" fill="#38bdf8" opacity="0.3" stroke="#38bdf8" strokeWidth="1" />
                          <text x="14" y="-4" fill="#38bdf8" fontSize="10" textAnchor="middle">12</text>
                          <text x="36" y="12" fill="#38bdf8" fontSize="10">{roofPitch}</text>
                        </g>
                      </g>
                    )}
                  </g>
                );
              })()}
            </svg>
          )}

          {/* SIDE ELEVATION 2D CAD VIEW */}
          {viewMode === 'side_elevation' && (
            <svg
              viewBox={`0 0 ${svgWidth} ${svgHeight}`}
              className="w-full h-full"
              preserveAspectRatio="xMidYMid meet"
            >
              {(() => {
                const groundY = 360;
                const scale = Math.min(6.5, 540 / length);
                const wallL = length * scale;
                const wallH = eaveHeight * scale;
                const leftX = (svgWidth - wallL) / 2;
                const rightX = leftX + wallL;
                const eaveY = groundY - wallH;
                const wainscotH = (materials.wainscotHeightFt || 3) * scale;

                return (
                  <g>
                    {/* Ground line */}
                    <line x1="40" y1={groundY} x2="760" y2={groundY} stroke="#475569" strokeWidth="2" />
                    
                    {/* Eave Wall Siding */}
                    <rect
                      x={leftX}
                      y={eaveY}
                      width={wallL}
                      height={wallH}
                      fill={sidingColor}
                      stroke={trimColor}
                      strokeWidth="2"
                    />

                    {/* 36" Ag-Panel 9" Major Ribs & 36" Lap Seams */}
                    <g pointerEvents="none">
                      {Array.from({ length: Math.floor(length / 0.75) }).map((_, rIdx) => {
                        const ribFt = (rIdx + 1) * 0.75;
                        if (ribFt >= length - 0.2) return null;
                        const rx = leftX + ribFt * scale;
                        const isSeam = (rIdx + 1) % 4 === 0;
                        return (
                          <line
                            key={rIdx}
                            x1={rx}
                            y1={groundY}
                            x2={rx}
                            y2={eaveY}
                            stroke={isSeam ? '#ffffff' : '#000000'}
                            strokeWidth={isSeam ? '1.5' : '0.8'}
                            opacity={isSeam ? 0.45 : 0.25}
                          />
                        );
                      })}
                    </g>

                    {/* Wainscot */}
                    {hasWainscot && (
                      <rect
                        x={leftX}
                        y={groundY - wainscotH}
                        width={wallL}
                        height={wainscotH}
                        fill={wainscotColor}
                        stroke={trimColor}
                        strokeWidth="1.5"
                      />
                    )}

                    {/* Roof Fascia & Drip Edge Line (Clean eave without gutters by default) */}
                    {(() => {
                      const ovPx = ((dimensions.overhangInches || 12) / 12) * scale;
                      const rakeTrimCol = materials.rakeTrimColor || trimColor;
                      const fasciaTrimCol = materials.fasciaTrimColor || trimColor;
                      const dripEdgeCol = materials.dripEdgeColor || trimColor;
                      const soffitCol = materials.soffitColor || '#f8fafc';
                      const eaveLeftX = leftX - ovPx;
                      const eaveRightX = rightX + ovPx;
                      const totalEaveWidth = wallL + ovPx * 2;

                      return (
                        <g>
                          {/* Metal roofing sheet overhanging lip */}
                          <line x1={eaveLeftX - 3} y1={eaveY - 4} x2={eaveRightX + 3} y2={eaveY - 4} stroke={roofColor} strokeWidth="4" />
                          {/* Low eave drip edge flashing */}
                          <line x1={eaveLeftX - 2} y1={eaveY - 1} x2={eaveRightX + 2} y2={eaveY - 1} stroke={dripEdgeCol} strokeWidth="2" />
                          {/* Plumb metal fascia wrap */}
                          <rect x={eaveLeftX} y={eaveY} width={totalEaveWidth} height="7" fill={fasciaTrimCol} stroke="#0f172a" strokeWidth="0.5" />

                          {/* Front & Rear Rake Trim End Drops capping the eave corners */}
                          <rect x={eaveLeftX} y={eaveY - 2} width="4" height="10" fill={rakeTrimCol} />
                          <rect x={eaveRightX - 4} y={eaveY - 2} width="4" height="10" fill={rakeTrimCol} />

                          {/* Finished horizontal soffit reveal under eave */}
                          {ovPx > 0 && (
                            <line x1={eaveLeftX} y1={eaveY + 7} x2={eaveRightX} y2={eaveY + 7} stroke={soffitCol} strokeWidth="1.5" />
                          )}

                          {/* Optional gutters (only rendered if explicitly enabled) */}
                          {materials.hasGutters && (
                            <rect x={eaveLeftX - 2} y={eaveY - 1} width={totalEaveWidth + 4} height="8" rx="2" fill={materials.gutterColor || trimColor} stroke="#0f172a" strokeWidth="1" />
                          )}
                        </g>
                      );
                    })()}

                    {/* Side Openings */}
                    {openings
                      .filter((op) => op.side === 'right')
                      .map((op) => renderElevationOpening(op, scale, scale, groundY, leftX))}

                    {/* Lean-to Porch Side View */}
                    {leanTo.enabled && (() => {
                      const hostL = length;
                      const ltW = leanTo.widthFt || 10;
                      const ltWPx = ltW * scale;
                      const ltL = Math.min(hostL, leanTo.lengthFt || hostL);
                      const maxOff = Math.max(0, hostL - ltL);
                      const ltOff = Math.max(0, Math.min(maxOff, leanTo.startOffsetFt ?? 0));
                      const ltStartX = leftX + ltOff * scale;
                      const ltLenPx = ltL * scale;
                      const ltAttElev = Math.max(6.5, eaveHeight - (leanTo.dropBelowEaveFt ?? 2));
                      const ltAttY = groundY - ltAttElev * scale;
                      const ltOuterElev = leanTo.outerEaveHeightFt
                        ? Math.max(6.0, Math.min(ltAttElev - 0.5, leanTo.outerEaveHeightFt))
                        : Math.max(6.0, ltAttElev - (ltW * ((leanTo.pitch || 2) / 12)));
                      const ltOuterH = ltOuterElev * scale;
                      const ltOuterY = groundY - ltOuterH;

                      if (leanTo.side === 'front') {
                        // Projecting outward from Front (South) wall to the left
                        const porchOuterX = leftX - ltWPx;
                        return (
                          <g>
                            {leanTo.enclosed ? (
                              <polygon
                                points={`${leftX},${ltAttY} ${porchOuterX},${ltOuterY} ${porchOuterX},${groundY} ${leftX},${groundY}`}
                                fill={sidingColor}
                                stroke={trimColor}
                                strokeWidth="2"
                              />
                            ) : (
                              <>
                                <line x1={leftX} y1={ltAttY} x2={porchOuterX - 4} y2={ltOuterY} stroke={roofColor} strokeWidth="5" />
                                <rect x={porchOuterX - 3} y={ltOuterY} width="6" height={ltOuterH} fill={trimColor} />
                              </>
                            )}
                            <text x={porchOuterX - 8} y={(ltOuterY + groundY) / 2} fill="#fbbf24" fontSize="9" fontFamily="monospace" textAnchor="end">
                              FRONT PORCH ({ltW}'W × {ltOuterElev.toFixed(1)}'H)
                            </text>
                          </g>
                        );
                      } else if (leanTo.side === 'back') {
                        // Projecting outward from Back (North) wall to the right
                        const porchOuterX = rightX + ltWPx;
                        return (
                          <g>
                            {leanTo.enclosed ? (
                              <polygon
                                points={`${rightX},${ltAttY} ${porchOuterX},${ltOuterY} ${porchOuterX},${groundY} ${rightX},${groundY}`}
                                fill={sidingColor}
                                stroke={trimColor}
                                strokeWidth="2"
                              />
                            ) : (
                              <>
                                <line x1={rightX} y1={ltAttY} x2={porchOuterX + 4} y2={ltOuterY} stroke={roofColor} strokeWidth="5" />
                                <rect x={porchOuterX - 3} y={ltOuterY} width="6" height={ltOuterH} fill={trimColor} />
                              </>
                            )}
                            <text x={porchOuterX + 8} y={(ltOuterY + groundY) / 2} fill="#fbbf24" fontSize="9" fontFamily="monospace" textAnchor="start">
                              REAR PORCH ({ltW}'W × {ltOuterElev.toFixed(1)}'H)
                            </text>
                          </g>
                        );
                      } else {
                        // Lean-to running along right or left sidewall
                        return (
                          <g>
                            {/* Lean-to Porch Profile along Side */}
                            <rect
                              x={ltStartX}
                              y={ltOuterY}
                              width={ltLenPx}
                              height={ltOuterH}
                              fill={leanTo.enclosed ? sidingColor : 'none'}
                              stroke="#fbbf24"
                              strokeWidth="2"
                              strokeDasharray={leanTo.enclosed ? 'none' : '4 3'}
                              opacity={leanTo.enclosed ? 0.9 : 0.75}
                            />
                            {/* Columns */}
                            {!leanTo.enclosed &&
                              Array.from({ length: Math.max(2, Math.ceil(ltL / 10) + 1) }).map((_, cIdx, arr) => {
                                const colX = ltStartX + (cIdx / (arr.length - 1)) * ltLenPx;
                                return <rect key={cIdx} x={colX - 2.5} y={ltOuterY} width="5" height={ltOuterH} fill="#fbbf24" />;
                              })}
                            <text
                              x={ltStartX + ltLenPx / 2}
                              y={ltOuterY - 10}
                              fill="#fbbf24"
                              fontSize="10"
                              fontFamily="monospace"
                              textAnchor="middle"
                              fontWeight="bold"
                            >
                              + LEAN-TO ({leanTo.widthFt}' WIDE × {ltL}' LONG • {leanTo.side.toUpperCase()} WALL)
                            </text>
                          </g>
                        );
                      }
                    })()}

                    {/* Dimensions */}
                    {showDimensions && (
                      <g className="font-mono">
                        <line x1={leftX} y1={groundY + 28} x2={rightX} y2={groundY + 28} stroke="#38bdf8" strokeWidth="1.5" />
                        <line x1={leftX} y1={groundY + 22} x2={leftX} y2={groundY + 34} stroke="#38bdf8" strokeWidth="1.5" />
                        <line x1={rightX} y1={groundY + 22} x2={rightX} y2={groundY + 34} stroke="#38bdf8" strokeWidth="1.5" />
                        <text x={(leftX + rightX) / 2} y={groundY + 44} fill="#38bdf8" fontSize="12" fontWeight="bold" textAnchor="middle">
                          {length}' - 0" BUILDING LENGTH
                        </text>

                        {/* Truss Spacing Callout */}
                        <line x1={leftX} y1={eaveY - 24} x2={leftX + trussSpacing * scale} y2={eaveY - 24} stroke="#f59e0b" strokeWidth="1.5" />
                        <text x={leftX + (trussSpacing * scale) / 2} y={eaveY - 32} fill="#f59e0b" fontSize="10" textAnchor="middle">
                          {trussSpacing}' O.C. TRUSS SPACING
                        </text>
                      </g>
                    )}
                  </g>
                );
              })()}
            </svg>
          )}
        </div>
      </div>
      )}

      {/* Bottom Summary Bar for 2D Elevation & CAD Views */}
      {viewMode !== '3d_interactive' && (
        <div className="bg-white px-4 py-2.5 border-t border-slate-200 flex flex-wrap items-center justify-between text-xs text-slate-600 gap-2 font-mono transition-colors">
          <div className="flex items-center gap-4">
            <span>Footprint: <strong className="text-[#0F172A]">{pricing.squareFootage.toLocaleString()} sq ft</strong></span>
            <span>Trusses: <strong className="text-[#0284C7]">{pricing.trusses.totalTrussesNeeded} units</strong> ({dimensions.trussSpacing}' O.C.)</span>
            <span>Pitch: <strong className="text-[#0F172A]">{roofPitch}:12</strong> ({pricing.trusses.slopeFactor}x slope)</span>
          </div>
          <div className="flex items-center gap-1.5 sm:gap-2">
            <ColorOptionPill
              name="Roof"
              color={roofColor}
              colorName={materials.roofColorName}
              size="xs"
              onClick={() => onOpenCategoryModal && onOpenCategoryModal('materials')}
            />
            <ColorOptionPill
              name="Siding"
              color={sidingColor}
              colorName={materials.sidingColorName}
              size="xs"
              onClick={() => onOpenCategoryModal && onOpenCategoryModal('materials')}
            />
            {hasWainscot && (
              <ColorOptionPill
                name="Wainscot"
                color={wainscotColor}
                colorName={materials.wainscotColorName}
                size="xs"
                onClick={() => onOpenCategoryModal && onOpenCategoryModal('materials')}
              />
            )}
            <ColorOptionPill
              name="Trims"
              color={trimColor}
              colorName={materials.trimColorName}
              size="xs"
              onClick={() => onOpenCategoryModal && onOpenCategoryModal('materials')}
            />
          </div>
        </div>
      )}

      {/* Category Navigation Tabs for 2D elevation */}
      {(viewMode === 'front_elevation' || viewMode === 'side_elevation') && (
        <div className="w-full bg-white border-t border-slate-200/90 py-2 sm:py-2.5 flex items-center justify-center transition-colors">
          <CategoryNavigationTabs
            activeTab={activeTab as any}
            onOpenCategoryModal={onOpenCategoryModal}
            dimensions={dimensions}
          />
        </div>
      )}
      </div>
    </div>
  );
};
