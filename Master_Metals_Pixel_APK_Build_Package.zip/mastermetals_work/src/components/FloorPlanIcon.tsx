import React from 'react';

interface FloorPlanIconProps {
  className?: string;
  width?: number | string;
  height?: number | string;
  strokeWidth?: number;
}

/**
 * Architectural Floor Plan Icon
 * Precise vector replica of 1790221986724.png:
 * Symmetrical bounding viewBox matching standard icon proportions.
 */
export const FloorPlanIcon: React.FC<FloorPlanIconProps> = ({
  className = 'w-4 h-4',
  width,
  height,
  strokeWidth = 1.6,
}) => {
  return (
    <svg
      viewBox="18 18 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`inline-block shrink-0 ${className}`}
      style={{
        width,
        height,
      }}
      aria-hidden="true"
    >
      <g
        stroke="currentColor"
        strokeWidth={strokeWidth}
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        {/* === OUTER WALL PERIMETER (Double-line framing) === */}
        {/* Top wall framing */}
        <line x1="21" y1="21" x2="79" y2="21" strokeWidth={strokeWidth} />
        <line x1="21" y1="23.2" x2="79" y2="23.2" strokeWidth={strokeWidth * 0.85} />

        {/* Bottom wall framing */}
        <line x1="21" y1="76.8" x2="45" y2="76.8" strokeWidth={strokeWidth * 0.85} />
        <line x1="21" y1="79" x2="45" y2="79" strokeWidth={strokeWidth} />
        <line x1="53" y1="76.8" x2="79" y2="76.8" strokeWidth={strokeWidth * 0.85} />
        <line x1="53" y1="79" x2="79" y2="79" strokeWidth={strokeWidth} />

        {/* Left wall framing */}
        <line x1="21" y1="21" x2="21" y2="79" strokeWidth={strokeWidth} />
        <line x1="23.2" y1="21" x2="23.2" y2="79" strokeWidth={strokeWidth * 0.85} />

        {/* Right wall framing */}
        <line x1="76.8" y1="21" x2="76.8" y2="79" strokeWidth={strokeWidth * 0.85} />
        <line x1="79" y1="21" x2="79" y2="79" strokeWidth={strokeWidth} />

        {/* === INTERIOR PARTITION WALLS === */}
        <line x1="50" y1="23.2" x2="50" y2="44" strokeWidth={strokeWidth} />
        <line x1="50" y1="50" x2="76.8" y2="50" strokeWidth={strokeWidth} />
        <line x1="55" y1="54" x2="61" y2="54" strokeWidth={strokeWidth * 0.9} />
        <line x1="55" y1="54" x2="55" y2="67" strokeWidth={strokeWidth * 0.9} />
        <line x1="55" y1="67" x2="61" y2="67" strokeWidth={strokeWidth * 0.9} />
        <line x1="61" y1="67" x2="61" y2="76.8" strokeWidth={strokeWidth * 0.9} />

        {/* Center Pivot Point */}
        <circle cx="50" cy="50" r="1.3" fill="currentColor" />

        {/* === DOOR SWINGS === */}
        <path d="M 50 50 A 6 6 0 0 1 56 44" fill="none" strokeWidth={strokeWidth * 0.85} />
        <line x1="50" y1="50" x2="50" y2="44" strokeWidth={strokeWidth * 0.85} />

        <path d="M 61 57 A 6 6 0 0 1 67 63" fill="none" strokeWidth={strokeWidth * 0.85} />
        <line x1="61" y1="57" x2="61" y2="63" strokeWidth={strokeWidth * 0.85} />

        <path d="M 45 76.8 A 7 7 0 0 1 52 69.8" fill="none" strokeWidth={strokeWidth * 0.85} />
        <line x1="45" y1="76.8" x2="52" y2="76.8" strokeWidth={strokeWidth * 0.85} />

        {/* === BEDROOM FURNITURE === */}
        <rect x="63" y="28.5" width="13.8" height="15.5" rx="0.8" strokeWidth={strokeWidth * 0.9} />
        <line x1="73.5" y1="28.5" x2="73.5" y2="44" strokeWidth={strokeWidth * 0.8} />
        <rect x="74" y="30" width="2.4" height="5.5" rx="0.5" strokeWidth={strokeWidth * 0.75} />
        <rect x="74" y="37" width="2.4" height="5.5" rx="0.5" strokeWidth={strokeWidth * 0.75} />

        {/* === LIVING ROOM FURNITURE === */}
        <rect x="28" y="48.5" width="15" height="7.5" rx="0.8" strokeWidth={strokeWidth * 0.9} />
        <line x1="30.2" y1="48.5" x2="30.2" y2="56" strokeWidth={strokeWidth * 0.7} />
        <line x1="40.8" y1="48.5" x2="40.8" y2="56" strokeWidth={strokeWidth * 0.7} />
        <line x1="30.2" y1="51.2" x2="40.8" y2="51.2" strokeWidth={strokeWidth * 0.7} />

        <rect x="22" y="54" width="7.5" height="14" rx="0.8" strokeWidth={strokeWidth * 0.9} />
        <line x1="22" y1="56" x2="29.5" y2="56" strokeWidth={strokeWidth * 0.7} />
        <line x1="22" y1="65.5" x2="29.5" y2="65.5" strokeWidth={strokeWidth * 0.7} />
        <line x1="24.8" y1="56" x2="24.8" y2="65.5" strokeWidth={strokeWidth * 0.7} />

        <rect x="32.5" y="60.5" width="11.5" height="5.5" rx="0.6" strokeWidth={strokeWidth * 0.85} />

        {/* === STRUCTURAL POST / COLUMN NODES WITH (X) === */}
        {/* Corners */}
        <circle cx="21" cy="22.1" r="2.8" strokeWidth={strokeWidth * 0.9} />
        <circle cx="79" cy="22.1" r="2.8" strokeWidth={strokeWidth * 0.9} />
        <circle cx="21" cy="77.9" r="2.8" strokeWidth={strokeWidth * 0.9} />
        <circle cx="79" cy="77.9" r="2.8" strokeWidth={strokeWidth * 0.9} />

        {/* Mid-span Posts */}
        <circle cx="50" cy="22.1" r="2.8" strokeWidth={strokeWidth * 0.9} />
        <line x1="48.2" y1="20.3" x2="51.8" y2="23.9" strokeWidth={strokeWidth * 0.85} />
        <line x1="51.8" y1="20.3" x2="48.2" y2="23.9" strokeWidth={strokeWidth * 0.85} />

        <circle cx="21" cy="50" r="2.8" strokeWidth={strokeWidth * 0.9} />
        <line x1="19.2" y1="48.2" x2="22.8" y2="51.8" strokeWidth={strokeWidth * 0.85} />
        <line x1="22.8" y1="48.2" x2="19.2" y2="51.8" strokeWidth={strokeWidth * 0.85} />

        <circle cx="79" cy="50" r="2.8" strokeWidth={strokeWidth * 0.9} />
        <line x1="77.2" y1="48.2" x2="80.8" y2="51.8" strokeWidth={strokeWidth * 0.85} />
        <line x1="80.8" y1="48.2" x2="77.2" y2="51.8" strokeWidth={strokeWidth * 0.85} />

        <circle cx="39.5" cy="77.9" r="2.8" strokeWidth={strokeWidth * 0.9} />
        <line x1="37.7" y1="76.1" x2="41.3" y2="79.7" strokeWidth={strokeWidth * 0.85} />
        <line x1="41.3" y1="76.1" x2="37.7" y2="79.7" strokeWidth={strokeWidth * 0.85} />

        <circle cx="61" cy="77.9" r="2.8" strokeWidth={strokeWidth * 0.9} />
        <line x1="59.2" y1="76.1" x2="62.8" y2="79.7" strokeWidth={strokeWidth * 0.85} />
        <line x1="62.8" y1="76.1" x2="59.2" y2="79.7" strokeWidth={strokeWidth * 0.85} />
      </g>
    </svg>
  );
};
