import React from 'react';
import { CustomBuildingState, PricingBreakdown } from '../types';
import { ViewMode } from './BuildingVisualizer';
import { NAV_TABS, CategoryTabId } from './CategoryNavigationTabs';

export { NAV_TABS };

export interface MasterCommandIslandProps {
  state?: CustomBuildingState;
  pricing?: PricingBreakdown;
  viewMode: ViewMode;
  onSelectViewMode: (mode: ViewMode) => void;
  onReset?: () => void;
  onOpenUnitRates?: () => void;
  onOpenBom?: () => void;
  onOpenLiveQuote?: () => void;
  onUpdateDimensions?: (dimensions: { length: number; width: number; eaveHeight: number }) => void;
  onOpenCategoryModal?: (tabId: CategoryTabId) => void;
  activeTab?: CategoryTabId;
  isAutoRotating?: boolean;
  onToggleAutoRotate?: () => void;
  showFraming?: boolean;
  onToggleFraming?: () => void;
  onZoomIn?: () => void;
  onZoomOut?: () => void;
  onResetCamera?: () => void;
  isPanMode?: boolean;
  onTogglePan?: () => void;
}

// 1. Reset Camera Icon
const ResetCameraIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="1.8" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
    <polyline points="3 3 3 8 8 8" />
  </svg>
);

// 3. Auto-Rotate Icon (Play triangle + orbit swoosh arrow)
const AutoRotateIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="1.8" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    {/* Play triangle */}
    <polygon points="10 3.5 16 7.5 10 11.5" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />
    {/* Elliptical orbit curve */}
    <path d="M5.5 14.5 C5 18 19 18 18.5 14.5 C18 12.5 15.5 12 14 12" />
    {/* Arrow tip */}
    <polyline points="3 13 5.5 15 7.5 12.5" />
  </svg>
);

// 4. Layers Icon (Stacked 3 diamond sheets)
const LayersIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="1.8" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <path d="m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z" />
    <path d="m2 12 8.58 3.91a2 2 0 0 0 1.66 0L22 12" />
    <path d="m2 17 8.58 3.91a2 2 0 0 0 1.66 0L22 17" />
  </svg>
);

// 5. Zoom In Icon
const ZoomInIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="1.8" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <circle cx="11" cy="11" r="7.5" />
    <line x1="21" y1="21" x2="16.5" y2="16.5" />
    <line x1="11" y1="7.5" x2="11" y2="14.5" />
    <line x1="7.5" y1="11" x2="14.5" y2="11" />
  </svg>
);

// 6. Zoom Out Icon
const ZoomOutIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="1.8" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <circle cx="11" cy="11" r="7.5" />
    <line x1="21" y1="21" x2="16.5" y2="16.5" />
    <line x1="7.5" y1="11" x2="14.5" y2="11" />
  </svg>
);

export const MasterCommandIsland: React.FC<MasterCommandIslandProps> = ({
  isAutoRotating = false,
  onToggleAutoRotate,
  showFraming = false,
  onToggleFraming,
  onZoomIn,
  onZoomOut,
  onResetCamera,
}) => {
  return (
    <div 
      id="master-command-island"
      className="w-full max-w-2xl mx-auto bg-white border border-sky-100/90 rounded-full shadow-[0_10px_30px_-5px_rgba(3,105,161,0.08),0_4px_12px_-2px_rgba(3,105,161,0.04)] overflow-hidden transition-all mb-2 sm:mb-2.5 select-none"
    >
      <div className="flex items-center justify-center sm:justify-around gap-1 sm:gap-3 px-3 sm:px-6 py-1.5 sm:py-2 overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {/* 1. Reset */}
        <button
          id="island-btn-reset"
          type="button"
          onClick={onResetCamera}
          className="flex flex-col items-center justify-center gap-0.5 sm:gap-1 px-3 sm:px-4 py-1.5 rounded-full text-[#0369A1] hover:text-[#075985] hover:bg-sky-50/80 transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] cursor-pointer active:scale-90 hover:scale-105 shrink-0"
          title="Reset barn dimensions, colors, and camera to default"
          aria-label="Reset"
        >
          <ResetCameraIcon className="w-5 h-5 sm:w-6 sm:h-6 text-[#0369A1]" />
          <span className="text-[11px] sm:text-xs font-semibold tracking-tight whitespace-nowrap">Reset</span>
        </button>

        {/* 2. Auto-Rotate */}
        <button
          id="island-btn-auto-rotate"
          type="button"
          onClick={onToggleAutoRotate}
          className={`relative flex flex-col items-center justify-center gap-0.5 sm:gap-1 px-3 sm:px-4 py-1.5 rounded-full transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] cursor-pointer active:scale-90 hover:scale-105 shrink-0 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
            isAutoRotating
              ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] shadow-sm shadow-cyan-400/25 font-black ring-2 ring-[#06B6D4]/30'
              : 'text-[#0369A1] hover:text-[#075985] hover:bg-sky-50/80 border border-transparent'
          }`}
          title={isAutoRotating ? 'Pause 360° Auto-Rotate' : 'Start 360° Auto-Rotate'}
          aria-label="Auto-Rotate"
        >
          <AutoRotateIcon className={`w-5 h-5 sm:w-6 sm:h-6 transition-colors ${isAutoRotating ? 'text-[#06B6D4]' : 'text-[#0369A1]'}`} />
          <span className={`text-[11px] sm:text-xs tracking-tight whitespace-nowrap ${isAutoRotating ? 'font-black text-[#075985]' : 'font-semibold'}`}>Auto-Rotate</span>
          {isAutoRotating && (
            <span className="absolute -bottom-[2px] inset-x-3 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
          )}
        </button>

        {/* 3. Layers */}
        <button
          id="island-btn-layers"
          type="button"
          onClick={onToggleFraming}
          className={`relative flex flex-col items-center justify-center gap-0.5 sm:gap-1 px-3 sm:px-4 py-1.5 rounded-full transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] cursor-pointer active:scale-90 hover:scale-105 shrink-0 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
            showFraming
              ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] shadow-sm shadow-cyan-400/25 font-black ring-2 ring-[#06B6D4]/30'
              : 'text-[#0369A1] hover:text-[#075985] hover:bg-sky-50/80 border border-transparent'
          }`}
          title={showFraming ? 'Switch to Exterior Cladding Shell' : 'Inspect Framing & Structural Layers'}
          aria-label="Layers"
        >
          <LayersIcon className={`w-5 h-5 sm:w-6 sm:h-6 transition-colors ${showFraming ? 'text-[#06B6D4]' : 'text-[#0369A1]'}`} />
          <span className={`text-[11px] sm:text-xs tracking-tight whitespace-nowrap ${showFraming ? 'font-black text-[#075985]' : 'font-semibold'}`}>Layers</span>
          {showFraming && (
            <span className="absolute -bottom-[2px] inset-x-3 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
          )}
        </button>

        {/* Vertical Divider Line */}
        <div className="h-7 sm:h-8 w-px bg-sky-100 mx-1 sm:mx-2 self-center shrink-0" />

        {/* 4. Zoom In */}
        <button
          id="island-btn-zoom-in"
          type="button"
          onClick={onZoomIn}
          className="flex flex-col items-center justify-center gap-0.5 sm:gap-1 px-3 sm:px-4 py-1.5 rounded-full text-[#0369A1] hover:text-[#075985] hover:bg-sky-50/80 transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] cursor-pointer active:scale-90 hover:scale-105 shrink-0"
          title="Zoom In Closer"
          aria-label="Zoom In"
        >
          <ZoomInIcon className="w-5 h-5 sm:w-6 sm:h-6 text-[#0369A1]" />
          <span className="text-[11px] sm:text-xs font-semibold tracking-tight whitespace-nowrap">Zoom In</span>
        </button>

        {/* 5. Zoom Out */}
        <button
          id="island-btn-zoom-out"
          type="button"
          onClick={onZoomOut}
          className="flex flex-col items-center justify-center gap-0.5 sm:gap-1 px-3 sm:px-4 py-1.5 rounded-full text-[#0369A1] hover:text-[#075985] hover:bg-sky-50/80 transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] cursor-pointer active:scale-90 hover:scale-105 shrink-0"
          title="Zoom Out Further"
          aria-label="Zoom Out"
        >
          <ZoomOutIcon className="w-5 h-5 sm:w-6 sm:h-6 text-[#0369A1]" />
          <span className="text-[11px] sm:text-xs font-semibold tracking-tight whitespace-nowrap">Zoom Out</span>
        </button>
      </div>
    </div>
  );
};
