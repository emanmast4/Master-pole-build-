import React from 'react';

interface WireframeCubeIconProps {
  className?: string;
  width?: number | string;
  height?: number | string;
  strokeWidth?: number;
}

/**
 * Geometric Wireframe Cube 3D Icon
 * Direct 1:1 isometric wireframe construction matching Screenshot_20260924-000150.png:
 * Symmetrical 30° isometric projection with uniform strut widths.
 */
export const WireframeCubeIcon: React.FC<WireframeCubeIconProps> = ({
  className = 'w-4 h-4',
  width,
  height,
  strokeWidth = 1.7,
}) => {
  return (
    <svg
      viewBox="10 5 80 90"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`inline-block shrink-0 ${className}`}
      style={{
        width,
        height,
      }}
      aria-hidden="true"
    >
      <g
        stroke="currentColor"
        strokeWidth={strokeWidth}
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        {/* Outer Hexagon boundary */}
        <polygon points="50,7 88,28.9 88,71.1 50,93 12,71.1 12,28.9" />

        {/* Outer Center Y-fork dividing the 3 visible faces */}
        <line x1="50" y1="7" x2="50" y2="50" />
        <line x1="12" y1="71.1" x2="50" y2="50" />
        <line x1="88" y1="71.1" x2="50" y2="50" />

        {/* Inner Cutout 1: Top Face Rhombus */}
        <polygon points="50,15 80,32.3 50,49.6 20,32.3" strokeWidth={strokeWidth * 0.9} />

        {/* Inner Cutout 2: Left Face Rhomboid */}
        <polygon points="18,35 44,50 44,83 18,68" strokeWidth={strokeWidth * 0.9} />

        {/* Inner Cutout 3: Right Face Rhomboid */}
        <polygon points="56,50 82,35 82,68 56,83" strokeWidth={strokeWidth * 0.9} />

        {/* Double-strut internal detail lines */}
        <line x1="47.5" y1="15" x2="47.5" y2="46" strokeWidth={strokeWidth * 0.8} />
        <line x1="52.5" y1="15" x2="52.5" y2="46" strokeWidth={strokeWidth * 0.8} />
        <line x1="47" y1="52" x2="47" y2="83" strokeWidth={strokeWidth * 0.8} />
        <line x1="53" y1="52" x2="53" y2="83" strokeWidth={strokeWidth * 0.8} />
        <line x1="20" y1="35" x2="46" y2="50" strokeWidth={strokeWidth * 0.75} />
        <line x1="80" y1="35" x2="54" y2="50" strokeWidth={strokeWidth * 0.75} />
      </g>
    </svg>
  );
};
