import React, { useState } from 'react';
import { ItemizedBomLine, PricingBreakdown } from '../types';
import { X, Download, Layers, Check, Ruler, Scissors, Sliders } from 'lucide-react';

interface BillOfMaterialsModalProps {
  pricing: PricingBreakdown;
  buildingName: string;
  onClose: () => void;
  onOpenUnitPricing?: () => void;
}

export const BillOfMaterialsModal: React.FC<BillOfMaterialsModalProps> = ({
  pricing,
  buildingName,
  onClose,
  onOpenUnitPricing,
}) => {
  const [activeFilter, setActiveFilter] = useState<'all' | 'metal' | 'framing' | 'trims' | 'openings'>('all');
  const categories = Array.from(new Set(pricing.bom.map((item) => item.category)));

  const handleExportCSV = () => {
    const headers = [
      'Category',
      'Item Name',
      'Cut Length',
      'Panel Coverage',
      'Specification / Notes',
      'Quantity',
      'Unit',
      'Unit Price ($)',
      'Extended Total ($)',
    ];
    const csvCell = (value: string | number) => `"${String(value).replace(/"/g, '""')}"`;
    const rows = pricing.bom.map((b) => [
      csvCell(b.category),
      csvCell(b.item),
      csvCell(b.sheetLengthFormatted || (b.sheetLengthFt ? `${b.sheetLengthFt} ft` : '-')),
      csvCell(b.coverageWidthInches ? `${b.coverageWidthInches}" Net Coverage` : '-'),
      csvCell(b.description),
      String(b.quantity),
      csvCell(b.unit),
      b.unitPrice.toFixed(2),
      b.totalCost.toFixed(2),
    ]);

    const csvContent = '\uFEFF' + [headers.map(csvCell).join(','), ...rows.map((r) => r.join(','))].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${buildingName.toLowerCase().replace(/\s+/g, '_')}_BOM_CutSchedule.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredBom = pricing.bom.filter((item) => {
    if (activeFilter === 'metal') return item.isMetalSheet || item.category === 'Roof Sheeting' || item.category === 'Wall Siding';
    if (activeFilter === 'framing') return item.category === 'Trusses' || item.category === 'Framing Structure';
    if (activeFilter === 'trims') return item.category === 'Trim & Fasteners';
    if (activeFilter === 'openings') return item.category === 'Doors & Windows';
    return true;
  });

  const filteredCategories = Array.from(new Set(filteredBom.map((item) => item.category)));
  const takeoff = pricing.metalTakeoff;

  return (
    <div className="fixed inset-0 z-50 bg-[#075985]/40 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white border border-sky-200/80 rounded-3xl w-full max-w-5xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 transition-all text-[#075985]">
        {/* Header */}
        <div className="bg-white/95 backdrop-blur-md px-6 py-4 border-b border-sky-100 flex items-center justify-between transition-colors text-[#075985] shadow-xs">
          <div>
            <h3 className="text-base sm:text-lg font-bold text-[#075985]">
              Bill of Materials & Manufacturing Cut Schedule
            </h3>
            <p className="text-xs sm:text-sm text-[#0369A1]/80 font-medium">
              {buildingName} — {pricing.squareFootage.toLocaleString()} Sq Ft • Metal panels calculated at 36" Net Coverage
            </p>
            <p className="mt-1 text-[11px] leading-relaxed text-amber-800">
              Preliminary takeoff only — verify all quantities, cut lengths, structural specifications, and supplier pricing against approved plans before ordering.
            </p>
            {pricing.validationWarnings && pricing.validationWarnings.length > 0 && (
              <div className="mt-2 rounded-lg border border-amber-300 bg-amber-50 p-2 text-[11px] text-amber-900">
                <strong>Configuration checks to resolve:</strong>
                <ul className="mt-1 list-disc pl-4 space-y-0.5">
                  {pricing.validationWarnings.map((warning, index) => <li key={`${index}-${warning}`}>{warning}</li>)}
                </ul>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2">
            {onOpenUnitPricing && (
              <button
                onClick={onOpenUnitPricing}
                className="text-xs flex items-center gap-1.5 px-4 py-2 rounded-full text-[#075985] hover:text-[#0c4a6e] bg-cyan-50 hover:bg-cyan-100 border border-cyan-200 cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-95 font-bold shadow-xs focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4]"
                title="Change the unit price of every component and trim piece in this BOM"
              >
                <Sliders className="w-3.5 h-3.5 text-[#06B6D4]" />
                <span>Change Component Prices</span>
              </button>
            )}
            <button
              onClick={handleExportCSV}
              className="text-xs flex items-center gap-1.5 px-4 py-2 rounded-full text-[#075985] hover:text-[#0c4a6e] bg-cyan-50 hover:bg-cyan-100 border border-cyan-200 cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-95 font-bold shadow-xs focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4]"
              title="Download CSV file with exact sheet lengths and quantities"
            >
              <Download className="w-3.5 h-3.5 text-[#06B6D4]" />
              <span>Export CSV</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-[#0369A1] hover:text-[#075985] rounded-full hover:bg-sky-100 cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-90 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4]"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* 36" Metal Panel Takeoff Highlight Card */}
        {takeoff && (
          <div className="bg-cyan-50/50 px-6 py-3 border-b border-sky-100 transition-colors">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-4 text-xs font-mono flex-wrap">
                <div>
                  <span className="text-[#0369A1]/80 text-[11px]">Total Sheets: </span>
                  <strong className="text-[#075985] font-bold">{takeoff.totalMetalSheets} sheets</strong>
                </div>
                <div>
                  <span className="text-[#0369A1]/80 text-[11px]">Roof: </span>
                  <strong className="text-[#075985] font-bold">{takeoff.totalRoofSheets}</strong>
                </div>
                <div>
                  <span className="text-[#0369A1]/80 text-[11px]">Wall: </span>
                  <strong className="text-[#075985] font-bold">{takeoff.totalWallSidingSheets}</strong>
                </div>
                {takeoff.totalWainscotSheets > 0 && (
                  <div>
                    <span className="text-[#0369A1]/80 text-[11px]">Wainscot: </span>
                    <strong className="text-[#075985] font-bold">{takeoff.totalWainscotSheets}</strong>
                  </div>
                )}
                <div>
                  <span className="text-[#0369A1]/80 text-[11px]">Linear Ft: </span>
                  <strong className="text-[#06B6D4] font-black">{takeoff.totalMetalLinearFeet.toLocaleString()} LF</strong>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Filter Tabs */}
        <div className="px-6 py-3 bg-sky-50/40 border-b border-sky-100 flex items-center gap-2 overflow-x-auto text-xs transition-colors">
          <span className="text-[#0369A1] font-semibold text-[11px] mr-1">Filter View:</span>
          <button
            onClick={() => setActiveFilter('all')}
            className={`relative px-4 py-1.5 rounded-full transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] cursor-pointer text-xs active:scale-95 whitespace-nowrap focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
              activeFilter === 'all'
                ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] font-black shadow-sm ring-2 ring-[#06B6D4]/30'
                : 'bg-white text-[#0369A1] hover:text-[#075985] hover:bg-sky-50 border border-sky-200/80 font-semibold'
            }`}
          >
            All Items ({pricing.bom.length})
            {activeFilter === 'all' && (
              <span className="absolute -bottom-[2px] inset-x-2.5 h-0.5 bg-[#06B6D4] rounded-full shadow-xs" />
            )}
          </button>
          <button
            onClick={() => setActiveFilter('metal')}
            className={`relative px-4 py-1.5 rounded-full transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] cursor-pointer flex items-center gap-1.5 text-xs active:scale-95 whitespace-nowrap focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
              activeFilter === 'metal'
                ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] font-black shadow-sm ring-2 ring-[#06B6D4]/30'
                : 'bg-white text-[#0369A1] hover:text-[#075985] hover:bg-sky-50 border border-sky-200/80 font-semibold'
            }`}
          >
            <Scissors className={`w-3.5 h-3.5 transition-colors ${activeFilter === 'metal' ? 'text-[#06B6D4]' : 'text-[#0369A1]'}`} />
            <span>36" Metal Cut Schedule ({pricing.bom.filter((i) => i.isMetalSheet).length})</span>
            {activeFilter === 'metal' && (
              <span className="absolute -bottom-[2px] inset-x-2.5 h-0.5 bg-[#06B6D4] rounded-full shadow-xs" />
            )}
          </button>
          <button
            onClick={() => setActiveFilter('framing')}
            className={`relative px-4 py-1.5 rounded-full transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] cursor-pointer text-xs active:scale-95 whitespace-nowrap focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
              activeFilter === 'framing'
                ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] font-black shadow-sm ring-2 ring-[#06B6D4]/30'
                : 'bg-white text-[#0369A1] hover:text-[#075985] hover:bg-sky-50 border border-sky-200/80 font-semibold'
            }`}
          >
            Trusses & Framing
            {activeFilter === 'framing' && (
              <span className="absolute -bottom-[2px] inset-x-2.5 h-0.5 bg-[#06B6D4] rounded-full shadow-xs" />
            )}
          </button>
          <button
            onClick={() => setActiveFilter('trims')}
            className={`relative px-4 py-1.5 rounded-full transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] cursor-pointer text-xs active:scale-95 whitespace-nowrap focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
              activeFilter === 'trims'
                ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] font-black shadow-sm ring-2 ring-[#06B6D4]/30'
                : 'bg-white text-[#0369A1] hover:text-[#075985] hover:bg-sky-50 border border-sky-200/80 font-semibold'
            }`}
          >
            Trims & Enclosure ({pricing.bom.filter((i) => i.category === 'Trim & Fasteners').length})
            {activeFilter === 'trims' && (
              <span className="absolute -bottom-[2px] inset-x-2.5 h-0.5 bg-[#06B6D4] rounded-full shadow-xs" />
            )}
          </button>
          <button
            onClick={() => setActiveFilter('openings')}
            className={`relative px-4 py-1.5 rounded-full transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] cursor-pointer text-xs active:scale-95 whitespace-nowrap focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
              activeFilter === 'openings'
                ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] font-black shadow-sm ring-2 ring-[#06B6D4]/30'
                : 'bg-white text-[#0369A1] hover:text-[#075985] hover:bg-sky-50 border border-sky-200/80 font-semibold'
            }`}
          >
            Doors & Windows
            {activeFilter === 'openings' && (
              <span className="absolute -bottom-[2px] inset-x-2.5 h-0.5 bg-[#06B6D4] rounded-full shadow-xs" />
            )}
          </button>
        </div>

        {/* Table Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          {filteredCategories.map((cat) => {
            const items = filteredBom.filter((i) => i.category === cat);
            const catTotal = items.reduce((sum, item) => sum + item.totalCost, 0);

            return (
              <div key={cat} className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-xs space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <h4 className="text-xs font-bold text-[#0284C7] uppercase tracking-wider flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-[#0284C7]" />
                    {cat}
                  </h4>
                  <span className="text-xs font-mono font-bold text-[#0F172A]">
                    ${catTotal.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-mono">
                    <thead>
                      <tr className="text-slate-500 border-b border-slate-200 text-[11px]">
                        <th className="py-2 font-semibold">Item Name</th>
                        <th className="py-2 font-semibold">Cut Length / Dimension</th>
                        <th className="py-2 font-semibold">Specification / Notes</th>
                        <th className="py-2 font-semibold text-right">Qty</th>
                        <th className="py-2 font-semibold text-center">Unit</th>
                        <th className="py-2 font-semibold text-right">Unit Rate</th>
                        <th className="py-2 font-semibold text-right">Extended Cost</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700">
                      {items.map((line) => (
                        <tr key={line.id} className="hover:bg-slate-50 transition-colors">
                          <td className="py-2.5 text-[#0F172A] font-sans font-medium">
                            <div className="flex items-center gap-1.5">
                              <span>{line.item}</span>
                              {line.isMetalSheet && (
                                <span className="text-[10px] px-2 py-0.5 rounded-full bg-sky-50 text-[#0284C7] border border-sky-200 font-mono font-semibold">
                                  36" Coverage
                                </span>
                              )}
                            </div>
                          </td>

                          {/* Cut Length / Dimension Column */}
                          <td className="py-2.5 font-mono">
                            {line.sheetLengthFormatted ? (
                              <span className="inline-flex items-center gap-1 font-bold text-[#0284C7] bg-sky-50 px-2 py-0.5 rounded-full border border-sky-200">
                                <Ruler className="w-3 h-3 text-[#0284C7]" />
                                {line.sheetLengthFormatted}
                                {line.sheetLengthFt && line.isMetalSheet && (
                                  <span className="text-[10px] text-slate-500 font-normal">({line.sheetLengthFt} ft)</span>
                                )}
                              </span>
                            ) : (
                              <span className="text-slate-400 text-[11px]">—</span>
                            )}
                          </td>

                          <td className="py-2.5 text-slate-500 font-sans text-[11px] max-w-xs">{line.description}</td>
                          <td className="py-2.5 text-right font-bold text-[#0F172A]">{line.quantity.toLocaleString()}</td>
                          <td className="py-2.5 text-center text-slate-500">{line.unit}</td>
                          <td className="py-2.5 text-right text-slate-600">
                            ${line.unitPrice.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                          </td>
                          <td className="py-2.5 text-right font-bold text-[#0284C7]">
                            ${line.totalCost.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer Summary */}
        <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex flex-wrap items-center justify-between gap-4 transition-colors">
          <div className="flex items-center gap-6 text-xs text-slate-600 font-mono">
            <div>
              Subtotal Materials & Labor: <strong className="text-[#0F172A]">${pricing.subtotal.toLocaleString()}</strong>
            </div>
            <div>
              Contingency & Margin: <strong className="text-[#0284C7]">+${pricing.contractorMarginAmount.toLocaleString()}</strong>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-mono font-medium">Grand Total Project Estimate</span>
              <span className="text-xl font-bold text-[#0F172A] font-mono">
                ${pricing.grandTotal.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
