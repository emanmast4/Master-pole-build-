import React, { useState, useEffect, useRef } from 'react';
import { CustomBuildingState, PricingBreakdown } from '../types';
import { FileText, DollarSign, SlidersHorizontal, Settings, X, Sliders } from 'lucide-react';
import { FloorPlanIcon } from './FloorPlanIcon';
import { TrussIcon } from './TrussIcon';
import { ViewMode } from './BuildingVisualizer';

interface HeaderProps {
  state?: CustomBuildingState;
  pricing?: PricingBreakdown;
  viewMode?: ViewMode;
  onSelectViewMode?: (mode: ViewMode) => void;
  onOpenUnitRates?: () => void;
  onOpenAppSettings?: () => void;
  onOpenBom?: () => void;
  onOpenLiveQuote?: () => void;
  onOpenFloorPlan?: () => void;
  onOpenTrussDetails?: () => void;
  isFloorPlanOpen?: boolean;
  isTrussDetailsOpen?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  state,
  pricing,
  viewMode,
  onSelectViewMode,
  onOpenUnitRates,
  onOpenAppSettings,
  onOpenBom,
  onOpenLiveQuote,
  onOpenFloorPlan,
  onOpenTrussDetails,
  isFloorPlanOpen = false,
  isTrussDetailsOpen = false,
}) => {
  // Navigation options toggle: stowed by default on page load
  const [isOptionsOpen, setIsOptionsOpen] = useState<boolean>(false);
  const navContainerRef = useRef<HTMLDivElement>(null);

  // Close when clicking outside the navigation container
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (navContainerRef.current && !navContainerRef.current.contains(event.target as Node)) {
        setIsOptionsOpen(false);
      }
    };

    if (isOptionsOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOptionsOpen]);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md text-[#075985] border-b border-sky-100 px-3 sm:px-6 py-2.5 sm:py-3 shadow-[0_8px_30px_rgb(3,105,161,0.06)] transition-all duration-300">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        {/* Brand & Building Tagline */}
        <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
          <span className="w-2.5 h-2.5 rounded-full bg-[#06B6D4] animate-pulse shadow-sm shadow-[#06B6D4]/60 shrink-0" />
          <h1 className="text-base sm:text-lg font-black tracking-tight uppercase flex items-center gap-2">
            <span className="text-[#075985] font-extrabold tracking-tight">
              Master Metals
            </span>
            <span className="text-sky-300 font-light hidden sm:inline">|</span>
            <span className="text-xs sm:text-sm font-semibold tracking-normal text-[#0369A1] normal-case hidden sm:inline">
              Custom Pole Building Designer
            </span>
          </h1>

          {/* Quick Structure Badge */}
          {state && (
            <div className="hidden xl:flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-50 border border-sky-200/80 text-xs font-mono font-bold text-[#075985] shadow-2xs">
              <span>{state.dimensions.width}'×{state.dimensions.length}'×{state.dimensions.eaveHeight}'</span>
              <span className="text-cyan-400">•</span>
              <span className="capitalize">{state.style}</span>
            </div>
          )}
        </div>

        {/* Top-Level Header Controls */}
        <div ref={navContainerRef} className="relative flex items-center justify-end gap-1.5 sm:gap-2 shrink-0">
          {/* Stowed Navigation Icons Container (slides out smoothly to the left of the Options icon) */}
          <div
            className={`nav-stowed-drawer flex items-center gap-1.5 sm:gap-2 h-8 sm:h-9 ${
              isOptionsOpen ? 'is-open' : ''
            }`}
            aria-hidden={!isOptionsOpen}
          >
            {/* 1. Blueprint (CAD Detailed Architectural Floor Plan) */}
            {(onOpenFloorPlan || onSelectViewMode) && (
              <button
                id="btn-header-floor-plan"
                type="button"
                tabIndex={isOptionsOpen ? 0 : -1}
                onClick={onOpenFloorPlan ? onOpenFloorPlan : () => onSelectViewMode && onSelectViewMode(viewMode === 'floor_plan' ? '3d_interactive' : 'floor_plan')}
                className={`relative group h-8 w-8 sm:h-9 sm:w-9 min-w-[32px] sm:min-w-[36px] shrink-0 rounded-full flex items-center justify-center cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-90 hover:scale-105 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
                  isFloorPlanOpen || viewMode === 'floor_plan'
                    ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] shadow-sm shadow-cyan-400/20 ring-2 ring-[#06B6D4]/30'
                    : 'bg-white hover:bg-sky-50 text-[#0369A1] hover:text-[#075985] border border-sky-200/80 hover:border-[#06B6D4]/60 shadow-xs'
                }`}
                title="Blueprint: Architectural Floor Plan & Framing Layout"
                aria-label="Blueprint: Architectural Floor Plan & Framing Layout"
              >
                <FloorPlanIcon
                  className={`w-4 h-4 transition-colors ${
                    isFloorPlanOpen || viewMode === 'floor_plan' ? 'text-[#06B6D4]' : 'text-[#0369A1] group-hover:text-[#06B6D4]'
                  }`}
                  strokeWidth={1.8}
                />
                {(isFloorPlanOpen || viewMode === 'floor_plan') && (
                  <span className="absolute -bottom-[2px] inset-x-1.5 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
                )}
              </button>
            )}

            {/* 2. Roof Pitch (Truss Engineering & Dynamic Pricing) */}
            {(onOpenTrussDetails || onSelectViewMode) && (
              <button
                id="btn-header-truss"
                type="button"
                tabIndex={isOptionsOpen ? 0 : -1}
                onClick={onOpenTrussDetails ? onOpenTrussDetails : () => onSelectViewMode && onSelectViewMode(viewMode === 'truss_details' ? '3d_interactive' : 'truss_details')}
                className={`relative group h-8 w-8 sm:h-9 sm:w-9 min-w-[32px] sm:min-w-[36px] shrink-0 rounded-full flex items-center justify-center cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-90 hover:scale-105 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
                  isTrussDetailsOpen || viewMode === 'truss_details'
                    ? 'bg-cyan-50 text-[#075985] border-2 border-[#06B6D4] shadow-sm shadow-cyan-400/20 ring-2 ring-[#06B6D4]/30'
                    : 'bg-white hover:bg-sky-50 text-[#0369A1] hover:text-[#075985] border border-sky-200/80 hover:border-[#06B6D4]/60 shadow-xs'
                }`}
                title="Roof Pitch: Engineered Truss Details & Dynamic Pricing"
                aria-label="Roof Pitch: Engineered Truss Details & Dynamic Pricing"
              >
                <TrussIcon
                  className={`w-4.5 h-3.5 transition-colors ${
                    isTrussDetailsOpen || viewMode === 'truss_details' ? 'text-[#06B6D4]' : 'text-[#0369A1] group-hover:text-[#06B6D4]'
                  }`}
                  strokeWidth={1.6}
                />
                {(isTrussDetailsOpen || viewMode === 'truss_details') && (
                  <span className="absolute -bottom-[2px] inset-x-1.5 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
                )}
              </button>
            )}

            {/* 3. Document (Bill of Materials BOM) */}
            {onOpenBom && (
              <button
                id="btn-header-bom"
                type="button"
                tabIndex={isOptionsOpen ? 0 : -1}
                onClick={onOpenBom}
                className="group h-8 w-8 sm:h-9 sm:w-9 min-w-[32px] sm:min-w-[36px] shrink-0 rounded-full bg-white hover:bg-sky-50 text-[#0369A1] hover:text-[#075985] border border-sky-200/80 hover:border-[#06B6D4]/60 shadow-xs cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-90 hover:scale-105 flex items-center justify-center focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4]"
                title="Document: Bill of Materials (BOM) & Cut Schedule"
                aria-label="Document: View Bill of Materials"
              >
                <FileText className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#0369A1] group-hover:text-[#06B6D4] transition-colors" />
              </button>
            )}

            {/* 4. Pricing (Live Dynamic Turnkey Quote) */}
            {onOpenLiveQuote && (
              <button
                id="btn-header-quote"
                type="button"
                tabIndex={isOptionsOpen ? 0 : -1}
                onClick={onOpenLiveQuote}
                className="group h-8 w-8 sm:h-9 sm:w-9 min-w-[32px] sm:min-w-[36px] shrink-0 rounded-full bg-gradient-to-r from-cyan-500 to-sky-500 text-white shadow-md shadow-cyan-500/25 hover:shadow-lg hover:shadow-cyan-400/40 cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-90 hover:scale-105 flex items-center justify-center focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4]"
                title={pricing ? `Pricing: Live Dynamic Quote ($${pricing.grandTotal.toLocaleString()})` : "Pricing: View Live Dynamic Quote"}
                aria-label={pricing ? `Pricing: Live Dynamic Quote ($${pricing.grandTotal.toLocaleString()})` : "Pricing: View Live Dynamic Quote"}
              >
                <DollarSign className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white stroke-[2.5]" />
              </button>
            )}

            {/* 5. Component & Trim Pricing Manager */}
            {onOpenUnitRates && (
              <button
                id="btn-header-unit-rates"
                type="button"
                tabIndex={isOptionsOpen ? 0 : -1}
                onClick={onOpenUnitRates}
                className="group h-8 w-8 sm:h-9 sm:w-9 min-w-[32px] sm:min-w-[36px] shrink-0 rounded-full bg-white hover:bg-sky-50 text-[#0369A1] hover:text-[#075985] border border-sky-200/80 hover:border-[#06B6D4]/60 shadow-xs cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-90 hover:scale-105 flex items-center justify-center focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4]"
                title="EDIT PRICES — Customize component, material, trim, and hardware prices"
                aria-label="Component and Trim Prices Manager"
              >
                <Sliders className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#0369A1] group-hover:text-[#06B6D4] transition-colors" />
              </button>
            )}

            {/* 6. Settings (App UI, 3D Engine & Preferences) */}
            {onOpenAppSettings && (
              <button
                id="btn-header-settings"
                type="button"
                tabIndex={isOptionsOpen ? 0 : -1}
                onClick={onOpenAppSettings}
                className="group h-8 w-8 sm:h-9 sm:w-9 min-w-[32px] sm:min-w-[36px] shrink-0 rounded-full bg-white hover:bg-sky-50 text-[#0369A1] hover:text-[#075985] border border-sky-200/80 hover:border-[#06B6D4]/60 shadow-xs cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-90 hover:scale-105 flex items-center justify-center focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4]"
                title="Settings: Display Units, 3D Rendering & UI Preferences"
                aria-label="App Settings and Display Preferences"
              >
                <Settings className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#0369A1] group-hover:text-[#06B6D4] transition-colors" />
              </button>
            )}
          </div>

          {/* Far-Right Options Toggle Button */}
          <button
            id="btn-header-options"
            type="button"
            onClick={() => setIsOptionsOpen((prev) => !prev)}
            className={`group h-8 w-8 sm:h-9 sm:w-9 min-w-[32px] sm:min-w-[36px] shrink-0 rounded-full cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-90 hover:scale-105 flex items-center justify-center focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
              isOptionsOpen
                ? 'bg-cyan-50 text-[#06B6D4] border-2 border-[#06B6D4] shadow-sm shadow-cyan-400/25 ring-2 ring-[#06B6D4]/30'
                : 'bg-white hover:bg-sky-50 text-[#075985] border border-sky-200/80 hover:border-[#06B6D4] shadow-xs'
            }`}
            title={isOptionsOpen ? "Hide navigation options" : "Show navigation options"}
            aria-label={isOptionsOpen ? "Hide navigation options" : "Show navigation options"}
            aria-expanded={isOptionsOpen}
          >
            <span className={`flex items-center justify-center transition-transform duration-500 ease-[cubic-bezier(0.34,1.56,0.64,1)] ${isOptionsOpen ? 'rotate-90' : 'rotate-0'}`}>
              {isOptionsOpen ? (
                <X className="w-4 h-4 text-[#06B6D4]" />
              ) : (
                <SlidersHorizontal className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#075985]" />
              )}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};

