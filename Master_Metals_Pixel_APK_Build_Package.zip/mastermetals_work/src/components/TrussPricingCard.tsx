import React, { useState } from 'react';
import { 
  BuildingDimensions, 
  CustomBuildingState, 
  SnowLoadRating, 
  TrussCalculationBreakdown, 
  TrussType 
} from '../types';
import { Calculator, Info, ShieldAlert, Sliders, ChevronDown, ChevronUp, Layers } from 'lucide-react';

interface TrussPricingCardProps {
  state: CustomBuildingState;
  trussData: TrussCalculationBreakdown;
  onUpdateState: (updater: (prev: CustomBuildingState) => CustomBuildingState) => void;
  onOpenUnitPricing: () => void;
}

export const TrussPricingCard: React.FC<TrussPricingCardProps> = ({
  state,
  trussData,
  onUpdateState,
  onOpenUnitPricing,
}) => {
  const [showFormulaDetails, setShowFormulaDetails] = useState(false);

  const { dimensions, snowLoad, trussType, unitRates } = state;
  const { width, roofPitch } = dimensions;

  // Chord size recommendations based on engineering span
  let chordSize = '2x4 #1 SPF/SYP';
  if (width > 26 && width <= 40) chordSize = '2x6 High-Stress Chord';
  if (width > 40 && width <= 56) chordSize = '2x8 Machine-Stress Rated (MSR)';
  if (width > 56) chordSize = 'Double 2x8 / 2x10 Heavy Timber';

  return (
    <div id="truss-pricing-card" className="bg-white border border-slate-200/90 rounded-xl p-5 sm:p-6 shadow-[0_4px_6px_-1px_rgba(0,0,0,0.1),0_2px_4px_-2px_rgba(0,0,0,0.06)] relative overflow-hidden transition-colors duration-200 text-[#0F172A]">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 mt-1">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-lg bg-sky-100 text-[#0284C7] border border-sky-300">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#0F172A] tracking-wide flex items-center gap-2 flex-wrap">
                <span>Truss Engineering & Dynamic Pricing</span>
                <span className="text-xs font-mono font-bold text-[#0284C7] bg-sky-100 px-2.5 py-0.5 rounded-full border border-sky-300">
                  {width}' Span @ {roofPitch}:12 Pitch
                </span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Lumber volume, rafter slope, and gusset plate engineering scale in real-time
              </p>
            </div>
          </div>
        </div>

        <button
          id="btn-edit-truss-rates"
          onClick={onOpenUnitPricing}
          className="text-xs flex items-center gap-1.5 text-slate-700 hover:text-[#0F172A] bg-slate-100 hover:bg-slate-200 border border-slate-200 px-4 py-2 rounded-lg transition-all cursor-pointer w-fit active:scale-95 shadow-xs font-medium"
        >
          <Sliders className="w-3.5 h-3.5 text-slate-600" />
          <span>Adjust Truss Rates</span>
        </button>
      </div>

      {/* Main Grid: Visual SVG Schematic on Left, Key Metrics on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-center">
        {/* Truss SVG Schematic */}
        <div className="lg:col-span-6 bg-white rounded-xl p-4 border border-slate-200/90 shadow-xs relative transition-colors duration-200">
          <div className="flex justify-between items-center text-[11px] text-slate-500 mb-2 font-mono">
            <span>SCHEMATIC TRUSS ELEVATION</span>
            <span className="text-[#0284C7] font-bold">{trussType.replace('_', ' ').toUpperCase()}</span>
          </div>

          <div className="w-full h-36 flex items-center justify-center relative">
            <svg
              viewBox="0 0 400 160"
              className="w-full h-full max-h-36 overflow-visible"
              preserveAspectRatio="xMidYMid meet"
            >
              {/* Ground & Eave reference line */}
              <line x1="20" y1="130" x2="380" y2="130" stroke="#94a3b8" strokeWidth="1" strokeDasharray="3 3" />
              
              {/* Calculate schematic SVG apex height based on pitch */}
              {(() => {
                const svgPitchRatio = Math.min(0.65, Math.max(0.18, (roofPitch / 12) * 0.75));
                const baseY = 125;
                const apexY = baseY - svgPitchRatio * 130;
                const leftX = 40;
                const rightX = 360;
                const centerX = 200;

                return (
                  <g>
                    {/* Double 2x12 Weight-Bearing Wall Header Blocks */}
                    {/* Left Wall Double 2x12 Header Block */}
                    <rect x={leftX - 8} y={baseY} width="8" height="16" fill="#d97706" stroke="#78350f" strokeWidth="1" rx="1" />
                    <line x1={leftX - 4} y1={baseY} x2={leftX - 4} y2={baseY + 16} stroke="#78350f" strokeWidth="0.8" />
                    <text x={leftX} y={baseY + 26} fill="#d97706" fontSize="7.5" fontFamily="monospace" textAnchor="middle" fontWeight="bold">
                      (2) 2x12
                    </text>

                    {/* Right Wall Double 2x12 Header Block */}
                    <rect x={rightX} y={baseY} width="8" height="16" fill="#d97706" stroke="#78350f" strokeWidth="1" rx="1" />
                    <line x1={rightX + 4} y1={baseY} x2={rightX + 4} y2={baseY + 16} stroke="#78350f" strokeWidth="0.8" />
                    <text x={rightX} y={baseY + 26} fill="#d97706" fontSize="7.5" fontFamily="monospace" textAnchor="middle" fontWeight="bold">
                      (2) 2x12
                    </text>

                    {/* Bottom Chord */}
                    <line x1={leftX} y1={baseY} x2={rightX} y2={baseY} stroke="#f59e0b" strokeWidth="4" strokeLinecap="round" />
                    
                    {/* Top Chords (Rafters) */}
                    <line x1={leftX} y1={baseY} x2={centerX} y2={apexY} stroke="#f59e0b" strokeWidth="4" strokeLinecap="round" />
                    <line x1={rightX} y1={baseY} x2={centerX} y2={apexY} stroke="#f59e0b" strokeWidth="4" strokeLinecap="round" />
                    
                    {/* King Post Center Web */}
                    <line x1={centerX} y1={apexY} x2={centerX} y2={baseY} stroke="#94a3b8" strokeWidth="2.5" />

                    {/* Internal Web Bracing */}
                    {width >= 24 && (
                      <>
                        {/* Fink / Howe diagonals */}
                        <line x1={leftX + (centerX - leftX) * 0.5} y1={baseY} x2={centerX} y2={apexY} stroke="#94a3b8" strokeWidth="2" />
                        <line x1={leftX + (centerX - leftX) * 0.5} y1={baseY} x2={leftX + (centerX - leftX) * 0.5} y2={apexY + (baseY - apexY) * 0.5} stroke="#94a3b8" strokeWidth="2" />
                        
                        <line x1={rightX - (rightX - centerX) * 0.5} y1={baseY} x2={centerX} y2={apexY} stroke="#94a3b8" strokeWidth="2" />
                        <line x1={rightX - (rightX - centerX) * 0.5} y1={baseY} x2={rightX - (rightX - centerX) * 0.5} y2={apexY + (baseY - apexY) * 0.5} stroke="#94a3b8" strokeWidth="2" />
                      </>
                    )}

                    {width >= 40 && (
                      <>
                        {/* Additional Queen / Fan web members for wide spans */}
                        <line x1={leftX + (centerX - leftX) * 0.25} y1={baseY} x2={leftX + (centerX - leftX) * 0.5} y2={apexY + (baseY - apexY) * 0.5} stroke="#64748b" strokeWidth="1.5" />
                        <line x1={rightX - (rightX - centerX) * 0.25} y1={baseY} x2={rightX - (rightX - centerX) * 0.5} y2={apexY + (baseY - apexY) * 0.5} stroke="#64748b" strokeWidth="1.5" />
                      </>
                    )}

                    {/* Steel Gusset Connector Plates (Metallic nodes) */}
                    <circle cx={leftX} cy={baseY} r="4.5" fill="#e2e8f0" stroke="#0f172a" strokeWidth="1.5" />
                    <circle cx={rightX} cy={baseY} r="4.5" fill="#e2e8f0" stroke="#0f172a" strokeWidth="1.5" />
                    <circle cx={centerX} cy={apexY} r="5" fill="#e2e8f0" stroke="#0f172a" strokeWidth="1.5" />
                    <circle cx={centerX} cy={baseY} r="4" fill="#e2e8f0" stroke="#0f172a" strokeWidth="1.5" />

                    {/* Slope Indicator Triangle */}
                    <g transform={`translate(${centerX + 28}, ${apexY + (baseY - apexY) * 0.45})`}>
                      <polygon points="0,0 24,0 24,14" fill="#38bdf8" opacity="0.3" stroke="#38bdf8" strokeWidth="1" />
                      <text x="10" y="-3" fill="#0284c7" fontSize="9" fontFamily="monospace" textAnchor="middle">12</text>
                      <text x="29" y="10" fill="#0284c7" fontSize="9" fontFamily="monospace">{roofPitch}</text>
                    </g>

                    {/* Dimensions Annotations */}
                    <text x={centerX} y={baseY + 18} fill="#334155" fontSize="11" fontFamily="sans-serif" textAnchor="middle" fontWeight="bold">
                      {width}' Clear Span
                    </text>
                    <text x={centerX - 10} y={apexY - 6} fill="#0284c7" fontSize="10" fontFamily="sans-serif" textAnchor="end" fontWeight="bold">
                      +{trussData.apexPeakHeightFt}' Peak
                    </text>
                    <text x={leftX + 20} y={apexY + (baseY - apexY) * 0.45} fill="#64748b" fontSize="10" fontFamily="sans-serif">
                      {trussData.rafterLengthFt}' Rafter
                    </text>
                  </g>
                );
              })()}
            </svg>
          </div>

          {/* Warning / Badge for Piggyback */}
          {trussData.piggybackRequired && (
            <div className="mt-2 text-xs bg-sky-50 text-sky-900 border border-sky-300 px-3 py-2 rounded-lg flex items-center gap-2 shadow-xs">
              <ShieldAlert className="w-4 h-4 shrink-0 text-[#0284C7]" />
              <span>
                <strong>Highway Shipping Envelope Exceeded:</strong> Peak height ({trussData.apexPeakHeightFt}ft) exceeds 13.5ft. Built as 2-piece piggyback truss with spliced apex framing.
              </span>
            </div>
          )}
        </div>

        {/* Pricing & Engineering Outputs */}
        <div className="lg:col-span-6 space-y-3">
          {/* Main Price Numbers */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white border border-slate-200/90 rounded-lg p-4 shadow-xs transition-colors">
              <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">Standard Truss Unit</span>
              <div className="text-2xl font-bold text-[#0F172A] mt-1">
                ${trussData.unitCostStandardTruss.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </div>
              <span className="text-[11px] text-slate-500 block mt-0.5">
                {trussData.standardTrussesCount} interior trusses needed
              </span>
            </div>

            <div className="bg-white border border-sky-300 rounded-lg p-4 shadow-xs transition-colors">
              <span className="text-[11px] font-bold text-[#0284C7] uppercase tracking-wider block">Total Truss Package</span>
              <div className="text-2xl font-bold text-[#0F172A] mt-1">
                ${trussData.totalTrussPackageCost.toLocaleString('en-US')}
              </div>
              <span className="text-[11px] text-slate-600 block mt-0.5">
                Includes {trussData.totalTrussesNeeded} trusses + Gable Ends + Crane
              </span>
            </div>
          </div>

          {/* Engineering Spec Chips */}
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="bg-white border border-slate-200/90 rounded-lg p-2.5 shadow-xs transition-colors">
              <span className="text-[10px] text-slate-500 uppercase block font-medium">Rafter Length</span>
              <span className="text-sm font-bold text-[#0F172A]">{trussData.rafterLengthFt} ft</span>
            </div>
            <div className="bg-white border border-slate-200/90 rounded-lg p-2.5 shadow-xs transition-colors">
              <span className="text-[10px] text-slate-500 uppercase block font-medium">Slope Multiplier</span>
              <span className="text-sm font-bold text-[#0284C7]">{trussData.slopeFactor}x</span>
            </div>
            <div className="bg-white border border-slate-200/90 rounded-lg p-2.5 shadow-xs transition-colors">
              <span className="text-[10px] text-slate-500 uppercase block font-medium">Truss Spacing</span>
              <span className="text-sm font-bold text-[#0F172A]">{dimensions.trussSpacing}' O.C.</span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="bg-white border border-slate-200/90 rounded-lg p-2.5 shadow-xs transition-colors">
              <span className="text-[10px] text-slate-500 uppercase block font-medium">Lumber Grade</span>
              <span className="text-xs font-bold text-[#0F172A] truncate block" title={chordSize}>{chordSize}</span>
            </div>
            <div className="bg-white border border-slate-200/90 rounded-lg p-2.5 shadow-xs transition-colors">
              <span className="text-[10px] text-slate-500 uppercase block font-medium">Snow Load</span>
              <span className="text-xs font-bold text-[#0284C7]">{snowLoad} PSF</span>
            </div>
            <div className="bg-white border border-slate-200/90 rounded-lg p-2.5 shadow-xs transition-colors">
              <span className="text-[10px] text-slate-500 uppercase block font-medium">Steel Plates</span>
              <span className="text-xs font-bold text-[#0F172A]">{trussData.plateConnectorsCount} Gang-Nail</span>
            </div>
          </div>

          {/* Quick Trusses Controls */}
          <div className="flex flex-wrap items-center gap-2 pt-1.5">
            <span className="text-xs text-slate-500 font-semibold">Truss Type:</span>
            {(['fink_gable', 'scissor', 'attic_storage'] as TrussType[]).map((t) => (
              <button
                key={t}
                onClick={() => onUpdateState((prev) => ({ ...prev, trussType: t }))}
                className={`text-xs px-3.5 py-1.5 rounded-lg transition-all cursor-pointer font-bold active:scale-95 border focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0284C7] ${
                  trussType === t
                    ? 'bg-sky-50 text-[#0F172A] border-[#0284C7] shadow-xs font-bold ring-1 ring-[#0284C7]/20'
                    : 'bg-white border-slate-200 text-slate-700 hover:text-[#0F172A] hover:bg-slate-50 shadow-xs'
                }`}
              >
                {t === 'fink_gable' ? 'Standard Gable' : t === 'scissor' ? 'Vaulted Scissor' : 'Attic Storage'}
              </button>
            ))}

            <div className="ml-auto flex items-center gap-1.5">
              <span className="text-xs text-slate-500 font-semibold">Snow:</span>
              {([20, 30, 40, 60] as SnowLoadRating[]).map((sl) => (
                <button
                  key={sl}
                  onClick={() => onUpdateState((prev) => ({ ...prev, snowLoad: sl }))}
                  className={`text-xs px-2.5 py-1 rounded-lg transition-all cursor-pointer font-bold border active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0284C7] ${
                    snowLoad === sl
                      ? 'bg-sky-50 text-[#0F172A] border-[#0284C7] font-extrabold shadow-xs ring-1 ring-[#0284C7]/20'
                      : 'bg-white text-slate-600 border-slate-200 hover:text-[#0F172A] hover:bg-slate-50 shadow-xs'
                  }`}
                >
                  {sl}#
                </button>
              ))}
            </div>
          </div>

          {/* Weight-Bearing Wall Headers Specification */}
          <div className="bg-white border border-sky-300 rounded-lg p-3 flex items-center justify-between text-xs mt-1 shadow-xs">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#0284C7] shrink-0" />
              <span className="text-slate-800 font-medium">
                Bearing Walls: <strong className="text-sky-900">(2) 2x12 Headers</strong> @ {dimensions.postSpacing || 8}' O.C. Posts
              </span>
            </div>
            <span className="font-mono text-[#0284C7] font-bold text-[11px] shrink-0">
              {4 * dimensions.length} LF (${((4 * dimensions.length) * unitRates.trussCarriersPerLinFt).toLocaleString()})
            </span>
          </div>
        </div>
      </div>

      {/* Accordion: Transparent Mathematical Formula Breakdown */}
      <div className="mt-5 pt-3.5 border-t border-slate-200">
        <button
          onClick={() => setShowFormulaDetails(!showFormulaDetails)}
          className="w-full flex items-center justify-between text-xs text-slate-700 hover:text-[#0F172A] transition-colors cursor-pointer py-1"
        >
          <span className="flex items-center gap-2 font-medium">
            <Info className="w-4 h-4 text-[#0284C7]" />
            <span>How width & pitch dynamically determine this truss price (Formula Breakdown)</span>
          </span>
          <span className="flex items-center gap-1 text-slate-400">
            {showFormulaDetails ? 'Hide calculation details' : 'Show calculation details'}
            {showFormulaDetails ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </span>
        </button>

        {showFormulaDetails && (
          <div className="mt-3 p-4 bg-white rounded-xl border border-slate-200/90 text-xs text-slate-700 space-y-2.5 font-mono shadow-xs transition-colors">
            <div className="text-[11px] text-[#0284C7] font-bold border-b border-slate-200 pb-2 flex items-center justify-between">
              <span>TRUSS FORMULATION ENGINE: P_truss = (B_span + Δ_pitch + C_plates + S_piggy) × M_snow × M_style</span>
              <span className="text-slate-500 font-normal">Active Building Spec</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-2.5 text-[11px] pt-1">
              <div>
                <span className="text-slate-500">1. Base Span Cost (Width):</span>
                <p className="text-slate-800">
                  {width}' Span × ${unitRates.trussBasePerFootSpan.toFixed(2)}/ft = <strong>${trussData.baseSpanCost}</strong>
                </p>
              </div>

              <div>
                <span className="text-slate-500">2. Pitch & Rafter Slope Factor:</span>
                <p className="text-slate-800">
                  Slope Factor = √(1 + ({roofPitch}/12)²) = <strong>{trussData.slopeFactor}x</strong>
                  <br />
                  Slope lumber surcharge = <strong>+${trussData.pitchSlopeSurcharge}</strong>
                </p>
              </div>

              <div>
                <span className="text-slate-500">3. Steel Gusset Plates & Hardware:</span>
                <p className="text-slate-800">
                  {trussData.plateConnectorsCount} Gang-nail plates ({trussData.webMembersCount} internal webs) = <strong>+${Math.round((trussData.plateConnectorsCount / 8) * unitRates.trussGussetPlateBase)}</strong>
                </p>
              </div>

              <div>
                <span className="text-slate-500">4. Snow Load Multiplier ({snowLoad} PSF):</span>
                <p className="text-slate-800">
                  Load tier adjustment = <strong>+${trussData.snowLoadSurcharge}</strong>
                </p>
              </div>

              <div>
                <span className="text-slate-500">5. Gable End Trusses (Vertical Studs):</span>
                <p className="text-slate-800">
                  2 Gable Ends @ ${trussData.unitCostGableTruss.toFixed(2)} = <strong>${Math.round(2 * trussData.unitCostGableTruss)}</strong>
                </p>
              </div>

              <div>
                <span className="text-slate-500">6. Delivery & Boom Crane Site Offload:</span>
                <p className="text-slate-800">
                  Flat jobsite freight & crane staging = <strong>${unitRates.trussDeliveryCraneSetup}</strong>
                </p>
              </div>
            </div>

            <div className="mt-2 pt-2 border-t border-slate-200 text-[11px] text-[#0284C7] flex justify-between items-center">
              <span>Total Package Cost: ({trussData.standardTrussesCount} std × ${trussData.unitCostStandardTruss}) + (2 gable × ${trussData.unitCostGableTruss}) + Crane (${unitRates.trussDeliveryCraneSetup})</span>
              <span className="font-bold text-[#0284C7] text-sm">${trussData.totalTrussPackageCost.toLocaleString()}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
