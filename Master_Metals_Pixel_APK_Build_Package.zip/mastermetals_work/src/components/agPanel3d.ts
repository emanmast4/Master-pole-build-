import * as THREE from 'three';
import { BuildingStyle, WallOpening, WallSide } from '../types';

/**
 * 36" Wide Ag-Panel Specification:
 * - Net Panel Width: 36 inches (3.0 feet)
 * - Major Rib Spacing: Every 9 inches (0.75 feet) on-center
 * - Major Rib Height: 3/4 inch (0.0625 feet)
 * - 4 major rib intervals per 36" panel (0", 9", 18", 27", lap at 36")
 */
export const AG_PANEL_CONSTANTS = {
  PANEL_WIDTH_FT: 3.0,     // 36 inches
  RIB_SPACING_FT: 0.75,    // 9 inches on-center
  RIB_HEIGHT_FT: 0.0625,   // 3/4 inch high (0.75" / 12)
  RIB_WIDTH_FT: 0.085,     // ~1 inch trapezoid crest width
  SEAM_RIB_WIDTH_FT: 0.11, // Overlapping seam rib width
};

/**
 * Calculates top of wall / roof profile Y elevation at any coordinate X
 * across the building span based on the selected Building Style Architecture.
 */
export function getRoofProfileY(
  x: number,
  width: number,
  eaveHeight: number,
  roofPitch: number,
  style: BuildingStyle = 'gable'
): number {
  const halfW = width / 2;
  const peakRise = halfW * (roofPitch / 12);

  if (style === 'monitor') {
    const centerW = width * 0.40;
    const halfCenterW = centerW / 2;
    const wingWidth = halfW - halfCenterW;
    const wingPitch = Math.max(2, roofPitch * 0.75);
    const wingRise = wingWidth * (wingPitch / 12);
    const wingTopY = eaveHeight + wingRise;
    const raisedEaveY = wingTopY + Math.max(3.5, eaveHeight * 0.25);
    const centerRise = halfCenterW * (roofPitch / 12);

    const absX = Math.abs(x);
    if (absX > halfCenterW) {
      // In side wing
      const wingFraction = Math.max(0, Math.min(1, (halfW - absX) / wingWidth));
      return eaveHeight + wingFraction * wingRise;
    } else {
      // In raised center monitor
      const centerFraction = Math.max(0, 1 - absX / halfCenterW);
      return raisedEaveY + centerFraction * centerRise;
    }
  }

  if (style === 'gambrel') {
    const knuckleX = halfW * 0.58;
    const knuckleRise = (halfW * 0.42) * (Math.max(16, roofPitch * 3.2) / 12);
    const knuckleY = eaveHeight + knuckleRise;
    const upperRise = (halfW * 0.58) * (Math.max(3.5, roofPitch * 0.75) / 12);
    const absX = Math.abs(x);

    if (absX > knuckleX) {
      const lowerFraction = Math.max(0, Math.min(1, (halfW - absX) / (halfW - knuckleX)));
      return eaveHeight + lowerFraction * knuckleRise;
    } else {
      const upperFraction = Math.max(0, 1 - absX / knuckleX);
      return knuckleY + upperFraction * upperRise;
    }
  }

  if (style === 'single_slope') {
    const highRise = width * (roofPitch / 12);
    // Slope from left (-halfW) high to right (+halfW) low
    const progress = Math.max(0, Math.min(1, (halfW - x) / width)); // 1 at -halfW, 0 at +halfW
    return eaveHeight + progress * highRise;
  }

  if (style === 'commercial') {
    // Parapet wall rises flat across the front/back
    return eaveHeight + peakRise + 2.5;
  }

  // Standard gable
  return eaveHeight + (1 - Math.min(1, Math.abs(x) / halfW)) * peakRise;
}

/**
 * Creates high-fidelity canvas texture reflecting the 36" Ag-Panel
 * with 9" rib highlights and intermediate stiffener pencil ribs
 */
export function createAgPanelTexture(baseColorHex: string): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  // 360 px wide represents one 36" panel (10 px per inch)
  // Ribs at 0px, 90px, 180px, 270px, 360px
  canvas.width = 360;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;

  // Fill base color
  ctx.fillStyle = baseColorHex;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Parse color to compute highlight and shadow tones
  const color = new THREE.Color(baseColorHex);
  const hsl = { h: 0, s: 0, l: 0 };
  color.getHSL(hsl);

  const shadowColor = new THREE.Color().setHSL(hsl.h, hsl.s * 0.9, Math.max(0.04, hsl.l * 0.65)).getStyle();
  const highlightColor = new THREE.Color().setHSL(hsl.h, hsl.s * 0.8, Math.min(0.96, hsl.l * 1.35)).getStyle();
  const crestColor = new THREE.Color().setHSL(hsl.h, hsl.s * 0.85, Math.min(0.98, hsl.l * 1.2)).getStyle();

  // Subtle vertical metallic brush lines
  for (let x = 0; x < canvas.width; x += 4) {
    ctx.fillStyle = Math.random() > 0.5 ? 'rgba(255,255,255,0.02)' : 'rgba(0,0,0,0.03)';
    ctx.fillRect(x, 0, 2, canvas.height);
  }

  // Draw 4 major 9-inch rib locations: 0, 90, 180, 270
  const majorRibs = [0, 90, 180, 270];
  majorRibs.forEach((rx, idx) => {
    // Rib base width is ~12px, crest is ~8px
    const ribW = idx === 0 ? 14 : 11; // 0 is the 36" lap seam

    // Shadow facet
    ctx.fillStyle = shadowColor;
    ctx.fillRect((rx - ribW / 2 + canvas.width) % canvas.width, 0, Math.ceil(ribW * 0.4), canvas.height);

    // Flat crest
    ctx.fillStyle = crestColor;
    ctx.fillRect((rx - 2 + canvas.width) % canvas.width, 0, 4, canvas.height);

    // Highlight facet
    ctx.fillStyle = highlightColor;
    ctx.fillRect((rx + 2 + canvas.width) % canvas.width, 0, Math.ceil(ribW * 0.4), canvas.height);

    // Intermediate 2 pencil stiffener ribs in each 9" pan (at +30px and +60px from major rib)
    const p1 = rx + 30;
    const p2 = rx + 60;
    [p1, p2].forEach((px) => {
      ctx.fillStyle = shadowColor;
      ctx.fillRect((px - 2 + canvas.width) % canvas.width, 0, 2, canvas.height);
      ctx.fillStyle = highlightColor;
      ctx.fillRect((px + canvas.width) % canvas.width, 0, 2, canvas.height);
    });
  });

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.anisotropy = 8;
  return texture;
}

/**
 * Creates realistic ribbed/vented soffit canvas texture for eave and gable soffit panels.
 * Features 4" to 6" grooved panel reveals with subtle perforated or solid v-groove detail.
 */
export function createSoffitTexture(baseColorHex: string): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = baseColorHex;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  const color = new THREE.Color(baseColorHex);
  const hsl = { h: 0, s: 0, l: 0 };
  color.getHSL(hsl);

  const grooveShadow = new THREE.Color().setHSL(hsl.h, hsl.s * 0.9, Math.max(0.04, hsl.l * 0.72)).getStyle();
  const grooveHighlight = new THREE.Color().setHSL(hsl.h, hsl.s * 0.8, Math.min(0.96, hsl.l * 1.25)).getStyle();
  const ventSlot = new THREE.Color().setHSL(hsl.h, hsl.s * 0.85, Math.max(0.03, hsl.l * 0.58)).getStyle();

  // Draw 4 distinct soffit panel boards with V-grooves every 64px (~4 inches)
  const panelStep = 64;
  for (let x = 0; x < canvas.width; x += panelStep) {
    // V-groove shadow and highlight
    ctx.fillStyle = grooveShadow;
    ctx.fillRect(x, 0, 3, canvas.height);
    ctx.fillStyle = grooveHighlight;
    ctx.fillRect(x + 3, 0, 2, canvas.height);

    // Subtle center stiffener bead
    ctx.fillStyle = grooveShadow;
    ctx.fillRect(x + panelStep / 2 - 1, 0, 1, canvas.height);
    ctx.fillStyle = grooveHighlight;
    ctx.fillRect(x + panelStep / 2, 0, 1, canvas.height);

    // Perforation slots in center of panel pan for realistic vented soffit
    for (let y = 10; y < canvas.height; y += 20) {
      ctx.fillStyle = ventSlot;
      ctx.fillRect(x + panelStep / 2 - 2, y, 4, 4);
    }
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(4, 4);
  texture.anisotropy = 8;
  return texture;
}

interface WallRibBuilderParams {
  width: number;
  length: number;
  eaveHeight: number;
  roofPitch: number;
  style?: BuildingStyle;
  walls: {
    front: { enclosed: boolean; hasWainscot: boolean };
    back: { enclosed: boolean; hasWainscot: boolean };
    left: { enclosed: boolean; hasWainscot: boolean };
    right: { enclosed: boolean; hasWainscot: boolean };
  };
  openings: WallOpening[];
  wainscotH: number;
  sidingRibMat: THREE.Material;
  wainscotRibMat: THREE.Material;
}

/**
 * Builds 3D physical 3/4" high ribs spaced every 9 inches on all walls
 */
export function buildWallAgPanelRibs(params: WallRibBuilderParams): THREE.Group {
  const {
    width,
    length,
    eaveHeight,
    roofPitch,
    style = 'gable',
    walls,
    openings,
    wainscotH,
    sidingRibMat,
    wainscotRibMat,
  } = params;

  const ribsGroup = new THREE.Group();
  ribsGroup.name = 'AgPanelWallRibs';

  const halfW = width / 2;
  const halfL = length / 2;
  const peakRise = halfW * (roofPitch / 12);
  const wallThick = 0.2;
  const { RIB_SPACING_FT, RIB_HEIGHT_FT, RIB_WIDTH_FT, SEAM_RIB_WIDTH_FT, PANEL_WIDTH_FT } = AG_PANEL_CONSTANTS;

  // Helper to test if a 1D coordinate falls inside any opening on a side
  const checkOpeningIntersections = (side: WallSide, coord: number) => {
    return openings.filter((op) => {
      if (op.side !== side) return false;
      let center = 0;
      if (side === 'front') {
        center = -halfW + op.positionOffsetFt + op.widthFt / 2;
      } else if (side === 'back') {
        center = halfW - op.positionOffsetFt - op.widthFt / 2;
      } else if (side === 'left') {
        center = halfL - op.positionOffsetFt - op.widthFt / 2;
      } else if (side === 'right') {
        center = -halfL + op.positionOffsetFt + op.widthFt / 2;
      }
      const min = center - op.widthFt / 2;
      const max = center + op.widthFt / 2;
      return coord >= min - 0.1 && coord <= max + 0.1;
    });
  };

  // Helper to add vertical rib segments avoiding door/window penetrations
  const addVerticalRib = (
    baseX: number,
    baseZ: number,
    maxHeight: number,
    hasWainscot: boolean,
    intersectingOps: WallOpening[],
    isSeam: boolean,
    planeAxis: 'X' | 'Z'
  ) => {
    const ribW = isSeam ? SEAM_RIB_WIDTH_FT : RIB_WIDTH_FT;
    // Geometry dimensions: if planeAxis === 'X' (left/right walls), rib projects in X: (RIB_HEIGHT_FT, height, ribW)
    // if planeAxis === 'Z' (front/back walls), rib projects in Z: (ribW, height, RIB_HEIGHT_FT)

    // Compute blocked vertical spans from doors/windows
    interface BlockedSpan {
      bottom: number;
      top: number;
    }
    const blocked: BlockedSpan[] = [];

    intersectingOps.forEach((op) => {
      const bottom = op.bottomOffsetFt ?? (op.type === 'window' ? 3 : 0);
      blocked.push({ bottom: Math.max(0, bottom - 0.1), top: bottom + op.heightFt + 0.2 });
    });

    // Compute valid segments from Y = 0 to maxHeight
    const segments: { yStart: number; yEnd: number }[] = [];
    if (blocked.length === 0) {
      segments.push({ yStart: 0, yEnd: maxHeight });
    } else {
      // Sort blocked spans
      blocked.sort((a, b) => a.bottom - b.bottom);
      let curY = 0;
      for (const span of blocked) {
        if (span.bottom > curY) {
          segments.push({ yStart: curY, yEnd: Math.min(span.bottom, maxHeight) });
        }
        curY = Math.max(curY, span.top);
      }
      if (curY < maxHeight) {
        segments.push({ yStart: curY, yEnd: maxHeight });
      }
    }

    // Render each valid vertical segment
    segments.forEach(({ yStart, yEnd }) => {
      if (yEnd - yStart < 0.2) return; // skip tiny slivers

      // Split into wainscot vs upper siding if wainscot applies
      if (hasWainscot && wainscotH > 0) {
        // Lower wainscot segment
        if (yStart < wainscotH) {
          const wEnd = Math.min(yEnd, wainscotH);
          const h = wEnd - yStart;
          if (h > 0.15) {
            const centerY = yStart + h / 2;
            const geo = planeAxis === 'X'
              ? new THREE.BoxGeometry(RIB_HEIGHT_FT, h, ribW)
              : new THREE.BoxGeometry(ribW, h, RIB_HEIGHT_FT);
            const mesh = new THREE.Mesh(geo, wainscotRibMat);
            mesh.position.set(baseX, centerY, baseZ);
            mesh.castShadow = true;
            mesh.receiveShadow = true;
            ribsGroup.add(mesh);
          }
        }
        // Upper siding segment
        if (yEnd > wainscotH) {
          const sStart = Math.max(yStart, wainscotH);
          const h = yEnd - sStart;
          if (h > 0.15) {
            const centerY = sStart + h / 2;
            const geo = planeAxis === 'X'
              ? new THREE.BoxGeometry(RIB_HEIGHT_FT, h, ribW)
              : new THREE.BoxGeometry(ribW, h, RIB_HEIGHT_FT);
            const mesh = new THREE.Mesh(geo, sidingRibMat);
            mesh.position.set(baseX, centerY, baseZ);
            mesh.castShadow = true;
            mesh.receiveShadow = true;
            ribsGroup.add(mesh);
          }
        }
      } else {
        // Single siding segment
        const h = yEnd - yStart;
        const centerY = yStart + h / 2;
        const geo = planeAxis === 'X'
          ? new THREE.BoxGeometry(RIB_HEIGHT_FT, h, ribW)
          : new THREE.BoxGeometry(ribW, h, RIB_HEIGHT_FT);
        const mesh = new THREE.Mesh(geo, sidingRibMat);
        mesh.position.set(baseX, centerY, baseZ);
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        ribsGroup.add(mesh);
      }
    });
  };

  // 1. LEFT WALL (-halfW)
  if (walls.left.enclosed) {
    const ribX = -halfW - wallThick / 2 - RIB_HEIGHT_FT / 2;
    const leftEaveH = style === 'single_slope' ? eaveHeight + width * (roofPitch / 12) : eaveHeight;
    let ribIdx = 0;
    for (let z = -halfL + RIB_SPACING_FT / 2; z < halfL; z += RIB_SPACING_FT) {
      const isSeam = ribIdx % 4 === 0;
      const intersectingOps = checkOpeningIntersections('left', z);
      addVerticalRib(ribX, z, leftEaveH, walls.left.hasWainscot, intersectingOps, isSeam, 'X');
      ribIdx++;
    }
  }

  // 2. RIGHT WALL (+halfW)
  if (walls.right.enclosed) {
    const ribX = halfW + wallThick / 2 + RIB_HEIGHT_FT / 2;
    let ribIdx = 0;
    for (let z = -halfL + RIB_SPACING_FT / 2; z < halfL; z += RIB_SPACING_FT) {
      const isSeam = ribIdx % 4 === 0;
      const intersectingOps = checkOpeningIntersections('right', z);
      addVerticalRib(ribX, z, eaveHeight, walls.right.hasWainscot, intersectingOps, isSeam, 'X');
      ribIdx++;
    }
  }

  // 3. FRONT WALL (+halfL)
  if (walls.front.enclosed) {
    const ribZ = halfL + wallThick / 2 + RIB_HEIGHT_FT / 2;
    let ribIdx = 0;
    for (let x = -halfW + RIB_SPACING_FT / 2; x < halfW; x += RIB_SPACING_FT) {
      const isSeam = ribIdx % 4 === 0;
      const wallTopY = getRoofProfileY(x, width, eaveHeight, roofPitch, style);
      const intersectingOps = checkOpeningIntersections('front', x);
      addVerticalRib(x, ribZ, wallTopY, walls.front.hasWainscot, intersectingOps, isSeam, 'Z');
      ribIdx++;
    }
  }

  // 4. BACK WALL (-halfL)
  if (walls.back.enclosed) {
    const ribZ = -halfL - wallThick / 2 - RIB_HEIGHT_FT / 2;
    let ribIdx = 0;
    for (let x = -halfW + RIB_SPACING_FT / 2; x < halfW; x += RIB_SPACING_FT) {
      const isSeam = ribIdx % 4 === 0;
      const wallTopY = getRoofProfileY(x, width, eaveHeight, roofPitch, style);
      const intersectingOps = checkOpeningIntersections('back', x);
      addVerticalRib(x, ribZ, wallTopY, walls.back.hasWainscot, intersectingOps, isSeam, 'Z');
      ribIdx++;
    }
  }

  return ribsGroup;
}

/**
 * Builds 3D physical 3/4" high ribs spaced every 9 inches on roof slopes
 */
export function buildRoofAgPanelRibs(
  rafterLength: number,
  roofLengthWithOverhang: number,
  roofThickness: number,
  roofRibMat: THREE.Material
): THREE.Group {
  const ribsGroup = new THREE.Group();
  ribsGroup.name = 'AgPanelRoofSlopeRibs';

  const { RIB_SPACING_FT, RIB_HEIGHT_FT, RIB_WIDTH_FT, SEAM_RIB_WIDTH_FT } = AG_PANEL_CONSTANTS;
  const yOffset = roofThickness / 2 + RIB_HEIGHT_FT / 2;

  let ribIdx = 0;
  for (let z = -roofLengthWithOverhang / 2 + RIB_SPACING_FT / 2; z < roofLengthWithOverhang / 2; z += RIB_SPACING_FT) {
    const isSeam = ribIdx % 4 === 0;
    const ribW = isSeam ? SEAM_RIB_WIDTH_FT : RIB_WIDTH_FT;
    const ribGeo = new THREE.BoxGeometry(rafterLength, RIB_HEIGHT_FT, ribW);
    const ribMesh = new THREE.Mesh(ribGeo, roofRibMat);
    ribMesh.position.set(0, yOffset, z);
    ribMesh.castShadow = true;
    ribMesh.receiveShadow = true;
    ribsGroup.add(ribMesh);
    ribIdx++;
  }

  return ribsGroup;
}
