import React, { createContext, useContext, useEffect, useState } from 'react';

export type ThemeMode = 'system' | 'light' | 'dark';

interface ThemeContextType {
  mode: ThemeMode;
  isDark: boolean;
  setMode: (mode: ThemeMode) => void;
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [mode, setModeState] = useState<ThemeMode>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = window.localStorage.getItem('master_metals_app_settings');
        if (saved) {
          const parsed: unknown = JSON.parse(saved);
          if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
            const theme = (parsed as { theme?: unknown }).theme;
            if (theme === 'light' || theme === 'dark' || theme === 'system') return theme;
          }
        }
      } catch {
        // Storage can be blocked or contain malformed data; use the system default.
      }
    }
    return 'system';
  });

  const [systemIsDark, setSystemIsDark] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return typeof window.matchMedia === 'function' ? window.matchMedia('(prefers-color-scheme: dark)').matches : false;
    }
    return true;
  });

  // Listen to phone system UI theme changes
  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (typeof window.matchMedia !== 'function') return;
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    setSystemIsDark(mediaQuery.matches);

    const handler = (e: MediaQueryListEvent) => {
      setSystemIsDark(e.matches);
    };

    mediaQuery.addEventListener('change', handler);
    return () => mediaQuery.removeEventListener('change', handler);
  }, []);

  const isDark = mode === 'dark' ? true : mode === 'light' ? false : systemIsDark;

  // The App settings are the single source of truth for the document theme.
  // This context intentionally does not mutate <html class='dark'> independently.

  const setMode = (newMode: ThemeMode) => {
    setModeState(newMode);
    try {
      const saved = window.localStorage.getItem('master_metals_app_settings');
      const parsed = saved ? JSON.parse(saved) : {};
      const settings = parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
      window.localStorage.setItem('master_metals_app_settings', JSON.stringify({ ...settings, theme: newMode }));
    } catch {
      // Theme changes still apply in memory if persistence is unavailable.
    }
  };

  const toggleTheme = () => {
    if (mode === 'system') {
      // Toggle to opposite of current system state
      setMode(systemIsDark ? 'light' : 'dark');
    } else if (mode === 'dark') {
      setMode('light');
    } else {
      setMode('system');
    }
  };

  return (
    <ThemeContext.Provider value={{ mode, isDark, setMode, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = (): ThemeContextType => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};
