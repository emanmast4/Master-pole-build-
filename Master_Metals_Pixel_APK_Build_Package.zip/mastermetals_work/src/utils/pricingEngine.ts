import {
  CustomBuildingState,
  ItemizedBomLine,
  MetalSheetTakeoffSummary,
  PricingBreakdown,
  TrussCalculationBreakdown,
  WeightBearingWallHeadersBreakdown,
  WallSide,
} from '../types';

export function formatCutLength(feetDecimal: number): {
  formatted: string;
  feet: number;
  inches: number;
  decimal: number;
} {
  let feet = Math.floor(feetDecimal);
  let inches = Math.round((feetDecimal - feet) * 12);
  if (inches === 12) {
    feet += 1;
    inches = 0;
  }
  const decimal = Number((feet + inches / 12).toFixed(2));
  const formatted = `${feet}'-${inches}"`;
  return { formatted, feet, inches, decimal };
}

export function calculateTrussEngineering(state: CustomBuildingState): TrussCalculationBreakdown {
  const { dimensions, snowLoad, trussType, unitRates } = state;
  const width = dimensions.width;
  const length = dimensions.length;
  const pitch = dimensions.roofPitch;
  const spacing = dimensions.trussSpacing;

  const halfSpan = width / 2;
  // Slope factor = sqrt(1 + (pitch/12)^2)
  const slopeFactor = Math.sqrt(1 + Math.pow(pitch / 12, 2));
  const rafterLengthFt = Number((halfSpan * slopeFactor).toFixed(2));
  const apexPeakHeightFt = Number((halfSpan * (pitch / 12)).toFixed(2));

  // Truss count based on building length and spacing
  // Place a truss at each end and at every spacing interval. Round up so a
  // non-divisible building length never leaves an oversized unsupported bay.
  const totalTrussesNeeded = Math.ceil(length / spacing) + 1;
  const gableEndTrussesCount = 2;
  const standardTrussesCount = Math.max(0, totalTrussesNeeded - gableEndTrussesCount);

  // Web members scale with span
  const webMembersCount = Math.max(4, Math.round(width / 4.8));

  // Board footage estimation based on chords and webs
  const boardFootagePerTruss = Math.round(
    (width * 1.6 + 2 * rafterLengthFt * 1.6 + webMembersCount * (apexPeakHeightFt * 0.75)) *
      (width > 40 ? 1.4 : 1.0)
  );

  // Plate connectors (apex, heels, web nodes)
  const plateConnectorsCount = 6 + Math.round(webMembersCount * 1.6);

  // Piggyback requirement if apex exceeds standard 13.5ft transport height
  const piggybackRequired = apexPeakHeightFt > 13.5;
  const piggybackSurcharge = piggybackRequired ? 120 + width * 4.2 : 0;

  // 1. Base span cost (scales with width)
  const baseSpanCost = width * unitRates.trussBasePerFootSpan;

  // 2. Pitch slope surcharge (steeper pitches consume more chord length and web material)
  const pitchDelta = slopeFactor - 1; // 0 for flat, ~0.05 for 4:12, ~0.20 for 8:12, ~0.41 for 12:12
  const pitchSlopeSurcharge = baseSpanCost * (pitchDelta * unitRates.trussPitchMultiplierWeight);

  // 3. Snow load factor (scales lumber grade, chord size 2x4 -> 2x6 -> 2x8)
  // The rate model is calibrated from a 20 PSF baseline; never discount
  // below that baseline if malformed or legacy data contains a lower value.
  const snowLoadSteps = Math.max(0, (snowLoad - 20) / 20); // 0 for 20psf, 0.5 for 30psf, 1.0 for 40psf, 2.0 for 60psf
  const snowLoadMultiplier = 1 + snowLoadSteps * (unitRates.trussHeavyLoadFactor - 1);

  // 4. Truss style multiplier
  let trussStyleMultiplier = 1.0;
  if (trussType === 'scissor') trussStyleMultiplier = 1.28;
  if (trussType === 'attic_storage') trussStyleMultiplier = 1.65;
  if (trussType === 'mono_slope') trussStyleMultiplier = 0.95;

  const gussetPlateCost = (plateConnectorsCount / 8) * unitRates.trussGussetPlateBase;

  // Single Standard Truss Unit Price
  const rawStandardUnit =
    (baseSpanCost + pitchSlopeSurcharge + gussetPlateCost + piggybackSurcharge) *
    snowLoadMultiplier *
    trussStyleMultiplier;
  const unitCostStandardTruss = Math.round(rawStandardUnit * 100) / 100;

  // Gable end truss has vertical drop studs spaced 24" O.C. for sheeting nailers
  const unitCostGableTruss = Math.round((unitCostStandardTruss * 1.25 + width * 3.5) * 100) / 100;

  // Total Truss Package Cost
  const totalTrussPackageCost = Math.round(
    standardTrussesCount * unitCostStandardTruss +
      gableEndTrussesCount * unitCostGableTruss +
      unitRates.trussDeliveryCraneSetup
  );

  return {
    spanWidthFt: width,
    pitch,
    slopeFactor: Number(slopeFactor.toFixed(3)),
    rafterLengthFt,
    apexPeakHeightFt,
    totalTrussesNeeded,
    standardTrussesCount,
    gableEndTrussesCount,
    webMembersCount,
    boardFootagePerTruss,
    plateConnectorsCount,
    piggybackRequired,
    baseSpanCost: Math.round(baseSpanCost),
    pitchSlopeSurcharge: Math.round(pitchSlopeSurcharge),
    snowLoadSurcharge: Math.round(baseSpanCost * (snowLoadMultiplier - 1)),
    trussStyleSurcharge: Math.round(baseSpanCost * (trussStyleMultiplier - 1)),
    piggybackSurcharge: Math.round(piggybackSurcharge),
    unitCostStandardTruss,
    unitCostGableTruss,
    totalTrussPackageCost,
  };
}

export function calculateBuildingPricing(state: CustomBuildingState): PricingBreakdown {
  const { style = 'gable', dimensions, materials, interior, openings, leanTo, unitRates, walls } = state;
  const { width, length, eaveHeight, overhangInches } = dimensions;

  const floorSqFt = width * length;
  const eaveOverhangInches = dimensions.eaveOverhangInches ?? overhangInches;
  const gableOverhangInches = dimensions.gableOverhangInches ?? overhangInches;
  const overhangFt = eaveOverhangInches / 12;
  const gableOverhangFt = gableOverhangInches / 12;
  const validationWarnings: string[] = [];
  if (style !== 'gable') validationWarnings.push(`The current takeoff geometry is primarily modeled for a conventional gable roof; ${style.replace('_', ' ')} style quantities need a separate geometry review.`);
  if (dimensions.roofPitch < 1 || dimensions.roofPitch > 12) validationWarnings.push('Main roof pitch is outside the supported 1:12–12:12 range.');
  if (leanTo.enabled && (leanTo.pitch < 1 || leanTo.pitch > 12)) validationWarnings.push('Lean-to pitch is outside the supported 1:12–12:12 range.');
  for (let i = 0; i < openings.length; i++) {
    const op = openings[i];
    const wallRun = op.side === 'front' || op.side === 'back' ? width : length;
    const sill = op.bottomOffsetFt ?? (op.type === 'window' ? 3 : 0);
    if (op.widthFt <= 0 || op.heightFt <= 0) validationWarnings.push(`${op.label}: opening width and height must be greater than zero.`);
    if (sill < 0) validationWarnings.push(`${op.label}: opening sill/bottom offset cannot be negative.`);
    if (op.positionOffsetFt < 0 || op.positionOffsetFt + op.widthFt > wallRun + 0.001) validationWarnings.push(`${op.label}: opening extends beyond the ${op.side} wall (${wallRun} ft long).`);
    if (!walls[op.side].enclosed) validationWarnings.push(`${op.label}: this opening is on an open ${op.side} wall, so no enclosed-wall panel cutout is modeled there.`);
    if (op.side === 'left' || op.side === 'right') {
      if (sill + op.heightFt > eaveHeight + 0.001) validationWarnings.push(`${op.label}: opening top exceeds the ${eaveHeight} ft eave-wall height; verify the vertical placement.`);
    } else {
      const x1 = Math.max(0, op.positionOffsetFt);
      const x2 = Math.min(width, op.positionOffsetFt + op.widthFt);
      const roofHeightAt = (x: number) => eaveHeight + Math.min(x, width - x) * dimensions.roofPitch / 12;
      const minRoofHeight = Math.min(roofHeightAt(x1), roofHeightAt(x2));
      if (sill + op.heightFt > minRoofHeight + 0.001) validationWarnings.push(`${op.label}: opening top may intersect the ${op.side} gable roof slope; check its width, position, and height.`);
    }
    for (let j = i + 1; j < openings.length; j++) {
      const other = openings[j];
      if (other.side !== op.side) continue;
      const otherSill = other.bottomOffsetFt ?? (other.type === 'window' ? 3 : 0);
      const horizontalOverlap = Math.max(op.positionOffsetFt, other.positionOffsetFt) < Math.min(op.positionOffsetFt + op.widthFt, other.positionOffsetFt + other.widthFt) - 0.001;
      const verticalOverlap = Math.max(sill, otherSill) < Math.min(sill + op.heightFt, otherSill + other.heightFt) - 0.001;
      if (horizontalOverlap && verticalOverlap) validationWarnings.push(`${op.label} and ${other.label} overlap on the ${op.side} wall; resolve the opening layout before ordering.`);
    }
  }
  if (leanTo.enabled) {
    const hostRun = leanTo.side === 'front' || leanTo.side === 'back' ? width : length;
    const startOffset = leanTo.startOffsetFt ?? 0;
    if (leanTo.widthFt <= 0 || leanTo.lengthFt <= 0) validationWarnings.push('Lean-to width and length must both be greater than zero.');
    if (startOffset < 0 || startOffset + leanTo.lengthFt > hostRun + 0.001) validationWarnings.push(`Lean-to run (${startOffset}' offset + ${leanTo.lengthFt}' length) extends beyond its ${hostRun}' host wall.`);
    const pitchDerivedOuterHeight = eaveHeight - leanTo.dropBelowEaveFt - leanTo.widthFt * leanTo.pitch / 12;
    const effectiveOuterHeight = leanTo.outerEaveHeightFt ?? pitchDerivedOuterHeight;
    if (effectiveOuterHeight > eaveHeight - leanTo.dropBelowEaveFt + 0.001) validationWarnings.push('Lean-to outer eave height is higher than its attachment-side clearance height; verify the roof plane and pitch.');
    if (leanTo.outerEaveHeightFt !== undefined && Math.abs(leanTo.outerEaveHeightFt - pitchDerivedOuterHeight) > 0.5) validationWarnings.push(`Lean-to outer eave height (${leanTo.outerEaveHeightFt.toFixed(1)} ft) does not match the selected ${leanTo.pitch}:12 pitch projection (about ${pitchDerivedOuterHeight.toFixed(1)} ft); verify which value should control the roof plane.`);
    if (effectiveOuterHeight < 6) validationWarnings.push('Lean-to outer eave height is below 6 ft; verify usable clearance and post design.');
  }

  // Truss calculations
  const trussBreakdown = calculateTrussEngineering(state);

  // 36" (3.0 ft) Net Coverage Specifications for Metal Panels
  const PANEL_COVERAGE_INCHES = 36;
  const PANEL_COVERAGE_FT = 3.0;

  // --- ROOF METAL PANELS (36" NET COVERAGE) ---
  const halfSpan = width / 2;
  const rafterWithOverhang = (halfSpan + overhangFt) * trussBreakdown.slopeFactor;
  const gableRakeLength = (halfSpan + gableOverhangFt) * trussBreakdown.slopeFactor;
  const lengthWithOverhang = length + 2 * gableOverhangFt;
  const totalRoofAreaSqFt = Math.round(2 * rafterWithOverhang * lengthWithOverhang);

  let roofRate = unitRates.roofRibbedSteelPerSqFt;
  let roofTypeName = '36" Ag-Panel Roofing (3/4" Ribs @ 9" O.C.)';
  let isMetalRoof = true;

  // Calculate cut length of main roof sheets (ridge to eave overhang)
  const roofCut = formatCutLength(rafterWithOverhang);
  // Sheets along ridge run per slope (36" = 3.0 ft net coverage)
  const roofSheetsPerSlope = Math.ceil(lengthWithOverhang / PANEL_COVERAGE_FT);
  const mainRoofSheetsQty = roofSheetsPerSlope * 2; // 2 symmetric slopes
  const sqFtPerRoofSheet = Number((roofCut.decimal * PANEL_COVERAGE_FT).toFixed(2));
  const unitPricePerRoofSheet = Number((sqFtPerRoofSheet * roofRate).toFixed(2));
  const mainRoofCost = Math.round(mainRoofSheetsQty * unitPricePerRoofSheet);

  // Lean-to porch roof metal (if enabled)
  let leanToRoofSheetsQty = 0;
  let leanToRoofCost = 0;
  let ltCut = { formatted: '', feet: 0, inches: 0, decimal: 0 };
  let sqFtPerLtSheet = 0;
  let unitPricePerLtSheet = 0;

  if (leanTo.enabled) {
    const leanToSlopeFactor = Math.sqrt(1 + Math.pow(leanTo.pitch / 12, 2));
    const leanToOutsideOverhangFt = (leanTo.hasOutsideEaveOverhang ?? true) ? overhangFt : 0;
    const leanToRafterFt = (leanTo.widthFt + leanToOutsideOverhangFt) * leanToSlopeFactor;
    ltCut = formatCutLength(leanToRafterFt);
    const leanToRoofRunFt = leanTo.lengthFt + 2 * gableOverhangFt;
    leanToRoofSheetsQty = Math.ceil(leanToRoofRunFt / PANEL_COVERAGE_FT);
    sqFtPerLtSheet = Number((ltCut.decimal * PANEL_COVERAGE_FT).toFixed(2));
    unitPricePerLtSheet = Number((sqFtPerLtSheet * roofRate).toFixed(2));
    leanToRoofCost = Math.round(leanToRoofSheetsQty * unitPricePerLtSheet);
  }

  const roofSheetingCost = isMetalRoof
    ? mainRoofCost + (leanTo.enabled ? leanToRoofCost : 0)
    : Math.round(totalRoofAreaSqFt * roofRate);
  const totalRoofMaterialAreaSqFt = totalRoofAreaSqFt + (leanTo.enabled ? leanToRoofSheetsQty * sqFtPerLtSheet : 0);

  // Main wall area follows the actual open/enclosed configuration. Open gables still receive metal on their truss triangle.
  const enclosedEaveWallCount = Number(walls.left.enclosed) + Number(walls.right.enclosed);
  const enclosedGableWallCount = Number(walls.front.enclosed) + Number(walls.back.enclosed);
  const eaveWallsArea = enclosedEaveWallCount * length * eaveHeight;
  const gableWallsRectArea = enclosedGableWallCount * width * eaveHeight;
  const gablePeaksArea = 2 * (0.5 * width * trussBreakdown.apexPeakHeightFt);
  const grossMainWallArea = eaveWallsArea + gableWallsRectArea + gablePeaksArea;
  const totalGrossWallArea = Math.max(0, grossMainWallArea - openings.reduce((sum, op) => sum + (walls[op.side].enclosed ? op.widthFt * op.heightFt : 0), 0));

  // Openings specification items
  let openingsArea = 0;
  let openingsCost = 0;
  const openingItems: ItemizedBomLine[] = [];

  openings.forEach((op) => {
    const area = op.widthFt * op.heightFt;
    openingsArea += area;

    let opCost = 0;
    if (op.type === 'overhead_door') {
      opCost = area * unitRates.overheadDoorBasePerSqFt;
      if (op.insulated) opCost += unitRates.overheadDoorInsulatedAddon;
      if (op.hasWindows) opCost += 140; // window insert package
    } else if (op.type === 'walk_door') {
      opCost = op.insulated ? unitRates.walkDoorInsulatedGlass : unitRates.walkDoorCommercialStandard;
    } else if (op.type === 'window') {
      opCost = unitRates.windowSliderStandard + (area > 12 ? 90 : 0);
    } else if (op.type === 'sliding_barn_door') {
      opCost = unitRates.slidingBarnDoorDouble;
    }

    openingsCost += opCost;
    openingItems.push({
      id: op.id,
      category: 'Doors & Windows',
      item: op.label,
      description: `${op.widthFt}'x${op.heightFt}' (${op.side.toUpperCase()} wall, sill ${op.bottomOffsetFt ?? (op.type === 'window' ? 3 : 0)}' above floor)${op.insulated ? ' - Insulated' : ''}`,
      quantity: 1,
      unit: 'ea',
      unitPrice: Math.round(opCost),
      totalCost: Math.round(opCost),
    });
  });

  // --- WALL SIDING & WAINSCOT PANELS (36" NET COVERAGE) ---
  let sidingRate = unitRates.siding29gaPerSqFt;
  let sidingTypeName = '36" Ag-Panel Siding (3/4" Ribs @ 9" O.C.)';
  if (materials.sidingType === '26ga_commercial') {
    sidingRate = unitRates.siding26gaPerSqFt;
    sidingTypeName = '36" Ag-Panel Commercial Gauge (3/4" Ribs @ 9" O.C.)';
  }

  // 1. Wainscot Panels (36" panels covering bottom 3ft or 4ft perimeter)
  const hasAnyWainscot = Object.values(walls).some((w) => w.hasWainscot && w.enclosed);
  const wainscotHeight = materials.wainscotHeightFt || 3;
  const wainscotCut = formatCutLength(wainscotHeight);
  const sqFtPerWainscotSheet = Number((wainscotCut.decimal * PANEL_COVERAGE_FT).toFixed(2));
  const wainscotRate = unitRates.wainscotPerSqFt ?? Number((sidingRate + 0.65).toFixed(2));
  const unitPricePerWainscotSheet = Number((sqFtPerWainscotSheet * wainscotRate).toFixed(2));

  let totalWainscotSheets = 0;
  if (hasAnyWainscot) {
    for (const side of ['left', 'right', 'front', 'back'] as WallSide[]) {
      if (!walls[side].enclosed || !walls[side].hasWainscot) continue;
      const sideRunFt = side === 'left' || side === 'right' ? length : width;
      const columns = Math.ceil(sideRunFt / PANEL_COVERAGE_FT);
      const wallOpenings = openings.filter((op) => op.side === side && op.type !== 'window' && (op.bottomOffsetFt ?? 0) <= 0.001);
      for (let col = 0; col < columns; col++) {
        const colStart = col * PANEL_COVERAGE_FT;
        const colEnd = Math.min(sideRunFt, colStart + PANEL_COVERAGE_FT);
        const coveredByDoor = wallOpenings.some((op) => op.heightFt >= wainscotHeight && op.positionOffsetFt <= colStart + 0.001 && op.positionOffsetFt + op.widthFt >= colEnd - 0.001);
        if (!coveredByDoor) totalWainscotSheets += 1;
      }
    }
  }
  const wainscotCost = Math.round(totalWainscotSheets * unitPricePerWainscotSheet);

  // 2. Sidewalls Upper Siding Panels (Left and Right Eave Walls)
  const sidewallNetHeight = hasAnyWainscot ? Math.max(1, eaveHeight - wainscotHeight) : eaveHeight;
  const sidewallCut = formatCutLength(sidewallNetHeight);
  const sidewallPanelGroupsMap = new Map<string, { cut: ReturnType<typeof formatCutLength>; quantity: number; sqFt: number; unitPrice: number; totalCost: number }>();
  let totalSidewallSheets = 0;
  // Individual 3-ft panel columns on enclosed eave walls. A column wholly inside a floor-level door opening can use a shorter panel above the header; columns partially intersecting an opening remain full-length so the opening can be cut from the sheet without assuming a horizontal splice detail.
  for (const side of ['left', 'right'] as WallSide[]) {
    if (!walls[side].enclosed) continue;
    const sideHasWainscot = walls[side].hasWainscot && walls[side].enclosed;
    const sideNetHeight = sideHasWainscot ? Math.max(1, eaveHeight - wainscotHeight) : eaveHeight;
    const wallOpenings = openings.filter((op) => op.side === side);
    const columns = Math.ceil(length / PANEL_COVERAGE_FT);
    for (let col = 0; col < columns; col++) {
      const colStart = col * PANEL_COVERAGE_FT;
      const colEnd = Math.min(length, colStart + PANEL_COVERAGE_FT);
      const floorDoors = wallOpenings.filter((op) => op.type !== 'window' && (op.bottomOffsetFt ?? 0) <= 0.001 && op.positionOffsetFt <= colStart + 0.001 && op.positionOffsetFt + op.widthFt >= colEnd - 0.001);
      const doorTop = floorDoors.reduce((max, op) => Math.max(max, op.heightFt), 0);
      const sheetHeight = Math.max(0, sideNetHeight - (doorTop > 0 ? Math.max(0, doorTop - (sideHasWainscot ? wainscotHeight : 0)) : 0));
      if (sheetHeight <= 0.05) continue;
      const cut = formatCutLength(sheetHeight);
      const sqFt = Number((cut.decimal * PANEL_COVERAGE_FT).toFixed(2));
      const unitPrice = Number((sqFt * sidingRate).toFixed(2));
      const group = sidewallPanelGroupsMap.get(cut.formatted);
      if (group) { group.quantity += 1; group.totalCost = Math.round(group.quantity * group.unitPrice); }
      else sidewallPanelGroupsMap.set(cut.formatted, { cut, quantity: 1, sqFt, unitPrice, totalCost: Math.round(unitPrice) });
      totalSidewallSheets += 1;
    }
  }
  const sidewallPanelGroups = Array.from(sidewallPanelGroupsMap.values()).sort((a, b) => b.cut.decimal - a.cut.decimal);
  const totalSidewallCost = sidewallPanelGroups.reduce((sum, group) => sum + group.totalCost, 0);

  // 3. Gable Endwalls Stepped Rake Cut Panels (Front and Back Walls)
  const panelsAcrossGable = Math.ceil(width / PANEL_COVERAGE_FT);
  const apexPeakHeightFt = trussBreakdown.apexPeakHeightFt;

  interface GableCutGroup {
    key: string;
    lengthFormatted: string;
    lengthDecimal: number;
    quantity: number;
    sqFtPerSheet: number;
    unitPrice: number;
    totalCost: number;
    label: string;
  }

  const gableCutMap = new Map<string, GableCutGroup>();
  let totalGableSheets = 0;

  // Enclosed gables receive full wall-height panels with individual rake cuts.
  // Open gables still receive metal over the gable-end truss triangle, leaving the area below the trusses open.
  const gableSides: WallSide[] = ['front', 'back'];
  for (const gableSide of gableSides) {
    for (let col = 0; col < panelsAcrossGable; col++) {
      const panelCenter = (col + 0.5) * PANEL_COVERAGE_FT;
      const distFromCenter = Math.abs(panelCenter - width / 2);
      const highEdgeDistFromCenter = Math.max(0, distFromCenter - PANEL_COVERAGE_FT / 2);
      const rakeGainFt = Math.max(0, apexPeakHeightFt - highEdgeDistFromCenter * (dimensions.roofPitch / 12));
      const isEnclosed = walls[gableSide].enclosed;
      const gableHasWainscot = isEnclosed && walls[gableSide].hasWainscot;
      const gableBaseHeight = gableHasWainscot ? Math.max(1, eaveHeight - wainscotHeight) : eaveHeight;
      let rawSheetHeight = (isEnclosed ? gableBaseHeight : 0) + rakeGainFt;
      const colStart = col * PANEL_COVERAGE_FT;
      const colEnd = Math.min(width, colStart + PANEL_COVERAGE_FT);
      if (isEnclosed) {
        const floorDoors = openings.filter((op) => op.side === gableSide && op.type !== 'window' && (op.bottomOffsetFt ?? 0) <= 0.001 && op.positionOffsetFt <= colStart + 0.001 && op.positionOffsetFt + op.widthFt >= colEnd - 0.001);
        const doorTop = floorDoors.reduce((max, op) => Math.max(max, op.heightFt), 0);
        if (doorTop > 0) rawSheetHeight = Math.max(0, rawSheetHeight - Math.max(0, doorTop - (gableHasWainscot ? wainscotHeight : 0)));
      }
      if (rawSheetHeight <= 0.05) continue;
      const cut = formatCutLength(rawSheetHeight);
      let label = isEnclosed ? 'Gable Intermediate Rake' : 'Open Gable Truss Cover';
      if (rakeGainFt >= apexPeakHeightFt - 0.4) label = isEnclosed ? 'Gable Peak' : 'Open Gable Peak';
      else if (distFromCenter > width / 2 - PANEL_COVERAGE_FT) label = isEnclosed ? 'Gable Eave Edge' : 'Open Gable Eave Edge';
      const existing = gableCutMap.get(cut.formatted);
      if (existing) { existing.quantity += 1; existing.totalCost = Math.round(existing.quantity * existing.unitPrice); }
      else {
        const sqFt = Number((cut.decimal * PANEL_COVERAGE_FT).toFixed(2));
        const unitPrice = Number((sqFt * sidingRate).toFixed(2));
        gableCutMap.set(cut.formatted, { key: cut.formatted, lengthFormatted: cut.formatted, lengthDecimal: cut.decimal, quantity: 1, sqFtPerSheet: sqFt, unitPrice, totalCost: Math.round(unitPrice), label });
      }
      totalGableSheets += 1;
    }
  }

  // Sort gable cut groups by length descending (Peak down to Eave)
  const gableCutGroups = Array.from(gableCutMap.values()).sort(
    (a, b) => b.lengthDecimal - a.lengthDecimal
  );
  const totalGableSidingCost = gableCutGroups.reduce((sum, g) => sum + g.totalCost, 0);

  const wallSidingCost = totalSidewallCost + totalGableSidingCost;

  // Summary of all 36" metal panels
  const totalRoofSheets = mainRoofSheetsQty + (leanTo.enabled ? leanToRoofSheetsQty : 0);
  let totalWallSidingSheets = totalSidewallSheets + totalGableSheets;
  let totalMetalSheets = totalRoofSheets + totalWallSidingSheets + totalWainscotSheets;

  let totalMetalLinearFeet =
    mainRoofSheetsQty * roofCut.decimal +
    (leanTo.enabled ? leanToRoofSheetsQty * ltCut.decimal : 0) +
    sidewallPanelGroups.reduce((sum, group) => sum + group.quantity * group.cut.decimal, 0) +
    gableCutGroups.reduce((acc, g) => acc + g.quantity * g.lengthDecimal, 0) +
    totalWainscotSheets * wainscotCut.decimal;

  totalMetalLinearFeet = Number(totalMetalLinearFeet.toFixed(1));
  let totalMetalSquareFeet = Number((totalMetalLinearFeet * PANEL_COVERAGE_FT).toFixed(1));

  const metalTakeoff: MetalSheetTakeoffSummary = {
    panelCoverageInches: PANEL_COVERAGE_INCHES,
    panelCoverageFt: PANEL_COVERAGE_FT,
    totalRoofSheets,
    totalWallSidingSheets,
    totalWainscotSheets,
    totalMetalSheets,
    totalMetalLinearFeet,
    totalMetalSquareFeet,
  };

  // Architectural Trim & Fasteners Package (Itemized & Accurate Takeoff)
  const defaultTrimColorName = materials.trimColorName || 'Trim Color';
  const cornerTrimColorName = (materials.customTrimColorsEnabled && materials.cornerTrimColorName) || defaultTrimColorName;
  const eaveTrimColorName = (materials.customTrimColorsEnabled && materials.eaveTrimColorName) || defaultTrimColorName;
  const rakeTrimColorName = (materials.customTrimColorsEnabled && materials.rakeTrimColorName) || defaultTrimColorName;
  const ridgeCapColorName = (materials.customTrimColorsEnabled && materials.ridgeCapColorName) || defaultTrimColorName;
  const doorTrimColorName = (materials.customTrimColorsEnabled && materials.doorTrimColorName) || defaultTrimColorName;
  const wainscotCapColorName = (materials.customTrimColorsEnabled && materials.wainscotCapColorName) || defaultTrimColorName;
  const ratGuardColorName = (materials.customTrimColorsEnabled && materials.ratGuardColorName) || defaultTrimColorName;
  const dripEdgeColorName = (materials.customTrimColorsEnabled && materials.dripEdgeColorName) || defaultTrimColorName;
  const fasciaColorName = (materials.customTrimColorsEnabled && materials.fasciaTrimColorName) || defaultTrimColorName;
  const soffitColorName = (materials.customTrimColorsEnabled && materials.soffitColorName) || defaultTrimColorName;
  const snowGuardColorName = (materials.customTrimColorsEnabled && materials.snowGuardColorName) || defaultTrimColorName;

  // Trim piece stock length preference: standard 10'-6" vs 12'-0" pieces
  const trimStockChoice = materials.trimStockLength || '10ft6in';
  const stockLengthFt = trimStockChoice === '12ft' ? 12.0 : 10.5;
  const stockLengthLabel = trimStockChoice === '12ft' ? `12'-0"` : `10'-6"`;
  const effectiveLapFt = stockLengthFt - 0.5; // standard 6-inch lap allowance

  const perimeterFt = 2 * (width + length);

  // 1. Lower Wall & Base Foundations
  // Rat Guard: installed horizontally along bottom perimeter, fastened directly to treated splash plank (skirt board) before siding/wainscot is hung
  const ratGuardRate = unitRates.ratGuardRate ?? 2.50;
  const ratGuardPcs = Math.ceil(perimeterFt / effectiveLapFt);
  const ratGuardCost = Math.round(ratGuardPcs * stockLengthFt * ratGuardRate);

  // Double Angle (Wainscot Drip Ledge): horizontal drip ledge preventing water from seeping into joint between wainscot and upper wall siding
  const doubleAngleRate = unitRates.doubleAngleRate ?? 2.75;
  const doubleAnglePcs = hasAnyWainscot ? Math.ceil(perimeterFt / effectiveLapFt) : 0;
  const doubleAngleCost = Math.round(doubleAnglePcs * stockLengthFt * doubleAngleRate);

  // 2. Openings (Doors & Windows)
  const overheadDoors = openings.filter((op) => op.type === 'overhead_door');
  const slidingDoors = openings.filter((op) => op.type === 'sliding_barn_door');
  const walkDoors = openings.filter((op) => op.type === 'walk_door');
  const windows = openings.filter((op) => op.type === 'window');

  // Overhead Door top: wraps around top header wood framing of overhead garage door openings
  const ohDoorTopRate = unitRates.overheadDoorTopWrapRate ?? 32.00;
  const ohDoorTopPcs = [...overheadDoors, ...slidingDoors].reduce((acc, op) => acc + Math.ceil((op.widthFt + 0.5) / stockLengthFt), 0);
  const ohDoorTopCost = Math.round(ohDoorTopPcs * ohDoorTopRate);

  // Overhead Door side: wraps around vertical side studs or posts of overhead garage door openings
  const ohDoorSideRate = unitRates.overheadDoorSideWrapRate ?? 32.00;
  const ohDoorSidePcs = [...overheadDoors, ...slidingDoors].reduce((acc, op) => acc + 2 * Math.ceil(op.heightFt / stockLengthFt), 0);
  const ohDoorSideCost = Math.round(ohDoorSidePcs * ohDoorSideRate);

  // Sliding Door sides: installed along vertical side jambs of sliding barn door openings
  const slidingSideRate = unitRates.slidingDoorSideWrapRate ?? 32.00;
  const slidingSidePcs = 0;
  const slidingSideCost = Math.round(slidingSidePcs * slidingSideRate);

  // Track Cover: mounted horizontally directly over top metal sliding door trolley track, shielding roller hardware from weather
  const trackCoverRate = unitRates.slidingDoorTrackCoverRate ?? 38.00;
  const trackCoverPcs = slidingDoors.reduce((acc, op) => acc + Math.ceil((op.widthFt * 2) / effectiveLapFt), 0);
  const trackCoverCost = Math.round(trackCoverPcs * trackCoverRate);

  // Drip Cap: fastened horizontally right above window frames, service doors, to push water out and away
  const dripCapPieceRate = unitRates.dripCapRate ?? 22.00;
  const dripCapLinFt = windows.reduce((acc, op) => acc + op.widthFt + 0.5, 0) + walkDoors.reduce((acc, op) => acc + op.widthFt + 0.5, 0);
  const dripCapPcs = dripCapLinFt > 0 ? Math.ceil(dripCapLinFt / effectiveLapFt) : 0;
  const dripCapCost = Math.round(dripCapPcs * dripCapPieceRate);

  // J Channel (J-Trim): fitted around side and bottom edges of windows, man doors, and sliding doors to capture raw cut metal edges
  const jChannelPieceRate = unitRates.jChannelRate ?? 28.00;
  const leanToOutsideOverhang = (leanTo.hasOutsideEaveOverhang ?? true) && eaveOverhangInches > 0;
  const leanToOuterEaveOpen = leanTo.openSides?.outerEave ?? !leanTo.enclosed;
  const openEaveJChannelRunFt = (eaveOverhangInches > 0 ? ((!walls.left.enclosed ? lengthWithOverhang : 0) + (!walls.right.enclosed ? lengthWithOverhang : 0)) : 0) + (leanTo.enabled && leanToOutsideOverhang && leanToOuterEaveOpen ? leanTo.lengthFt + 2 * gableOverhangFt : 0);
  const jChannelLinFt =
    windows.reduce((acc, op) => acc + op.widthFt + 2 * op.heightFt, 0) +
    walkDoors.reduce((acc, op) => acc + op.widthFt + 2 * op.heightFt, 0) + openEaveJChannelRunFt;
  const hasJChannelOpening = windows.length > 0 || walkDoors.length > 0;
  const jChannelPcs = jChannelLinFt > 0 && (hasJChannelOpening || openEaveJChannelRunFt > 0) ? Math.ceil(jChannelLinFt / effectiveLapFt) : 0;
  const jChannelCost = Math.round(jChannelPcs * jChannelPieceRate);

  // F&J: dual-purpose transition trim to cleanly bridge vertical wall panels with horizontal soffit under eaves & gables
  const fAndJPieceRate = unitRates.fAndJTrimRate ?? 32.00;
  const leanToFJGableRunFt = leanTo.enabled && gableOverhangFt > 0 ? 2 * (leanTo.widthFt + gableOverhangFt) * Math.sqrt(1 + Math.pow(leanTo.pitch / 12, 2)) : 0;
  const fAndJPcs =
    (eaveOverhangInches > 0 ? (walls.left.enclosed ? Math.ceil(lengthWithOverhang / effectiveLapFt) : 0) + (walls.right.enclosed ? Math.ceil(lengthWithOverhang / effectiveLapFt) : 0) : 0) +
    (leanTo.enabled && leanToOutsideOverhang && !leanToOuterEaveOpen ? Math.ceil((leanTo.lengthFt + 2 * gableOverhangFt) / effectiveLapFt) : 0) +
    (gableOverhangInches > 0 ? 4 * Math.ceil(gableRakeLength / effectiveLapFt) + (leanTo.enabled ? 2 * Math.ceil((leanToFJGableRunFt / 2) / effectiveLapFt) : 0) : 0);
  const fAndJCost = Math.round(fAndJPcs * fAndJPieceRate);

  // 3. Corners & Vertical Transitions
  // Outside Corner: installed vertically on outside 90-degree corners where two exterior walls join (10'6" min up to 30' cut-to-length)
  const outsideCornerRate = unitRates.outsideCornerRate ?? 3.25;
  const cornerPcs = 4 + (leanTo.enabled ? 2 : 0);
  const cornerTrimCost = Math.round(cornerPcs * eaveHeight * outsideCornerRate);

  // Inside Corner: placed vertically inside interior room corners or where exterior walls form an internal angle
  const insideCornerRate = unitRates.insideCornerRate ?? 30.00;
  const insideCornerPcs = leanTo.enabled ? 2 : 0;
  const insideCornerCost = Math.round(insideCornerPcs * insideCornerRate);

  // 4. Roof-to-Wall Interfaces
  // Sidewall: along sloped roof line where roof meets adjacent vertical wall
  const sidewallPieceRate = unitRates.sidewallFlashingRate ?? 34.00;
  const isEaveSideLeanTo = leanTo.side === 'left' || leanTo.side === 'right';
  const leanToPitchChanges = leanTo.enabled && Math.abs(leanTo.pitch - dimensions.roofPitch) > 0.001;
  // On an eave-side connection at equal height and pitch, roof sheets may continue through: no transition flashing.
  // A pitch change calls for transition trim along the full connection; a height change is handled as end-wall trim.
  const sidewallConnectionRunFt = leanTo.enabled && isEaveSideLeanTo && leanToPitchChanges ? leanTo.lengthFt : 0;
  const sidewallPcs = Math.ceil(sidewallConnectionRunFt / effectiveLapFt);
  const sidewallCost = Math.round(sidewallPcs * sidewallPieceRate);

  // Endwall trim is required for gable-end attachment, or for an eave-side attachment with a height change.
  const endwallPieceRate = unitRates.endwallFlashingRate ?? 34.00;
  const leanToHeightChanges = leanTo.enabled && leanTo.dropBelowEaveFt > 0.001;
  const endwallConnectionRunFt = leanTo.enabled && (!isEaveSideLeanTo || leanToHeightChanges) ? leanTo.lengthFt : 0;
  const endwallPcs = Math.ceil(endwallConnectionRunFt / effectiveLapFt);
  const endwallCost = Math.round(endwallPcs * endwallPieceRate);

  // Valley: inside internal diagonal channels where two sloping roof sections intersect
  const valleyPieceRate = unitRates.valleyFlashingRate ?? 36.00;
  const valleyPcs = (style === 'monitor' || style === 'gambrel') ? 2 : 0;
  const valleyCost = Math.round(valleyPcs * valleyPieceRate);

  // 5. Eaves, Overhangs & Gables
  // Drip Edge: fastened along low horizontal edge of roof before roof panels are installed
  const dripEdgePieceRate = unitRates.dripEdgeRate ?? 28.00;
  const leanToRoofEaveRunFt = leanTo.enabled ? leanTo.lengthFt + 2 * gableOverhangFt : 0;
  const leanToOutsideOverhangRunFt = (leanTo.hasOutsideEaveOverhang ?? true) ? leanToRoofEaveRunFt : 0;
  const dripEdgePcs = 2 * Math.ceil(lengthWithOverhang / effectiveLapFt) + (leanTo.enabled ? Math.ceil(leanToRoofEaveRunFt / effectiveLapFt) : 0);
  const dripEdgeCost = Math.round(dripEdgePcs * dripEdgePieceRate);

  // Fascia: installed before drip edge and rakes; holds top of fascia in place and captures soffit outer edge
  const fasciaPieceRate = unitRates.fasciaCoverRate ?? 35.00;
  const leanToGableRakeLengthFt = leanTo.enabled ? (leanTo.widthFt + gableOverhangFt) * Math.sqrt(1 + Math.pow(leanTo.pitch / 12, 2)) : 0;
  const fasciaRunFt = (eaveOverhangInches > 0 ? 2 * lengthWithOverhang : 0) + (gableOverhangInches > 0 ? 4 * gableRakeLength : 0) + (leanTo.enabled && leanToOutsideOverhang ? leanToOutsideOverhangRunFt : 0) + (leanTo.enabled && gableOverhangInches > 0 ? 2 * leanToGableRakeLengthFt : 0);
  // Count each physically separate roof edge as its own stock-length run to avoid under-ordering at corners.
  const fasciaPcs =
    (eaveOverhangInches > 0 ? 2 * Math.ceil(lengthWithOverhang / effectiveLapFt) : 0) +
    (gableOverhangInches > 0 ? 4 * Math.ceil(gableRakeLength / effectiveLapFt) : 0) +
    (leanTo.enabled && leanToOutsideOverhang ? Math.ceil(leanToOutsideOverhangRunFt / effectiveLapFt) : 0) +
    (leanTo.enabled && gableOverhangInches > 0 ? 2 * Math.ceil(leanToGableRakeLengthFt / effectiveLapFt) : 0);
  const fasciaCost = Math.round(fasciaPcs * fasciaPieceRate);

  // Soffit: 3 feet wide cut either 11½" long for 1-ft overhangs, or 23½" long for 2-ft overhangs; vented for eaves, solid for gables
  const soffitCutLabelForOverhang = (inches: number) => inches <= 12 ? '11½"' : inches <= 18 ? '17½"' : '23½"';
  const eaveSoffitCutLengthLabel = soffitCutLabelForOverhang(eaveOverhangInches);
  const gableSoffitCutLengthLabel = soffitCutLabelForOverhang(gableOverhangInches);
  const eaveSoffitSheets = (eaveOverhangInches > 0 ? 2 * Math.ceil(lengthWithOverhang / 3.0) : 0) + (leanTo.enabled && leanToOutsideOverhang ? Math.ceil(leanToOutsideOverhangRunFt / 3.0) : 0); // Vented; each physical run is counted separately
  const gableSoffitSheets = gableOverhangInches > 0 ? 4 * Math.ceil(gableRakeLength / 3.0) + (leanTo.enabled ? 2 * Math.ceil(leanToGableRakeLengthFt / 3.0) : 0) : 0; // Solid on main and lean-to rake edges
  const totalSoffitSheets = eaveSoffitSheets + gableSoffitSheets;
  const soffitRateForOverhang = (inches: number) => {
    const oneFt = unitRates.soffitPanel1ftRate ?? 14.50;
    const twoFt = unitRates.soffitPanel2ftRate ?? 26.00;
    if (inches <= 12) return oneFt;
    if (inches <= 18) return Number((oneFt + (twoFt - oneFt) * 0.5).toFixed(2));
    return twoFt;
  };
  const eaveSoffitUnitPrice = soffitRateForOverhang(eaveOverhangInches);
  const gableSoffitUnitPrice = soffitRateForOverhang(gableOverhangInches);
  const soffitCost = Math.round(eaveSoffitSheets * eaveSoffitUnitPrice + gableSoffitSheets * gableSoffitUnitPrice);
  const soffitUnitPrice = totalSoffitSheets > 0 ? Number((soffitCost / totalSoffitSheets).toFixed(2)) : 0;

  // Residential Rake: installed along sloped gable edges from eave corner up to roof peak (10'6" up to 30' cut-to-length)
  const residentialRakeRate = unitRates.residentialRakeRate ?? 3.25;
  const rakePcs = 4 * Math.ceil(gableRakeLength / effectiveLapFt) + (leanTo.enabled ? 2 * Math.ceil(leanToGableRakeLengthFt / effectiveLapFt) : 0);
  const rakeCost = Math.round(rakePcs * stockLengthFt * residentialRakeRate);

  // 6. Peak & Roof Penetrations
  // Ridge Cap: placed along absolute peak (ridge line) of roof (10'6" minimum length up to 30 ft)
  const ridgeCapRate = unitRates.ridgeCapRate ?? 3.50;
  const ridgeCapPcs = Math.ceil(lengthWithOverhang / effectiveLapFt);
  const ridgeCapCost = Math.round(ridgeCapPcs * stockLengthFt * ridgeCapRate);

  // Vented Closure Foam (Rolls): sandwiched directly beneath both sides of ridge cap on top of roof ribs along entire ridge line (20' rolls)
  const ventedClosureRollRate = unitRates.ventedClosureFoam20ftRate ?? 22.00;
  const ventedClosureRolls = Math.ceil((2 * lengthWithOverhang) / 20.0);
  const ventedClosureCost = Math.round(ventedClosureRolls * ventedClosureRollRate);

  // Snow Guards: rail installed on top of roof panel 3' to 4' from bottom of roof panel
  const snowGuardRailRate = unitRates.snowGuardRailRate ?? 12.50;
  const snowGuardsActive = materials.hasSnowGuards ?? (state.snowLoad >= 30);
  const snowGuardSides = materials.snowGuardSides || 'both';
  const snowGuardRuns = snowGuardSides === 'both' ? 2 : snowGuardSides === 'none' ? 0 : 1;
  const snowGuardLinFt = snowGuardsActive ? Math.round(snowGuardRuns * lengthWithOverhang) : 0;
  const snowGuardCost = snowGuardsActive ? Math.round(snowGuardLinFt * snowGuardRailRate) : 0;

  // Optional Gutters & Downspouts (Default is false / no gutters, clean eave & fascia per build photo)
  const guttersActive = !!materials.hasGutters;
  const gutterLinFt = guttersActive ? (2 * lengthWithOverhang + (leanTo.enabled ? leanTo.lengthFt : 0)) : 0;
  const gutterPieceRate = unitRates.seamlessGutterRate ?? 8.50;
  const gutterCost = Math.round(gutterLinFt * gutterPieceRate);
  const downspoutCount = guttersActive ? (4 + (leanTo.enabled ? 2 : 0)) : 0;
  const downspoutPieceRate = unitRates.downspoutRate ?? 45.00;
  const downspoutCost = Math.round(downspoutCount * downspoutPieceRate);

  // Closures & Weatherproofing (Inside eave closures, outside closures & Butyl tape)
  const insideClosuresStripRate = unitRates.insideClosuresStripRate ?? 4.50;
  const outsideClosuresStripRate = unitRates.outsideClosuresStripRate ?? 4.50;
  const butylTapeRollRate = unitRates.butylTapeRollRate ?? 14.00;
  const woodgripScrewsBoxRate = unitRates.woodgripScrewsBoxRate ?? 38.00;
  const stitchScrewsBoxRate = unitRates.stitchScrewsBoxRate ?? 32.00;
  const hurricaneTieRate = unitRates.hurricaneTieRate ?? 2.85;

  const insideClosuresCount = Math.ceil((2 * lengthWithOverhang) / 3.0); // 3ft inside closure strips along eaves
  const outsideClosuresCount = Math.ceil((2 * lengthWithOverhang) / 3.0); // 3ft outside closure strips along ridge
  const insideClosuresCost = Math.round(insideClosuresCount * insideClosuresStripRate);
  const closuresCost = Math.round(insideClosuresCount * insideClosuresStripRate + outsideClosuresCount * outsideClosuresStripRate);
  const butylTapeRolls = Math.ceil((2 * lengthWithOverhang + perimeterFt * 0.3) / 45.0);
  const butylTapeCost = Math.round(butylTapeRolls * butylTapeRollRate);

  // Fasteners (1-1/2" Woodgrip screws in 250-ct boxes)
  const totalScrewsEst = Math.round((totalRoofMaterialAreaSqFt + totalGrossWallArea + (leanTo.enabled ? leanTo.widthFt * leanTo.lengthFt : 0)) * 1.1);
  const screwBoxes250 = Math.ceil(totalScrewsEst / 250);
  const fastenersCost = Math.round(screwBoxes250 * woodgripScrewsBoxRate);

  // Stitch Screws 7/8" (for panel laps, 250-ct boxes)
  let stitchBoxes250 = Math.ceil(totalMetalLinearFeet / (1.5 * 250));
  let stitchCost = Math.round(stitchBoxes250 * stitchScrewsBoxRate);

  const openGableCount = (walls.front.enclosed ? 0 : 1) + (walls.back.enclosed ? 0 : 1);
  const openGableDripCapPcs = openGableCount > 0 ? Math.ceil((openGableCount * width) / effectiveLapFt) : 0;
  const openGableDripCapCost = Math.round(openGableDripCapPcs * (unitRates.dripCapRate ?? 22.00));

  const trimCost =
    ratGuardCost +
    doubleAngleCost +
    ohDoorTopCost +
    ohDoorSideCost +
    slidingSideCost +
    trackCoverCost +
    dripCapCost +
    jChannelCost +
    fAndJCost +
    cornerTrimCost +
    insideCornerCost +
    sidewallCost +
    endwallCost +
    valleyCost +
    dripEdgeCost +
    fasciaCost +
    soffitCost +
    rakeCost +
    ridgeCapCost +
    ventedClosureCost +
    snowGuardCost +
    gutterCost +
    downspoutCost +
    closuresCost +
    butylTapeCost +
    openGableDripCapCost;

  let trimAndFastenersCost = trimCost + fastenersCost + stitchCost;

  // Framing Structure (Posts, Weight-Bearing Wall Headers, Purlins, Girts)
  // Posts spaced on center around perimeter (default 8 ft O.C.)
  const postSpacing = dimensions.postSpacing || 8;
  // Main perimeter post layout: corners plus intermediate posts on each wall run.
  const postsCount = 2 * (Math.ceil(length / postSpacing) + 1) + 2 * Math.max(0, Math.ceil(width / postSpacing) - 1);
  const postLengthFt = eaveHeight + 4; // 4ft in ground embedment or anchor
  const totalPostLinFt = postsCount * postLengthFt;
  const postsCost = totalPostLinFt * unitRates.postsTreatedPerLinFt;

  // Weight-Bearing Walls (Left and Right Eave Walls carrying roof trusses)
  // When posts are 8 ft on center, two 2x12s for headers are required (2-ply 2x12 header beam per wall)
  const headerPlyCount = postSpacing <= 8 ? 2 : 3;
  const headerSize = postSpacing === 8 ? '(2) 2x12s' : postSpacing === 6 ? '(2) 2x10s' : '(3) 2x12s';
  const total2x12LinearFeet = 2 * headerPlyCount * length; // 2 weight-bearing walls * 2 plies * length = 4 * length
  const standard16FtBoardsCount = Math.ceil(total2x12LinearFeet / 16);
  const headersCost = Math.round(total2x12LinearFeet * unitRates.trussCarriersPerLinFt);

  const weightBearingHeaders: WeightBearingWallHeadersBreakdown = {
    postSpacing,
    headerSize,
    plyCount: headerPlyCount,
    wallRunsCount: 2,
    linearFeetPerPly: length,
    total2x12LinearFeet,
    standard16FtBoardsCount,
    unitPricePerLinFt: unitRates.trussCarriersPerLinFt,
    totalHeaderCost: headersCost,
    description: `${headerSize} structural lumber headers spanning ${postSpacing}' O.C. posts along both weight-bearing eave sidewalls; roof trusses bear on these headers, not directly on the posts. This is an estimating assumption, not an engineered header schedule.`,
  };

  // Purlins across roof (every 2ft on center)
  const purlinRowsPerSlope = Math.ceil(rafterWithOverhang / 2) + 1;
  const purlinRunsCount = purlinRowsPerSlope * 2;
  const purlinTotalLinFt = purlinRunsCount * lengthWithOverhang;

  // Wall girts are counted only on enclosed walls; openings still need framing around their perimeter.
  const girtRowsCount = Math.ceil(eaveHeight / 2.5) + 1;
  const enclosedWallRunFt = (walls.left.enclosed ? length : 0) + (walls.right.enclosed ? length : 0) + (walls.front.enclosed ? width : 0) + (walls.back.enclosed ? width : 0);
  const girtTotalLinFt = girtRowsCount * enclosedWallRunFt;

  // Preliminary opening framing allowance (not an engineered header schedule). Included in the estimate and BOM.
  const openingFramingLinFt = openings.reduce((sum, op) => sum + 2 * op.heightFt + op.widthFt * (op.type === 'window' ? 2 : 1), 0);
  const openingFramingCost = Math.round(openingFramingLinFt * unitRates.purlinsGirtsPerLinFt);
  const roofPurlinsCost = Math.round(purlinTotalLinFt * unitRates.purlinsGirtsPerLinFt);
  const wallGirtsCost = Math.round(girtTotalLinFt * unitRates.purlinsGirtsPerLinFt);
  const purlinsAndGirtsCost = roofPurlinsCost + wallGirtsCost;
  const hurricaneTieCount = trussBreakdown.totalTrussesNeeded * 2;
  const hurricaneTieCost = Math.round(hurricaneTieCount * hurricaneTieRate);
  const splashPlankBoardsCount = Math.ceil(perimeterFt / 16);
  const splashPlankCost = Math.round(splashPlankBoardsCount * 38.50);
  const framingStructureCost = Math.round(postsCost + headersCost + purlinsAndGirtsCost + openingFramingCost + hurricaneTieCost + splashPlankCost);

  // Foundation / Floor Options
  let foundationCost = 0;
  let foundationDescription = 'Concrete Slab';
  if (materials.foundation === 'dirt') {
    foundationCost = 0;
    foundationDescription = 'Unimproved Dirt Floor Base';
  } else if (materials.foundation === 'crushed_gravel' || materials.foundation === 'dirt_gravel') {
    foundationCost = Math.round(floorSqFt * unitRates.dirtGravelPrepPerSqFt);
    foundationDescription = '4" Compacted Crushed Gravel Base';
  } else if (materials.foundation === 'slab_4in') {
    foundationCost = Math.round(floorSqFt * unitRates.concrete4inPerSqFt);
    foundationDescription = '4" 4,000 PSI Reinforced Concrete Slab with Vapor Barrier';
  } else if (materials.foundation === 'slab_6in') {
    foundationCost = Math.round(floorSqFt * unitRates.concrete6inPerSqFt);
    foundationDescription = '6" Heavy Commercial Reinforced Slab with #4 Rebar Grid';
  } else if (materials.foundation === 'piers_perma_columns') {
    const pierCount = postsCount;
    foundationCost = Math.round(pierCount * unitRates.piersPermaColumnPerUnit + floorSqFt * unitRates.dirtGravelPrepPerSqFt);
    foundationDescription = `Engineered Concrete Perma-Columns (${pierCount} Units) + Gravel Floor`;
  }

  // Lean-to porch addition. Model the outside eave and the two shed-roof end walls independently.
  let leanToCost = 0;
  const leanToPanelGroupsMap = new Map<string, { cut: ReturnType<typeof formatCutLength>; quantity: number; sqFt: number; unitPrice: number; totalCost: number; label: string }>();
  let leanToFramingCost = 0;
  let leanToPostCost = 0;
  let leanToFrameAllowanceCost = 0;
  let leanToEnclosureCost = 0;
  let leanToPosts = 0;
  let leanToClearHeight = 0;
  let leanToOuterHeight = 0;
  if (leanTo.enabled) {
    const leanToArea = leanTo.widthFt * leanTo.lengthFt;
    leanToPosts = Math.ceil(leanTo.lengthFt / postSpacing) + 1;
    leanToClearHeight = Math.max(0, eaveHeight - leanTo.dropBelowEaveFt);
    leanToOuterHeight = Math.max(0, leanTo.outerEaveHeightFt ?? (leanToClearHeight - leanTo.widthFt * leanTo.pitch / 12));
    leanToPostCost = Math.round(leanToPosts * (leanToOuterHeight + 3) * unitRates.postsTreatedPerLinFt);
    leanToFrameAllowanceCost = Math.round(leanToArea * 3.5);
    leanToFramingCost = leanToPostCost + leanToFrameAllowanceCost;
    const sideState = leanTo.openSides ?? { host: !leanTo.enclosed, outerEave: !leanTo.enclosed, frontGable: !leanTo.enclosed, backGable: !leanTo.enclosed };

    const addLeanToPanel = (rawLength: number, label: string) => {
      if (rawLength <= 0.05) return;
      const cut = formatCutLength(rawLength);
      const sqFt = Number((cut.decimal * PANEL_COVERAGE_FT).toFixed(2));
      const unitPrice = Number((sqFt * sidingRate).toFixed(2));
      const key = `${label}|${cut.formatted}`;
      const existing = leanToPanelGroupsMap.get(key);
      if (existing) { existing.quantity += 1; existing.totalCost = Math.round(existing.quantity * existing.unitPrice); }
      else leanToPanelGroupsMap.set(key, { cut, quantity: 1, sqFt, unitPrice, totalCost: Math.round(unitPrice), label });
    };

    // Enclosed outside eave wall: full-height vertical sheets at the outer eave clearance height.
    if (!sideState.outerEave) {
      for (let col = 0; col < Math.ceil(leanTo.lengthFt / PANEL_COVERAGE_FT); col++) addLeanToPanel(leanToOuterHeight, 'Lean-to outside eave wall');
    }
    // Lean-to end walls are trapezoidal under a shed roof; each sheet gets a cut length based on the high edge of its 3-ft strip.
    for (const endSide of ['frontGable', 'backGable'] as const) {
      if (sideState[endSide]) continue;
      for (let col = 0; col < Math.ceil(leanTo.widthFt / PANEL_COVERAGE_FT); col++) {
        const x = col * PANEL_COVERAGE_FT;
        const highEdgeHeight = Math.max(leanToOuterHeight, leanToClearHeight - x * leanTo.pitch / 12);
        addLeanToPanel(Math.min(leanToClearHeight, highEdgeHeight), endSide === 'frontGable' ? 'Lean-to front end wall' : 'Lean-to back end wall');
      }
    }
    const leanToPanelGroups = Array.from(leanToPanelGroupsMap.values());
    leanToEnclosureCost = leanToPanelGroups.reduce((sum, group) => sum + group.totalCost, 0);
    leanToCost = Math.round(leanToFramingCost + leanToEnclosureCost);
  }
  const leanToPanelGroups = Array.from(leanToPanelGroupsMap.values()).sort((a, b) => b.cut.decimal - a.cut.decimal);
  const leanToPanelSheetCount = leanToPanelGroups.reduce((sum, group) => sum + group.quantity, 0);
  const leanToPanelLinearFeet = leanToPanelGroups.reduce((sum, group) => sum + group.quantity * group.cut.decimal, 0);
  const totalLeanToWallPanelAreaSqFt = leanToPanelGroups.reduce((sum, group) => sum + group.quantity * group.sqFt, 0);
  totalWallSidingSheets += leanToPanelSheetCount;
  totalMetalSheets += leanToPanelSheetCount;
  totalMetalLinearFeet = Number((totalMetalLinearFeet + leanToPanelLinearFeet).toFixed(1));
  totalMetalSquareFeet = Number((totalMetalLinearFeet * PANEL_COVERAGE_FT).toFixed(1));
  metalTakeoff.totalWallSidingSheets = totalWallSidingSheets;
  metalTakeoff.totalMetalSheets = totalMetalSheets;
  metalTakeoff.totalMetalLinearFeet = totalMetalLinearFeet;
  metalTakeoff.totalMetalSquareFeet = totalMetalSquareFeet;
  stitchBoxes250 = Math.ceil(totalMetalLinearFeet / (1.5 * 250));
  stitchCost = Math.round(stitchBoxes250 * stitchScrewsBoxRate);
  trimAndFastenersCost = trimCost + fastenersCost + stitchCost;

  // Interior options
  let insulationCost = 0;
  let insulationDesc = 'None';
  if (interior.insulation === 'vapor_bubble') {
    insulationCost = Math.round((totalRoofMaterialAreaSqFt + totalGrossWallArea + totalLeanToWallPanelAreaSqFt) * unitRates.insulationVaporBarrierPerSqFt);
    insulationDesc = 'Reflective Single-Bubble Vapor Thermal Barrier';
  } else if (interior.insulation === 'r19_batt') {
    insulationCost = Math.round((totalRoofMaterialAreaSqFt + totalGrossWallArea + totalLeanToWallPanelAreaSqFt) * unitRates.insulationR19BattPerSqFt);
    insulationDesc = 'R-19 Kraft-Faced Fiberglass Batt Wall & Roof Cavities';
  } else if (interior.insulation === 'spray_foam_2in') {
    insulationCost = Math.round((totalRoofMaterialAreaSqFt + totalGrossWallArea + totalLeanToWallPanelAreaSqFt) * unitRates.insulationSprayFoam2inPerSqFt);
    insulationDesc = '2" Closed-Cell Rigid Polyurethane Spray Foam';
  } else if (interior.insulation === 'spray_foam_3in') {
    insulationCost = Math.round((totalRoofMaterialAreaSqFt + totalGrossWallArea + totalLeanToWallPanelAreaSqFt) * unitRates.insulationSprayFoam3inPerSqFt);
    insulationDesc = '3" High-Performance Closed-Cell Spray Foam (R-21)';
  } else if (interior.insulation === 'deluxe_combo') {
    insulationCost = Math.round((totalRoofMaterialAreaSqFt + totalGrossWallArea + totalLeanToWallPanelAreaSqFt) * (unitRates.insulationSprayFoam2inPerSqFt + 0.8));
    insulationDesc = '2" Spray Foam Flash + R-13 Fiberglass Hybrid System';
  }

  let linerCost = 0;
  let linerDesc = 'None';
  if (interior.linerPanel === 'steel_liner_all') {
    linerCost = Math.round((floorSqFt + totalGrossWallArea) * unitRates.linerSteelPerSqFt);
    linerDesc = 'Bright White 29-Ga Steel Liner Package (Ceiling & All Walls)';
  } else if (interior.linerPanel === 'steel_liner_ceiling') {
    linerCost = Math.round(floorSqFt * unitRates.linerSteelPerSqFt);
    linerDesc = 'Bright White 29-Ga Steel Liner Package (Ceiling Only)';
  } else if (interior.linerPanel === 'osb_plywood') {
    linerCost = Math.round((totalGrossWallArea) * unitRates.linerOsbPerSqFt);
    linerDesc = '7/16" Heavy OSB Impact Liner (Walls up to 8ft)';
  } else if (interior.linerPanel === 'drywall_ready') {
    linerCost = Math.round((floorSqFt + totalGrossWallArea) * 1.85);
    linerDesc = 'Ceiling & Wall Drywall Nailer Girt Grid (Ready for Sheetrock)';
  }

  let electricalCost = 0;
  let electricalDesc = 'None';
  if (interior.electrical === 'basic_shop') {
    electricalCost = Math.round(floorSqFt * unitRates.electricalBasicPerSqFt);
    electricalDesc = '100A Panel, High-Bay LED Fixtures (1 per 300 sq ft), Outlets every 12ft';
  } else if (interior.electrical === 'deluxe_commercial') {
    electricalCost = Math.round(floorSqFt * unitRates.electricalDeluxePerSqFt);
    electricalDesc = '200A Commercial Panel, 50A Welder Plug, Dimmable High-Bay LEDs, Exterior Floodlights';
  }

  let loftCost = 0;
  let loftDesc = 'None';
  let loftSqFt = 0;
  if (interior.loft !== 'none') {
    if (interior.loft === 'quarter_loft') loftSqFt = Math.round(floorSqFt * 0.25);
    if (interior.loft === 'half_loft') loftSqFt = Math.round(floorSqFt * 0.5);
    if (interior.loft === 'full_loft') loftSqFt = Math.round(floorSqFt * 0.85);

    const loftRate = interior.loftFloorRating === 'heavy_mezzanine' ? unitRates.loftPerSqFt * 1.45 : unitRates.loftPerSqFt;
    loftCost = Math.round(loftSqFt * loftRate + 1200); // 1200 for framed stair package & steel handrail
    loftDesc = `${loftSqFt} sq ft Framing Mezzanine with Structural Timber Posts, Stairs & Railing`;
  }

  const interiorCost = insulationCost + linerCost + electricalCost + loftCost;

  // Labor & Erection
  const laborFraming = Math.round(floorSqFt * unitRates.laborFramingPerSqFt);
  const laborSidingRoof = Math.round((totalRoofMaterialAreaSqFt + totalGrossWallArea + totalLeanToWallPanelAreaSqFt) * 0.55 * unitRates.laborSidingRoofPerSqFt);
  const laborCost = laborFraming + laborSidingRoof;

  // Subtotal and Contractor contingency margin
  const subtotal =
    trussBreakdown.totalTrussPackageCost +
    roofSheetingCost +
    wallSidingCost +
    wainscotCost +
    trimAndFastenersCost +
    framingStructureCost +
    foundationCost +
    openingsCost +
    leanToCost +
    interiorCost +
    laborCost;

  const contractorMarginAmount = Math.round(subtotal * (unitRates.contingencyMarginPercent / 100));
  const grandTotal = subtotal + contractorMarginAmount;
  const costPerSquareFoot = Number((grandTotal / floorSqFt).toFixed(2));

  // Build itemized Bill of Materials (BOM)
  const bom: ItemizedBomLine[] = [
    {
      id: 'bom-truss-std',
      category: 'Trusses',
      item: 'Engineered Clear-Span Roof Trusses',
      description: `${width}' Span, ${dimensions.roofPitch}:12 Pitch, ${dimensions.trussSpacing}' O.C., ${state.snowLoad} PSF Snow Load (${trussBreakdown.rafterLengthFt}' rafter)`,
      quantity: trussBreakdown.standardTrussesCount,
      unit: 'ea',
      unitPrice: trussBreakdown.unitCostStandardTruss,
      totalCost: Math.round(trussBreakdown.standardTrussesCount * trussBreakdown.unitCostStandardTruss),
    },
    {
      id: 'bom-truss-gable',
      category: 'Trusses',
      item: 'Gable End Trusses with Dropped Chord & Studs',
      description: `${width}' Gable End with factory vertical framing nailers 24" O.C.`,
      quantity: trussBreakdown.gableEndTrussesCount,
      unit: 'ea',
      unitPrice: trussBreakdown.unitCostGableTruss,
      totalCost: Math.round(trussBreakdown.gableEndTrussesCount * trussBreakdown.unitCostGableTruss),
    },
    {
      id: 'bom-truss-delivery',
      category: 'Trusses',
      item: 'Truss Freight & Hydraulic Boom Crane Offload',
      description: 'Jobsite delivery, wide-load permit routing, and crane placement staging',
      quantity: 1,
      unit: 'ls',
      unitPrice: unitRates.trussDeliveryCraneSetup,
      totalCost: unitRates.trussDeliveryCraneSetup,
    },
    // Roof Sheeting Line Items (36" Coverage Sheets or Shingles)
    ...(isMetalRoof
      ? [
          {
            id: 'bom-roof-sheet-main',
            category: 'Roof Sheeting' as const,
            item: `${roofTypeName} - ${roofCut.formatted} Sheets`,
            description: `36" Net Coverage × ${roofCut.formatted} (${roofCut.decimal} ft) Cut Length • ${sqFtPerRoofSheet} sq ft/sheet • Eave-to-Ridge (${dimensions.roofPitch}:12 Pitch, ${eaveOverhangInches}" eave overhang)`,
            quantity: mainRoofSheetsQty,
            unit: 'sheets',
            unitPrice: unitPricePerRoofSheet,
            totalCost: mainRoofCost,
            sheetLengthFt: roofCut.decimal,
            sheetLengthFormatted: roofCut.formatted,
            coverageWidthInches: PANEL_COVERAGE_INCHES,
            isMetalSheet: true,
          },
          ...(leanTo.enabled && leanToRoofSheetsQty > 0
            ? [
                {
                  id: 'bom-roof-sheet-leanto',
                  category: 'Roof Sheeting' as const,
                  item: `${roofTypeName} - ${ltCut.formatted} Lean-to Sheets`,
                  description: `36" Net Coverage × ${ltCut.formatted} (${ltCut.decimal} ft) Cut Length • ${sqFtPerLtSheet} sq ft/sheet • Lean-to Shed Roof Extension`,
                  quantity: leanToRoofSheetsQty,
                  unit: 'sheets',
                  unitPrice: unitPricePerLtSheet,
                  totalCost: leanToRoofCost,
                  sheetLengthFt: ltCut.decimal,
                  sheetLengthFormatted: ltCut.formatted,
                  coverageWidthInches: PANEL_COVERAGE_INCHES,
                  isMetalSheet: true,
                },
              ]
            : []),
        ]
      : [
          {
            id: 'bom-roof-sheeting',
            category: 'Roof Sheeting' as const,
            item: roofTypeName,
            description: `${totalRoofAreaSqFt} sq ft architectural fiberglass shingle roofing with synthetic underlayment`,
            quantity: totalRoofAreaSqFt,
            unit: 'sq ft',
            unitPrice: roofRate,
            totalCost: roofSheetingCost,
            coverageWidthInches: PANEL_COVERAGE_INCHES,
          },
        ]),

    // Wall Siding Line Items (36" Coverage Sheets with Length & Qty)
    ...sidewallPanelGroups.map((group, idx) => ({
      id: `bom-siding-sidewall-${idx}`,
      category: 'Wall Siding' as const,
      item: `${sidingTypeName} - ${group.cut.formatted} (Eave Sidewalls)`,
      description: `36" Net Coverage × ${group.cut.formatted} (${group.cut.decimal} ft) cut length • ${group.sqFt} sq ft/sheet • door-column panels shortened above floor-level openings where a full panel column is clear • ${materials.sidingColorName} finish`,
      quantity: group.quantity,
      unit: 'sheets',
      unitPrice: group.unitPrice,
      totalCost: group.totalCost,
      sheetLengthFt: group.cut.decimal,
      sheetLengthFormatted: group.cut.formatted,
      coverageWidthInches: PANEL_COVERAGE_INCHES,
      isMetalSheet: true,
    })),
    ...gableCutGroups.map((group, idx) => ({
      id: `bom-siding-gable-${idx}`,
      category: 'Wall Siding' as const,
      item: `${sidingTypeName} - ${group.lengthFormatted} (${group.label})`,
      description: `36" Net Coverage × ${group.lengthFormatted} (${group.lengthDecimal} ft) Length • ${group.sqFtPerSheet} sq ft/sheet • Gable Rake Stepped Profile • ${materials.sidingColorName}`,
      quantity: group.quantity,
      unit: 'sheets',
      unitPrice: group.unitPrice,
      totalCost: group.totalCost,
      sheetLengthFt: group.lengthDecimal,
      sheetLengthFormatted: group.lengthFormatted,
      coverageWidthInches: PANEL_COVERAGE_INCHES,
      isMetalSheet: true,
    })),
  ];

  leanToPanelGroups.forEach((group, idx) => bom.push({
    id: `bom-siding-leanto-${idx}`,
    category: 'Wall Siding',
    item: `${sidingTypeName} - ${group.cut.formatted} (${group.label})`,
    description: `36" Net Coverage × ${group.cut.formatted} (${group.cut.decimal} ft) cut length • ${group.sqFt} sq ft/sheet • lean-to siding only on faces marked enclosed • ${materials.sidingColorName}`,
    quantity: group.quantity,
    unit: 'sheets',
    unitPrice: group.unitPrice,
    totalCost: group.totalCost,
    sheetLengthFt: group.cut.decimal,
    sheetLengthFormatted: group.cut.formatted,
    coverageWidthInches: PANEL_COVERAGE_INCHES,
    isMetalSheet: true,
  }));

  if (hasAnyWainscot && totalWainscotSheets > 0) {
    bom.push({
      id: 'bom-wainscot',
      category: 'Wall Siding',
      item: `Designer 2-Tone Wainscot Steel - ${wainscotCut.formatted} Sheets`,
      description: `36" Net Coverage × ${wainscotCut.formatted} (${wainscotCut.decimal} ft) Length • ${sqFtPerWainscotSheet} sq ft/sheet • Perimeter Base in ${materials.wainscotColorName}`,
      quantity: totalWainscotSheets,
      unit: 'sheets',
      unitPrice: unitPricePerWainscotSheet,
      totalCost: wainscotCost,
      sheetLengthFt: wainscotCut.decimal,
      sheetLengthFormatted: wainscotCut.formatted,
      coverageWidthInches: PANEL_COVERAGE_INCHES,
      isMetalSheet: true,
    });
  }

  // Recommended extra material is separate from required quantities and quote totals.
  // Calculate the allowance once across all sidewall cuts; rounding every length group
  // independently would add one extra sheet to many small groups and create excessive waste.
  const recommendedExtraTotal = totalSidewallSheets > 0 ? Math.ceil(totalSidewallSheets * 0.05) : 0;
  if (recommendedExtraTotal > 0 && sidewallPanelGroups.length > 0) {
    const allocation = sidewallPanelGroups.map((group, idx) => {
      const exactShare = recommendedExtraTotal * group.quantity / totalSidewallSheets;
      return { idx, group, quantity: Math.floor(exactShare), remainder: exactShare - Math.floor(exactShare) };
    });
    let unallocated = recommendedExtraTotal - allocation.reduce((sum, item) => sum + item.quantity, 0);
    allocation.sort((a, b) => b.remainder - a.remainder || b.group.quantity - a.group.quantity || a.idx - b.idx);
    for (let i = 0; i < allocation.length && unallocated > 0; i++, unallocated--) allocation[i].quantity += 1;
    allocation.filter((item) => item.quantity > 0).sort((a, b) => a.idx - b.idx).forEach(({ idx, group, quantity }) => {
      bom.push({
        id: `bom-extra-sidewall-panels-${idx}`,
        category: 'Recommended Extras',
        item: `Optional extra sidewall AG panels - ${group.cut.formatted}`,
        description: `Optional share of the overall 5% sidewall-only allowance (${quantity} additional sheet(s)); separate from required quantity and excluded from the quote total. Extra sheets are assigned to common cut lengths; no blanket waste factor is applied to roof or gable panel lengths.`,
        quantity,
        unit: 'sheets',
        unitPrice: group.unitPrice,
        totalCost: Math.round(quantity * group.unitPrice),
        sheetLengthFt: group.cut.decimal,
        sheetLengthFormatted: group.cut.formatted,
        coverageWidthInches: PANEL_COVERAGE_INCHES,
        isMetalSheet: true,
      });
    });
  }

  // Itemized Architectural Trims & Weatherproofing Package
  // 1. Lower Wall & Base Foundations
  bom.push({
    id: 'bom-trim-rat-guard',
    category: 'Trim & Fasteners',
    item: `Rat Guard Base Trim - ${stockLengthLabel} Pieces`,
    description: `Installed horizontally along bottom perimeter, fastened directly to treated splash plank (skirt board) before wall panels or wainscot are hung; sloped ledge supports metal • ${ratGuardColorName}`,
    quantity: ratGuardPcs,
    unit: 'pcs',
    unitPrice: Number((ratGuardCost / Math.max(1, ratGuardPcs)).toFixed(2)),
    totalCost: ratGuardCost,
    sheetLengthFt: stockLengthFt,
    sheetLengthFormatted: stockLengthLabel,
  });

  if (hasAnyWainscot && doubleAnglePcs > 0) {
    bom.push({
      id: 'bom-trim-double-angle',
      category: 'Trim & Fasteners',
      item: `Wainscot Double Angle Drip Ledge - ${stockLengthLabel} Pieces`,
      description: `Horizontal drip ledge installed roughly 3' to 4' off ground that prevents water from seeping into joint between lower wainscot panel and upper siding • ${wainscotCapColorName}`,
      quantity: doubleAnglePcs,
      unit: 'pcs',
      unitPrice: Number((doubleAngleCost / Math.max(1, doubleAnglePcs)).toFixed(2)),
      totalCost: doubleAngleCost,
      sheetLengthFt: stockLengthFt,
      sheetLengthFormatted: stockLengthLabel,
    });
  }

  // 2. Openings (Doors & Windows)
  if (ohDoorTopPcs > 0) {
    bom.push({
      id: 'bom-trim-oh-door-top',
      category: 'Trim & Fasteners',
      item: `Overhead door trim top - ${stockLengthLabel} Pieces`,
      description: `Wraps across the top header of overhead and sliding-door openings to protect raw wood from weather • ${doorTrimColorName}`,
      quantity: ohDoorTopPcs,
      unit: 'pcs',
      unitPrice: Number((ohDoorTopCost / Math.max(1, ohDoorTopPcs)).toFixed(2)),
      totalCost: ohDoorTopCost,
      sheetLengthFt: stockLengthFt,
      sheetLengthFormatted: stockLengthLabel,
    });
  }

  if (ohDoorSidePcs > 0) {
    bom.push({
      id: 'bom-trim-oh-door-side',
      category: 'Trim & Fasteners',
      item: `Overhead door trim sides - ${stockLengthLabel} Pieces`,
      description: `Wraps along both vertical jambs of overhead and sliding-door openings to protect raw wood from weather • ${doorTrimColorName}`,
      quantity: ohDoorSidePcs,
      unit: 'pcs',
      unitPrice: Number((ohDoorSideCost / Math.max(1, ohDoorSidePcs)).toFixed(2)),
      totalCost: ohDoorSideCost,
      sheetLengthFt: stockLengthFt,
      sheetLengthFormatted: stockLengthLabel,
    });
  }

  if (slidingSidePcs > 0) {
    bom.push({
      id: 'bom-trim-sliding-door-side',
      category: 'Trim & Fasteners',
      item: `Sliding Barn Door Side Jamb Trim - ${stockLengthLabel} Pieces`,
      description: `Installed along vertical side jambs of sliding barn door openings • ${doorTrimColorName}`,
      quantity: slidingSidePcs,
      unit: 'pcs',
      unitPrice: Number((slidingSideCost / Math.max(1, slidingSidePcs)).toFixed(2)),
      totalCost: slidingSideCost,
      sheetLengthFt: stockLengthFt,
      sheetLengthFormatted: stockLengthLabel,
    });
  }

  if (trackCoverPcs > 0) {
    bom.push({
      id: 'bom-trim-track-cover',
      category: 'Trim & Fasteners',
      item: `Sliding Door Trolley Track Cover - ${stockLengthLabel} Pieces`,
      description: `Mounted horizontally directly over top metal sliding door trolley track, shielding roller hardware and track from snow, ice, and rain • ${doorTrimColorName}`,
      quantity: trackCoverPcs,
      unit: 'pcs',
      unitPrice: Number((trackCoverCost / Math.max(1, trackCoverPcs)).toFixed(2)),
      totalCost: trackCoverCost,
      sheetLengthFt: stockLengthFt,
      sheetLengthFormatted: stockLengthLabel,
    });
  }

  if (dripCapPcs > 0) {
    bom.push({
      id: 'bom-trim-drip-cap',
      category: 'Trim & Fasteners',
      item: `Opening Drip Cap Flashing - ${stockLengthLabel} Pieces`,
      description: `Fastened horizontally right above window frames and service doors to deflect descending water away from opening top edges • ${doorTrimColorName}`,
      quantity: dripCapPcs,
      unit: 'pcs',
      unitPrice: Number((dripCapCost / Math.max(1, dripCapPcs)).toFixed(2)),
      totalCost: dripCapCost,
      sheetLengthFt: stockLengthFt,
      sheetLengthFormatted: stockLengthLabel,
    });
  }

  if (jChannelPcs > 0) {
    bom.push({
      id: 'bom-trim-j-channel',
      category: 'Trim & Fasteners',
      item: `J-channel - ${stockLengthLabel} Pieces`,
      description: `Fitted on both sides and bottom of windows and walk doors; open eave runs use J-channel instead of F-J channel • ${doorTrimColorName}`,
      quantity: jChannelPcs,
      unit: 'pcs',
      unitPrice: Number((jChannelCost / Math.max(1, jChannelPcs)).toFixed(2)),
      totalCost: jChannelCost,
      sheetLengthFt: stockLengthFt,
      sheetLengthFormatted: stockLengthLabel,
    });
  }

  if (fAndJPcs > 0) {
    bom.push({
      id: 'bom-trim-f-and-j',
      category: 'Trim & Fasteners',
      item: `F-J channel - ${stockLengthLabel} Pieces`,
      description: `Cleanly bridges vertical wall panels with horizontal soffit under eaves & gables; lower J-receiver captures raw top edge of vertical wall metal, perpendicular F-leg supports inner edge of soffit panel creating seamless weather-tight seal against wind, water, hornets, and birds • ${defaultTrimColorName}`,
      quantity: fAndJPcs,
      unit: 'pcs',
      unitPrice: Number((fAndJCost / Math.max(1, fAndJPcs)).toFixed(2)),
      totalCost: fAndJCost,
      sheetLengthFt: stockLengthFt,
      sheetLengthFormatted: stockLengthLabel,
    });
  }

  // 3. Corners & Vertical Transitions
  bom.push(
    {
      id: 'bom-trim-corner',
      category: 'Trim & Fasteners',
      item: `Outside Corner Trim - ${eaveHeight}'-0" Lengths`,
      description: `Installed vertically on outside 90-degree corners where two exterior walls join, covering panel seams (Supplied 10'-6" min up to 30' cut-to-length) • ${cornerTrimColorName}`,
      quantity: cornerPcs,
      unit: 'pcs',
      unitPrice: Number((cornerTrimCost / Math.max(1, cornerPcs)).toFixed(2)),
      totalCost: cornerTrimCost,
      sheetLengthFt: eaveHeight,
      sheetLengthFormatted: `${eaveHeight}'-0"`,
    }
  );

  if (insideCornerPcs > 0) {
    bom.push({
      id: 'bom-trim-inside-corner',
      category: 'Trim & Fasteners',
      item: `Inside Corner Trim - ${stockLengthLabel} Pieces`,
      description: `Placed vertically inside interior room corners or where two exterior walls form an internal angle (such as lean-to roof wall junctions) • ${cornerTrimColorName}`,
      quantity: insideCornerPcs,
      unit: 'pcs',
      unitPrice: Number((insideCornerCost / Math.max(1, insideCornerPcs)).toFixed(2)),
      totalCost: insideCornerCost,
      sheetLengthFt: stockLengthFt,
      sheetLengthFormatted: stockLengthLabel,
    });
  }

  // 4. Roof-to-Wall Interfaces
  if (sidewallPcs > 0) {
    bom.push({
      id: 'bom-trim-sidewall',
      category: 'Trim & Fasteners',
      item: `Transition Trim - ${stockLengthLabel} Pieces`,
      description: `Used along the full eave-side lean-to connection when the roof pitch changes; same-height, same-pitch continuation does not receive transition trim • ${defaultTrimColorName}`,
      quantity: sidewallPcs,
      unit: 'pcs',
      unitPrice: Number((sidewallCost / Math.max(1, sidewallPcs)).toFixed(2)),
      totalCost: sidewallCost,
      sheetLengthFt: stockLengthFt,
      sheetLengthFormatted: stockLengthLabel,
    });
  }

  if (endwallPcs > 0) {
    bom.push({
      id: 'bom-trim-endwall',
      category: 'Trim & Fasteners',
      item: `End-wall Trim - ${stockLengthLabel} Pieces`,
      description: `Used along the full lean-to connection when attachment height changes or when the lean-to attaches at a gable end • ${defaultTrimColorName}`,
      quantity: endwallPcs,
      unit: 'pcs',
      unitPrice: Number((endwallCost / Math.max(1, endwallPcs)).toFixed(2)),
      totalCost: endwallCost,
      sheetLengthFt: stockLengthFt,
      sheetLengthFormatted: stockLengthLabel,
    });
  }

  if (valleyPcs > 0) {
    bom.push({
      id: 'bom-trim-valley',
      category: 'Trim & Fasteners',
      item: `Valley Flashing - ${stockLengthLabel} Pieces`,
      description: `Laid down inside internal diagonal channels where two sloping roof sections intersect • ${materials.roofColorName}`,
      quantity: valleyPcs,
      unit: 'pcs',
      unitPrice: Number((valleyCost / Math.max(1, valleyPcs)).toFixed(2)),
      totalCost: valleyCost,
      sheetLengthFt: stockLengthFt,
      sheetLengthFormatted: stockLengthLabel,
    });
  }

  // 5. Eaves, Overhangs & Gables
  bom.push(
    {
      id: 'bom-trim-drip-edge',
      category: 'Trim & Fasteners',
      item: `Barn Drip - ${stockLengthLabel} Pieces`,
      description: `Supplier barn-drip profile at eaves; its bend angle must be verified for the selected roof pitch • ${dripEdgeColorName}`,
      quantity: dripEdgePcs,
      unit: 'pcs',
      unitPrice: Number((dripEdgeCost / Math.max(1, dripEdgePcs)).toFixed(2)),
      totalCost: dripEdgeCost,
      sheetLengthFt: stockLengthFt,
      sheetLengthFormatted: stockLengthLabel,
    },
    {
      id: 'bom-trim-fascia',
      category: 'Trim & Fasteners',
      item: `Fascia Cover - ${stockLengthLabel} Pieces`,
      description: `L-shaped fascia cover; top tucks behind/under barn drip at eaves or Residential Rake at gables; included only where that edge has an overhang • ${fasciaColorName}`,
      quantity: fasciaPcs,
      unit: 'pcs',
      unitPrice: Number((fasciaCost / Math.max(1, fasciaPcs)).toFixed(2)),
      totalCost: fasciaCost,
      sheetLengthFt: stockLengthFt,
      sheetLengthFormatted: stockLengthLabel,
    }
  );

  if (eaveSoffitSheets > 0) {
    bom.push({
      id: 'bom-soffit-eave-panels',
      category: 'Trim & Fasteners',
      item: `Vented Eave Soffit Panels (${eaveSoffitCutLengthLabel} Cut)`,
      description: `3-ft wide vented soffit panels cut ${eaveSoffitCutLengthLabel} for eave overhangs only (${eaveOverhangInches}" projection). Inner edge uses F-J channel on enclosed eaves and J-channel on open eaves; outer edge fastens to fascia cover • ${soffitColorName}`,
      quantity: eaveSoffitSheets,
      unit: 'panels',
      unitPrice: eaveSoffitUnitPrice,
      totalCost: Math.round(eaveSoffitSheets * eaveSoffitUnitPrice),
    });
  }
  if (gableSoffitSheets > 0) {
    bom.push({
      id: 'bom-soffit-gable-panels',
      category: 'Trim & Fasteners',
      item: `Solid Gable Soffit Panels (${gableSoffitCutLengthLabel} Cut)`,
      description: `3-ft wide solid soffit panels cut ${gableSoffitCutLengthLabel} for gable/rake overhangs only (${gableOverhangInches}" projection); includes main roof and lean-to gable edges where applicable • ${soffitColorName}`,
      quantity: gableSoffitSheets,
      unit: 'panels',
      unitPrice: gableSoffitUnitPrice,
      totalCost: Math.round(gableSoffitSheets * gableSoffitUnitPrice),
    });
  }

  // Gutters are excluded by default (clean eave & fascia per build photo); included only when explicitly enabled
  if (guttersActive && gutterLinFt > 0) {
    bom.push(
      {
        id: 'bom-trim-seamless-gutters',
        category: 'Trim & Fasteners',
        item: `6" Seamless K-Style Gutter Runs`,
        description: `Seamless gutters mounted to vertical eave fascia covers • ${materials.gutterColorName || defaultTrimColorName}`,
        quantity: Math.round(gutterLinFt),
        unit: 'LF',
        unitPrice: gutterPieceRate,
        totalCost: gutterCost,
      },
      {
        id: 'bom-trim-downspouts',
        category: 'Trim & Fasteners',
        item: `3"x4" Commercial Downspout Assemblies`,
        description: `Complete downspout drop assemblies, A/B elbows, and 10ft vertical pipes with ground splash discharge • ${materials.gutterColorName || defaultTrimColorName}`,
        quantity: downspoutCount,
        unit: 'pcs',
        unitPrice: downspoutPieceRate,
        totalCost: downspoutCost,
      }
    );
  }

  bom.push(
    {
      id: 'bom-trim-rake',
      category: 'Trim & Fasteners',
      item: `Residential Rake - ${stockLengthLabel} Pieces`,
      description: `Installed along sloped gable edges from eave corner up to roof peak (Supplied 10'-6" min up to 30' cut-to-length) • ${rakeTrimColorName}`,
      quantity: rakePcs,
      unit: 'pcs',
      unitPrice: Number((rakeCost / Math.max(1, rakePcs)).toFixed(2)),
      totalCost: rakeCost,
      sheetLengthFt: stockLengthFt,
      sheetLengthFormatted: stockLengthLabel,
    },
    // 6. Peak & Roof Penetrations
    {
      id: 'bom-trim-ridge-cap',
      category: 'Trim & Fasteners',
      item: `Regular Ridge Cap 13-inch - ${stockLengthLabel} Pieces`,
      description: `Placed along absolute peak (ridge line) where opposing sloped roof panels meet (Supplied 10'-6" min up to 30' cut-to-length) • ${ridgeCapColorName}`,
      quantity: ridgeCapPcs,
      unit: 'pcs',
      unitPrice: Number((ridgeCapCost / Math.max(1, ridgeCapPcs)).toFixed(2)),
      totalCost: ridgeCapCost,
      sheetLengthFt: stockLengthFt,
      sheetLengthFormatted: stockLengthLabel,
    },
    {
      id: 'bom-trim-vented-closure-foam',
      category: 'Trim & Fasteners',
      item: `Vented Ridge Closure Foam (20-Ft Rolls)`,
      description: `Sandwiched directly beneath both sides of ridge cap on top of roof metal ribs along entire ridge line, sealing gaps while letting attic heat exhaust out • 20' rolls`,
      quantity: ventedClosureRolls,
      unit: 'rolls',
      unitPrice: ventedClosureRollRate,
      totalCost: ventedClosureCost,
    }
  );

  if (snowGuardsActive && snowGuardLinFt > 0) {
    bom.push({
      id: 'bom-trim-snow-guards',
      category: 'Trim & Fasteners',
      item: `Snow Guard (${snowGuardLinFt}' Run)`,
      description: `Extruded heavy-duty snow rail installed on top of roof panels 3' to 4' from bottom of roof panel, preventing snow and ice sheets from sliding off roof • ${snowGuardColorName}`,
      quantity: snowGuardLinFt,
      unit: 'lin ft',
      unitPrice: snowGuardRailRate,
      totalCost: snowGuardCost,
    });
  }

  bom.push(
    {
      id: 'bom-closures-foam',
      category: 'Trim & Fasteners',
      item: `Vented & Solid Foam Rib Closures (36" Strips)`,
      description: `${insideClosuresCount} inside eave closures + ${outsideClosuresCount} outside ridge closures to seal metal ribs against weather/pests`,
      quantity: insideClosuresCount + outsideClosuresCount,
      unit: 'pcs',
      unitPrice: Number((closuresCost / Math.max(1, insideClosuresCount + outsideClosuresCount)).toFixed(2)),
      totalCost: closuresCost,
    },
    {
      id: 'bom-butyl-tape',
      category: 'Trim & Fasteners',
      item: `Butyl Mastic Sealant Tape (45-Ft Rolls)`,
      description: `Heavy-duty 3/8" non-drying butyl tape for ridge cap laps, rake junctions, and end seams`,
      quantity: butylTapeRolls,
      unit: 'rolls',
      unitPrice: butylTapeRollRate,
      totalCost: butylTapeCost,
    },
    {
      id: 'bom-fasteners-screws',
      category: 'Trim & Fasteners',
      item: `Color-Matched 1-1/2" Woodgrip Screws (Box of 250)`,
      description: `#10 Hi-Lo mechanical fasteners with vulcanized EPDM neoprene sealing washers • Matching paint finish`,
      quantity: screwBoxes250,
      unit: 'boxes',
      unitPrice: woodgripScrewsBoxRate,
      totalCost: fastenersCost,
    },
    {
      id: 'bom-fasteners-stitch',
      category: 'Trim & Fasteners',
      item: `Lap Stitch Screws 7/8" Self-Drilling (Box of 250)`,
      description: `1/4" hex head color-matched stitch screws for securing metal panel side laps every 18" O.C.`,
      quantity: stitchBoxes250,
      unit: 'boxes',
      unitPrice: stitchScrewsBoxRate,
      totalCost: stitchCost,
    },
    {
      id: 'bom-hurricane-ties',
      category: 'Framing Structure',
      item: 'Simpson Strong-Tie H1 Truss Hurricane Anchors',
      description: `Heavy-gauge galvanized tie-down brackets (2 per truss) securing truss heels to the carrier headers; headers transfer load to posts`,
      quantity: hurricaneTieCount,
      unit: 'ea',
      unitPrice: hurricaneTieRate,
      totalCost: hurricaneTieCost,
    },
    {
      id: 'bom-splash-plank',
      category: 'Framing Structure',
      item: '2x8 Pressure-Treated Grade Skirt Board / Splash Plank',
      description: `Ground contact treated lumber forming the bottom foundation frame around ${perimeterFt} ft perimeter`,
      quantity: splashPlankBoardsCount,
      unit: '16ft bds',
      unitPrice: 38.50,
      totalCost: splashPlankCost,
    },
    {
      id: 'bom-weight-bearing-headers',
      category: 'Framing Structure',
      item: `${headerSize} Headers - Weight-Bearing Walls (${postSpacing}' O.C. Posts)`,
      description: `${headerSize} #1 structural timber headers along both weight-bearing eave walls to carry trusses on the headers, not directly on the posts (${2 * length}' total wall run × ${headerPlyCount} plies = ${total2x12LinearFeet} LF / ${standard16FtBoardsCount} estimated 16-ft boards). Header size and splices require engineering verification.`,
      quantity: standard16FtBoardsCount,
      unit: '16ft bds',
      unitPrice: Number((headersCost / Math.max(1, standard16FtBoardsCount)).toFixed(2)),
      totalCost: headersCost,
      sheetLengthFt: 16,
      sheetLengthFormatted: `16'-0"`,
    },
    {
      id: 'bom-framing-posts',
      category: 'Framing Structure',
      item: `Pressure-Treated Solid/Laminated Columns (${postSpacing}' O.C.)`,
      description: `${postsCount} estimated main-building post stations at up to ${postSpacing} ft O.C.; assumes ${eaveHeight + 4}' uniform column length. Gable-end post lengths vary with roof geometry and must be field/engineer verified.`,
      quantity: postsCount,
      unit: 'ea',
      unitPrice: Number((postsCost / Math.max(1, postsCount)).toFixed(2)),
      totalCost: Math.round(postsCost),
    },
    {
      id: 'bom-framing-roof-purlins',
      category: 'Framing Structure',
      item: '2x4 Roof Purlins (24-inch O.C. estimate)',
      description: `${purlinRunsCount} rows across both roof slopes; estimated ${Number(lengthWithOverhang.toFixed(2))}' run per row (${Number(purlinTotalLinFt.toFixed(1))} total linear feet). Cut lengths and purlin size/spacing must be verified for roof loads and supplier panel requirements.`,
      quantity: Number(purlinTotalLinFt.toFixed(1)),
      unit: 'lin ft',
      unitPrice: unitRates.purlinsGirtsPerLinFt,
      totalCost: roofPurlinsCost,
    },
    {
      id: 'bom-framing-wall-girts',
      category: 'Framing Structure',
      item: 'Wall Girts (approximately 30-inch O.C. estimate)',
      description: `${girtRowsCount} estimated horizontal rows over ${Number(enclosedWallRunFt.toFixed(1))}' of enclosed main-building wall run (${Number(girtTotalLinFt.toFixed(1))} total linear feet). Opening framing is listed separately as a preliminary allowance; actual rows, splice locations, and member sizes require plan/engineering verification.`,
      quantity: Number(girtTotalLinFt.toFixed(1)),
      unit: 'lin ft',
      unitPrice: unitRates.purlinsGirtsPerLinFt,
      totalCost: wallGirtsCost,
    },
    {
      id: 'bom-foundation',
      category: 'Foundation',
      item: foundationDescription,
      description: `${floorSqFt} sq ft interior ground footprint`,
      quantity: floorSqFt,
      unit: 'sq ft',
      unitPrice: Number((foundationCost / floorSqFt).toFixed(2)),
      totalCost: foundationCost,
    },
    ...openingItems
  );

  if (openGableCount > 0) {
    bom.push({ id: 'bom-open-gable-drip-cap', category: 'Trim & Fasteners',
      item: `Open gable opening drip cap - ${stockLengthLabel} Pieces`,
      description: `Drip cap across the top of each open gable opening (${openGableCount} end(s)); gable-end truss triangle remains metal-covered. Verify the final edge detail with the supplier.`,
      quantity: openGableDripCapPcs, unit: 'pcs',
      unitPrice: Number((openGableDripCapCost / Math.max(1, openGableDripCapPcs)).toFixed(2)),
      totalCost: openGableDripCapCost, sheetLengthFt: stockLengthFt, sheetLengthFormatted: stockLengthLabel });
  }

  if (openings.length > 0) {
    bom.push({
      id: 'bom-opening-framing', category: 'Framing Structure',
      item: 'Opening framing lumber allowance (verify header design)',
      description: `Preliminary jamb-and-header lumber takeoff for ${openings.length} opening(s): ${openings.map(op => `${op.label} ${op.widthFt}x${op.heightFt} on ${op.side}`).join('; ')}. Quantity includes two jamb lengths and one header per door, plus a sill member for windows. Header sizing, jack/king studs, cripples, and load transfer remain to be confirmed for the actual structure.`,
      quantity: Number(openingFramingLinFt.toFixed(1)), unit: 'lin ft',
      unitPrice: unitRates.purlinsGirtsPerLinFt, totalCost: openingFramingCost,
    });
  }

  if (leanTo.enabled) {
    bom.push({
      id: 'bom-leanto-posts',
      category: 'Framing Structure',
      item: 'Lean-to outside support posts',
      description: `${leanToPosts} estimated posts at up to ${postSpacing}' O.C.; estimated post length ${Number((leanToOuterHeight + 3).toFixed(1))}' including embedment/connection allowance. Confirm actual post height, base, and uplift connection with the engineer.`,
      quantity: leanToPosts,
      unit: 'ea',
      unitPrice: Number((leanToPosts > 0 ? (leanToPostCost / leanToPosts) : 0).toFixed(2)),
      totalCost: Math.round(leanToPostCost),
    }, {
      id: 'bom-leanto-framing-allowance',
      category: 'Framing Structure',
      item: 'Lean-to roof and connection framing allowance',
      description: 'Area-based preliminary allowance for lean-to framing members and connections; member sizes, ledger, purlins, bracing, and uplift connections require structural verification.',
      quantity: Number((leanTo.widthFt * leanTo.lengthFt).toFixed(1)),
      unit: 'sq ft',
      unitPrice: 3.5,
      totalCost: leanToFrameAllowanceCost,
    }, {
      id: 'bom-leanto',
      category: 'Lean-to Additions',
      item: `${leanTo.widthFt}'x${leanTo.lengthFt}' Lean-to Porch Addition — summary`,
      description: `${leanTo.side.toUpperCase()} elevation shed extension (${leanTo.pitch}:12 pitch, ${leanTo.widthFt}' projection × ${leanTo.lengthFt}' run). Component costs are itemized in lean-to roof sheets, wall panels, posts, and framing allowance above; this summary row is informational only.`,
      quantity: 1,
      unit: 'summary',
      unitPrice: 0,
      totalCost: 0,
    });
  }

  if (interior.insulation !== 'none') {
    bom.push({
      id: 'bom-insulation',
      category: 'Interior & Insulation',
      item: 'Insulation Package',
      description: insulationDesc,
      quantity: Math.round(totalRoofMaterialAreaSqFt + totalGrossWallArea + totalLeanToWallPanelAreaSqFt),
      unit: 'sq ft',
      unitPrice: Number((insulationCost / Math.max(1, totalRoofMaterialAreaSqFt + totalGrossWallArea + totalLeanToWallPanelAreaSqFt)).toFixed(2)),
      totalCost: insulationCost,
    });
  }

  if (interior.linerPanel !== 'none') {
    bom.push({
      id: 'bom-liner',
      category: 'Interior & Insulation',
      item: 'Interior Finish Liner Panels',
      description: linerDesc,
      quantity: floorSqFt,
      unit: 'sq ft',
      unitPrice: Number((linerCost / floorSqFt).toFixed(2)),
      totalCost: linerCost,
    });
  }

  if (interior.electrical !== 'none') {
    bom.push({
      id: 'bom-electrical',
      category: 'Interior & Insulation',
      item: 'Electrical & Lighting Package',
      description: electricalDesc,
      quantity: floorSqFt,
      unit: 'sq ft',
      unitPrice: Number((electricalCost / floorSqFt).toFixed(2)),
      totalCost: electricalCost,
    });
  }

  if (interior.loft !== 'none' && loftCost > 0) {
    bom.push({
      id: 'bom-loft',
      category: 'Interior & Insulation',
      item: 'Structural Timber Storage Loft / Mezzanine',
      description: loftDesc,
      quantity: loftSqFt,
      unit: 'sq ft',
      unitPrice: Number((loftCost / loftSqFt).toFixed(2)),
      totalCost: loftCost,
    });
  }

  bom.push({
    id: 'bom-labor',
    category: 'Labor & Delivery',
    item: 'Erection & Installation Crew Labor',
    description: 'Site layout, post augering, framing erection, truss crane placement, metal siding & roofing installation',
    quantity: floorSqFt,
    unit: 'sq ft',
    unitPrice: Number((laborCost / floorSqFt).toFixed(2)),
    totalCost: laborCost,
  });

  return {
    squareFootage: floorSqFt,
    trusses: trussBreakdown,
    trussPackageCost: trussBreakdown.totalTrussPackageCost,
    roofSheetingCost,
    wallSidingCost,
    wainscotCost,
    trimAndFastenersCost,
    framingStructureCost,
    foundationCost,
    openingsCost,
    leanToCost,
    interiorCost,
    laborCost,
    subtotal,
    contractorMarginAmount,
    grandTotal,
    costPerSquareFoot,
    bom,
    metalTakeoff,
    weightBearingHeaders,
    validationWarnings,
  };
}
