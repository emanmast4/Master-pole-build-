import { CustomBuildingState, UnitPricingRates, AppSettings } from '../types';

export const DEFAULT_APP_SETTINGS: AppSettings = {
  theme: 'dark',
  unitSystem: 'imperial',
  renderQuality: 'high',
  showDimensions3D: true,
  showGrid3D: true,
  autoRotate3D: false,
  showFloatingPriceBar: true,
  soundEffects: true,
};

export const DEFAULT_UNIT_RATES: UnitPricingRates = {
  // Truss rates
  trussBasePerFootSpan: 9.85,          // $9.85 per linear foot of clear span
  trussPitchMultiplierWeight: 1.45,     // slope cost scaling factor
  trussHeavyLoadFactor: 1.18,          // multiplier per snow load tier above 20 psf
  trussGussetPlateBase: 38.00,         // heavy stamped steel gang-nail plate set per truss
  trussDeliveryCraneSetup: 450.00,     // flat truss delivery & site boom crane offload fee

  // Steel & Sheeting
  siding29gaPerSqFt: 3.40,
  siding26gaPerSqFt: 4.65,
  sidingBoardBattenPerSqFt: 5.80,
  wainscotPerSqFt: 4.05,                  // Lower accent wainscot panel rate per sq ft
  roofRibbedSteelPerSqFt: 3.85,
  roofStandingSeamPerSqFt: 6.95,
  roofShinglePerSqFt: 4.20,
  trimFlashingPerLinFt: 2.75,
  fastenersScrewsPerSqFt: 0.45,

  // Individual Pole Barn Trims Rates ($ per piece or $ per linear foot)
  ratGuardRate: 2.50,                     // Rat Guard per linear foot
  doubleAngleRate: 2.75,                  // Wainscot Double Angle per linear foot
  overheadDoorTopWrapRate: 32.00,         // Overhead Door Top Header wrap per piece
  overheadDoorSideWrapRate: 32.00,        // Overhead Door Side Stud wrap per piece
  slidingDoorSideWrapRate: 32.00,         // Sliding Barn Door Side Jamb per piece
  slidingDoorTrackCoverRate: 38.00,       // Sliding Door Trolley Track Cover per piece
  dripCapRate: 22.00,                     // Window & Walk Door Drip Cap per piece
  jChannelRate: 28.00,                    // J-Channel / J-Trim per piece
  fAndJTrimRate: 32.00,                   // F&J Soffit Transition Trim per piece
  outsideCornerRate: 3.25,                // Outside Corner Flashing per linear foot
  insideCornerRate: 30.00,                // Inside Corner Flashing per piece
  sidewallFlashingRate: 34.00,            // Sidewall Transition Flashing per piece
  endwallFlashingRate: 34.00,             // Endwall Transition Flashing per piece
  valleyFlashingRate: 36.00,              // Valley Gutter Flashing per piece
  dripEdgeRate: 28.00,                    // Low Eave Drip Edge per piece
  fasciaCoverRate: 35.00,                 // Metal Fascia Cover per piece
  soffitPanel1ftRate: 14.50,              // 1-Ft Overhang Soffit (11½") per 3-ft sheet
  soffitPanel2ftRate: 26.00,              // 2-Ft Overhang Soffit (23½") per 3-ft sheet
  seamlessGutterRate: 8.50,               // 6" Seamless K-Style Gutter per linear foot (optional)
  downspoutRate: 45.00,                   // 3x4 Commercial Downspout assembly (10ft + elbows) per unit
  residentialRakeRate: 3.25,              // Residential Gable Rake Flashing per linear foot
  ridgeCapRate: 3.50,                     // Ridge Cap Flashing per linear foot
  ventedClosureFoam20ftRate: 22.00,       // Vented Ridge Closure Foam per 20' roll
  snowGuardRailRate: 12.50,               // Continuous Snow Guard Roof Rail per linear foot
  insideClosuresStripRate: 4.50,          // Inside Foam Rib Closures 36" strip
  outsideClosuresStripRate: 4.50,         // Outside Foam Rib Closures 36" strip
  butylTapeRollRate: 14.00,               // Butyl Mastic Sealant Tape 45' roll
  woodgripScrewsBoxRate: 38.00,           // Color-matched Woodgrip Screws 250-box
  stitchScrewsBoxRate: 32.00,             // Lap Stitch Screws 250-box
  hurricaneTieRate: 2.85,                 // Simpson H1 Hurricane Tie-Downs per unit

  // Framing & Columns
  lumberFramingPerBf: 1.65,
  postsTreatedPerLinFt: 6.80,          // 3-ply glue-laminated or 6x6 treated post
  trussCarriersPerLinFt: 4.85,         // #1 Structural 2x12 header beam per linear foot
  purlinsGirtsPerLinFt: 1.85,          // 2x4 & 2x6 framing runners

  // Foundation
  concrete4inPerSqFt: 7.25,
  concrete6inPerSqFt: 9.80,
  dirtGravelPrepPerSqFt: 1.80,
  piersPermaColumnPerUnit: 185.00,

  // Openings
  overheadDoorBasePerSqFt: 22.50,
  overheadDoorInsulatedAddon: 280.00,
  walkDoorCommercialStandard: 520.00,
  walkDoorInsulatedGlass: 780.00,
  windowSliderStandard: 290.00,
  slidingBarnDoorDouble: 1450.00,

  // Interior options
  insulationVaporBarrierPerSqFt: 0.65,
  insulationR19BattPerSqFt: 1.95,
  insulationSprayFoam2inPerSqFt: 2.85,
  insulationSprayFoam3inPerSqFt: 3.90,
  linerSteelPerSqFt: 2.90,
  linerOsbPerSqFt: 2.20,
  electricalBasicPerSqFt: 3.10,
  electricalDeluxePerSqFt: 5.75,
  loftPerSqFt: 14.50,

  // Labor & Overhead
  laborFramingPerSqFt: 6.50,
  laborSidingRoofPerSqFt: 4.25,
  contingencyMarginPercent: 12.0, // 12% contractor/contingency margin
};

export const COLOR_PALETTE = [
  { name: 'Charcoal Gray', hex: '#374151', textDark: false },
  { name: 'Burnished Slate', hex: '#475569', textDark: false },
  { name: 'Matte Black', hex: '#18181b', textDark: false },
  { name: 'Bright White', hex: '#f8fafc', textDark: true },
  { name: 'Classic Barn Red', hex: '#991b1b', textDark: false },
  { name: 'Crimson Burgundy', hex: '#831843', textDark: false },
  { name: 'Forest Green', hex: '#166534', textDark: false },
  { name: 'Evergreen Pine', hex: '#064e3b', textDark: false },
  { name: 'Gallery Blue', hex: '#1e40af', textDark: false },
  { name: 'Hawaiian Blue', hex: '#0284c7', textDark: false },
  { name: 'Dark Bronze', hex: '#3b2f2f', textDark: false },
  { name: 'Cocoa Brown', hex: '#583622', textDark: false },
  { name: 'Light Stone / Sand', hex: '#d6d3d1', textDark: true },
  { name: 'Desert Clay / Tan', hex: '#a8715a', textDark: false },
  { name: 'Ash Gray', hex: '#94a3b8', textDark: true },
  { name: 'Pewter Gray', hex: '#64748b', textDark: false },
  { name: 'Galvalume Silver', hex: '#cbd5e1', textDark: true },
  { name: 'Copper Metallic', hex: '#b45309', textDark: false },
];

export const BUILDING_STYLES = [
  {
    id: 'gable' as const,
    name: 'Gable Post-Frame',
    badge: 'Most Popular',
    description: 'Symmetrical A-frame truss roof. Cost-effective, maximum interior volume, classic farm & workshop look.',
  },
  {
    id: 'monitor' as const,
    name: 'Raised Monitor / Barn',
    badge: 'High Loft',
    description: 'Elevated central roofline with clerestory side wall options for natural daylight and large loft space.',
  },
  {
    id: 'gambrel' as const,
    name: 'Dutch Gambrel',
    badge: 'Heritage',
    description: 'Dual-pitch mansard barn roof providing enormous 2nd-floor ceiling clearance and storage capacity.',
  },
  {
    id: 'single_slope' as const,
    name: 'Mono-Slope / Shed',
    badge: 'Modern',
    description: 'Single pitched continuous roofline. Ideal for equipment run-ins, solar panel exposure, and modern aesthetics.',
  },
  {
    id: 'commercial' as const,
    name: 'Commercial Box Gable',
    badge: 'Heavy Duty',
    description: 'Wide-span truss design engineered for retail, industrial storage, and high-clearance overhead doors.',
  },
];

export const DEFAULT_BUILDING_STATE: CustomBuildingState = {
  style: 'gable',
  dimensions: {
    width: 30,
    length: 40,
    eaveHeight: 14,
    roofPitch: 4,
    trussSpacing: 4,
    postSpacing: 8,
    overhangInches: 12,
    eaveOverhangInches: 12,
    gableOverhangInches: 12,
  },
  snowLoad: 30,
  trussType: 'fink_gable',
  walls: {
    front: { side: 'front', enclosed: true, hasWainscot: false },
    back: { side: 'back', enclosed: true, hasWainscot: false },
    left: { side: 'left', enclosed: true, hasWainscot: false },
    right: { side: 'right', enclosed: true, hasWainscot: false },
  },
  openings: [],
  leanTo: {
    enabled: false,
    side: 'right',
    widthFt: 12,
    lengthFt: 40,
    pitch: 2,
    enclosed: false,
    openSides: { host: true, outerEave: true, frontGable: true, backGable: true },
    hasOutsideEaveOverhang: true,
    dropBelowEaveFt: 2,
  },
  materials: {
    sidingType: 'ag_panel_36',
    sidingColor: '#f8fafc',
    sidingColorName: 'Bright White',
    wainscotColor: '#18181b',
    wainscotColorName: 'Matte Black',
    wainscotHeightFt: 3,
    roofType: 'ag_panel_36',
    roofColor: '#18181b',
    roofColorName: 'Matte Black',
    trimColor: '#18181b',
    trimColorName: 'Matte Black',
    hasGutters: false, // Default: No gutters, clean eave & fascia per build photo
    foundation: 'slab_4in',
  },
  interior: {
    insulation: 'r19_batt',
    linerPanel: 'steel_liner_all',
    electrical: 'none',
    loft: 'none',
    loftFloorRating: 'light_storage',
  },
  unitRates: { ...DEFAULT_UNIT_RATES },
};

export const PRESET_TEMPLATES: { name: string; tag: string; description: string; state: Partial<CustomBuildingState> }[] = [
  {
    name: 'Standard Building 30x40',
    tag: 'Contractor Favorite',
    description: '1,200 sq ft building shell with 14ft eaves, clean full-height siding, ready for custom doors and windows.',
    state: {
      style: 'gable',
      dimensions: {
        width: 30,
        length: 40,
        eaveHeight: 14,
        roofPitch: 4,
        trussSpacing: 4,
        postSpacing: 8,
        overhangInches: 12,
      },
      snowLoad: 30,
      trussType: 'fink_gable',
      walls: {
        front: { side: 'front', enclosed: true, hasWainscot: false },
        back: { side: 'back', enclosed: true, hasWainscot: false },
        left: { side: 'left', enclosed: true, hasWainscot: false },
        right: { side: 'right', enclosed: true, hasWainscot: false },
      },
      openings: [],
      leanTo: { enabled: false, side: 'right', widthFt: 12, lengthFt: 40, pitch: 2, enclosed: false, dropBelowEaveFt: 2 },
      materials: {
        sidingType: 'ag_panel_36',
        sidingColor: '#f8fafc',
        sidingColorName: 'Bright White',
        wainscotColor: '#18181b',
        wainscotColorName: 'Matte Black',
        wainscotHeightFt: 3,
        roofType: 'ag_panel_36',
        roofColor: '#18181b',
        roofColorName: 'Matte Black',
        trimColor: '#18181b',
        trimColorName: 'Matte Black',
        foundation: 'slab_4in',
      },
      interior: {
        insulation: 'r19_batt',
        linerPanel: 'steel_liner_all',
        electrical: 'basic_shop',
        loft: 'none',
        loftFloorRating: 'light_storage',
      },
    },
  },
  {
    name: 'Ranch Barn 36x48 with Lean-to',
    tag: 'Agricultural',
    description: 'Classic red post-frame building with 12ft open-bay lean-to porch for tractor/equipment shelter.',
    state: {
      style: 'gable',
      dimensions: {
        width: 36,
        length: 48,
        eaveHeight: 14,
        roofPitch: 4,
        trussSpacing: 4,
        postSpacing: 8,
        overhangInches: 18,
      },
      snowLoad: 30,
      trussType: 'fink_gable',
      walls: {
        front: { side: 'front', enclosed: true, hasWainscot: false },
        back: { side: 'back', enclosed: true, hasWainscot: false },
        left: { side: 'left', enclosed: true, hasWainscot: false },
        right: { side: 'right', enclosed: true, hasWainscot: false },
      },
      openings: [],
      leanTo: { enabled: true, side: 'right', widthFt: 12, lengthFt: 48, pitch: 2, enclosed: false, dropBelowEaveFt: 2 },
      materials: {
        sidingType: 'ag_panel_36',
        sidingColor: '#991b1b',
        sidingColorName: 'Classic Barn Red',
        wainscotColor: '#374151',
        wainscotColorName: 'Charcoal Gray',
        wainscotHeightFt: 3,
        roofType: 'ag_panel_36',
        roofColor: '#f8fafc',
        roofColorName: 'Bright White',
        trimColor: '#f8fafc',
        trimColorName: 'Bright White',
        foundation: 'dirt_gravel',
      },
      interior: {
        insulation: 'vapor_bubble',
        linerPanel: 'none',
        electrical: 'basic_shop',
        loft: 'quarter_loft',
        loftFloorRating: 'light_storage',
      },
    },
  },
  {
    name: 'Barndominium / Studio 40x60',
    tag: 'Living & Storage',
    description: 'High-clearance 16ft walls, 6:12 pitch, scissor vaulted trusses, standing seam roof, and mezzanine loft.',
    state: {
      style: 'gable',
      dimensions: {
        width: 40,
        length: 60,
        eaveHeight: 16,
        roofPitch: 6,
        trussSpacing: 4,
        postSpacing: 8,
        overhangInches: 24,
      },
      snowLoad: 40,
      trussType: 'scissor',
      walls: {
        front: { side: 'front', enclosed: true, hasWainscot: false },
        back: { side: 'back', enclosed: true, hasWainscot: false },
        left: { side: 'left', enclosed: true, hasWainscot: false },
        right: { side: 'right', enclosed: true, hasWainscot: false },
      },
      openings: [],
      leanTo: { enabled: false, side: 'right', widthFt: 10, lengthFt: 60, pitch: 3, enclosed: false, dropBelowEaveFt: 3 },
      materials: {
        sidingType: 'ag_panel_36',
        sidingColor: '#18181b',
        sidingColorName: 'Matte Black',
        wainscotColor: '#3b2f2f',
        wainscotColorName: 'Dark Bronze',
        wainscotHeightFt: 4,
        roofType: 'ag_panel_36',
        roofColor: '#374151',
        roofColorName: 'Charcoal Gray',
        trimColor: '#374151',
        trimColorName: 'Charcoal Gray',
        foundation: 'slab_6in',
      },
      interior: {
        insulation: 'spray_foam_3in',
        linerPanel: 'drywall_ready',
        electrical: 'deluxe_commercial',
        loft: 'half_loft',
        loftFloorRating: 'heavy_mezzanine',
      },
    },
  },
  {
    name: 'Compact 2-Car Garage 24x30',
    tag: 'Residential',
    description: 'Clean residential layout with 10ft eaves, 4:12 pitch, smooth slab, ready for custom garage doors.',
    state: {
      style: 'gable',
      dimensions: {
        width: 24,
        length: 30,
        eaveHeight: 10,
        roofPitch: 4,
        trussSpacing: 4,
        postSpacing: 8,
        overhangInches: 12,
      },
      snowLoad: 20,
      trussType: 'fink_gable',
      walls: {
        front: { side: 'front', enclosed: true, hasWainscot: false },
        back: { side: 'back', enclosed: true, hasWainscot: false },
        left: { side: 'left', enclosed: true, hasWainscot: false },
        right: { side: 'right', enclosed: true, hasWainscot: false },
      },
      openings: [],
      leanTo: { enabled: false, side: 'left', widthFt: 8, lengthFt: 30, pitch: 2, enclosed: false, dropBelowEaveFt: 2 },
      materials: {
        sidingType: 'ag_panel_36',
        sidingColor: '#d6d3d1',
        sidingColorName: 'Light Stone / Sand',
        wainscotColor: '#475569',
        wainscotColorName: 'Burnished Slate',
        wainscotHeightFt: 3,
        roofType: 'ag_panel_36',
        roofColor: '#475569',
        roofColorName: 'Burnished Slate',
        trimColor: '#f8fafc',
        trimColorName: 'Bright White',
        foundation: 'slab_4in',
      },
      interior: {
        insulation: 'r19_batt',
        linerPanel: 'steel_liner_ceiling',
        electrical: 'basic_shop',
        loft: 'none',
        loftFloorRating: 'light_storage',
      },
    },
  },
];
