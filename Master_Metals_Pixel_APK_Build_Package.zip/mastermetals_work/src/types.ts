export type BuildingStyle = 
  | 'gable' 
  | 'monitor' 
  | 'gambrel' 
  | 'single_slope' 
  | 'commercial';

export type TrussSpacing = 4 | 8 | 10 | 12;

export type PostSpacing = 6 | 8 | 10 | 12;

export type SnowLoadRating = 20 | 30 | 40 | 60; // PSF

export type TrussType = 'fink_gable' | 'scissor' | 'attic_storage' | 'mono_slope';

export type WallSide = 'front' | 'back' | 'left' | 'right';

export type OpeningType = 'overhead_door' | 'walk_door' | 'window' | 'sliding_barn_door';

export interface WallOpening {
  id: string;
  type: OpeningType;
  side: WallSide;
  widthFt: number;
  heightFt: number;
  label: string;
  insulated?: boolean;
  hasWindows?: boolean; // for garage doors with window inserts
  positionOffsetFt: number; // offset from left corner of that side
  bottomOffsetFt?: number; // opening sill height above finished floor; doors default to 0
}

export interface LeanToPorch {
  enabled: boolean;
  side: 'left' | 'right' | 'front' | 'back';
  widthFt: number; // outward projection (depth) e.g., 6 - 40 ft
  lengthFt: number; // longitudinal length e.g., 8 - 200 ft
  pitch: number; // roof pitch e.g., 1 - 8:12
  enclosed: boolean; // Legacy all-sides enclosure fallback
  openSides?: { host: boolean; outerEave: boolean; frontGable: boolean; backGable: boolean };
  hasOutsideEaveOverhang?: boolean; // Whether the lean-to outside eave has soffit/fascia cover
  dropBelowEaveFt: number; // ledger drop below main building eave (0 - 10 ft)
  outerEaveHeightFt?: number; // clearance height at outer posts (6 - 20 ft)
  startOffsetFt?: number; // placement offset along the wall from the corner (0 - 100 ft)
}

export interface BuildingDimensions {
  width: number;       // feet (e.g., 20 - 80)
  length: number;      // feet (e.g., 24 - 160)
  eaveHeight: number;  // feet (e.g., 8 - 24)
  roofPitch: number;   // x:12 (e.g., 2, 3, 4, 5, 6, 8, 10, 12)
  trussSpacing: TrussSpacing;
  postSpacing: PostSpacing;
  overhangInches: number; // Legacy shared overhang fallback for saved projects
  eaveOverhangInches?: number; // Independent eave overhang (0, 12, 18, 24)
  gableOverhangInches?: number; // Independent gable overhang (0, 12, 18, 24)
}

export interface WallConfig {
  side: WallSide;
  enclosed: boolean;
  hasWainscot: boolean;
}

export interface MaterialsConfig {
  sidingType: 'ag_panel_36' | '29ga_ribbed' | '26ga_commercial'; // 36" Ag-Panel: 3/4" high ribs @ 9" O.C.
  sidingColor: string;
  sidingColorName: string;
  wainscotColor: string;
  wainscotColorName: string;
  wainscotHeightFt: number;
  roofType: 'ag_panel_36' | 'ribbed_steel'; // 36" Ag-Panel: 3/4" high ribs @ 9" O.C.
  roofColor: string;
  roofColorName: string;
  trimColor: string;
  trimColorName: string;
  // Trim piece stock length preference: 10'6" or 12' standard pieces
  trimStockLength?: '10ft6in' | '12ft';
  // Heavy-duty Snow Guard rail system
  hasSnowGuards?: boolean;
  snowGuardSides?: 'both' | 'left' | 'right' | 'none';
  snowGuardColor?: string;
  snowGuardColorName?: string;
  // Gutters & Downspouts (Disabled by default: clean eave & fascia without gutters)
  hasGutters?: boolean;
  gutterColor?: string;
  gutterColorName?: string;
  // Soffit & Fascia enclosure package
  hasSoffitFascia?: boolean;
  soffitColor?: string;
  soffitColorName?: string;
  fasciaTrimColor?: string;
  fasciaTrimColorName?: string;
  // Specific trim color overrides
  customTrimColorsEnabled?: boolean;
  cornerTrimColor?: string;
  cornerTrimColorName?: string;
  eaveTrimColor?: string;
  eaveTrimColorName?: string;
  ridgeCapColor?: string;
  ridgeCapColorName?: string;
  rakeTrimColor?: string;
  rakeTrimColorName?: string;
  doorTrimColor?: string;
  doorTrimColorName?: string;
  wainscotCapColor?: string;
  wainscotCapColorName?: string;
  ratGuardColor?: string;
  ratGuardColorName?: string;
  dripEdgeColor?: string;
  dripEdgeColorName?: string;
  fAndJColor?: string;
  fAndJColorName?: string;
  foundation: 'slab_4in' | 'dirt' | 'crushed_gravel' | 'dirt_gravel' | 'slab_6in' | 'piers_perma_columns';
  cupolasCount?: number;
  cupolaHasWeathervane?: boolean;
}

export interface InteriorConfig {
  insulation: 'none' | 'vapor_bubble' | 'r19_batt' | 'spray_foam_2in' | 'spray_foam_3in' | 'deluxe_combo';
  linerPanel: 'none' | 'steel_liner_all' | 'steel_liner_ceiling' | 'osb_plywood' | 'drywall_ready';
  electrical: 'none' | 'basic_shop' | 'deluxe_commercial';
  loft: 'none' | 'quarter_loft' | 'half_loft' | 'full_loft';
  loftFloorRating: 'light_storage' | 'heavy_mezzanine';
}

export interface UnitPricingRates {
  // Truss rates
  trussBasePerFootSpan: number;        // e.g., $9.50 per ft of span base
  trussPitchMultiplierWeight: number;   // factor for slope curvature & rafter chord
  trussHeavyLoadFactor: number;        // per snow load step
  trussGussetPlateBase: number;        // steel gang-nail gusset plate cost
  trussDeliveryCraneSetup: number;     // flat delivery / rigging fee

  // Steel & Sheeting rates per sq ft
  siding29gaPerSqFt: number;
  siding26gaPerSqFt: number;
  sidingBoardBattenPerSqFt: number;
  wainscotPerSqFt?: number;             // Lower accent wainscot 36" steel panel rate ($ / sq ft)
  roofRibbedSteelPerSqFt: number;
  roofStandingSeamPerSqFt: number;
  roofShinglePerSqFt: number;
  trimFlashingPerLinFt: number;
  fastenersScrewsPerSqFt: number;

  // Individual Pole Barn Trims Rates ($ per piece or $ per linear foot)
  ratGuardRate: number;                   // Rat Guard per linear foot
  doubleAngleRate: number;                // Wainscot Double Angle per linear foot
  overheadDoorTopWrapRate: number;        // Overhead Door Top Header wrap per piece
  overheadDoorSideWrapRate: number;       // Overhead Door Side Stud wrap per piece
  slidingDoorSideWrapRate: number;        // Sliding Barn Door Side Jamb per piece
  slidingDoorTrackCoverRate: number;      // Sliding Door Trolley Track Cover per piece
  dripCapRate: number;                    // Window & Walk Door Drip Cap per piece
  jChannelRate: number;                   // J-Channel / J-Trim per piece
  fAndJTrimRate: number;                  // F&J Soffit Transition Trim per piece
  outsideCornerRate: number;              // Outside Corner Flashing per linear foot
  insideCornerRate: number;               // Inside Corner Flashing per piece
  sidewallFlashingRate: number;           // Sidewall Transition Flashing per piece
  endwallFlashingRate: number;            // Endwall Transition Flashing per piece
  valleyFlashingRate: number;             // Valley Gutter Flashing per piece
  dripEdgeRate: number;                   // Low Eave Drip Edge per piece
  fasciaCoverRate: number;                // Metal Fascia Cover per piece
  soffitPanel1ftRate: number;             // 1-Ft Overhang Soffit (11½") per 3-ft sheet
  soffitPanel2ftRate: number;             // 2-Ft Overhang Soffit (23½") per 3-ft sheet
  seamlessGutterRate?: number;            // 6" Seamless K-Style Gutter per linear foot (optional add-on)
  downspoutRate?: number;                 // 3x4 Commercial Downspout assembly (10ft + elbows) per unit
  residentialRakeRate: number;            // Residential Gable Rake Flashing per linear foot
  ridgeCapRate: number;                   // Ridge Cap Flashing per linear foot
  ventedClosureFoam20ftRate: number;      // Vented Ridge Closure Foam per 20' roll
  snowGuardRailRate: number;              // Continuous Snow Guard Roof Rail per linear foot
  insideClosuresStripRate: number;        // Inside Foam Rib Closures 36" strip
  outsideClosuresStripRate: number;       // Outside Foam Rib Closures 36" strip
  butylTapeRollRate: number;              // Butyl Mastic Sealant Tape 45' roll
  woodgripScrewsBoxRate: number;          // Color-matched Woodgrip Screws 250-box
  stitchScrewsBoxRate: number;            // Lap Stitch Screws 250-box
  hurricaneTieRate: number;               // Simpson H1 Hurricane Tie-Downs per unit

  // Framing & Columns
  lumberFramingPerBf: number;
  postsTreatedPerLinFt: number;
  trussCarriersPerLinFt: number;
  purlinsGirtsPerLinFt: number;

  // Foundation
  concrete4inPerSqFt: number;
  concrete6inPerSqFt: number;
  dirtGravelPrepPerSqFt: number;
  piersPermaColumnPerUnit: number;

  // Openings base prices
  overheadDoorBasePerSqFt: number;
  overheadDoorInsulatedAddon: number;
  walkDoorCommercialStandard: number;
  walkDoorInsulatedGlass: number;
  windowSliderStandard: number;
  slidingBarnDoorDouble: number;

  // Interior options
  insulationVaporBarrierPerSqFt: number;
  insulationR19BattPerSqFt: number;
  insulationSprayFoam2inPerSqFt: number;
  insulationSprayFoam3inPerSqFt: number;
  linerSteelPerSqFt: number;
  linerOsbPerSqFt: number;
  electricalBasicPerSqFt: number;
  electricalDeluxePerSqFt: number;
  loftPerSqFt: number;

  // Labor & Overhead
  laborFramingPerSqFt: number;
  laborSidingRoofPerSqFt: number;
  contingencyMarginPercent: number; // e.g. 15%
}

export interface TrussCalculationBreakdown {
  spanWidthFt: number;
  pitch: number;
  slopeFactor: number;
  rafterLengthFt: number;
  apexPeakHeightFt: number;
  totalTrussesNeeded: number;
  standardTrussesCount: number;
  gableEndTrussesCount: number;
  webMembersCount: number;
  boardFootagePerTruss: number;
  plateConnectorsCount: number;
  piggybackRequired: boolean; // if apex height > 13.5ft
  baseSpanCost: number;
  pitchSlopeSurcharge: number;
  snowLoadSurcharge: number;
  trussStyleSurcharge: number;
  piggybackSurcharge: number;
  unitCostStandardTruss: number;
  unitCostGableTruss: number;
  totalTrussPackageCost: number;
}

export interface ItemizedBomLine {
  id: string;
  category: 'Trusses' | 'Roof Sheeting' | 'Wall Siding' | 'Trim & Fasteners' | 'Framing Structure' | 'Foundation' | 'Doors & Windows' | 'Lean-to Additions' | 'Interior & Insulation' | 'Labor & Delivery' | 'Recommended Extras';
  item: string;
  description: string;
  quantity: number;
  unit: string;
  unitPrice: number;
  totalCost: number;
  sheetLengthFt?: number;
  sheetLengthFormatted?: string;
  coverageWidthInches?: number;
  isMetalSheet?: boolean;
}

export interface MetalSheetTakeoffSummary {
  panelCoverageInches: number; // 36" net coverage
  panelCoverageFt: number; // 3.0 ft
  totalRoofSheets: number;
  totalWallSidingSheets: number;
  totalWainscotSheets: number;
  totalMetalSheets: number;
  totalMetalLinearFeet: number;
  totalMetalSquareFeet: number;
}

export interface WeightBearingWallHeadersBreakdown {
  postSpacing: number;
  headerSize: string; // e.g. '(2) 2x12s'
  plyCount: number; // 2 plies
  wallRunsCount: number; // 2 weight-bearing walls (left & right eave walls)
  linearFeetPerPly: number; // building length
  total2x12LinearFeet: number; // 4 * length
  standard16FtBoardsCount: number; // Math.ceil((4 * length) / 16)
  unitPricePerLinFt: number;
  totalHeaderCost: number;
  description: string;
}

export interface PricingBreakdown {
  squareFootage: number;
  trusses: TrussCalculationBreakdown;
  trussPackageCost: number;
  roofSheetingCost: number;
  wallSidingCost: number;
  wainscotCost: number;
  trimAndFastenersCost: number;
  framingStructureCost: number;
  foundationCost: number;
  openingsCost: number;
  leanToCost: number;
  interiorCost: number;
  laborCost: number;
  subtotal: number;
  contractorMarginAmount: number;
  grandTotal: number;
  costPerSquareFoot: number;
  bom: ItemizedBomLine[];
  metalTakeoff?: MetalSheetTakeoffSummary;
  weightBearingHeaders?: WeightBearingWallHeadersBreakdown;
  validationWarnings?: string[];
}

export interface AppSettings {
  theme: 'dark' | 'light' | 'system';
  unitSystem: 'imperial' | 'metric';
  renderQuality: 'high' | 'fast';
  showDimensions3D: boolean;
  showGrid3D: boolean;
  autoRotate3D: boolean;
  showFloatingPriceBar: boolean;
  soundEffects: boolean;
}

export interface CustomBuildingState {
  style: BuildingStyle;
  dimensions: BuildingDimensions;
  snowLoad: SnowLoadRating;
  trussType: TrussType;
  walls: Record<WallSide, WallConfig>;
  openings: WallOpening[];
  leanTo: LeanToPorch;
  materials: MaterialsConfig;
  interior: InteriorConfig;
  unitRates: UnitPricingRates;
}
