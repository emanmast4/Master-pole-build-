import React, { useMemo, useState, useEffect, useRef } from 'react';
import { CustomBuildingState, UnitPricingRates, WallSide, AppSettings } from './types';
import { DEFAULT_BUILDING_STATE, DEFAULT_UNIT_RATES, DEFAULT_APP_SETTINGS, PRESET_TEMPLATES } from './utils/constants';
import { calculateBuildingPricing } from './utils/pricingEngine';
import { Header } from './components/Header';
import { BuildingVisualizer, ViewMode } from './components/BuildingVisualizer';
import { StyleAndSizeTab } from './components/ConfigTabs/StyleAndSizeTab';
import { SidesAndOpeningsTab } from './components/ConfigTabs/SidesAndOpeningsTab';
import { MaterialsTab } from './components/ConfigTabs/MaterialsTab';
import { InteriorTab } from './components/ConfigTabs/InteriorTab';
import { PricingSummary } from './components/PricingSummary';
import { AppSettingsModal } from './components/AppSettingsModal';
import { UnitPricingEditorModal } from './components/UnitPricingEditorModal';
import { BillOfMaterialsModal } from './components/BillOfMaterialsModal';
import { FloorPlanModal } from './components/FloorPlanModal';
import { TrussDetailsModal } from './components/TrussDetailsModal';
import { QuoteExportModal } from './components/QuoteExportModal';
import { ColorOptionPill } from './components/ColorOptionPill';
import {
  Box,
  Layers,
  Palette,
  Wrench,
  ShieldCheck,
  CheckCircle2,
  DollarSign,
  X,
  Maximize2,
  ChevronLeft,
  ChevronRight,
  Sliders,
  Sparkles,
  Check,
  Compass,
  Ruler,
  Minus,
  Plus
} from 'lucide-react';

const TAB_ITEMS = [
  {
    id: 'dimensions' as const,
    label: 'Dimensions',
    icon: Ruler,
    description: 'Length, width, eave height & overall footprint sizing',
  },
  {
    id: 'style' as const,
    label: 'Style',
    icon: Box,
    description: 'Structural architecture, roof profile & building style preset',
  },
  {
    id: 'framing' as const,
    label: 'Framing',
    icon: Compass,
    description: 'Roof pitch, truss spacing, post grid & snow load engineering',
  },
  {
    id: 'sides_openings' as const,
    label: 'Sides & Openings',
    icon: Layers,
    description: 'Wall enclosures, roll-up doors, walk doors & windows layout',
  },
  {
    id: 'materials' as const,
    label: 'Colors',
    icon: Palette,
    description: 'Wall, roof & trim color palettes, panel gauge & wainscoting',
  },
  {
    id: 'interior' as const,
    label: 'Interior Options',
    icon: Wrench,
    description: 'Insulation barrier, lean-to porch extensions & concrete slab options',
  },
];

export default function App() {
  // App & UI preferences (Theme, units, 3D options)
  const [appSettings, setAppSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem('master_metals_app_settings');
      if (saved) {
        const parsed: unknown = JSON.parse(saved);
        if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
          const value = parsed as Partial<AppSettings>;
          // Treat persisted browser data as untrusted: accept only known enum
          // values and booleans, otherwise use safe defaults.
          return {
            ...DEFAULT_APP_SETTINGS,
            theme: value.theme === 'dark' || value.theme === 'light' || value.theme === 'system' ? value.theme : DEFAULT_APP_SETTINGS.theme,
            unitSystem: value.unitSystem === 'imperial' || value.unitSystem === 'metric' ? value.unitSystem : DEFAULT_APP_SETTINGS.unitSystem,
            renderQuality: value.renderQuality === 'high' || value.renderQuality === 'fast' ? value.renderQuality : DEFAULT_APP_SETTINGS.renderQuality,
            showDimensions3D: typeof value.showDimensions3D === 'boolean' ? value.showDimensions3D : DEFAULT_APP_SETTINGS.showDimensions3D,
            showGrid3D: typeof value.showGrid3D === 'boolean' ? value.showGrid3D : DEFAULT_APP_SETTINGS.showGrid3D,
            autoRotate3D: typeof value.autoRotate3D === 'boolean' ? value.autoRotate3D : DEFAULT_APP_SETTINGS.autoRotate3D,
            showFloatingPriceBar: typeof value.showFloatingPriceBar === 'boolean' ? value.showFloatingPriceBar : DEFAULT_APP_SETTINGS.showFloatingPriceBar,
            soundEffects: typeof value.soundEffects === 'boolean' ? value.soundEffects : DEFAULT_APP_SETTINGS.soundEffects,
          };
        }
      }
    } catch (e) {
      // fallback
    }
    return DEFAULT_APP_SETTINGS;
  });

  // Apply Theme (Dark / Light / System) on root HTML element
  useEffect(() => {
    try {
      localStorage.setItem('master_metals_app_settings', JSON.stringify(appSettings));
    } catch (e) {
      // ignore
    }

    const root = document.documentElement;
    if (appSettings.theme === 'dark') {
      root.classList.add('dark');
    } else if (appSettings.theme === 'light') {
      root.classList.remove('dark');
    } else {
      if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }
    }
  }, [appSettings]);

  // Load saved component rates separately so edited prices survive refreshes and app restarts.
  const [buildingState, setBuildingState] = useState<CustomBuildingState>(() => {
    let unitRates = { ...DEFAULT_UNIT_RATES };
    try {
      const saved = localStorage.getItem('master_metals_unit_rates');
      if (saved) {
        const parsed: unknown = JSON.parse(saved);
        if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
          const candidate = parsed as Record<string, unknown>;
          for (const key of Object.keys(DEFAULT_UNIT_RATES) as Array<keyof UnitPricingRates>) {
            const value = candidate[key];
            // Reject strings, NaN/Infinity, negative amounts, and unreasonably large values.
            if (typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 1_000_000) {
              unitRates[key] = value;
            }
          }
        }
      }
    } catch {
      // Malformed browser storage falls back to the known defaults.
    }
    return { ...DEFAULT_BUILDING_STATE, unitRates };
  });

  // Persist rates whenever changed. Prices are local to this browser/device and are not synced.
  useEffect(() => {
    try {
      localStorage.setItem('master_metals_unit_rates', JSON.stringify(buildingState.unitRates));
    } catch {
      // Storage can be unavailable in private browsing or when device storage is full.
    }
  }, [buildingState.unitRates]);

  // Active visualizer view mode (3D Orbit View, Front Elevation, Side Elevation, CAD Floor Plan)
  const [viewMode, setViewMode] = useState<ViewMode>('3d_interactive');

  // Active configuration category
  const [activeTab, setActiveTab] = useState<'dimensions' | 'style' | 'framing' | 'sides_openings' | 'materials' | 'interior' | 'style_size'>('style');

  // Full Screen Pop-up Category Modal state
  const [categoryModalOpen, setCategoryModalOpen] = useState<boolean>(false);

  // Modals state
  const [showUnitRatesModal, setShowUnitRatesModal] = useState<boolean>(false);
  const [showAppSettingsModal, setShowAppSettingsModal] = useState<boolean>(false);
  const [showBomModal, setShowBomModal] = useState<boolean>(false);
  const [showFloorPlanModal, setShowFloorPlanModal] = useState<boolean>(false);
  const [showTrussModal, setShowTrussModal] = useState<boolean>(false);
  const [showQuoteModal, setShowQuoteModal] = useState<boolean>(false);
  const [showLiveQuoteModal, setShowLiveQuoteModal] = useState<boolean>(false);

  // Lock body scroll when full-screen category modal is open
  useEffect(() => {
    if (categoryModalOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [categoryModalOpen]);

  const openCategoryModal = (tabId: typeof activeTab) => {
    setActiveTab(tabId);
    setCategoryModalOpen(true);
    setTimeout(() => {
      document.getElementById(`modal-tab-${tabId}`)?.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
    }, 50);
  };

  // Swipe Left / Right gesture navigation for the Category Modal
  const touchStartXRef = useRef<number | null>(null);
  const touchStartYRef = useRef<number | null>(null);

  const goToNextTab = () => {
    const currentIndex = TAB_ITEMS.findIndex((t) => t.id === activeTab);
    if (currentIndex < TAB_ITEMS.length - 1) {
      const nextTab = TAB_ITEMS[currentIndex + 1].id;
      setActiveTab(nextTab);
      setTimeout(() => {
        document.getElementById(`modal-tab-${nextTab}`)?.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
      }, 50);
    }
  };

  const goToPrevTab = () => {
    const currentIndex = TAB_ITEMS.findIndex((t) => t.id === activeTab);
    if (currentIndex > 0) {
      const prevTab = TAB_ITEMS[currentIndex - 1].id;
      setActiveTab(prevTab);
      setTimeout(() => {
        document.getElementById(`modal-tab-${prevTab}`)?.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
      }, 50);
    }
  };

  const handleModalTouchStart = (e: React.TouchEvent) => {
    const target = e.target as HTMLElement | null;
    // Don't hijack swipe when user interacts with sliders, buttons, or scroll areas
    if (target) {
      if (
        target.tagName === 'INPUT' ||
        target.getAttribute('type') === 'range' ||
        target.closest('input[type="range"]') ||
        target.closest('.no-swipe')
      ) {
        touchStartXRef.current = null;
        touchStartYRef.current = null;
        return;
      }
    }
    touchStartXRef.current = e.touches[0].clientX;
    touchStartYRef.current = e.touches[0].clientY;
  };

  const handleModalTouchEnd = (e: React.TouchEvent) => {
    if (touchStartXRef.current === null || touchStartYRef.current === null) return;
    const touchEndX = e.changedTouches[0].clientX;
    const touchEndY = e.changedTouches[0].clientY;
    const deltaX = touchEndX - touchStartXRef.current;
    const deltaY = touchEndY - touchStartYRef.current;

    // Must be predominantly horizontal and at least 45px distance
    if (Math.abs(deltaX) > 45 && Math.abs(deltaX) > Math.abs(deltaY) * 1.2) {
      if (deltaX < 0) {
        // Swiped Left -> Move to Next Tab
        goToNextTab();
      } else {
        // Swiped Right -> Move to Previous Tab
        goToPrevTab();
      }
    }

    touchStartXRef.current = null;
    touchStartYRef.current = null;
  };

  // Keyboard navigation (ArrowLeft & ArrowRight) when modal is open
  useEffect(() => {
    if (!categoryModalOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.key === 'ArrowRight') {
        goToNextTab();
      } else if (e.key === 'ArrowLeft') {
        goToPrevTab();
      } else if (e.key === 'Escape') {
        setCategoryModalOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [categoryModalOpen, activeTab]);

  // Real-time Dynamic Pricing calculation
  const pricing = useMemo(() => {
    return calculateBuildingPricing(buildingState);
  }, [buildingState]);

  // Load a preset template
  const handleLoadPreset = (presetPatch: Partial<CustomBuildingState>) => {
    setBuildingState((prev) => ({
      ...prev,
      ...presetPatch,
      dimensions: {
        ...prev.dimensions,
        ...(presetPatch.dimensions || {}),
      },
      materials: {
        ...prev.materials,
        ...(presetPatch.materials || {}),
      },
      interior: {
        ...prev.interior,
        ...(presetPatch.interior || {}),
      },
      walls: {
        ...prev.walls,
        ...(presetPatch.walls || {}),
      },
      openings: presetPatch.openings ?? [],
      leanTo: presetPatch.leanTo || prev.leanTo,
    }));
  };

  // Reset to clean default baseline (default size, colors & structure)
  const handleReset = () => {
    setBuildingState((prev) => ({
      ...DEFAULT_BUILDING_STATE,
      unitRates: prev.unitRates || DEFAULT_BUILDING_STATE.unitRates,
    }));
  };

  // Update unit rates
  const handleUpdateUnitRates = (newRates: UnitPricingRates) => {
    setBuildingState((prev) => ({
      ...prev,
      unitRates: newRates,
    }));
  };

  const handleOpenLiveQuote = () => {
    setShowLiveQuoteModal(true);
  };

  const buildingName = `${buildingState.dimensions.width}'x${buildingState.dimensions.length}' ${
    buildingState.style.charAt(0).toUpperCase() + buildingState.style.slice(1)
  } Structure`;

  // Summary labels for Category cards
  const getCategorySummary = (id: typeof activeTab) => {
    switch (id) {
      case 'dimensions':
        return `${buildingState.dimensions.width}'W × ${buildingState.dimensions.length}'L × ${buildingState.dimensions.eaveHeight}'H • ${(buildingState.dimensions.width * buildingState.dimensions.length).toLocaleString()} SQ FT Floor Area`;
      case 'style':
        return `Architecture: ${buildingState.style.charAt(0).toUpperCase() + buildingState.style.slice(1).replace('_', ' ')} • Profile & Roofline`;
      case 'framing':
        return `Roof Pitch: ${buildingState.dimensions.roofPitch}:12 • Truss: ${buildingState.dimensions.trussSpacing}' O.C. • Post: ${buildingState.dimensions.postSpacing}' O.C. • ${buildingState.snowLoad} PSF Snow`;
      case 'style_size':
        return `${buildingState.dimensions.width}'W × ${buildingState.dimensions.length}'L × ${buildingState.dimensions.eaveHeight}'H • ${buildingState.dimensions.roofPitch}:12 Pitch • ${buildingState.dimensions.postSpacing}' Post Spacing`;
      case 'sides_openings': {
        const totalOpenings = buildingState.openings.length;
        const overheadCount = buildingState.openings.filter((o) => o.type === 'overhead_door' || o.type === 'sliding_barn_door').length;
        const walkCount = buildingState.openings.filter((o) => o.type === 'walk_door').length;
        const windowCount = buildingState.openings.filter((o) => o.type === 'window').length;
        return `${totalOpenings} Openings (${overheadCount} Doors, ${walkCount} Walk, ${windowCount} Windows)`;
      }
      case 'materials':
        return `Walls: ${buildingState.materials.sidingColorName} | Roof: ${buildingState.materials.roofColorName} | Trim: ${buildingState.materials.trimColorName}`;
      case 'interior': {
        const ins = buildingState.interior.insulation !== 'none' ? `Insulation: ${buildingState.interior.insulation.replace(/_/g, ' ')}` : 'No Insulation';
        const lean = buildingState.leanTo.enabled ? `Lean-To (${buildingState.leanTo.widthFt}' x ${buildingState.leanTo.lengthFt}')` : 'No Lean-To';
        return `${ins} • ${lean}`;
      }
      default:
        return '';
    }
  };

  return (
    <div className="min-h-screen bg-[#38BDF8] text-[#0F172A] flex flex-col font-sans selection:bg-[#0F172A] selection:text-white transition-colors duration-200">
      {/* Stationary Top Header Banner */}
      <Header
        state={buildingState}
        pricing={pricing}
        viewMode={viewMode}
        onSelectViewMode={setViewMode}
        onOpenUnitRates={() => setShowUnitRatesModal(true)}
        onOpenAppSettings={() => setShowAppSettingsModal(true)}
        onOpenBom={() => setShowBomModal(true)}
        onOpenLiveQuote={handleOpenLiveQuote}
        onOpenFloorPlan={() => setShowFloorPlanModal(true)}
        onOpenTrussDetails={() => setShowTrussModal(true)}
        isFloorPlanOpen={showFloorPlanModal}
        isTrussDetailsOpen={showTrussModal}
      />

      {/* Main Workspace Layout */}
      <main className="flex-1 max-w-6xl w-full mx-auto pt-3 sm:pt-5 p-3 sm:p-6 lg:p-8 space-y-6 sm:space-y-8">
        {/* Interactive CAD Visualizer, Master Command Island & Floor Plan */}
        <BuildingVisualizer
          state={buildingState}
          pricing={pricing}
          viewMode={viewMode}
          onSelectViewMode={setViewMode}
          onReset={handleReset}
          onOpenUnitRates={() => setShowUnitRatesModal(true)}
          onOpenBom={() => setShowBomModal(true)}
          onOpenLiveQuote={handleOpenLiveQuote}
          onUpdateDimensions={(newDims) => {
            setBuildingState((prev) => ({
              ...prev,
              dimensions: {
                ...prev.dimensions,
                ...newDims,
              },
            }));
          }}
          onOpenCategoryModal={openCategoryModal}
          activeTab={activeTab}
          onUpdateState={setBuildingState}
        />
      </main>

      {/* CATEGORY POP-UP MODAL */}
      {categoryModalOpen && (
        <div 
          className="fixed inset-0 z-50 bg-[#075985]/40 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-y-auto animate-in fade-in duration-200"
          onClick={(e) => {
            if (e.target === e.currentTarget) setCategoryModalOpen(false);
          }}
        >
          <div 
            className="bg-white border border-sky-200/80 rounded-3xl w-full max-w-5xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 transition-all text-[#075985]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <header className="bg-white/95 backdrop-blur-md px-4 sm:px-6 py-3.5 sm:py-4 border-b border-sky-100 flex flex-col md:flex-row md:items-center md:justify-between gap-3 shrink-0 text-[#075985] shadow-xs">
              <div className="flex items-center justify-between gap-3 w-full md:w-auto">
                <div className="flex items-center gap-3">
                  {(() => {
                    const ActiveIcon = TAB_ITEMS.find((t) => t.id === activeTab)?.icon || Box;
                    return (
                      <span className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-cyan-50 text-[#06B6D4] border border-cyan-200 flex items-center justify-center shadow-xs shrink-0">
                        <ActiveIcon className="w-5 h-5 text-[#06B6D4]" />
                      </span>
                    );
                  })()}
                  <div>
                    <h2 className="text-base sm:text-lg font-bold text-[#075985] flex items-center gap-2">
                      <span>{TAB_ITEMS.find((t) => t.id === activeTab)?.label}</span>
                    </h2>
                    <p className="text-xs text-[#0369A1]/80 hidden sm:block font-medium">
                      {TAB_ITEMS.find((t) => t.id === activeTab)?.description}
                    </p>
                  </div>
                </div>

                {/* Close X button for mobile */}
                <button
                  type="button"
                  onClick={() => setCategoryModalOpen(false)}
                  className="md:hidden p-2 text-[#0369A1] hover:text-[#075985] rounded-full hover:bg-sky-100 cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-90 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4]"
                  title="Close configurator"
                  aria-label="Close configurator"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Category Switcher Tabs in Modal Header */}
              <div className="flex items-center justify-center gap-1.5 sm:gap-2 overflow-x-auto py-1 max-w-full [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
                {TAB_ITEMS.map((tab) => {
                  const Icon = tab.icon;
                  const isActive = activeTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      id={`modal-tab-${tab.id}`}
                      onClick={() => setActiveTab(tab.id)}
                      className={`relative h-9 sm:h-10 px-3.5 sm:px-4 rounded-full text-xs sm:text-sm font-bold flex items-center gap-1.5 sm:gap-2 transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] cursor-pointer whitespace-nowrap active:scale-95 hover:scale-[1.02] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
                        isActive
                          ? 'bg-cyan-50 text-[#075985] shadow-sm border-2 border-[#06B6D4] font-black ring-2 ring-[#06B6D4]/30'
                          : 'bg-white hover:bg-sky-50 text-[#0369A1] hover:text-[#075985] border border-sky-200/80 font-semibold'
                      }`}
                      title={tab.label}
                    >
                      <Icon className={`w-4 h-4 shrink-0 transition-colors ${isActive ? 'text-[#06B6D4]' : 'text-[#0369A1]'}`} strokeWidth={isActive ? 2.4 : 1.8} />
                      <span>{tab.label}</span>
                      {isActive && (
                        <span className="absolute -bottom-1 inset-x-3 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Right Action Bar (Close & Total on desktop) */}
              <div className="hidden md:flex items-center gap-3 shrink-0">
                <div className="flex items-center gap-2 bg-cyan-50/80 border border-cyan-200/80 px-3.5 py-1.5 rounded-full font-mono text-xs shadow-xs text-[#075985]">
                  <span className="text-[#0369A1]/70 font-semibold">Total:</span>
                  <span className="text-[#06B6D4] font-black">${pricing.grandTotal.toLocaleString()}</span>
                </div>

                <button
                  type="button"
                  onClick={() => setCategoryModalOpen(false)}
                  className="p-2 text-[#0369A1] hover:text-[#075985] rounded-full hover:bg-sky-100 cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-90 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4]"
                  title="Close configurator"
                  aria-label="Close configurator"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </header>

            {/* Modal Body with Swipe Left/Right Support */}
            <div 
              className="flex-1 bg-sky-50/40 text-[#075985] overflow-y-auto p-4 sm:p-6 select-none"
              onTouchStart={handleModalTouchStart}
              onTouchEnd={handleModalTouchEnd}
            >
              <div className="max-w-4xl mx-auto space-y-6">
                <div 
                  key={activeTab}
                  className="bg-white border border-sky-100 p-5 sm:p-6 rounded-2xl shadow-sm space-y-6 text-[#075985] animate-in fade-in duration-200"
                >
                  <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-sky-100">
                    <div className="flex items-center gap-3">
                      {(() => {
                        const ActiveIcon = TAB_ITEMS.find((t) => t.id === activeTab)?.icon || Box;
                        return (
                          <span className="w-8 h-8 rounded-full bg-cyan-50 text-[#06B6D4] border border-cyan-200 flex items-center justify-center shrink-0">
                            <ActiveIcon className="w-4 h-4 text-[#06B6D4]" />
                          </span>
                        );
                      })()}
                      <div>
                        <h3 className="text-base font-bold text-[#075985] flex items-center gap-2">
                          <span>{TAB_ITEMS.find((t) => t.id === activeTab)?.label} Configuration</span>
                        </h3>
                        <p className="text-xs text-[#0369A1]/80 font-medium">
                          {TAB_ITEMS.find((t) => t.id === activeTab)?.description}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-[#075985] bg-cyan-50 border border-cyan-200 px-3 py-1 rounded-full shadow-2xs">
                        {getCategorySummary(activeTab)}
                      </span>
                    </div>
                  </div>

                  {activeTab === 'dimensions' && (
                    <div className="space-y-6">
                      <div className="bg-white border border-sky-100 p-5 sm:p-6 rounded-2xl shadow-sm space-y-6">
                        <div className="flex items-center justify-between border-b border-sky-100 pb-3">
                          <label className="text-sm font-bold text-[#075985] flex items-center gap-2">
                            <span className="w-6 h-6 rounded-full bg-cyan-50 text-[#06B6D4] text-xs flex items-center justify-center font-bold">
                              ★
                            </span>
                            <span>Building Dimensions & Footprint</span>
                          </label>
                          <span className="text-xs text-[#075985] flex items-center gap-1.5 font-mono font-bold bg-cyan-50 border border-cyan-200 px-3 py-1 rounded-full">
                            <Ruler className="w-3.5 h-3.5 text-[#06B6D4]" />
                            {buildingState.dimensions.width}'W × {buildingState.dimensions.length}'L × {buildingState.dimensions.eaveHeight}'H
                          </span>
                        </div>

                        {/* Quick Size Presets */}
                        <div>
                          <label className="text-xs font-semibold text-[#0369A1] block mb-2">
                            Popular Standard Footprint Presets
                          </label>
                          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
                            {[
                              { w: 24, l: 30, h: 10, label: "24' × 30'" },
                              { w: 30, l: 40, h: 12, label: "30' × 40'" },
                              { w: 30, l: 50, h: 14, label: "30' × 50'" },
                              { w: 40, l: 60, h: 14, label: "40' × 60'" },
                              { w: 40, l: 80, h: 16, label: "40' × 80'" },
                              { w: 50, l: 100, h: 16, label: "50' × 100'" },
                            ].map((preset) => {
                              const isMatch =
                                buildingState.dimensions.width === preset.w &&
                                buildingState.dimensions.length === preset.l;
                              return (
                                <button
                                  key={preset.label}
                                  onClick={() =>
                                    setBuildingState((prev) => ({
                                      ...prev,
                                      dimensions: {
                                        ...prev.dimensions,
                                        width: preset.w,
                                        length: preset.l,
                                        eaveHeight: preset.h,
                                      },
                                    }))
                                  }
                                  className={`relative p-2.5 rounded-2xl text-center cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-95 hover:scale-[1.02] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06B6D4] ${
                                    isMatch
                                      ? 'bg-cyan-50 border-2 border-[#06B6D4] text-[#075985] font-black shadow-sm ring-2 ring-[#06B6D4]/30'
                                      : 'bg-white border border-sky-200 text-[#0369A1] hover:text-[#075985] hover:bg-sky-50 font-semibold'
                                  }`}
                                >
                                  <span className="text-xs font-bold block">{preset.label}</span>
                                  <span className="text-[10px] text-[#0369A1]/70 block">{preset.h}' Eave</span>
                                  {isMatch && (
                                    <span className="absolute -bottom-[2px] inset-x-2.5 h-0.5 bg-[#06B6D4] rounded-full shadow-sm shadow-[#06B6D4]/50" />
                                  )}
                                </button>
                              );
                            })}
                          </div>
                        </div>

                        {/* Numerical Controls for Width, Length, Eave Height with Steppers & Sliders */}
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-2">
                          {/* Width */}
                          <div className="space-y-2 bg-sky-50/50 p-3.5 rounded-2xl border border-sky-100">
                            <div className="flex justify-between items-center text-xs">
                              <span className="font-bold text-[#075985]">Building Width</span>
                              <div className="flex items-center gap-1.5">
                                <button
                                  type="button"
                                  onClick={() =>
                                    setBuildingState((prev) => ({
                                      ...prev,
                                      dimensions: { ...prev.dimensions, width: Math.max(12, prev.dimensions.width - 2) },
                                    }))
                                  }
                                  className="w-7 h-7 rounded-full bg-white hover:bg-sky-50 text-[#075985] flex items-center justify-center border border-sky-200 shadow-2xs cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-90"
                                  title="Decrease width by 2 ft"
                                >
                                  <Minus className="w-3.5 h-3.5" />
                                </button>
                                <span className="font-mono font-black text-[#075985] bg-cyan-50/80 px-2.5 py-0.5 rounded-full border border-cyan-200 shadow-2xs min-w-[52px] text-center">
                                  {buildingState.dimensions.width}'
                                </span>
                                <button
                                  type="button"
                                  onClick={() =>
                                    setBuildingState((prev) => ({
                                      ...prev,
                                      dimensions: { ...prev.dimensions, width: Math.min(100, prev.dimensions.width + 2) },
                                    }))
                                  }
                                  className="w-7 h-7 rounded-full bg-white hover:bg-sky-50 text-[#075985] flex items-center justify-center border border-sky-200 shadow-2xs cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-90"
                                  title="Increase width by 2 ft"
                                >
                                  <Plus className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                            <input
                              type="range"
                              min="12"
                              max="100"
                              step="2"
                              value={buildingState.dimensions.width}
                              onChange={(e) =>
                                setBuildingState((prev) => ({
                                  ...prev,
                                  dimensions: { ...prev.dimensions, width: Number(e.target.value) },
                                }))
                              }
                              className="w-full accent-[#06B6D4] cursor-pointer h-2 bg-sky-200 rounded-full"
                            />
                            <div className="flex justify-between text-[10px] text-[#0369A1]/70 font-mono">
                              <span>Min: 12'</span>
                              <span>Gable End</span>
                              <span>Max: 100'</span>
                            </div>
                          </div>

                          {/* Length */}
                          <div className="space-y-2 bg-sky-50/50 p-3.5 rounded-2xl border border-sky-100">
                            <div className="flex justify-between items-center text-xs">
                              <span className="font-bold text-[#075985]">Building Length</span>
                              <div className="flex items-center gap-1.5">
                                <button
                                  type="button"
                                  onClick={() =>
                                    setBuildingState((prev) => ({
                                      ...prev,
                                      dimensions: { ...prev.dimensions, length: Math.max(12, prev.dimensions.length - 5) },
                                    }))
                                  }
                                  className="w-7 h-7 rounded-full bg-white hover:bg-sky-50 text-[#075985] flex items-center justify-center border border-sky-200 shadow-2xs cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-90"
                                  title="Decrease length by 5 ft"
                                >
                                  <Minus className="w-3.5 h-3.5" />
                                </button>
                                <span className="font-mono font-black text-[#075985] bg-cyan-50/80 px-2.5 py-0.5 rounded-full border border-cyan-200 shadow-2xs min-w-[52px] text-center">
                                  {buildingState.dimensions.length}'
                                </span>
                                <button
                                  type="button"
                                  onClick={() =>
                                    setBuildingState((prev) => ({
                                      ...prev,
                                      dimensions: { ...prev.dimensions, length: Math.min(240, prev.dimensions.length + 5) },
                                    }))
                                  }
                                  className="w-7 h-7 rounded-full bg-white hover:bg-sky-50 text-[#075985] flex items-center justify-center border border-sky-200 shadow-2xs cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-90"
                                  title="Increase length by 5 ft"
                                >
                                  <Plus className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                            <input
                              type="range"
                              min="12"
                              max="240"
                              step="2"
                              value={buildingState.dimensions.length}
                              onChange={(e) =>
                                setBuildingState((prev) => ({
                                  ...prev,
                                  dimensions: { ...prev.dimensions, length: Number(e.target.value) },
                                }))
                              }
                              className="w-full accent-[#06B6D4] cursor-pointer h-2 bg-sky-200 rounded-full"
                            />
                            <div className="flex justify-between text-[10px] text-[#0369A1]/70 font-mono">
                              <span>Min: 12'</span>
                              <span>Sidewall</span>
                              <span>Max: 240'</span>
                            </div>
                          </div>

                          {/* Eave Height */}
                          <div className="space-y-2 bg-sky-50/50 p-3.5 rounded-2xl border border-sky-100">
                            <div className="flex justify-between items-center text-xs">
                              <span className="font-bold text-[#075985]">Eave Height</span>
                              <div className="flex items-center gap-1.5">
                                <button
                                  type="button"
                                  onClick={() =>
                                    setBuildingState((prev) => ({
                                      ...prev,
                                      dimensions: { ...prev.dimensions, eaveHeight: Math.max(8, prev.dimensions.eaveHeight - 1) },
                                    }))
                                  }
                                  className="w-7 h-7 rounded-full bg-white hover:bg-sky-50 text-[#075985] flex items-center justify-center border border-sky-200 shadow-2xs cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-90"
                                  title="Decrease height by 1 ft"
                                >
                                  <Minus className="w-3.5 h-3.5" />
                                </button>
                                <span className="font-mono font-black text-[#075985] bg-cyan-50/80 px-2.5 py-0.5 rounded-full border border-cyan-200 shadow-2xs min-w-[52px] text-center">
                                  {buildingState.dimensions.eaveHeight}'
                                </span>
                                <button
                                  type="button"
                                  onClick={() =>
                                    setBuildingState((prev) => ({
                                      ...prev,
                                      dimensions: { ...prev.dimensions, eaveHeight: Math.min(32, prev.dimensions.eaveHeight + 1) },
                                    }))
                                  }
                                  className="w-7 h-7 rounded-full bg-white hover:bg-sky-50 text-[#075985] flex items-center justify-center border border-sky-200 shadow-2xs cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] active:scale-90"
                                  title="Increase height by 1 ft"
                                >
                                  <Plus className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                            <input
                              type="range"
                              min="8"
                              max="32"
                              step="1"
                              value={buildingState.dimensions.eaveHeight}
                              onChange={(e) =>
                                setBuildingState((prev) => ({
                                  ...prev,
                                  dimensions: { ...prev.dimensions, eaveHeight: Number(e.target.value) },
                                }))
                              }
                              className="w-full accent-[#06B6D4] cursor-pointer h-2 bg-sky-200 rounded-full"
                            />
                            <div className="flex justify-between text-[10px] text-[#0369A1]/70 font-mono">
                              <span>Min: 8'</span>
                              <span>Clearance</span>
                              <span>Max: 32'</span>
                            </div>
                          </div>
                        </div>

                        {/* Structural Footprint & Area Metrics Bar */}
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-sky-100">
                          <div className="p-3 rounded-2xl bg-cyan-50/50 border border-cyan-100">
                            <span className="text-[10px] uppercase font-bold text-[#0369A1] block">Ground Floor Area</span>
                            <span className="text-sm sm:text-base font-extrabold text-[#075985] font-mono">
                              {(buildingState.dimensions.width * buildingState.dimensions.length).toLocaleString()} <span className="text-xs font-semibold text-[#0369A1]">SQ FT</span>
                            </span>
                          </div>
                          <div className="p-3 rounded-2xl bg-cyan-50/50 border border-cyan-100">
                            <span className="text-[10px] uppercase font-bold text-[#0369A1] block">Peak Ridge Height</span>
                            <span className="text-sm sm:text-base font-extrabold text-[#075985] font-mono">
                              {(buildingState.dimensions.eaveHeight + (buildingState.dimensions.width / 2) * (buildingState.dimensions.roofPitch / 12)).toFixed(1)} <span className="text-xs font-semibold text-[#0369A1]">FT</span>
                            </span>
                          </div>
                          <div className="p-3 rounded-2xl bg-cyan-50/50 border border-cyan-100">
                            <span className="text-[10px] uppercase font-bold text-[#0369A1] block">Exterior Perimeter</span>
                            <span className="text-sm sm:text-base font-extrabold text-[#075985] font-mono">
                              {(2 * (buildingState.dimensions.width + buildingState.dimensions.length)).toLocaleString()} <span className="text-xs font-semibold text-[#0369A1]">FT</span>
                            </span>
                          </div>
                          <div className="p-3 rounded-2xl bg-cyan-50/50 border border-cyan-100">
                            <span className="text-[10px] uppercase font-bold text-[#0369A1] block">Roof Slope Ratio</span>
                            <span className="text-sm sm:text-base font-extrabold text-[#075985] font-mono">
                              {buildingState.dimensions.roofPitch}:12 <span className="text-xs font-semibold text-[#0369A1]">Pitch</span>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {activeTab === 'style' && (
                    <StyleAndSizeTab state={buildingState} onUpdateState={setBuildingState} mode="style" />
                  )}

                  {activeTab === 'framing' && (
                    <StyleAndSizeTab state={buildingState} onUpdateState={setBuildingState} mode="framing" />
                  )}

                  {activeTab === 'style_size' && (
                    <StyleAndSizeTab state={buildingState} onUpdateState={setBuildingState} mode="all" />
                  )}

                  {activeTab === 'sides_openings' && (
                    <SidesAndOpeningsTab state={buildingState} onUpdateState={setBuildingState} />
                  )}

                  {activeTab === 'materials' && (
                    <MaterialsTab
                      state={buildingState}
                      onUpdateState={setBuildingState}
                      onOpenUnitPricing={() => setShowUnitRatesModal(true)}
                    />
                  )}

                  {activeTab === 'interior' && (
                    <InteriorTab state={buildingState} onUpdateState={setBuildingState} />
                  )}

                  {/* Swipe Left/Right Navigation & Progress Dots */}
                  {(() => {
                    const currentTabIndex = TAB_ITEMS.findIndex((t) => t.id === activeTab);
                    const prevTabItem = currentTabIndex > 0 ? TAB_ITEMS[currentTabIndex - 1] : null;
                    const nextTabItem = currentTabIndex < TAB_ITEMS.length - 1 ? TAB_ITEMS[currentTabIndex + 1] : null;

                    return (
                      <div className="pt-5 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 select-none">
                        <button
                          type="button"
                          onClick={goToPrevTab}
                          disabled={!prevTabItem}
                          className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                            prevTabItem
                              ? 'bg-slate-100 hover:bg-slate-200 text-[#0F172A] border border-slate-300 shadow-2xs active:scale-95'
                              : 'opacity-0 pointer-events-none'
                          }`}
                          title={prevTabItem ? `Swipe right or click for ${prevTabItem.label}` : ''}
                        >
                          <ChevronLeft className="w-4 h-4 text-[#0284C7]" />
                          <span>{prevTabItem ? prevTabItem.label : ''}</span>
                        </button>

                        {/* Step Progress Dots & Swipe Hint */}
                        <div className="flex flex-col items-center gap-1.5">
                          <div className="flex items-center gap-1.5">
                            {TAB_ITEMS.map((tab, idx) => {
                              const isCurrent = idx === currentTabIndex;
                              return (
                                <button
                                  key={tab.id}
                                  type="button"
                                  onClick={() => {
                                    setActiveTab(tab.id);
                                    setTimeout(() => {
                                      document.getElementById(`modal-tab-${tab.id}`)?.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
                                    }, 30);
                                  }}
                                  className={`h-2.5 rounded-full transition-all cursor-pointer ${
                                    isCurrent
                                      ? 'w-7 bg-[#0284C7] shadow-xs'
                                      : 'w-2.5 bg-slate-200 hover:bg-slate-300'
                                  }`}
                                  title={tab.label}
                                  aria-label={tab.label}
                                />
                              );
                            })}
                          </div>
                          <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1 tracking-tight">
                            <span>←</span>
                            <span>Swipe left or right to change tab</span>
                            <span>→</span>
                          </span>
                        </div>

                        <button
                          type="button"
                          onClick={goToNextTab}
                          disabled={!nextTabItem}
                          className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                            nextTabItem
                              ? 'bg-[#0284C7] hover:bg-[#0369a1] text-white shadow-xs active:scale-95'
                              : 'opacity-0 pointer-events-none'
                          }`}
                          title={nextTabItem ? `Swipe left or click for ${nextTabItem.label}` : ''}
                        >
                          <span>{nextTabItem ? nextTabItem.label : ''}</span>
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      </div>
                    );
                  })()}
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <footer className="bg-slate-50 border-t border-slate-200 px-4 sm:px-6 py-3 flex items-center justify-between shrink-0 text-[#0F172A] transition-colors">
              <div className="flex items-center gap-2 bg-white border border-slate-200 px-3.5 py-1.5 rounded-full font-mono text-xs sm:text-sm shadow-2xs text-slate-700">
                <span className="text-slate-500 font-medium">Building Total:</span>
                <span className="text-[#0284C7] font-extrabold">${pricing.grandTotal.toLocaleString()}</span>
              </div>

              <button
                id="modal-btn-done-footer"
                type="button"
                onClick={() => setCategoryModalOpen(false)}
                className="px-6 py-2 bg-[#0284C7] hover:bg-[#0369a1] text-white rounded-full font-bold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer shadow-md shadow-sky-600/20 active:scale-95"
              >
                <span>Done</span>
                <Check className="w-4 h-4 stroke-[2.5]" />
              </button>
            </footer>
          </div>
        </div>
      )}

      {/* Modals */}
      {showUnitRatesModal && (
        <UnitPricingEditorModal
          rates={buildingState.unitRates}
          onUpdateRates={handleUpdateUnitRates}
          onClose={() => setShowUnitRatesModal(false)}
        />
      )}

      {showAppSettingsModal && (
        <AppSettingsModal
          settings={appSettings}
          rates={buildingState.unitRates}
          onUpdateSettings={setAppSettings}
          onUpdateRates={handleUpdateUnitRates}
          onOpenPricingManager={() => {
            setShowAppSettingsModal(false);
            setShowUnitRatesModal(true);
          }}
          onClose={() => setShowAppSettingsModal(false)}
        />
      )}

      {showBomModal && (
        <BillOfMaterialsModal
          pricing={pricing}
          buildingName={buildingName}
          onOpenUnitPricing={() => setShowUnitRatesModal(true)}
          onClose={() => setShowBomModal(false)}
        />
      )}

      {showFloorPlanModal && (
        <FloorPlanModal
          state={buildingState}
          pricing={pricing}
          onClose={() => setShowFloorPlanModal(false)}
        />
      )}

      {showTrussModal && (
        <TrussDetailsModal
          state={buildingState}
          pricing={pricing}
          onUpdateState={setBuildingState}
          onOpenUnitPricing={() => {
            setShowTrussModal(false);
            setShowUnitRatesModal(true);
          }}
          onClose={() => setShowTrussModal(false)}
        />
      )}

      {showQuoteModal && (
        <QuoteExportModal
          state={buildingState}
          pricing={pricing}
          onClose={() => setShowQuoteModal(false)}
        />
      )}

      {/* Live Dynamic Quote Modal (Mobile / Responsive View) */}
      {showLiveQuoteModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="bg-white border border-slate-200/90 rounded-xl w-full max-w-xl max-h-[92vh] flex flex-col shadow-[0_4px_6px_-1px_rgba(0,0,0,0.1),0_2px_4px_-2px_rgba(0,0,0,0.06)] overflow-hidden animate-in fade-in zoom-in-95">
            <div className="bg-[#0F172A] px-5 py-3.5 border-b border-slate-800 flex items-center justify-between text-white">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-sky-500/20 text-[#38BDF8]">
                  <DollarSign className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                  Live Dynamic Quote
                </h3>
              </div>
              <button
                onClick={() => setShowLiveQuoteModal(false)}
                className="p-1.5 text-slate-300 hover:text-white rounded-full hover:bg-slate-800 cursor-pointer transition-colors"
                title="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4 sm:p-6 overflow-y-auto bg-slate-50">
              <PricingSummary
                pricing={pricing}
                onOpenUnitPricing={() => {
                  setShowLiveQuoteModal(false);
                  setShowUnitRatesModal(true);
                }}
                onOpenBom={() => {
                  setShowLiveQuoteModal(false);
                  setShowBomModal(true);
                }}
                onOpenQuote={() => {
                  setShowLiveQuoteModal(false);
                  setShowQuoteModal(true);
                }}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

