# Offline operation

This project has been prepared for offline use as a Progressive Web App (PWA).

## What works offline

- The app's JavaScript, CSS, and same-origin assets are cached by `public/sw.js` after the first successful online load.
- The Google Fonts network dependency was removed; the app uses system fonts.
- Pricing and settings continue to use browser `localStorage` on the same browser/profile/device.
- The core design, pricing, and bill-of-materials logic is client-side and has no runtime API fetch calls in `src/`.

## Important limitations

1. **The first load must be online** so the browser can download and cache the app shell. After that, reopen it once while online to allow service-worker installation/caching to finish before going offline.
2. Service workers require HTTPS (or localhost). Opening `index.html` directly as a `file://` URL will not enable offline caching.
3. This change does **not** turn the project into an Android APK. For a fully packaged Android app that works from first launch without ever connecting, it must be wrapped/built as an APK with its assets bundled locally and tested on-device.
4. Browser storage is local to that browser profile. Clearing site data or using a different browser/device can remove or not include saved prices and projects.
5. WebGL/3D support depends on the device/browser GPU and still needs offline on-device testing.

## Verification checklist

- Deploy the production build over HTTPS.
- Open it online and wait for the app to load completely; reload once to allow the service worker to activate.
- Confirm the browser reports the service worker as activated.
- Turn on airplane mode, close/reopen the installed web app, and test design edits, price edits, saved settings, BOM, and quote export.
- Repeat the test on the target Pixel device.

Do not treat estimates as supplier-verified pricing merely because they work offline. Unit rates must be maintained from approved current price data.
