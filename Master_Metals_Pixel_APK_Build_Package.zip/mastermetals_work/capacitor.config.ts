import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.mastermetals.offline',
  appName: 'Master Metals',
  webDir: 'dist',
  bundledWebRuntime: false,
  backgroundColor: '#38bdf8',
  android: {
    allowMixedContent: false,
  },
};

export default config;
