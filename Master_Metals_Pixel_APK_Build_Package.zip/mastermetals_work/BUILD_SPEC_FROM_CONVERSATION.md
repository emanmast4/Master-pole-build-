# Master Metals App Update — Conversation Specification

This document records the requested construction/BOM behavior and the implementation status in this archive. It is not a construction or engineering certification.

## Implemented in this revision
- Main roof pitch selector supports every whole-number pitch from 1:12 through 12:12.
- Truss count uses ceiling-based spacing (`ceil(length / spacing) + 1`); the default truss spacing remains 4 ft and post spacing remains configurable with 8 ft as the standard option.
- Eave and gable overhangs have independent controls, defaulting to 12 inches. Legacy projects continue to use their shared overhang field as a fallback.
- Main roof sheets use calculated sloped cut lengths; ridge-run counts use the gable overhang. Gable panels are grouped by individually calculated stepped-rake lengths rather than a blanket waste factor.
- Enclosed eave walls are calculated separately. Fully panel-width columns directly above floor-level doors can use shorter panel lengths; columns partially intersecting openings remain full-length rather than assuming an unverified horizontal splice. Window sill height can be configured.
- AG-panel wall cut groups account for open/enclosed main walls, open gable triangles remain metal-covered, and lean-to wall panel cut groups are generated only for selected enclosed exterior faces.
- Recommended 5% extra sidewall panels are listed separately by cut length and excluded from the quote total. No blanket extra percentage is applied to roof or gable panels.
- Soffit and fascia cover are omitted from edges with no corresponding overhang. Eave and gable soffit panels are separate BOM lines; 18-inch overhang soffit pricing is interpolated between the configured 1-ft and 2-ft rates and flagged as an estimate.
- Lean-to configuration supports open/enclosed flags for host, outer-eave, front-end, and back-end faces plus an outside-eave-overhang toggle. Lean-to roof sheets account for the outside-eave overhang selection and gable-end run extensions.
- Lean-to connection flashing is conditional: equal-height/equal-pitch eave-side attachments do not automatically receive transition trim; pitch changes trigger transition flashing, height changes trigger end-wall trim, and gable-end attachments receive end-wall trim.
- Open gable ends retain metal coverage for the truss triangle and receive a separate drip-cap line across the opening top.
- Walk-door and window trim uses J-channel on both sides and the bottom, plus drip cap across the top. Overhead and sliding doors use separate “overhead door trim sides” and “overhead door trim top” line items.
- BOM naming uses Barn Drip, Fascia Cover, Residential Rake, Regular Ridge Cap 13-inch, Snow Guard, J-channel, and F-J channel. Residential Rake remains included on gable edges even when the gable overhang is zero.
- Main perimeter post counts use separate wall runs rather than a single perimeter-spacing shortcut. Roof purlins and wall girts are estimated from spacing, and girts are only counted on enclosed main walls.
- Opening jamb/header framing allowance is now included in the estimate and BOM, but is clearly marked preliminary rather than an engineered framing schedule. Lean-to posts and a separate framing allowance are itemized.
- The BOM pricing was reconciled so framing includes the splash plank and hurricane ties, trim includes both inside/outside closures and open-gable drip cap, and lean-to component lines are not duplicated by its informational summary row. Roof purlins and wall girts are split into separate BOM lines with estimated row/run quantities.
- Added a configurable window sill height, opening/lean-to geometry warnings, and a BOM cut-schedule CSV export that includes recommended extras and separate panel cut lengths. CSV text fields are escaped correctly and exported with a UTF-8 BOM for spreadsheet compatibility.

## Existing functionality retained
- The existing app remains the baseline rather than being rebuilt.
- Existing building dimensions, wall enclosure settings, door/window configuration, lean-to location/pitch/size, price editing, visualization, and quote export remain in the project.
- The bill of materials modal continues to warn that the takeoff is preliminary and must be checked against approved plans and supplier specifications.

## Remaining limitations
- Window openings are not cut into individually optimized panel pieces; window columns remain full-length because a horizontal splice/cut-reuse strategy was not specified. Door-column shortening is only applied when a full 3-ft panel column lies within a floor-level door opening.
- Lean-to panel lengths use a simplified shed-end wall model. Roof-to-wall flashing, wall trim, post stations, bracing, ledgers, and connection details still need verification for the actual attachment geometry.
- Framing remains an estimate: the app does not engineer header sizes, jack/king studs, cripple studs, post sizes, girder/header plies, foundations, uplift connections, or load paths. The current purlin/girt counts are spacing-based estimates, not a stamped lumber schedule.
- Trim pieces use the configured 10-ft-6-in or 12-ft stock preference and a modeled 6-in lap; supplier stock lengths, actual lap allowances, cut-to-length rules, and profile-specific dimensions are not confirmed from a supplier trim sheet in the provided project files.
- The roof/wall rates and some legacy assumptions are estimates. Supplier part numbers, effective AG-panel coverage, overlap/underlap details, closure placement, and pitch-specific Barn Drip bends still need confirmation.
- The app contains other building styles (monitor, gambrel, mono-slope, commercial), but the takeoff geometry remains primarily a conventional gable roof model. Those styles should not be treated as geometrically verified by this revision.
- A full app build and full type-check are still blocked because this working environment does not have the project's npm dependencies installed; syntax transpilation and direct pricing-engine runtime checks are being used as partial validation.

## Supplier and engineering verification required
Confirm supplier part numbers, nominal versus effective panel coverage, overlap/underlap, panel rib geometry, trim profile dimensions, stock lengths and lap rules, pitch-specific Barn Drip bends, and current prices. Verify open-gable details with the user and supplier. Have structural framing, connections, foundations, wind/snow loads, and opening headers checked by a qualified professional. Do not represent this BOM as supplier-ready until these checks and a full build/test pass are complete.
