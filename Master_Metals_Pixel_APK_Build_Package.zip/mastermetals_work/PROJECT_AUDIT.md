# Master Metals Designer — source audit notes

## Changes applied

- Fixed truss count rounding in `src/utils/pricingEngine.ts`: truss count now uses `ceil(length / spacing) + 1`, so lengths that are not exact multiples of the selected spacing do not undercount intermediate/end bays.
- Clamped the snow-load surcharge steps to zero at or below the model's 20 PSF baseline. Invalid/legacy lower values can no longer produce a negative load discount.
- Hardened restoration of `master_metals_app_settings` from browser storage. Stored JSON is treated as untrusted; malformed shapes, invalid enum values, and non-boolean toggles fall back to defaults.

## Pricing and bill-of-materials accuracy limitations

The rates in `src/utils/constants.ts` are hard-coded estimates, and the pricing engine includes additional hard-coded allowances (for example opening window inserts, loft stair/rail allowance, trim pieces, and labor multipliers). No dated supplier price list, Master Metals quote, tax/shipping rules, local labor schedule, engineered truss quote, or waste policy was included with the project. Therefore these rates cannot be certified as current or as Master Metals' actual prices from this source archive alone.

The BOM is a conceptual takeoff, not a construction-ready engineered material schedule. Truss member sizing, post/foundation design, wind/snow loads, connections, opening framing, local code requirements, and exact supplier stock/cut optimization require review by a qualified building designer/engineer and supplier. Treat displayed totals as preliminary estimates until rates and quantities are checked against current quotes and approved plans.

## Additional review findings

- The archive contains no dedicated project JSON import feature; therefore there was no import path to schema-validate in this version. If project import is added, validate every nested field and numeric range before setting application state, and continue rendering imported strings as React text (not HTML).
- User-editable unit prices are intentionally configurable. Validate/approve those values against dated supplier data before using a quote commercially.
- `innerHTML` is used only to clear a Three.js container in `Interactive3DBuilding.tsx` in the inspected matches; no imported user string was found being injected through it.

## Verification status

Build/type-check status should be confirmed with `npm install` followed by `npm run lint` and `npm run build` in an environment with Node.js and package registry access. This source-only review is not a structural engineering certification or a guarantee of final material quantities.

## Editable and persistent prices
- The header's sliders button opens the Component & Trim Pricing Manager; Settings also contains a Component Prices & Unit Rates tab.
- Component rates now load from `localStorage` key `master_metals_unit_rates` and save automatically after edits, so changed prices survive a page refresh/reopen on the same browser/device.
- Stored rates are validated individually: only finite numeric values from $0 through $1,000,000 are accepted; invalid or missing entries use defaults.
- These prices are local to the current browser/device and are not synced to other devices. Reset Prices restores the built-in defaults.
- Build/typecheck could not be verified in this environment because project dependencies are not installed (`vite/client` types missing); run `npm install` then `npm run lint` and `npm run build` in a connected build environment.
