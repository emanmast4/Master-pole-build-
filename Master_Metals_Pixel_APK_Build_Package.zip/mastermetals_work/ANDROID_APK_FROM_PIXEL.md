# Build the Master Metals APK using only your Pixel phone

This project now includes a GitHub Actions workflow that can compile an Android debug APK in GitHub's hosted build environment. No Android Studio or computer is needed on your side. This is build scaffolding; the APK still must be built successfully and tested on the Pixel before it should be treated as ready for daily quoting.

## One-time setup

1. Create a **private** repository on GitHub for this project.
2. Upload the project files to the repository from your phone. Upload the contents of this project folder, including the hidden `.github/workflows/android-apk.yml` file and `capacitor.config.ts`. Do not upload `.env` secrets or `node_modules`.
3. In the repository, open **Actions**. If GitHub asks, enable workflows.
4. Choose **Build Master Metals Android APK** and tap **Run workflow**. Wait for the job to finish.
5. Open the completed workflow run. Under **Artifacts**, download `master-metals-debug-apk`. Extract the ZIP on your Pixel to get `app-debug.apk`.
6. Tap the APK to install it. Android may ask you to allow your browser or file manager to install unknown apps; only allow this for the APK you just built from your own private repository.

## Important

- The workflow builds a **debug APK** for personal testing, not a Play Store release.
- Each build's artifact is retained for 14 days. Download it to your phone or copy it to your Drive for safekeeping.
- The app's existing settings and pricing use local browser-style storage. An APK does not automatically make that data backed up. Keep manual export/restore backups before uninstalling, clearing app data, or switching devices.
- After installation, test opening a saved design, changing a value, closing/reopening the app, exporting a quote, and reopening it in airplane mode. Also test the 3D view. Do not use the material quantities as supplier-verified until the project calculations have been validated against the actual supplier specifications.
- Do not add private API keys or credentials to this repository. The app's core offline design should not require a hosted website.

## What the workflow does

It installs the JavaScript dependencies, builds the Vite app, generates the native Android project using Capacitor, copies the built app into the APK, compiles with Gradle, and publishes the APK as a downloadable workflow artifact.
